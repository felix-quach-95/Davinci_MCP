"""v3.5.0: more B-roll with a burned-text check, more transition SFX with a peak ceiling, ramp step names."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def text(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def load(name):
    g = {"__name__": "test"}
    exec(compile(text("scripts/" + name), name, "exec"), g)
    return g


def seg(i, track=1, record="auto", **kw):
    s = {"id": "s%02d" % i, "clip": "A", "src_in": i * 100, "src_out": i * 100 + 45, "track": track, "record": record,
         "why": "x", "grp": "g%d" % i}
    s.update(kw)
    return s


class Broll(unittest.TestCase):
    def test_eight_cutaways_for_27_s_and_text_check(self):
        E = load("edit_analysis.py")
        v1 = [seg(i) for i in range(1, 19)]                      # 27 s
        b = [seg(50 + k, track=2, record=30 + k * 95, broll_type="detail", text_checked=True) for k in range(7)]
        for x in b:
            x["src_out"] = x["src_in"] + 40
        r = E["broll_report"]({"expected_fps": 30, "segments": v1 + b}, None, 30)
        self.assertEqual(r["flags"], [])
        b[0].pop("text_checked")
        r = E["broll_report"]({"expected_fps": 30, "segments": v1 + b}, None, 30)
        self.assertTrue(any("text_checked" in f for f in r["flags"]))
        self.assertEqual(E["BROLL_EVERY_S"], 4.0)


class Sfx(unittest.TestCase):
    def test_target_and_ceiling(self):
        S = load("sfx_library.py")
        self.assertEqual(S["transition_target"](828, 29.97), 6)
        self.assertEqual(S["transition_target"](900, 30), 7)
        e = {"peak_db": -1.6, "peak_t": 0.3, "shape": "swell"}
        plan = S["plan_cue"](e, {"event": 100, "role": "whoosh"}, 30, 30, 60, S["LEVELS"], {}, (-30.0, 10.0), ["whoosh"], (8.0, "loud bed"))
        self.assertLessEqual(plan["volume"], 1.6)
        self.assertIn("capped", plan["level_note"])
        self.assertEqual(S["LEVELS"]["whoosh"], -4)

    def test_docs(self):
        self.assertIn("7–10 SFX in 30 s", text("references/sfx-library.md"))


class Names(unittest.TestCase):
    def test_ramp_steps_share_a_number(self):
        B = load("build_from_blueprint.py")
        bp = B["expand_ramps"]({"segments": [
            {"id": "v01", "src_in": 0, "src_out": 30, "track": 1, "ramp": [{"frames": 20, "speed": 100}, {"frames": 10, "speed": 200}]},
            {"id": "v02", "src_in": 40, "src_out": 70, "track": 1},
            {"id": "b01", "src_in": 90, "src_out": 100, "track": 2, "record": 5}]})
        keys = B["segment_keys"](bp, 1)
        self.assertEqual(B["grouped_names"](keys, "shot"), ["shot_01a", "shot_01b", "shot_02"])
        self.assertEqual(B["grouped_names"](B["segment_keys"](bp, 2), "broll"), ["broll_01"])


if __name__ == "__main__":
    unittest.main()
