"""Offline tests for v2.6.0: free-first research (vidIQ free credits, then free sources), trending sounds/hashtags.
Run all tests: python3 -m unittest discover -s tests -v"""
import json, os, unittest
from _skilltext import skill_text

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "loaded"}
    with open(os.path.join(SCRIPTS, name), encoding="utf-8") as f:
        exec(compile(f.read(), name, "exec"), g)
    return g


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


class FreeSourcesCard(unittest.TestCase):
    def card(self):
        C = load("research_card.py")
        return C["build_card"]({
            "topic": "Hồng Kông về đêm", "platform": "tiktok", "credits_spent": 0, "credits_left": 0,
            "keywords": [{"term": "hong kong night", "volume": 80, "competition": 40}],
            "trending_hashtags": [{"tag": "#fyp", "rank": 1}, {"tag": "#hongkongnight", "rank": 7},
                                  {"tag": "#dulichhongkong", "rank": 3}, {"tag": "#skincare", "rank": 2}],
            "trending_music": [{"title": "B", "artist": "y", "rank": 5, "rank_change": -2},
                               {"title": "A", "artist": "x", "rank": 2, "rank_change": 14, "commercial": True}],
            "videos": [{"title": "POV: 2h sáng ở Mong Kok", "views": 400000, "channel_median": 50000, "duration_s": 21,
                        "platform": "tiktok", "source": "tiktok_search"},
                       {"title": "POV: đêm đầu tiên ở Hồng Kông", "views": 300000, "channel_median": 60000,
                        "duration_s": 25, "platform": "tiktok", "source": "tiktok_search"}]})

    def test_hashtags_prefer_on_topic_trending_tags(self):
        tags = self.card()["hashtags"]
        self.assertEqual(tags[:2], ["#dulichhongkong", "#hongkongnight"])   # on-topic trending, rank order
        self.assertNotIn("#fyp", tags)
        self.assertNotIn("#skincare", tags)
        self.assertIn("#hongkongnight", tags)

    def test_trending_music_with_licence_note(self):
        card = self.card()
        self.assertEqual([m["title"] for m in card["trending_music"]], ["A", "B"])
        self.assertTrue(card["trending_music"][0]["rising"])
        self.assertIn("not a licence", card["music_note"])

    def test_sources_and_credits_reported(self):
        card = self.card()
        self.assertEqual(card["sources"], ["creative_center", "tiktok_search"])
        self.assertEqual(card["credits_left"], 0)
        self.assertEqual(card["recommended_hook"], "pov")
        self.assertFalse(any("YouTube data" in w for w in card["warnings"]))

    def test_no_music_no_note(self):
        C = load("research_card.py")
        self.assertIsNone(C["build_card"]({"topic": "x", "videos": []})["music_note"])


class FreeFirstPolicy(unittest.TestCase):
    def test_skill_rules(self):
        s = skill_text()
        for txt in ("free credits", "switch to the free sources on your own", "never ask to buy credits",
                    "Creative Center", "Google Trends", "TikTok Studio retention only with the user's OK"):
            self.assertIn(txt, s)

    def test_reference_sources_and_safety(self):
        doc = read("references/trend-research.md")
        for txt in ("Free-first rule", "creativeCenter",   # v3.0.1: TikTok One URL (old business/creativecenter redirects)
 "tiktok.com/search", "trends.google.com", "gprop=youtube",
                    "Region **Vietnam**", "read only", "not a licence", "never suggest buying or upgrading",
                    "Partial budget"):
            self.assertIn(txt, doc)

    def test_config(self):
        d = json.loads(read("config/defaults.json"))
        r = d["research"]
        self.assertEqual(r["max_credits"], 30)
        self.assertEqual(r["creative_center_region"], "VN")
        self.assertIn("google_trends", r["free_sources"])
        self.assertIn("— v%s" % d["version"], skill_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
