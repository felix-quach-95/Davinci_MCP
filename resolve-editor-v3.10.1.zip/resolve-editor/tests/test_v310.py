"""v3.1.0 token plan: phase_run (T2), STATUS.md + subagent card (T3), overview sheet / sheet caps / api-quick (T1)."""
import json
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class PhaseRun(unittest.TestCase):
    def setUp(self):
        self.P = load("phase_run.py")

    def test_budget_stops_and_resume_continues(self):
        t = [0.0]
        clock = lambda: t[0]
        calls = []

        def step(name, cost):
            def fn(s):
                calls.append(name)
                t[0] += cost
                return {"ok": name}
            return fn
        steps = [("inventory", step("inventory", 4)), ("overview", step("overview", 15)), ("audio", step("audio", 20))]
        state = {}
        done, rem = self.P["run_steps"](steps, state, clock, 20)
        self.assertEqual(calls, ["inventory", "overview"])
        self.assertEqual(rem, ["audio"])
        t[0] = 0.0
        done, rem = self.P["run_steps"](steps, state, clock, 40)
        self.assertEqual(calls, ["inventory", "overview", "audio"])
        self.assertEqual(rem, [])

    def test_failing_step_is_reported_not_retried(self):
        def bad(s):
            raise RuntimeError("boom")
        state = {}
        done, rem = self.P["run_steps"]([("qa", bad), ("qc_sheet", lambda s: {})], state, lambda: 0.0, 40)
        self.assertIn("boom", done["qa"]["error"])
        self.assertEqual(rem, ["qc_sheet"])

    def test_summaries_are_short(self):
        P = self.P
        pres = P["sum_presence"]({"status": "CHECKED", "mix_peak_dbfs": -1.0, "integrated_lufs": -17.4, "clipping": False,
                                  "items": [{"item": "a.wav", "verdict": "present"}, {"item": "b.mp4", "verdict": "weak / masked"}]})
        self.assertEqual(pres["not_clearly_present"], [["b.mp4", "weak / masked"]])
        qa = P["sum_qa"]({"verdict": "FAIL: x", "checks": {"x": {"ok": False, "items": ["v.mov"]}, "y": {"ok": True}}})
        self.assertEqual(list(qa["failed"]), ["x"])
        inv = P["sum_inventory"]({"clips": [{"kind": "video"}, {"kind": "video"}, {"kind": "audio"}], "warnings": ["W" * 400],
                                  "project_settings": {"timelineFrameRate": 30}})
        self.assertEqual(inv["kinds"], {"video": 2, "audio": 1})
        self.assertLessEqual(len(inv["warnings"][0]), 160)

    def test_state_restarts_when_inputs_change_or_run_completed(self):
        P = self.P
        sig = P["input_sig"]("p6", {"beats_s": [0.1], "build": True}, {"blueprint": {"segments": [1]}})
        self.assertEqual(sig, P["input_sig"]("p6", {"beats_s": [0.1]}, {"blueprint": {"segments": [1]}}))  # build flag ignored
        self.assertNotEqual(sig, P["input_sig"]("p6", {"beats_s": [0.1]}, {"blueprint": {"segments": [2]}}))
        prev = {"sig": sig, "done": {"edit_analysis": {}}}
        self.assertIs(P["fresh_state"](prev, sig, 0), prev)                       # resume a PARTIAL run
        self.assertEqual(P["fresh_state"](prev, sig + "x", 0)["done"], {})        # inputs changed
        self.assertEqual(P["fresh_state"](dict(prev, complete=True), sig, 0)["done"], {})   # re-run after DONE
        self.assertEqual(P["fresh_state"](prev, sig, 0, reset=True)["done"], {})

    def test_status_md_has_resume_instructions(self):
        md = self.P["status_md"]("TNC", "p9", {"qa": {"verdict": "STRUCTURAL PASS"}}, [], {"gate1": {"story": "B"}, "secret": 1})
        self.assertIn("# STATUS — TNC", md)
        self.assertIn("Read this file and project.json to continue", md)
        self.assertIn("gate1", md)
        self.assertNotIn("secret", md)
        self.assertIn("Draft review", md)
        self.assertIn("resume p9", self.P["status_md"]("TNC", "p9", {}, ["audio"], {}))


class TokenRules(unittest.TestCase):
    def test_core_rules_and_cards(self):
        core = text("SKILL.md")
        self.assertLess(len(core.split()), 2000)
        for needle in ("One chat", "STATUS.md", "phase_run.py", "footage-subagent.md",
                       "≤ 12 lines", "api-quick.md", "sips -Z 1024"):
            self.assertIn(needle, core)
        self.assertIn('"sonnet" for the deepen pass', text("references/phases/footage-subagent.md"))  # v3.8.0: scan on haiku
        self.assertIn("AppendToTimeline", text("references/api-quick.md"))

    def test_fast_paths_and_runbook(self):
        for n in (1, 3, 6, 7, 8, 9, 10):
            self.assertIn("## Steps", text("references/phases/phase-%02d.md" % n))
        self.assertIn("STATUS.md", text("references/phases/phase-01.md"))
        rb = text("references/phases/express-runbook.md")
        for k in ("Story approval", "Draft review", "Final approval", "phase_run.py` MODE p1", "stage.py"):
            self.assertIn(k, rb)
        self.assertIn("express-runbook.md", text("SKILL.md"))
        pr = text("scripts/phase_run.py")
        self.assertIn('tool("frame_probe.py", {"JOB": TITLE})', pr)
        self.assertIn('"sheet": c.get("contact_sheet")', pr)

    def test_sheet_caps(self):
        fp, qc = text("scripts/frame_probe.py"), text("scripts/qc_stills.py")
        self.assertIn("OVERVIEW = True", fp)
        self.assertIn("overview_sheet", fp)
        self.assertIn("SHEET_MAX = 1024", qc)
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertIn("phase_run.py", d["scripts"])


if __name__ == "__main__":
    unittest.main()
