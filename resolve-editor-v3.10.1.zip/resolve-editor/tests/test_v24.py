"""Offline tests for the v2.4.0 lead-editor layer (edit_analysis.py, composition_check.py, docs).
Run all tests: python3 -m unittest discover -s tests -v"""
import os, unittest
from _skilltext import skill_text

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "loaded"}
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    exec(compile(src, name, "exec"), g)
    return g


def read(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


def seg(i, clip, a, b, section, **kw):
    s = {"id": "s%d" % i, "clip": clip, "src_in": a, "src_out": b, "section": section}
    if i > 1:
        s["cut"] = {"reason": ["story"], "on": "breath", "why": "test"}
    s.update(kw)
    return s


class EditAnalysis(unittest.TestCase):
    def test_rationale_coverage_and_vocabulary(self):
        E = load("edit_analysis.py")
        segs = [seg(1, "a", 0, 24, "hook"), seg(2, "b", 0, 24, "hook", cut=None),
                seg(3, "c", 0, 24, "hook", cut={"reason": ["vibes"], "on": "beat", "why": "x"})]
        r = E["rationale_report"](segs)
        self.assertEqual(r["missing_reason"], ["s2"])
        self.assertEqual(r["unknown_vocabulary"], ["s3"])

    def test_pace_must_follow_the_arc_and_release_after_peak(self):
        E = load("edit_analysis.py")
        bp = {"expected_fps": 24, "arc": {"setup": 2, "peak": 5, "release": 1},
              "segments": [seg(1, "a", 0, 48, "setup"), seg(2, "a", 48, 96, "setup"),
                           seg(3, "b", 0, 72, "peak"), seg(4, "c", 0, 24, "release")]}
        r = E["analyse"](bp, None, 24)
        self.assertTrue(any("peak (tension 5) cuts no faster than setup" in n for n in r["notes"]))
        self.assertTrue(any("no release after the peak" in n for n in r["notes"]))
        bp["segments"][2]["src_out"] = 24
        bp["segments"][3]["src_out"] = 96
        r = E["analyse"](bp, None, 24)
        self.assertFalse(any("cuts no faster" in n for n in r["notes"]))
        self.assertFalse(any("no release" in n for n in r["notes"]))

    def test_mechanical_lengths_and_metric_acceleration(self):
        E = load("edit_analysis.py")
        pos = [({"id": "x%d" % i, "section": "build"}, i * 24, i * 24 + 24) for i in range(5)]
        self.assertTrue(any("mechanical" in f for f in E["pacing_report"](pos, {}, 24)["flags"]))
        pos = [({"id": "m%d" % i, "section": "metric_build"}, 0, n) for i, n in enumerate([48, 24, 36])]
        self.assertTrue(any("does not accelerate" in f for f in E["pacing_report"](pos, {}, 24)["flags"]))

    def test_beats_and_drop(self):
        E = load("edit_analysis.py")
        segs = [seg(1, "a", 0, 48, "hook"), seg(2, "b", 0, 50, "build", cut={"reason": ["rhythm"], "on": "beat", "why": "x"}),
                seg(3, "c", 0, 48, "peak", cut={"reason": ["reveal"], "on": "beat", "why": "drop"})]
        pos = E["positions"]({"segments": segs}, None, 24)
        r = E["beat_report"](pos, [2.0, 4.0], 24, drop_frame=98)
        self.assertEqual(r["cuts_on_grid"], 1)
        self.assertEqual(r["claimed_beat_but_off"][0]["id"], "s3")
        self.assertTrue(r["drop"]["ok"])

    def test_continuity_flags(self):
        E = load("edit_analysis.py")
        a = seg(1, "a", 0, 24, "x", size="MS", direction="R", subject_out=[0.2, 0.3])
        b = seg(2, "a", 40, 64, "x", size="MS", direction="L", subject_in=[0.85, 0.7])
        flags = E["continuity_report"]([a, b])
        self.assertTrue(any("jump cut" in f for f in flags))
        self.assertTrue(any("screen direction flips" in f for f in flags))
        self.assertTrue(any("eye-trace jumps" in f for f in flags))
        b2 = dict(b, cut={"reason": ["rhythm"], "on": "contrast", "type": "jump", "why": "x"})
        self.assertEqual(E["continuity_report"]([a, b2]), [])
        c = seg(3, "b", 0, 24, "x", size="ECU")
        d = dict(seg(2, "c", 0, 24, "x", size="EWS"))
        self.assertTrue(any("big jump in scale" in f for f in E["continuity_report"]([d, c])))
        c["cut"] = {"reason": ["reveal"], "on": "beat", "why": "x"}
        self.assertFalse(any("big jump" in f for f in E["continuity_report"]([d, c])))

    def test_parallel_threads_must_tighten(self):
        E = load("edit_analysis.py")
        segs = [dict(seg(i, "a", 0, n, "x"), thread=t) for i, (t, n) in
                enumerate([("A", 72), ("B", 72), ("A", 48), ("B", 48), ("A", 24), ("B", 24)], 1)]
        pos = E["positions"]({"segments": segs}, None, 24)
        self.assertEqual(E["parallel_report"](segs, pos)["flags"], [])
        segs[4]["src_out"] = 96
        pos = E["positions"]({"segments": segs}, None, 24)
        self.assertTrue(E["parallel_report"](segs, pos)["flags"])

    def test_split_edits_move_the_audio_cut_point(self):
        E = load("edit_analysis.py")
        bp = {"expected_fps": 24, "segments": [
            seg(1, "a", 0, 48, "x", media="both", audio_tail=8),
            seg(2, "b", 100, 148, "x", media="both", audio_lead=0),
            seg(3, "c", 200, 248, "x", media="both", audio_lead=6)]}
        new, notes = E["expand_split_edits"](bp, {"a": 24, "b": 24, "c": 24}, 24)
        self.assertTrue(all(s["media"] == "video" for s in new["segments"]))
        self.assertEqual([s["record"] for s in new["segments"]], [0, 48, 96])
        au = {a["id"]: a for a in new["audio"]}
        self.assertEqual((au["s1_a"]["record"], au["s1_a"]["src_out"]), (0, 56))      # L: 8 frames longer
        self.assertEqual((au["s2_a"]["record"], au["s2_a"]["src_in"]), (56, 108))      # starts after the tail
        self.assertEqual((au["s2_a"]["src_out"], au["s3_a"]["record"]), (142, 90))     # J: s3 sound 6 frames early
        self.assertEqual(au["s3_a"]["src_in"], 194)
        ends = sorted((a["record"], a["record"] + a["src_out"] - a["src_in"]) for a in new["audio"])
        self.assertTrue(all(e1 <= s2 for (s1, e1), (s2, e2) in zip(ends, ends[1:])))   # no overlap
        B = load("build_from_blueprint.py")
        self.assertEqual(B["validate_blueprint"](new, {"a": 400, "b": 400, "c": 400}), [])
        bp["segments"][0]["speed"] = 50
        new, notes = E["expand_split_edits"](bp, {"a": 24, "b": 24, "c": 24}, 24)
        self.assertTrue(any("not split" in n for n in notes))
        self.assertEqual(E["expand_split_edits"]({"segments": [seg(1, "a", 0, 10, "x")]}, None, 24)[1],
                         ["no audio_lead/audio_tail: nothing to split"])

    def test_j_cut_before_source_start_is_shortened(self):
        E = load("edit_analysis.py")
        bp = {"segments": [seg(1, "a", 0, 48, "x", media="both"), seg(2, "b", 2, 50, "x", media="both", audio_lead=8)]}
        new, notes = E["expand_split_edits"](bp, {"a": 24, "b": 24}, 24)
        b = [a for a in new["audio"] if a["id"] == "s2_a"][0]
        self.assertEqual(b["src_in"], 0)
        self.assertTrue(any("lead shortened" in n for n in notes))


class Composition(unittest.TestCase):
    def test_frame_mapping_and_suggested_pan(self):
        C = load("composition_check.py")
        self.assertAlmostEqual(C["to_frame_x"](0.5, 0), 0.5)
        self.assertAlmostEqual(C["to_frame_x"](0.5 - 0.0316, 0), 0.4, places=3)
        pan, x = C["suggest_pan"](0.30, 0.64)
        self.assertAlmostEqual(x, 0.64, places=2)
        self.assertAlmostEqual(C["window_x"](pan), 0.30 - 0.14 * 0.316, places=3)
        pan, x = C["suggest_pan"](0.02, 0.5)                     # far left: clamped, cannot centre it
        self.assertEqual(pan, 900)
        self.assertLess(x, 0.5)

    def test_look_room_eye_line_and_ui(self):
        C = load("composition_check.py")
        good = C["analyse_shot"]({"box": [0.46, 0.20, 0.54, 0.95], "eyes_y": 0.31, "gaze": "left"}, 60)   # +Pan: view left, subject right of centre
        self.assertEqual(good["notes"], [])
        self.assertGreater(good["look_room_ratio"], 1)
        bad = C["analyse_shot"]({"box": [0.60, 0.40, 0.66, 0.98], "eyes_y": 0.48, "gaze": "right"}, 0)
        txt = " ".join(bad["notes"])
        self.assertIn("below the upper third", txt)
        self.assertIn("look room", txt)
        self.assertIn("platform UI", txt)
        self.assertEqual(C["target_x"]("right"), 0.36)

    def test_native_mode(self):
        C = load("composition_check.py")
        r = C["analyse_shot"]({"box": [0.30, 0.25, 0.40, 0.90], "eyes_y": 0.33, "gaze": "right"}, 0, mode="native")
        self.assertEqual(r["frame_box"][0], 0.3)
        self.assertEqual(r["suggested_pan"], 0.0)


class Docs(unittest.TestCase):
    def test_lead_editor_rules_and_router(self):
        s = skill_text()
        self.assertIn("No generic advice", s)
        for f in ("montage-advanced.md", "story-structure.md", "composition.md"):
            self.assertIn(f, s)
            self.assertTrue(os.path.exists(os.path.join(ROOT, "references", f)))
        self.assertIn("edit_analysis.py", s)
        self.assertIn("composition_check.py", s)

    def test_cut_vocabulary_documented(self):
        E = load("edit_analysis.py")
        doc = read("references/montage-advanced.md")
        for word in sorted(E["REASONS"] | E["CUT_ON"]):
            self.assertIn(word, doc)
        for size in E["SIZES"]:
            self.assertIn(size, read("references/composition.md"))

    def test_frame_math_table(self):
        doc = read("references/montage-advanced.md")
        for txt in ("70 BPM = 20.57 f", "120 = 12 f", "30 fps: 120 BPM = 15 f"):
            self.assertIn(txt, doc)
        self.assertAlmostEqual(24 * 60 / 70.0, 20.57, places=2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
