"""v3.10.1: Phase 11 build agent stops only 3 times; changes batched; lean relay."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class Relay(unittest.TestCase):
    def test_three_stops_and_batching(self):
        p = text("references/phases/phase-11.md")
        for s in ("**Only 3 stops**", "preview + review in one", "export + placing in one", "Lean relay",
                  "in **one** message", "already answered at stop ③", "Stop only 3 times"):
            self.assertIn(s, p)
        self.assertNotIn('ask: "Đặt các lớp vào DaVinci?"', p)
        self.assertIn("**một** tin nhắn", text("motion-studio/references/review-and-export.md"))


if __name__ == "__main__":
    unittest.main()
