"""v3.8.0: model per agent, depth 1, briefs by reference, escalation; nothing removed."""
import json
import os
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class Models(unittest.TestCase):
    def test_config(self):
        m = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))["models"]
        self.assertEqual((m["A1_footage_scan"], m["A2_footage_deepen"], m["A3_stills_check"], m["A4_research"],
                          m["A5_judgement"], m["A6_phase11_builder"]), ("haiku", "sonnet", "sonnet", "haiku", "opus", "sonnet"))
        self.assertEqual(m["max_agent_depth"], 1)
        self.assertNotIn("fable", json.dumps(m))

    def test_roster_and_rules(self):
        t = text("references/agents-and-models.md")
        for s in ("Depth 1", "Brief by reference", "Images once, in one turn", "Escalation", "A5", "A6", "≤ 4 sources"):
            self.assertIn(s, t)

    def test_cards_name_their_agent_and_model(self):
        t = skill_text()
        for s in ('"haiku" for the scan (A1)', "A2 (`sonnet`", "A3 (`sonnet`", "A4 (`haiku`", "A5 (`opus`",
                  'model: "sonnet"', "Never start another agent (depth 1)", "does not open these stills",
                  "references/agents-and-models.md"):
            self.assertIn(s, t)

    def test_core_unchanged_rules_kept(self):
        core = text("SKILL.md")
        self.assertLess(len(core.split()), 2000)
        for n in range(1, 11):
            self.assertIn("references/phases/phase-%02d.md" % n, core)
        for s in ("Music boundary", "Graphics boundary", "Creative colour boundary", "Honest delivery", "Phase 11"):
            self.assertIn(s, core)


if __name__ == "__main__":
    unittest.main()
