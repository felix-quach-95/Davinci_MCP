"""v3.4.0: SFX only on transitions, more speed ramps and zoom moves (fx_plan, zoom_keys), a B-roll layer on V2."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def text(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def load(name):
    g = {"__name__": "test"}
    exec(compile(text("scripts/" + name), name, "exec"), g)
    return g


def seg(i, track=1, record="auto", **kw):
    s = {"id": "s%02d" % i, "clip": "A", "src_in": i * 100, "src_out": i * 100 + 45, "track": track, "record": record,
         "why": "x", "grp": "g%d" % i}
    s.update(kw)
    return s


class TransitionSfx(unittest.TestCase):
    def test_on_a_cut(self):
        S = load("sfx_library.py")
        self.assertTrue(S["TRANSITION_ONLY"])
        self.assertTrue(S["on_a_cut"](102, [100, 200], 3))
        self.assertFalse(S["on_a_cut"](150, [100, 200], 3))

    def test_docs(self):
        self.assertIn("transitions only", text("references/sfx-library.md"))
        self.assertIn("SFX only for transitions", text("SKILL.md"))


class Effects(unittest.TestCase):
    def test_zoom_keys_curve(self):
        M = load("motion_fx.py")
        keys, static = M["fx_points"]({"fx": "zoom_keys", "keys": [[0, 1.0], [-8, 1.08], [-1, 1.28, "in"]]}, 40)
        pts = keys[("Xf", "Size")]
        self.assertEqual([p[0] for p in pts], [0, 32, 39])
        self.assertEqual(pts[-1][1], 1.28)

    def test_zoom_keys_conflicts(self):
        M = load("motion_fx.py")
        probs = M["validate"]([{"index": 1, "fx": "zoom_keys", "keys": [[0, 1.0], [10, 1.4]]},
                               {"index": 1, "fx": "push", "t0": 0, "t1": 10}], {(1, 1): 40})
        self.assertTrue(any("1.35" in p for p in probs))
        self.assertTrue(any("same Size" in p for p in probs))

    def test_fx_report_counts(self):
        E = load("edit_analysis.py")
        bp = {"expected_fps": 30, "segments": [seg(i) for i in range(1, 19)]}
        r = E["analyse"](bp, {}, 30)
        self.assertTrue(any("speed ramps" in f for f in r["fx"]["flags"]))
        self.assertTrue(any("zoom moves" in f for f in r["fx"]["flags"]))
        for i, s in enumerate(bp["segments"]):
            s["fx_plan"] = ["ramp_through"] if i % 4 == 0 else (["push"] if i % 2 else ["pull"])
        r = E["analyse"](bp, {}, 30)
        self.assertEqual(r["fx"]["flags"], [])


class Broll(unittest.TestCase):
    def test_broll_layer_required(self):
        E = load("edit_analysis.py")
        v1 = [seg(i) for i in range(1, 19)]                        # 18 × 45 frames = 27 s
        r = E["broll_report"]({"expected_fps": 30, "segments": v1}, None, 30)
        self.assertEqual(r["count"], 0)
        self.assertTrue(any("B-roll layer" in f for f in r["flags"]))
        b = [seg(50 + k, track=2, record=40 + k * 100, broll_type="detail", text_checked=True) for k in range(7)]
        for x in b:
            x["src_out"] = x["src_in"] + 40                       # v3.5.0 targets: 7 cutaways, 25–50 % coverage
        r = E["broll_report"]({"expected_fps": 30, "segments": v1 + b}, None, 30)
        self.assertEqual(r["count"], 7)
        self.assertEqual(r["flags"], [])

    def test_broll_repeat_of_v1_picture(self):
        E = load("edit_analysis.py")
        v1 = [seg(i) for i in range(1, 19)]
        b = [seg(50 + k, track=2, record=40 + k * 100, broll_type="detail", text_checked=True) for k in range(7)]
        b[0]["grp"] = "g3"
        r = E["broll_report"]({"expected_fps": 30, "segments": v1 + b}, None, 30)
        self.assertTrue(any("image group g3" in f for f in r["flags"]))

    def test_docs(self):
        self.assertIn("B-roll layer on V2", text("references/broll.md"))
        self.assertIn("broll_report", text("references/phases/phase-05.md"))


if __name__ == "__main__":
    unittest.main()
