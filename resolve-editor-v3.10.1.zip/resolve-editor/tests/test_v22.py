"""Offline tests for the v2.2.0 additions (pure helpers; no Resolve needed).
Run all tests: python3 -m unittest discover -s tests -v"""
import json, math, os, unittest
from _skilltext import skill_text

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "loaded"}
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    exec(compile(src, name, "exec"), g)
    return g


def tone(sr, seconds, bursts=(), base=0.0, amp=0.6, freq=220.0, burst_len=0.25):
    """Quiet bed with loud bursts starting at the given times (seconds)."""
    n = int(sr * seconds)
    out = [base] * n
    for t0 in bursts:
        a = int(t0 * sr)
        for i in range(a, min(a + int(burst_len * sr), n)):
            out[i] = amp * math.sin(2 * math.pi * freq * i / sr) * (1 - (i - a) / (burst_len * sr))
    return out


class ConfigAndLoader(unittest.TestCase):
    def test_defaults_json_resolves_and_has_one_level_table(self):
        L = load("loader.py")
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        cfg = L["effective_config"](d)
        self.assertEqual(cfg["scripts"]["sfx_library.py"]["ROOT"], d["paths"]["sfx"])
        self.assertEqual(cfg["scripts"]["sfx_library.py"]["SFX_TRACKS"], [3, 4])      # keeps list type
        self.assertEqual(cfg["scripts"]["duck_music.py"]["DUCK_DB"], -20)
        self.assertIn("1080", str(cfg["scripts"]["render_deliver.py"]["PRESETS"]["tiktok"]))
        self.assertEqual(d["tracks"]["music_track"], 2)
        self.assertLessEqual(d["timeouts"]["budget_s"], d["timeouts"]["mcp_hard_limit_s"])

    def test_every_injected_name_exists_in_its_script(self):
        L = load("loader.py")
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        for tool, vals in d["scripts"].items():
            if tool.startswith("_"):
                continue
            src = open(os.path.join(SCRIPTS, tool), encoding="utf-8").read()
            for k in vals:
                self.assertRegex(src, r"(?m)^%s\s*=" % k, "%s has no CONFIG %s" % (tool, k))
            self.assertIn(L["MARKER"], src)

    def test_project_overrides_win_and_inject_before_resolve_block(self):
        L = load("loader.py")
        d = {"paths": {"sfx": "/a"}, "scripts": {"x.py": {"ROOT": "${paths.sfx}", "N": 3}}}
        cfg = L["effective_config"](d, {"paths": {"sfx": "/b"}})
        vals = L["overrides_for"]("x.py", cfg, {"N": 5})
        self.assertEqual(vals, {"ROOT": "/b", "N": 5})
        src = 'ROOT = "/old"\n\ntry:\n    resolve\nexcept NameError:\n    pass\n'
        new = L["inject"](src, L["to_source"](vals))
        self.assertLess(new.index("ROOT = '/b'"), new.index("try:"))
        g = {}
        exec(new.replace("    resolve\n", "    raise NameError\n"), g)
        self.assertEqual((g["ROOT"], g["N"]), ("/b", 5))
        self.assertRaises(ValueError, L["overrides_for"], "x.py", cfg, {"lower": 1})
        self.assertRaises(ValueError, L["project_path"], "/q", "Hồng Kông")
        self.assertEqual(L["project_path"]("/q/", "HongKong"), "/q/HongKong/project.json")

    def test_comment_keys_are_not_resolved(self):
        L = load("loader.py")
        cfg = L["resolve_refs"]({"_doc": "use ${a.b}", "a": {"b": 1}, "c": "${a.b}"}, {"a": {"b": 1}})
        self.assertEqual(cfg["_doc"], "use ${a.b}")
        self.assertEqual(cfg["c"], 1)


class MusicTrackDetection(unittest.TestCase):
    def test_named_track_then_audio_files_then_coverage(self):
        for name in ("ending_plan.py", "qa_audit.py"):
            pick = load(name)["pick_music_track"]
            self.assertEqual(pick({1: {"name": "DIALOGUE", "cover": 500, "video_src": True},
                                   2: {"name": "MUSIC", "cover": 400}}), 2)
            self.assertEqual(pick({1: {"name": "", "cover": 500, "video_src": True},
                                   2: {"name": "", "cover": 300}, 3: {"name": "", "cover": 40}}), 2)
            self.assertEqual(pick({1: {"name": "", "cover": 500, "video_src": True}}), 1)
            self.assertIsNone(pick({}))

    def test_ending_plan_default_is_auto(self):
        src = open(os.path.join(SCRIPTS, "ending_plan.py"), encoding="utf-8").read()
        self.assertIn('MUSIC_TRACK = "auto"', src)


class Render(unittest.TestCase):
    def test_unique_path_never_overwrites(self):
        R = load("render_deliver.py")
        taken = {"/o/Final_A_01.mp4", "/o/Final_A_01_2.mp4"}
        self.assertEqual(R["unique_path"]("/o", "Final_A_01", "mp4", taken.__contains__), ("/o/Final_A_01_3.mp4", "Final_A_01_3"))
        self.assertEqual(R["unique_path"]("/o/", "B", "mp4", taken.__contains__)[0], "/o/B.mp4")

    def test_codec_matching_and_aspect(self):
        R = load("render_deliver.py")
        codecs = {"H.264": "H264", "H.265": "H265", "Apple ProRes 422 HQ": "ProRes422HQ"}
        self.assertEqual(R["pick_codec"](codecs, "H264"), "H264")
        self.assertEqual(R["pick_codec"]({"H.264 NVIDIA": "H264_NVIDIA"}, "H.264"), "H264_NVIDIA")
        self.assertIsNone(R["pick_codec"]({}, "H264"))
        self.assertTrue(R["aspect_mismatch"](2160, 3840, 1920, 1080))
        self.assertFalse(R["aspect_mismatch"](2160, 3840, 1080, 1920))

    def test_parse_and_check_delivery(self):
        R = load("render_deliver.py")
        probe = R["parse_ffprobe"](json.dumps({"format": {"duration": "16.500"}, "streams": [
            {"codec_type": "video", "codec_name": "h264", "width": 1080, "height": 1920, "avg_frame_rate": "24/1", "nb_frames": "396"},
            {"codec_type": "audio", "codec_name": "aac", "sample_rate": "48000", "channels": 2}]}))
        self.assertEqual(probe["video"]["fps"], 24.0)
        loud = R["parse_ebur128"]("...\nSummary:\n\n  Integrated loudness:\n    I:         -15.6 LUFS\n"
                                  "  Loudness range:\n    LRA:         5.1 LU\n  True peak:\n    Peak:       -0.4 dBFS\n")
        self.assertEqual(loud, {"integrated_lufs": -15.6, "lra_lu": 5.1, "true_peak_dbtp": -0.4})
        pre = R["PRESETS"]["tiktok"]
        c = R["check_delivery"](probe, loud, pre, 24, 396, R["LOUDNESS_TARGET"])
        self.assertTrue(c["size"]["ok"] and c["fps"]["ok"] and c["duration"]["ok"] and c["audio"]["ok"])
        self.assertFalse(c["loudness"]["ok"])
        self.assertEqual(c["loudness"]["fix_db"], 1.6)
        self.assertFalse(c["true_peak"]["ok"])
        self.assertTrue(R["verdict"](c).startswith("FILE CHECK FAIL"))


class MusicLibrary(unittest.TestCase):
    def test_features_find_phrases_and_button_ending(self):
        M = load("music_library.py")
        sr = 2000
        x = tone(sr, 20, bursts=[1.0, 5.0, 9.0, 13.0, 17.0, 18.5], base=0.0005, burst_len=0.4)
        f = M["features"](x, sr)
        self.assertAlmostEqual(f["duration_s"], 20.0, places=1)
        self.assertTrue(any(abs(h - 5.0) <= 0.25 for h in f["hits_s"]))
        self.assertAlmostEqual(f["phrase_s"], 4.0, delta=0.3)
        self.assertEqual(f["ending"], "button")

    def test_rank_prefers_mood_and_duration(self):
        M = load("music_library.py")
        entries = [{"rel": "Chill Piano Night.mp3", "duration_s": 60, "bpm": 82, "bpm_conf": 0.4, "level_p90_db": -18,
                    "phrase_s": 3.4, "ending": "fade", "intro_s": 2},
                   {"rel": "Upbeat Summer Party.mp3", "duration_s": 60, "bpm": 128, "bpm_conf": 0.5, "level_p90_db": -9,
                    "phrase_s": 1.9, "ending": "cut", "intro_s": 0},
                   {"rel": "Tiny Sting.wav", "duration_s": 4}]
        top = M["rank"](entries, {"mood": "calm", "min_dur": 15, "max_dur": 240, "n": 3})
        self.assertEqual(top[0][1]["rel"], "Chill Piano Night.mp3")
        self.assertEqual(len(top), 2)                       # 4 s file filtered out
        en = M["rank"](entries, {"mood": "energetic", "min_dur": 15, "n": 1})
        self.assertEqual(en[0][1]["rel"], "Upbeat Summer Party.mp3")


class Ducking(unittest.TestCase):
    def test_plan_merges_short_gaps_and_crossfades(self):
        D = load("duck_music.py")
        sp = D["speech_intervals"]([[50, 100], [110, 160], [300, 340]], 6, 10, 24, lo=0, hi=400)
        self.assertEqual(sp, [[44, 170], [294, 350]])
        segs = D["duck_plan"](0, 400, sp, 16)
        self.assertEqual([s[2] for s in segs], ["normal", "duck", "normal", "duck", "normal"])
        self.assertEqual(segs[0][0], 0)
        self.assertEqual(segs[-1][1], 400)
        items = D["layout"](segs, 100, 0, 8, 2, 5, -9, -20, 6, 36)
        self.assertEqual([i["track"] for i in items], [2, 5, 2, 5, 2])
        self.assertEqual(items[0]["end"] - items[1]["rec"], 8)           # 8-frame overlap = crossfade
        self.assertEqual(items[1]["src_in"], 144)                        # source stays continuous
        self.assertEqual(items[0]["fades"]["FadeIn"], 6)
        self.assertEqual(items[-1]["fades"]["FadeOut"], 36)
        self.assertEqual(items[1]["volume"], -20)

    def test_tiny_segments_are_absorbed(self):
        D = load("duck_music.py")
        segs = D["duck_plan"](0, 200, [[5, 60], [70, 120]], 16)
        self.assertTrue(all(b - a >= 16 for a, b, _ in segs))
        self.assertEqual(segs[0][0], 0)
        self.assertEqual(segs[-1][1], 200)


# TranscriptCut tests moved to test_v23.py (planner rewritten in v2.3)


class PictureAndColor(unittest.TestCase):
    def test_smooth_ramp_is_monotone_and_complete(self):
        M = load("motion_fx.py")
        c = M["ramp_curve"]([[0, 300], [20, 300], [30, 40], [50, 40], [59, 200]], 60)
        self.assertEqual(c[0], (0, 0.0))
        self.assertEqual(c[-1], (59, 1.0))
        self.assertTrue(all(b[1] > a[1] for a, b in zip(c, c[1:])))
        slope_fast = c[5][1] - c[4][1]
        slope_slow = [b[1] - a[1] for a, b in zip(c, c[1:]) if 32 <= a[0] < 48][0]
        self.assertGreater(slope_fast / slope_slow, 5)
        self.assertRaises(ValueError, M["ramp_curve"], [[0, 0]], 10)
        self.assertTrue(M["validate"]([{"index": 1, "fx": "freeze", "t": 5},
                                       {"index": 1, "fx": "ramp_smooth", "profile": [[0, 100]]}], {(1, 1): 30}))

    def test_fill_geometry_for_other_aspects(self):
        B = load("build_from_blueprint.py")
        g = B["fill_geometry"]
        self.assertEqual(g(3840, 2160, 2160, 3840)["visible"], 0.3164)
        self.assertEqual(g(3840, 2160, 1080, 1350)["visible"], 0.45)
        self.assertEqual(g(3840, 2160, 1080, 1080)["visible"], 0.5625)
        self.assertEqual(g(1080, 1920, 1920, 1080)["axis"], "tilt")
        self.assertIsNone(g(1920, 1080, 3840, 2160)["axis"])

    def test_shots_from_scene_cuts(self):
        P = load("picture_tools.py")
        s = P["shots_from_items"]([{"name": "a", "src_in": 0, "src_out": 99}, {"name": "a", "src_in": 100, "src_out": 102},
                                   {"name": "a", "src_in": 103, "src_out": 199}, {"name": "b", "src_in": 0, "src_out": 49}])
        self.assertEqual(s, {"a": [[0, 103], [103, 200]], "b": [[0, 50]]})
        self.assertEqual(P["diff_props"]({"Pan": 0, "ZoomX": 1}, {"Pan": 120, "ZoomX": 1}), {"Pan": [0, 120]})

    def test_gamma_detection_and_lut_choice(self):
        C = load("color_look.py")
        self.assertEqual(C["detect_gamma"]({"Input Gamma": "Sony S-Log3"})[0], "slog3")
        self.assertEqual(C["detect_gamma"]({}, "DJI_0012_DLOG.MP4")[0], "dlog")
        self.assertEqual(C["detect_gamma"]({"Input Gamma": "Rec.709 Gamma 2.4"})[0], "rec709")
        self.assertEqual(C["detect_gamma"]({}, "IMG_2231.MOV")[0], "unknown")
        self.assertEqual(C["choose_lut"]("slog3", "teal_orange")[0], "MCP/cinematic_teal_orange_slog3_v1.cube")
        self.assertEqual(C["choose_lut"]("vlog", "convert")[0], "Panasonic/V-Log to V-709.cube")
        lut, note = C["choose_lut"]("vlog", "teal_orange")
        self.assertEqual(lut, "Panasonic/V-Log to V-709.cube")
        self.assertIn("conversion only", note)
        self.assertIsNone(C["choose_lut"]("unknown", "convert")[0])
        self.assertIsNone(C["choose_lut"]("applelog", "convert")[0])



class DocsConsistency(unittest.TestCase):
    """Guards for the v2.1.0 documentation mismatches fixed in v2.2.0."""
    def read(self, rel):
        return open(os.path.join(ROOT, rel), encoding="utf-8").read()

    def test_skill_frontmatter_limits(self):
        # Claude's skill upload rejects a description over 1024 characters
        import re
        txt = skill_text()
        self.assertTrue(txt.startswith("---\n"))
        front = txt.split("---", 2)[1]
        desc = re.search(r"(?m)^description: (.*)$", front).group(1)
        name = re.search(r'(?m)^name: "?([^"\n]*)"?$', front).group(1)
        self.assertLessEqual(len(desc), 1024)
        self.assertLessEqual(len(name), 64)
        self.assertRegex(name, r"^[a-z0-9-]+$")

    def test_skill_name_is_resolve_editor_everywhere(self):
        self.assertIn('name: "resolve-editor"', skill_text())
        for rel in ("INSTALL.md", "TEST-PROMPTS.md", "README.md"):
            # the upgrade note may name the old v1.x skill once
            txt = self.read(rel).replace('it was called "resolve-shortform-editor"', "")
            self.assertNotIn("resolve-shortform-editor", txt, rel)

    def test_no_legacy_uppercase_draft_names_in_references(self):
        import re
        for rel in os.listdir(os.path.join(ROOT, "references")):
            if os.path.isdir(os.path.join(ROOT, "references", rel)):
                continue                      # v3.0.2: references/phases holds the phase cards
            txt = self.read(os.path.join("references", rel))
            for m in re.finditer(r"DRAFT_[A-Za-z]", txt):
                ctx = txt[max(0, m.start() - 60):m.end() + 60]
                self.assertIn("historic name", ctx, "%s: legacy name near: %s" % (rel, ctx))

    def test_module_and_test_counts_in_docs(self):
        n_refs = len([f for f in os.listdir(os.path.join(ROOT, "references")) if f.endswith(".md")])
        self.assertIn("%d modules" % n_refs, self.read("README.md"))



if __name__ == "__main__":
    unittest.main(verbosity=2)
