"""v3.6.0: Phase 11 with the user's motion-studio skill, package and session boundary."""
import json
import os
import shutil
import tempfile
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


SPEC = {"title": "T", "final_timeline": "Final_T_01", "fps": 29.97, "width": 1080, "height": 1920, "duration_frames": 899,
        "safe_zone": {"x0": .06, "y_top": .08, "x1": .87, "y_bottom": .8}, "style": {"status": "approved", "look": "coral"},
        "cuts": [0, 96], "beats": [48], "audio_events": [{"frame": 96, "role": "whoosh", "file": "W.wav"}],
        "stills": {"e1": "stills/e1.png"}}
EL = {"id": "e1", "category": "title_main", "text": {"vi": "HƯƠNG CẢNG", "en": "Harbour"}, "start": 96, "end": 200,
      "position": {"anchor": "upper_third", "x": .5, "y": .3}, "hierarchy": 1, "animation": {"in": "rise", "out": "fade"},
      "anchored_to": {"kind": "cut", "ref": "96"}, "status": "approved", "source": "user"}


class Phase11(unittest.TestCase):
    def setUp(self):
        self.H = load("hyperframes_handoff.py")

    def data(self, **el):
        e = dict(EL, **el)
        return self.H["build_handoff"](dict(SPEC, elements=[e]))

    def test_request_only_when_approved(self):
        self.assertIsNone(self.H["hf_request"](self.data(status="proposed", source="claude_proposal")))
        self.assertIsNotNone(self.H["hf_request"](self.data()))

    def test_request_content(self):
        r = self.H["hf_request"](self.data(), SPEC["stills"])
        for s in ("Make a new video (fresh creation) with HyperFrames.", "Talk to me in: Vietnamese", "Transparent canvas",
                  "No sound at all", "899 frames at 30000/1001 fps", "(frames 96-200)", '"HƯƠNG CẢNG"',
                  "render --format mov --fps 30000/1001", "styles.mjs path \"coral\"", "stills/e1.png",
                  "Words on screen in: vi, en", "Skip step 2", "storylines no", "SPEC summary"):
            self.assertIn(s, r)

    def test_integer_fps_no_conform_note(self):
        d = self.H["build_handoff"](dict(SPEC, fps=30, duration_frames=900, elements=[EL]))
        self.assertNotIn("Clip Attributes", self.H["hf_request"](d))
        self.assertIn("--fps 30 ", self.H["hf_request"](d))
        self.assertEqual(self.H["render_fps"](23.976)[0], "24000/1001")
        self.assertFalse(self.H["render_fps"](29.97)[2])

    def test_write_files_package(self):
        tmp = tempfile.mkdtemp()
        try:
            out = self.H["write_files"](self.data(), tmp, SPEC["stills"])
            names = sorted(os.path.basename(p) for p in out)
            self.assertEqual(names, ["HF_REQUEST_T.md", "START_PHASE11.md", "handoff_T.json", "handoff_T.md", "layers_T.json"])
            st = open(os.path.join(tmp, "START_PHASE11.md"), encoding="utf-8").read()
            self.assertNotIn("/clear`", st)              # v3.10.0: never sends the user to /clear or a new chat
            self.assertIn("cùng cuộc trò chuyện", st)
            self.assertIn("HF_REQUEST_T.md", st)
            out2 = self.H["write_files"](self.data(status="open"), tmp + "/b")
            self.assertEqual(len(out2), 2)
        finally:
            shutil.rmtree(tmp)


class Docs(unittest.TestCase):
    def test_phase11_card_and_rules(self):
        t = skill_text()
        for s in ("Phase 11", "motion-studio", "One chat", "fresh-context agent", "START_PHASE11.md", "ffprobe"):
            self.assertIn(s, t)

    def test_vendor_zip_and_config(self):
        self.assertFalse(os.path.exists(os.path.join(ROOT, "vendor")), "skill zips cannot contain zips")
        c = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(c["handoff"]["phase11"]["skill"], "motion-studio")
        self.assertFalse(c["handoff"]["phase11"]["new_session"])
        self.assertTrue(c["handoff"]["phase11"]["same_chat"])

    def test_status_next_stays_in_same_chat(self):
        src = open(os.path.join(ROOT, "scripts", "phase_run.py"), encoding="utf-8").read()
        self.assertIn("SAME CHAT: Phase 11 with motion-studio", src)
        self.assertNotIn("NEW SESSION", src)


if __name__ == "__main__":
    unittest.main()
