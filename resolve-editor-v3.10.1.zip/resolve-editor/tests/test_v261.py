"""v2.6.1: loader injection reaches default arguments (live bug 2026-10-25, color_look LOOKS ignored)."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


class InjectBeforeDefs(unittest.TestCase):
    def test_default_argument_sees_override(self):
        L = load("loader.py")
        src = 'LOOKS = {"a": 1}\n\ndef pick(looks=LOOKS):\n    return looks\n\ntry:\n    resolve\nexcept NameError:\n    pass\nR = pick()\n'
        g = {}
        exec(L["inject"](src, L["to_source"]({"LOOKS": {"b": 2}})), g)
        self.assertEqual(g["R"], {"b": 2})

    def test_color_look_override_used(self):
        L = load("loader.py")
        src = open(os.path.join(SCRIPTS, "color_look.py"), encoding="utf-8").read()
        new = L["inject"](src, L["to_source"]({"LOOKS": {"warm": {"rec709": "MCP/w.cube"}}}))
        g = {"__name__": "offline"}
        exec(compile(new, "color_look.py", "exec"), g)
        self.assertEqual(g["choose_lut"]("rec709", "warm")[0], "MCP/w.cube")


if __name__ == "__main__":
    unittest.main()
