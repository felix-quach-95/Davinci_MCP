"""v3.7.1: Motion Studio shipped inside the skill as a folder; one SKILL.md, no nested zip."""
import filecmp
import os
import shutil
import tarfile
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    path = os.path.join(ROOT, "scripts", name)
    g = {"__name__": "offline", "__file__": path}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


class OneSkillFile(unittest.TestCase):
    def test_one_skill_md_no_archives(self):
        skills, archives = [], []
        for root, _, files in os.walk(ROOT):
            for f in files:
                if f == "SKILL.md":
                    skills.append(os.path.relpath(os.path.join(root, f), ROOT))
                if f.lower().endswith((".zip", ".skill", ".tar.gz", ".tgz")):
                    archives.append(f)
        self.assertEqual(skills, ["SKILL.md"])
        self.assertEqual(archives, [])

    def test_embedded_motion_studio(self):
        ms = os.path.join(ROOT, "motion-studio")
        for f in ("GUIDE.md", "INSTALL.md", "package.json", "scripts/install.sh", "scripts/setup.mjs", "scripts/styles.mjs",
                  "scripts/sync-text.mjs", "references/handoff.md"):
            self.assertTrue(os.path.isfile(os.path.join(ms, f)), f)
        self.assertIn("name: motion-studio", open(os.path.join(ms, "GUIDE.md"), encoding="utf-8").read())


class Installer(unittest.TestCase):
    def setUp(self):
        self.I = load("install_motion_studio.py")
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_install_restores_skill_md_and_keeps_styles(self):
        dest = os.path.join(self.tmp, "skills", "motion-studio")
        os.makedirs(os.path.join(dest, "styles", "mine"))
        r = self.I["install"](dest)
        self.assertEqual(r["status"], "COPIED")
        self.assertTrue(os.path.isfile(os.path.join(dest, "SKILL.md")))
        self.assertFalse(os.path.exists(os.path.join(dest, "GUIDE.md")))
        self.assertTrue(os.path.isdir(os.path.join(dest, "styles", "mine")))
        self.assertTrue(filecmp.cmp(os.path.join(dest, "SKILL.md"), os.path.join(ROOT, "motion-studio", "GUIDE.md"), shallow=False))
        self.assertTrue(os.access(os.path.join(dest, "scripts", "install.sh"), os.X_OK))
        self.assertIn("install.sh", r["next"])

    def test_link_refused(self):
        real = os.path.join(self.tmp, "real")
        os.makedirs(real)
        link = os.path.join(self.tmp, "motion-studio")
        os.symlink(real, link)
        self.assertEqual(self.I["install"](link)["status"], "REFUSED")

    def test_pack(self):
        out = os.path.join(self.tmp, "ms.tgz")
        self.I["pack"](out)
        names = tarfile.open(out).getnames()
        self.assertIn("motion-studio/SKILL.md", names)
        self.assertNotIn("motion-studio/GUIDE.md", names)


if __name__ == "__main__":
    unittest.main()
