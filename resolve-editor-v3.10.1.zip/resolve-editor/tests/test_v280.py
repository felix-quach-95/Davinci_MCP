"""v2.8.0: accent density 5–10, footage-relative SFX levels, beat text (accent animations, kinetic lines,
density plan), cross-video preferences, free audio ingest with licences, Gate 0 in SKILL.md."""
import json
import os
import tempfile
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class ContextLevels(unittest.TestCase):
    def setUp(self):
        self.S = load("sfx_library.py")

    def test_power_sum(self):
        self.assertEqual(self.S["power_sum_db"]([-20, -20]), -17.0)
        self.assertIsNone(self.S["power_sum_db"]([]))

    def test_rms(self):
        self.assertAlmostEqual(self.S["rms_dbfs"]([0.5, -0.5]), -6.0, places=1)
        self.assertIsNone(self.S["rms_dbfs"]([]))

    def test_loud_bed_raises_quiet_bed_lowers(self):
        cs = self.S["context_shift"]
        self.assertEqual(cs(-18.0, -24.0)[0], 6.0)
        self.assertEqual(cs(-34.0, -24.0)[0], -10.0)
        self.assertEqual(cs(-5.0, -24.0)[0], 9.0)           # clamped up
        self.assertEqual(cs(-50.0, -24.0)[0], -12.0)        # clamped down

    def test_speech_never_raises(self):
        self.assertEqual(self.S["context_shift"](-14.0, -24.0, speech=True)[0], 0.0)
        self.assertEqual(self.S["context_shift"](-30.0, -24.0, speech=True)[0], -6.0)

    def test_silence_and_unknown(self):
        self.assertEqual(self.S["context_shift"](-70.0, -24.0)[0], -6.0)
        self.assertEqual(self.S["context_shift"](None)[0], 0.0)

    def test_plan_cue_applies_shift_but_not_to_hand_levels(self):
        e = {"shape": "swell", "peak_t": 0.5, "onset_t": 0.1, "peak_db": -6.0}
        refs = {"whoosh": -6.0}
        base = self.S["plan_cue"](e, {"event": 100, "role": "whoosh"}, 24, 24, 48, self.S["LEVELS"], refs)
        up = self.S["plan_cue"](e, {"event": 100, "role": "whoosh"}, 24, 24, 48, self.S["LEVELS"], refs,
                                shift=(6.0, "bed"))
        self.assertEqual(up["volume"] - base["volume"], 6.0)
        self.assertIn("context", up["level_note"])
        hand = self.S["plan_cue"](e, {"event": 100, "role": "whoosh", "volume": -12}, 24, 24, 48,
                                  self.S["LEVELS"], refs, shift=(6.0, "bed"))
        self.assertEqual(hand["volume"], -12.0)

    def test_defaults(self):
        self.assertEqual(self.S["LEVEL_MODE"], "context")
        self.assertIn('elif MODE == "bed"', text("scripts/sfx_library.py"))




class Prefs(unittest.TestCase):
    def test_merge_prefs(self):
        L = load("loader.py")
        p = L["merge_prefs"]({"choices": {"look": "warm"}, "lessons": ["a", "b"]},
                             {"choices": {"text": {"density": "beat"}}, "lessons": ["a", "c"],
                              "config": {"mix": {"bed_ref_dbfs": -22}}})
        self.assertEqual(p["choices"], {"look": "warm", "text": {"density": "beat"}})
        self.assertEqual(p["lessons"], ["b", "a", "c"])
        self.assertEqual(p["config"]["mix"]["bed_ref_dbfs"], -22)
        self.assertEqual(len(L["merge_prefs"]({}, {"lessons": [str(i) for i in range(80)]})["lessons"]), 60)


class FreeAudio(unittest.TestCase):
    def setUp(self):
        self.A = load("audio_ingest.py")

    def test_licences(self):
        li = self.A["licence_info"]
        self.assertTrue(li("Pixabay Content License")["ok"])
        self.assertFalse(li("Pixabay Content License")["attribution"])
        self.assertTrue(li("CC BY 4.0")["attribution"])
        for bad in ("CC BY-NC 4.0", "CC-BY-ND", "BBC RemArc", "Non-Commercial", "", "Some EULA"):
            self.assertFalse(li(bad)["ok"], bad)

    def test_hosts(self):
        h = self.A["ALLOWED_HOSTS"]
        self.assertTrue(self.A["host_allowed"]("https://assets.mixkit.co/music/1.mp3", h))
        self.assertFalse(self.A["host_allowed"]("http://assets.mixkit.co/music/1.mp3", h))
        self.assertFalse(self.A["host_allowed"]("https://mixkit.co.evil.com/x.mp3", h))

    def test_never_overwrites(self):
        with tempfile.TemporaryDirectory() as d:
            p1 = self.A["target_path"](d, "_Free", "Mixkit", "a.mp3")
            os.makedirs(os.path.dirname(p1))
            open(p1, "w").close()
            p2 = self.A["target_path"](d, "_Free", "Mixkit", "a.mp3")
            self.assertTrue(p1.endswith(os.path.join("_Free", "mixkit", "a.mp3")))
            self.assertTrue(p2.endswith("a_2.mp3"))

    def test_credit_line(self):
        line = self.A["credit_line"]({"title": "Wallpaper", "artist": "Kevin MacLeod", "source": "incompetech",
                                      "licence": "CC BY 4.0"})
        self.assertIn("Kevin MacLeod", line)
        self.assertIn("CC BY 4.0", line)


class Docs(unittest.TestCase):
    def test_versions(self):
        self.assertEqual(json.load(open(os.path.join(ROOT, "config", "defaults.json")))["version"], "3.10.1")
        self.assertIn("v3.10.1", skill_text())

    def test_rules_in_skill(self):
        s = skill_text()
        self.assertIn("5–7 speed ramps per 30 s", s)
        self.assertIn("Kickoff questions", s)
        for ref in ("hyperframes-handoff.md", "options-playbook.md", "free-audio-sources.md"):
            self.assertIn(ref, s)
            self.assertTrue(os.path.exists(os.path.join(ROOT, "references", ref)))
        self.assertNotIn("3–5 accents", text("references/motion-effects.md"))

    def test_config_wiring(self):
        cfg = json.load(open(os.path.join(ROOT, "config", "defaults.json")))
        self.assertEqual(cfg["creative"]["accents_per_20s"]["cinematic"], [5, 10])
        self.assertIn("BED_REF_DBFS", cfg["scripts"]["sfx_library.py"])
        self.assertIn("audio_ingest.py", cfg["scripts"])


if __name__ == "__main__":
    unittest.main()
