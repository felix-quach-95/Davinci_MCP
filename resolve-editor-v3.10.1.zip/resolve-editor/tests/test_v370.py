"""v3.7.0: Phase 11 switch asked by Claude; one named, coloured layer per HyperFrames object."""
import json
import os
import shutil
import subprocess
import tempfile
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def el(i, cat, s, e, vi=""):
    return {"id": "e%d" % i, "category": cat, "text": {"vi": vi}, "start": s, "end": e, "position": {"x": .5, "y": .5},
            "hierarchy": 1, "animation": {"in": "fade"}, "anchored_to": {"kind": "none"}, "status": "approved", "source": "user"}


SPEC = {"title": "T", "final_timeline": "Final_T_01", "fps": 30, "width": 1080, "height": 1920, "duration_frames": 900,
        "style": {"status": "approved", "look": "coral"}}


class Layers(unittest.TestCase):
    def setUp(self):
        self.H = load("hyperframes_handoff.py")

    def plan(self, els):
        return self.H["plan_layers"](self.H["build_handoff"](dict(SPEC, elements=els)), "/pkg")

    def test_names_colours_tracks(self):
        p = self.plan([el(1, "title_main", 30, 120, "Hương Cảng về đêm"), el(2, "subtitle", 10, 60, "Đi thôi"),
                       el(3, "motion_graphic", 200, 260)])
        names = [L["name"] for L in p["layers"]]
        self.assertEqual(names, ["DH01_PhuDe_DiThoi", "DH02_TieuDeChinh_HuongCangVe", "DH03_DoHoaDong"])
        col = {L["category"]: L["colour"] for L in p["layers"]}
        self.assertEqual((col["title_main"], col["subtitle"], col["motion_graphic"]), ("Orange", "Teal", "Pink"))
        self.assertNotIn("Green", col.values())
        self.assertNotIn("Yellow", col.values())
        self.assertEqual([t["name"] for t in p["tracks"]], ["ĐH Chuyển động", "ĐH Tiêu đề", "ĐH Phụ đề"])
        self.assertEqual([t["index"] for t in p["tracks"]], [3, 4, 5])
        m = p["media"][1]
        self.assertEqual((m["path"], m["record"], m["track"], m["name"], m["color"]),
                         ("/pkg/layers/DH02_TieuDeChinh_HuongCangVe.mov", 30, 4, "DH02_TieuDeChinh_HuongCangVe", "Orange"))
        self.assertEqual(p["solo_rows"][0], {"name": "DH01_PhuDe_DiThoi", "solo": "DH01_PhuDe_DiThoi"})

    def test_overlap_gets_second_lane(self):
        p = self.plan([el(1, "onscreen_text", 0, 100, "A"), el(2, "caption", 50, 150, "B"), el(3, "onscreen_text", 150, 200, "C")])
        self.assertEqual([L["track_name"] for L in p["layers"]], ["ĐH Chữ", "ĐH Chữ 2", "ĐH Chữ"])

    def test_request_asks_for_layers(self):
        d = self.H["build_handoff"](dict(SPEC, elements=[el(1, "title_main", 30, 120, "Hương Cảng")]))
        r = self.H["hf_request"](d)
        for s in ("Separate named layers", "DH01_TieuDeChinh_HuongCang = e1", "`solo`", "layers_full"):
            self.assertIn(s, r)


class Trim(unittest.TestCase):
    def setUp(self):
        self.L = load("hf_layers.py")

    def test_cmd(self):
        c = self.L["trim_cmd"]("ffmpeg", "a.mov", "b.mov", 96, 104, 30)
        self.assertEqual(c[c.index("-ss") + 1], "3.200000")
        self.assertEqual(c[c.index("-frames:v") + 1], "104")
        self.assertIn("copy", c)

    def test_check_probe(self):
        good = {"streams": [{"codec_type": "video", "codec_name": "prores", "pix_fmt": "yuva444p12le", "width": 1080,
                             "height": 1920, "nb_read_frames": "104"}]}
        self.assertEqual(self.L["check_probe"](good, 104, 1080, 1920), [])
        bad = {"streams": [{"codec_type": "video", "codec_name": "h264", "pix_fmt": "yuv420p", "width": 1080,
                            "height": 1920, "nb_read_frames": "900"}, {"codec_type": "audio"}]}
        self.assertEqual(len(self.L["check_probe"](bad, 104, 1080, 1920)), 4)

    @unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "needs ffmpeg")
    def test_real_trim_is_frame_exact(self):
        tmp = tempfile.mkdtemp()
        try:
            full = os.path.join(tmp, "proj", "renders", "layers_full")
            os.makedirs(full)
            src = os.path.join(full, "DH01_A.mov")
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=64x96:rate=30:duration=3,format=yuva444p10le",
                            "-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", src], check=True)
            pkg = os.path.join(tmp, "pkg")
            os.makedirs(pkg)
            json.dump({"layers": [{"name": "DH01_A", "start": 37, "frames": 20, "file": "layers/DH01_A.mov"}],
                       "render_fps": 30, "width": 64, "height": 96}, open(os.path.join(pkg, "l.json"), "w"))
            r = self.L["run"](os.path.join(pkg, "l.json"), os.path.join(tmp, "proj"))
            self.assertEqual(r["status"], "LAYERS_OK", r)
            md5 = lambda args: subprocess.run(["ffmpeg", "-v", "error"] + args + ["-f", "md5", "-"], capture_output=True, text=True).stdout
            self.assertEqual(md5(["-i", src, "-vf", "select=eq(n\\,37)", "-frames:v", "1"]),
                             md5(["-i", os.path.join(pkg, "layers", "DH01_A.mov"), "-frames:v", "1"]))
        finally:
            shutil.rmtree(tmp)


class Docs(unittest.TestCase):
    def test_switch_and_colours_documented(self):
        t = skill_text()
        for s in ("Chuyển sang Phase 11 — làm đồ họa với HyperFrames?", "Chuyển sang HyperFrames ngay", "STOP <kind>",
                  "SendMessage", "DH01_TieuDeChinh_HuongCang", "ĐH Phụ đề", "hf_layers.py", "Teal"):
            self.assertIn(s, t)

    def test_place_media_sets_name_colour_track(self):
        src = open(os.path.join(ROOT, "scripts", "timeline_ops.py"), encoding="utf-8").read()
        for s in ('it.SetName(m["name"])', 'it.SetClipColor(m["color"])', 'item.SetClipColor(m["color"])',
                  'cur.SetTrackName(kind, int(track), m["track_name"])', 'GetTrackCount("video") < track'):
            self.assertIn(s, src)


if __name__ == "__main__":
    unittest.main()
