"""v3.1.3 fixes from the first live Express run (project Test / TNCCoffee, 2026-10-27)."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class MusicRank(unittest.TestCase):
    def setUp(self):
        self.M = load("music_library.py")
        self.q = {"mood": "calm", "min_dur": 20, "max_dur": 300, "keywords": ["coffee", "jazz"], "n": 6}

    def entry(self, rel, bpm, **kw):
        return dict({"rel": rel, "duration_s": 120, "bpm": bpm, "bpm_conf": 0.7, "ending": "fade"}, **kw)

    def test_keyword_track_beats_comical_calm_tempo(self):
        es = [self.entry("mixkit-comical-2.mp3", 69, phrase_s=2.5), self.entry("mixkit-cold-coffee-1092.mp3", 104)]
        ranked = [e["rel"] for _, e, _ in self.M["rank"](es, self.q)]
        self.assertEqual(ranked[0], "mixkit-cold-coffee-1092.mp3")

    def test_comical_is_named_funny(self):
        self.assertEqual(self.M["mood_of"]({"rel": "mixkit-comical-2.mp3"})[1], "funny")


class TempoLabel(unittest.TestCase):
    def test_disagreeing_tools_are_estimated(self):
        M = load("music_library.py")
        lab = M["tempo_label"]({"bpm": 98.7, "bpm_conf": 0.76}, 96.27)["bpm_label"]
        self.assertTrue(lab.startswith("estimated"))

    def test_analyse_mode_passes_second_bpm(self):
        src = text("scripts/music_library.py")
        self.assertIn("row.update(tempo_label(e, sb))", src)


class Budget(unittest.TestCase):
    def test_budget_below_mcp_timeout(self):
        self.assertLess(load("phase_run.py")["BUDGET_S"], 10)

    def test_timeout_handling_documented(self):
        self.assertIn("STATUS.md", text("references/phases/express-runbook.md").split("times out")[1][:200])
