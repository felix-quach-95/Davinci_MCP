"""v3.0.0: graphics handed to HyperFrames, ten phases, technical colour only, hand-over brief."""
import json
import os
import re
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


SPEC = {"title": "T", "final_timeline": "Final_T_01", "fps": 24, "width": 1080, "height": 1920, "duration_frames": 480,
        "safe_zone": {"x0": .06, "y_top": .08, "x1": .87, "y_bottom": .8}, "style": {"status": "approved", "direction": "calm"},
        "cuts": [0, 96], "beats": [48], "markers": [{"frame": 200, "name": "DROP"}]}


def el(**kw):
    e = {"id": "e1", "category": "title_main", "text": {"vi": "A"}, "start": 96, "end": 200, "position": {"x": .5, "y": .3},
         "hierarchy": 1, "animation": {"in": "fade"}, "anchored_to": {"kind": "cut"}, "status": "approved", "source": "user"}
    e.update(kw)
    return e


class Handoff(unittest.TestCase):
    def setUp(self):
        self.H = load("hyperframes_handoff.py")

    def build(self, els, **over):
        s = dict(SPEC, elements=els, **over)
        return self.H["build_handoff"](s)

    def test_approved_only_when_everything_approved(self):
        self.assertEqual(self.build([el()])["status"], "APPROVED")
        self.assertEqual(self.build([el(status="proposed", source="claude_proposal")])["status"], "AWAITING_USER_APPROVAL")
        self.assertEqual(self.build([el()], style={"status": "proposed"})["status"], "AWAITING_USER_APPROVAL")

    def test_claude_proposal_cannot_be_approved(self):
        d = self.build([el(source="claude_proposal")])
        self.assertEqual(d["status"], "INCOMPLETE")

    def test_bounds_ids_and_category(self):
        d = self.build([el(end=999), el(category="sticker"), el(start=50, end=40)])
        msgs = " ".join(i["issue"] for i in d["issues"] if i["severity"] == "BLOCKER")
        self.assertIn("outside the cut", msgs)
        self.assertIn("unknown category", msgs)
        self.assertIn("start < end", msgs)
        self.assertIn("duplicate id", msgs)

    def test_anchor_and_safe_zone_warnings(self):
        d = self.build([el(start=120, end=150, position={"x": .95, "y": .3})])
        w = " ".join(i["issue"] for i in d["issues"])
        self.assertIn("not within", w)
        self.assertIn("safe zone", w)

    def test_subtitles_expanded_and_checked(self):
        d = self.build([], subtitle_cues=[{"start": 0, "end": 6, "vi": "x" * 40, "en": "ok"},
                                          {"start": 3, "end": 30, "vi": "ngắn"}])
        subs = [e for e in d["elements"] if e["category"] == "subtitle"]
        self.assertEqual(len(subs), 2)
        w = " ".join(i["issue"] for i in d["issues"])
        self.assertIn("40 characters", w)
        self.assertIn("overlap", w)
        self.assertTrue(all(e["status"] == "proposed" for e in subs))

    def test_markdown_and_timecodes(self):
        d = self.build([el()])
        md = self.H["to_markdown"](d)
        self.assertIn("00:00:04:00", md)
        self.assertIn("Bàn giao HyperFrames", md)
        self.assertEqual(d["counts"]["title_main"], 1)


class Scope(unittest.TestCase):
    REMOVED_SCRIPTS = ("text_fx.py", "text_qa.py", "calibrate_fonts.py", "fonts.py", "track_point.py")
    REMOVED_REFS = ("text-system.md", "beat-text-fx.md", "advanced-text-fx.md", "motion-graphics.md", "design-directions.md")

    def test_removed_files_gone(self):
        for f in self.REMOVED_SCRIPTS:
            self.assertFalse(os.path.exists(os.path.join(ROOT, "scripts", f)), f)
        for f in self.REMOVED_REFS:
            self.assertFalse(os.path.exists(os.path.join(ROOT, "references", f)), f)

    def test_no_dangling_references(self):
        names = [r.replace(".md", "") for r in self.REMOVED_REFS] + [s for s in self.REMOVED_SCRIPTS]
        skip = ("CHANGELOG.md", "THIRD_PARTY_NOTICES.md", "README.md")
        for base, _, files in os.walk(ROOT):
            if "tests" in base.split(os.sep) or "__pycache__" in base:
                continue
            for f in files:
                if f in skip or not f.endswith((".md", ".py", ".json")):
                    continue
                rel = os.path.relpath(os.path.join(base, f), ROOT)
                if rel == os.path.join("scripts", "README.md"):
                    continue          # historical notes, headed by the v3.0 banner
                s = text(rel)
                if rel == os.path.join("config", "defaults.json"):
                    d = json.loads(s)
                    d.pop("removed_tools", None)      # the list stage_check uses to find stale staged copies
                    s = json.dumps(d)
                for n in names:
                    pat = re.escape(n) if n.endswith(".py") else r"`?" + re.escape(n) + r"(\.md)?`?"
                    for m in re.finditer(pat, s):
                        ctx = s[max(0, m.start() - 80):m.end() + 40]
                        self.assertTrue(re.search(r"removed|v2\.x|historical|legacy|older", ctx, re.I),
                                        "%s still points at %s: …%s…" % (rel, n, ctx.replace("\n", " ")))

    def test_config_has_no_text_tooling(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["version"], "3.10.1")
        for k in ("text_fx.py", "text_qa.py", "track_point.py"):
            self.assertNotIn(k, d["scripts"])
        self.assertNotIn("text_density", d["creative"])
        self.assertIn("graphics_tracks", d["tracks"])
        self.assertFalse(d["creative"]["creative_look"])
        for tr in d["tracks"]["video"].values():
            self.assertFalse(tr.startswith("TITLES"))

    def test_every_script_still_compiles_and_config_names_exist(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        for tool, vals in d["scripts"].items():
            if tool.startswith("_"):
                continue
            src = text("scripts/" + tool)
            for k in vals:
                self.assertRegex(src, r"(?m)^%s\s*=" % k)

    def test_style_profiles_have_no_text_recipes(self):
        for f in os.listdir(os.path.join(ROOT, "config", "styles")):
            p = json.load(open(os.path.join(ROOT, "config", "styles", f), encoding="utf-8"))
            self.assertNotIn("text", p)
            self.assertNotIn("look", p)
            self.assertNotIn("text_density", p.get("project", {}).get("creative", {}))


class SkillText(unittest.TestCase):
    def test_ten_phases_in_order(self):
        s = skill_text()
        pos = [s.index("### Phase %d" % i) for i in range(1, 11)]
        self.assertEqual(pos, sorted(pos))

    def test_boundaries_and_rules(self):
        s = skill_text()
        for needle in ("Graphics boundary", "Creative colour boundary", "HyperFrames", "measured", "estimated",
                       "documented by the footage", "multi-format", "No render by Claude"):
            self.assertIn(needle, s if needle != "multi-format" else s.lower().replace("format: multi-format", "multi-format"))
        self.assertIn("never ask about titles, subtitles or graphics before phase 11", s.lower())

    def test_router_lists_new_modules(self):
        s = skill_text()
        for ref in ("hyperframes-handoff.md", "music-analysis.md"):
            self.assertIn(ref, s)
            self.assertTrue(os.path.exists(os.path.join(ROOT, "references", ref)))

    def test_color_is_technical_only(self):
        c = text("references/color-look.md")
        self.assertIn("only when the user asks for a creative look", c)
        self.assertNotIn("Gate 1b", c.split("## Contents")[0])


class LiveRunFixes(unittest.TestCase):
    """Regressions found on the first live run of v3.0 (project Test_, 13 pool items, 2026-10-27)."""

    def test_duplicate_imports_grouped(self):
        I = load("inventory.py")
        base = {"kind": "video", "Frames": "170", "Duration": "00:00:05:20", "Resolution": "1280x720",
                "Video Codec": "H.264", "Audio Ch": "2", "FPS": 30.0}
        clips = [dict(base, name="a.mp4"), dict(base, name="a (1).mp4"), dict(base, name="a (2).mp4"),
                 dict(base, name="b.mp4"), dict(base, name="c.mp4", Frames="99")]
        self.assertEqual(I["duplicate_groups"](clips), [["a (1).mp4", "a (2).mp4", "a.mp4"]])
        ps = {"timelineFrameRate": 30.0, "timelineResolutionWidth": "1080", "timelineResolutionHeight": "1920"}
        w = I["preflight_warnings"](ps, clips, [])
        self.assertTrue(any(x.startswith("DUPLICATE_MEDIA") for x in w))

    def test_same_length_different_takes_not_merged(self):
        I = load("inventory.py")
        base = {"kind": "video", "Frames": "170", "Duration": "00:00:05:20", "Resolution": "1280x720", "Video Codec": "H.264"}
        self.assertEqual(I["duplicate_groups"]([dict(base, name="take1.mp4"), dict(base, name="take2.mp4")]), [])

    def test_low_res_warning(self):
        I = load("inventory.py")
        clips = [{"kind": "video", "name": "x.mp4", "FPS": 30.0, "Resolution": "1280x720"}]
        ps = {"timelineFrameRate": 30.0, "timelineResolutionWidth": "2160", "timelineResolutionHeight": "3840"}
        self.assertTrue(any(x.startswith("LOW_RES_SOURCE") for x in I["preflight_warnings"](ps, clips, [])))
        ps["timelineResolutionWidth"], ps["timelineResolutionHeight"] = "1080", "1920"
        portrait = [{"kind": "video", "name": "p.mp4", "FPS": 30.0, "Resolution": "720x1280"}]   # 1.5x: fine
        self.assertFalse(any(x.startswith("LOW_RES_SOURCE") for x in I["preflight_warnings"](ps, portrait, [])))

    def test_fps_question_before_first_timeline(self):
        I = load("inventory.py")
        w = I["preflight_warnings"]({"timelineFrameRate": 24.0}, [{"kind": "video", "name": "a", "FPS": 30.0}], [])
        self.assertIn("kickoff questions", w[0])

    def test_tempo_labels(self):
        M = load("music_library.py")
        self.assertEqual(M["tempo_label"]({"bpm": 69.4, "bpm_conf": 0.68})["bpm_label"], "measured")
        low = M["tempo_label"]({"bpm": 144.2, "bpm_conf": 0.43})
        self.assertTrue(low["bpm_label"].startswith("estimated"))
        self.assertEqual(low["bpm_octaves"], [72.1, 288.4])
        self.assertEqual(M["tempo_label"]({})["bpm_label"], "not measured")
        e = {"bpm": 117.2, "bpm_conf": 0.8}
        self.assertTrue(M["tempo_label"](e, 80.6)["bpm_label"].startswith("estimated (two estimates disagree"))
        self.assertEqual(M["tempo_label"](e, 116.5)["bpm_label"], "measured")
        self.assertEqual(M["tempo_label"]({"bpm": 69.4, "bpm_conf": 0.7}, 139.0)["bpm_label"], "measured")   # double time

    def test_frame_probe_dup_key(self):
        F = load("frame_probe.py")
        p = {"Frames": "170", "Duration": "5", "Resolution": "1280x720", "Video Codec": "H.264"}
        self.assertEqual(F["dup_key"]("a (1).mp4", p), F["dup_key"]("a.mp4", p))
        self.assertNotEqual(F["dup_key"]("b.mp4", p), F["dup_key"]("a.mp4", p))

    def test_loader_finds_config_in_subfolder_and_flags_obsolete(self):
        src = text("scripts/loader.py")
        self.assertIn('os.path.join(tools, "config", CONFIG_FILE)', src)
        self.assertIn("OBSOLETE_FILES_STAGED", src)
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        for f in d["removed_tools"]:
            self.assertFalse(os.path.exists(os.path.join(ROOT, "scripts", f)))

    def test_broll_and_graphics_tracks_do_not_overlap(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertNotIn(d["tracks"]["broll_track"], d["tracks"]["graphics_tracks"])
        self.assertEqual(d["tracks"]["video"][str(d["tracks"]["broll_track"])], "B-ROLL")
        self.assertIn("GRAPHICS_TRACKS = [3, 4, 5]", text("scripts/qa_audit.py"))
        self.assertIn("GRAPHICS_PLACED", text("scripts/qa_audit.py"))
        self.assertIn("TEXT_TRACKS = [3, 4, 5]", text("scripts/finalize_project.py"))


class Phase7LiveFixes(unittest.TestCase):
    """Second live session (Draft_TNCRoast_v01, Phase 7)."""

    def test_profile_shift_finds_offset(self):
        P = load("picture_tools.py")
        import random
        rnd = random.Random(7)                      # aperiodic texture (a periodic one has several valid shifts)
        a = [rnd.random() * 100 for _ in range(360)]
        b = [a[x - 84] if x >= 84 else 0.0 for x in range(360)]
        self.assertEqual(P["profile_shift"](a, b, 170)[0], 84)
        c = [a[x + 50] if x + 50 < 360 else 0.0 for x in range(360)]
        self.assertEqual(P["profile_shift"](a, c, 170)[0], -50)

    def test_pan_calibrate_documented_and_wired(self):
        self.assertIn('MODE == "pan_calibrate"', text("scripts/picture_tools.py"))
        self.assertIn("pan_calibrate", skill_text())
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertIn("pan_calibrate", d["framing"]["_doc"])

    def test_dialogue_tracks_configurable(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["scripts"]["sfx_library.py"]["DIALOGUE_TRACKS"], "${mix.dialogue_tracks}")
        L = load("loader.py")
        self.assertEqual(L["effective_config"](d, {"mix": {"dialogue_tracks": []}})["scripts"]["sfx_library.py"]["DIALOGUE_TRACKS"], [])

    def test_stale_catalogue_and_peak_report(self):
        s = text("scripts/sfx_library.py")
        self.assertIn("stale_entries", s)
        self.assertIn("file missing on disk", s)
        self.assertIn("mix_peak_dbfs", text("scripts/audio_presence.py"))
        self.assertIn("integrated_lufs", text("scripts/audio_presence.py"))
        self.assertIn("does NOT show Edit-page fades", text("scripts/qc_stills.py"))


class MusicIntake(unittest.TestCase):
    ROOT_M = "/Users/felix/Desktop/Asset/Music"

    def setUp(self):
        self.M = load("music_intake.py")

    def test_none(self):
        r = self.M["classify"]([], None, self.ROOT_M)
        self.assertEqual(r["status"], "NONE")
        self.assertIsNone(self.M["question"]("NONE"))            # v3.3.0: a Music request message, no options
        msg = self.M["music_request"]({"label": "Nhịp mạnh theo beat", "asl_s": [1.2, 2.0], "ending": "hit-cut"}, 30)
        self.assertIn("Yêu cầu gửi nhạc nền", msg)
        self.assertIn("Nhịp mạnh theo beat", msg)
        self.assertIn("30 s", msg)
        self.assertNotIn("preview_question", self.M)

    def test_excerpt_ends_on_phrase(self):
        L = load("music_library.py")
        st, en, why = L["choose_excerpt"](130, 0.25, [53.25, 96.5], 20)
        self.assertEqual((st, en), (33.25, 53.25))
        self.assertIn("phrase", why)
        self.assertEqual(L["choose_excerpt"](15, 0, [], 20)[:2], (0.0, 15.0))
        st, en, _ = L["choose_excerpt"](160, 32, [], 20)
        self.assertEqual((st, en), (16.0, 36.0))

    def test_claude_pick_is_not_user_music(self):
        lib = {"path": self.ROOT_M + "/mixkit-cold-coffee-1092.mp3", "where": "media_pool", "bin": "Music", "duration_s": 130}
        r = self.M["classify"]([lib], {"file": "mixkit-cold-coffee-1092.mp3"}, self.ROOT_M)
        self.assertEqual(r["status"], "CHOSEN_BY_CLAUDE")
        self.assertIn("Dùng bài này", self.M["question"](r["status"], [], r["claude_pick"])["options"][0]["label"])   # v3.3.0 wording
        r2 = self.M["classify"]([lib], None, self.ROOT_M)            # imported into Claude's bin, chooser unknown
        self.assertEqual(r2["status"], "CHOSEN_BY_CLAUDE")

    def test_user_music_found_in_pool_or_footage_folder(self):
        a = {"path": "/Users/felix/Desktop/Footage/Coffee/song.mp3", "where": "footage_folder", "duration_s": 95}
        self.assertEqual(self.M["classify"]([a], None, self.ROOT_M)["status"], "USER_MUSIC")
        b = {"path": "/Users/felix/Downloads/b.wav", "where": "media_pool", "bin": "Master", "duration_s": 60}
        self.assertEqual(self.M["classify"]([a, b], None, self.ROOT_M)["status"], "USER_MUSIC_SEVERAL")
        self.assertIsNone(self.M["question"]("USER_MUSIC"))

    def test_short_audio_is_not_music_and_duplicates_collapse(self):
        s = {"path": "/x/whoosh.wav", "where": "media_pool", "bin": "SFX", "duration_s": 1.2}
        a = {"path": "/x/song.mp3", "where": "named", "duration_s": None}
        r = self.M["classify"]([s, a, dict(a)], None, self.ROOT_M)
        self.assertEqual(r["status"], "USER_MUSIC")
        self.assertEqual(len(r["short"]), 1)

    def test_wired(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertIn("music_intake.py", d["scripts"])
        self.assertIn("music_intake.py", skill_text())
        self.assertIn('MODE == "analyse"', text("scripts/music_library.py"))
        self.assertIn("When the music should arrive", text("references/music-analysis.md"))


class TechnicalColour(unittest.TestCase):
    def setUp(self):
        self.C = load("color_look.py")

    def test_neutral_white_balance_and_cap(self):
        slope, why = self.C["suggest_slope"]({"y_med": 100, "y_p98": 220, "neutral_rgb": [166, 163, 159], "neutral_pct": 28}, 103)
        self.assertEqual(slope[1], 1.0)
        self.assertLess(slope[0], 1.0)
        self.assertGreater(slope[2], 1.0)
        slope, _ = self.C["suggest_slope"]({"y_med": 100, "y_p98": 220, "neutral_rgb": [200, 150, 100], "neutral_pct": 30}, 100)
        self.assertEqual(slope, [0.94, 1.0, 1.06])                      # capped at ±6 %

    def test_beans_without_neutrals_are_not_neutralised(self):
        slope, why = self.C["suggest_slope"]({"y_med": 100, "y_p98": 220, "neutral_rgb": None, "neutral_pct": 2}, 100)
        self.assertEqual(slope, [1.0, 1.0, 1.0])
        self.assertIn("too few neutral", why[0])

    def test_exposure_only_for_outliers_and_capped_by_highlights(self):
        s, _ = self.C["suggest_slope"]({"y_med": 90, "y_p98": 220, "neutral_rgb": None, "neutral_pct": 0}, 103)
        self.assertEqual(s, [1.0, 1.0, 1.0])                            # 87 % of the sequence: left alone
        s, why = self.C["suggest_slope"]({"y_med": 49, "y_p98": 118, "neutral_rgb": None, "neutral_pct": 0}, 103)
        self.assertEqual(s, [1.5, 1.5, 1.5])
        s, _ = self.C["suggest_slope"]({"y_med": 49, "y_p98": 200, "neutral_rgb": None, "neutral_pct": 0}, 103)
        self.assertLessEqual(s[0] * 200, 235.5)

    def test_frame_stats(self):
        px = [(150, 150, 150)] * 50 + [(120, 60, 20)] * 50
        st = self.C["frame_stats"](px)
        self.assertAlmostEqual(st["neutral_pct"], 50.0)
        self.assertEqual([round(v) for v in st["neutral_rgb"]], [150, 150, 150])


if __name__ == "__main__":
    unittest.main()
