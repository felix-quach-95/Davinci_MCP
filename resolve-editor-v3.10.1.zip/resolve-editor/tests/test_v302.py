"""v3.0.2 (option A): Express mode, repeated timeline jobs in one script, core SKILL.md + phase cards, compact output."""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class CoreAndCards(unittest.TestCase):
    def test_core_is_small_and_points_to_ten_cards(self):
        core = text("SKILL.md")
        self.assertLess(len(core.split()), 2000, "the always-loaded core must stay small")
        for n in range(1, 11):
            card = "references/phases/phase-%02d.md" % n
            self.assertIn(card, core)
            body = text(card)
            self.assertIn("**Done when:**", body)
            self.assertIn("**Tools:**", body)
        self.assertTrue(os.path.exists(os.path.join(ROOT, "references", "phases", "router.md")))

    def test_express_is_default_and_keeps_hard_gates(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["workflow"]["mode"], "express")
        core = text("SKILL.md")
        for needle in ("Express", "Standard", "Story approval", "Draft review", "Final approval", "Hard rules (every mode)",
                       "Never ask about titles, subtitles or graphics before Phase 11"):
            self.assertIn(needle, core)
        self.assertIn("Express", text("references/phases/phase-06.md"))
        self.assertIn("Express", text("references/phases/phase-10.md"))


class TimelineOps(unittest.TestCase):
    def setUp(self):
        self.T = load("timeline_ops.py")

    def test_next_draft_name(self):
        f = self.T["next_draft_name"]
        self.assertEqual(f(["Draft_TNC_v02", "Draft_TNC_v04", "Final_TNC_02", "Draft_X_v09"], "TNC"), "Draft_TNC_v05")
        self.assertEqual(f([], "TNC"), "Draft_TNC_v01")

    def test_diff_stats(self):
        self.assertEqual(self.T["diff_stats"](bytes([10, 20]), bytes([10, 20])), (0.0, 15.0, 15.0))
        self.assertEqual(self.T["diff_stats"](b"", b"")[0], None)

    def test_wired_and_documented(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertIn("timeline_ops.py", d["scripts"])
        self.assertIn("timeline_ops.py", text("SKILL.md"))
        self.assertIn("timeline_ops.py", text("scripts/README.md"))


class Stage(unittest.TestCase):
    def test_stage_copies_moves_obsolete_and_checks_md5(self):
        tmp = tempfile.mkdtemp()
        try:
            open(os.path.join(tmp, "text_fx.py"), "w").write("# stale v2.9 tool")
            r = subprocess.run([sys.executable, "-I", os.path.join(ROOT, "scripts", "stage.py"), tmp],
                               capture_output=True, text=True, check=True)
            out = json.loads(r.stdout)
            self.assertEqual(out["status"], "OK")
            self.assertIn("text_fx.py", out["moved_obsolete"])
            self.assertTrue(os.path.exists(os.path.join(tmp, "config", "defaults.json")))
            self.assertTrue(os.path.exists(os.path.join(tmp, "timeline_ops.py")))
        finally:
            shutil.rmtree(tmp)


class CompactInventory(unittest.TestCase):
    def test_compact_rows_drop_paths(self):
        I = load("inventory.py")
        rows, dirs = I["compact_rows"]([{"name": "a.mp4", "kind": "video", "FPS": 30.0, "Frames": "170",
                                         "Resolution": "1280x720", "File Path": "/x/a.mp4", "Video Codec": "H.264",
                                         "orientation": "landscape"}])
        self.assertEqual(dirs, ["/x"])
        self.assertNotIn("File Path", rows[0])
        self.assertEqual(rows[0]["Frames"], "170")


if __name__ == "__main__":
    unittest.main()
