"""v3.10.0: graphic questions only in Phase 11, same chat (no new window), gallery with pictures first, preview link sent."""
import json
import os
import shutil
import tempfile
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


def load(name):
    g = {"__name__": "offline"}
    exec(compile(text("scripts/" + name), name, "exec"), g)
    return g


class Phase10(unittest.TestCase):
    def test_final_approval_has_no_graphic_question(self):
        p10 = text("references/phases/phase-10.md")
        self.assertIn("exactly two questions", p10)
        self.assertIn("Never add a graphic question", p10)
        self.assertNotIn("hyperframes_handoff.py", p10)
        pb = text("references/options-playbook.md")
        sec8 = pb[pb.index("## 8. Final approval"):pb.index("## 8b.")]
        self.assertNotIn("Graphic cần làm", sec8)
        self.assertNotIn("Phong cách graphic", sec8)
        self.assertIn("Chuyển sang HyperFrames ngay", sec8)

    def test_switch_question_has_no_new_window(self):
        for rel in ("references/phases/phase-10.md", "references/phases/phase-11.md", "references/options-playbook.md", "SKILL.md"):
            t = text(rel)
            self.assertNotIn("Phiên mới hoàn toàn", t, rel)
            self.assertNotIn("Tự tách phiên", t, rel)
        self.assertNotIn("scheduled task", text("references/phases/phase-11.md"))
        c = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))["handoff"]["phase11"]
        self.assertTrue(c["same_chat"])
        self.assertFalse(c["new_session"])
        self.assertEqual(c["order"][:3], ["install_check", "style_gallery", "graphic_questions"])


class Phase11(unittest.TestCase):
    def test_order_gallery_before_questions(self):
        p = text("references/phases/phase-11.md")
        self.assertLess(p.index("### B. Style gallery with pictures"), p.index("### C. Graphic questions"))
        self.assertIn("styles.mjs gallery --open", p)
        self.assertIn("file://<library>/gallery.html", p)
        self.assertIn("never replace the gallery by a text-only list", p)

    def test_preview_link_rule(self):
        p = text("references/phases/phase-11.md")
        for s in ("STOP preview", "LINK: http://localhost:<port>", "first the links", "Never wait for the user to say they cannot see it"):
            self.assertIn(s, p)
        g = text("motion-studio/GUIDE.md")
        self.assertIn("Preview link, always sent", g)
        self.assertIn("Inside resolve-editor's Phase 11 this section does not apply", g)
        self.assertIn("http://localhost:<port>", text("motion-studio/references/review-and-export.md"))

    def test_hf_request_asks_for_preview_link_and_resume_is_same_chat(self):
        H = load("hyperframes_handoff.py")
        spec = {"title": "T", "final_timeline": "Final_T_01", "fps": 30, "width": 1080, "height": 1920, "duration_frames": 300,
                "style": {"status": "approved", "look": "coral"},
                "elements": [{"id": "e1", "category": "title_main", "text": {"vi": "Đêm"}, "start": 10, "end": 60,
                              "position": {"x": .5, "y": .3}, "hierarchy": 1, "animation": {"in": "fade"},
                              "anchored_to": {"kind": "none"}, "status": "approved", "source": "user"}]}
        d = H["build_handoff"](spec)
        self.assertIn("Preview: as soon as the Studio preview runs, give me its link", H["hf_request"](d))
        tmp = tempfile.mkdtemp()
        try:
            H["write_files"](d, tmp)
            st = open(os.path.join(tmp, "START_PHASE11.md"), encoding="utf-8").read()
            self.assertIn("không cần mở cửa sổ mới", st)
            self.assertNotIn("Ứng dụng Claude: mở cuộc trò chuyện mới", st)
        finally:
            shutil.rmtree(tmp)

    def test_skill_core(self):
        t = skill_text()
        self.assertIn("Never propose a new chat, window or `/clear`", t)
        self.assertIn("Phase 11 — Graphics (same chat", t)


if __name__ == "__main__":
    unittest.main()
