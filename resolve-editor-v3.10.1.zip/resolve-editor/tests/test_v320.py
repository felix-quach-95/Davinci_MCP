"""v3.2.0: editorial intelligence, 30 s cap, E0a/E0b opening gates, repeat checks."""
import json
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


NEW = ["footage-intelligence.md", "story-decision-framework.md", "shot-selection-and-continuity.md",
       "editorial-decision-and-qc.md"]


class Docs(unittest.TestCase):
    def test_four_modules_exist_and_are_routed(self):
        router = text("references/phases/router.md")
        for n in NEW:
            self.assertTrue(os.path.exists(os.path.join(ROOT, "references", n)), n)
            self.assertIn(n, router)

    def test_integration_points(self):
        pairs = {"references/phases/phase-03.md": "footage-intelligence.md",
                 "references/phases/footage-subagent.md": "footage-intelligence.md",
                 "references/phases/phase-04.md": "story-decision-framework.md",
                 "references/story-structure.md": "story-decision-framework.md",
                 "references/phases/phase-05.md": "shot-selection-and-continuity.md",
                 "references/broll.md": "shot-selection-and-continuity.md",
                 "references/phases/phase-06.md": "editorial-decision-and-qc.md",
                 "references/phases/phase-09.md": "editorial-decision-and-qc.md",
                 "references/review-scorecard.md": "editorial-decision-and-qc.md"}
        for f, ref in pairs.items():
            self.assertIn(ref, text(f), f)

    def test_required_content(self):
        fi = text("references/footage-intelligence.md")
        for n in ("SEEN", "INFERRED", "UNVERIFIED", "Begin", "Peak", "keep", "grp", "C03.S02", "hook", "ending"):
            self.assertIn(n, fi)
        sd = text("references/story-decision-framework.md")
        for n in ("story contract", "Causal", "Associative", "Definition of ready", "30 s"):
            self.assertIn(n.lower(), sd.lower())
        ss = text("references/shot-selection-and-continuity.md")
        for n in ("rejected", "30°", "eye trace", "Match on action", "Shot–reverse-shot", "zoom out"):
            self.assertIn(n.lower(), ss.lower())
        eq = text("references/editorial-decision-and-qc.md")
        for n in ("Early cut", "Late cut", "Spare shot", "Too many effects", "Hook", "scope", "Retention"):
            self.assertIn(n.lower(), eq.lower())

    def test_opening_gates_documented(self):
        pb = text("references/options-playbook.md")
        self.assertIn("Style choice", pb)
        self.assertIn("Music request", pb)
        self.assertIn("Tự viết phong cách", pb)
        self.assertNotIn("Tôi gửi bài của tôi", pb)          # v3.3.0: no music options
        core = text("SKILL.md")
        self.assertIn("Style choice", core)
        self.assertIn("Music request", core)
        self.assertLess(len(core.split()), 2000)
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["workflow"]["max_runtime_s"], 30)
        self.assertEqual(d["scripts"]["edit_analysis.py"]["MAX_RUNTIME_S"], "${workflow.max_runtime_s}")

    def test_cinematic_priority(self):
        m = text("references/motion-effects.md")
        self.assertIn("Cinematic priority", m)
        for n in ("Speed ramp", "Zoom in", "Zoom out"):
            self.assertIn(n, m)


class RepeatReport(unittest.TestCase):
    def setUp(self):
        self.E = load("edit_analysis.py")

    def seg(self, i, clip="a.mov", a=0, b=48, **kw):
        return dict({"id": i, "clip": clip, "src_in": a, "src_out": b, "dur": 48, "track": 1}, **kw)

    def test_clean_blueprint_has_no_repeat_flags(self):
        segs = [self.seg("s1", a=0, b=48, shot="C1.S1", grp="G1", info="a", size="WS", why="x"),
                self.seg("s2", a=48, b=96, shot="C1.S2", grp="G2", info="b", size="CU", why="x")]
        self.assertEqual(self.E["repeat_report"](segs), [])

    def test_source_overlap_same_group_same_info_flagged(self):
        segs = [self.seg("s1", a=0, b=48, shot="C1.S1", grp="G1", info="a", why="x"),
                self.seg("s2", a=40, b=90, shot="C1.S2", grp="G1", info="a", why="x")]
        out = " ".join(self.E["repeat_report"](segs))
        self.assertIn("source frames", out)
        self.assertIn("image group", out)
        self.assertIn("information", out)

    def test_boundary_frames_and_callback_are_not_repeats(self):
        segs = [self.seg("s1", a=0, b=48, shot="C1.S1", grp="G1", why="x"),
                self.seg("s2", a=48, b=96, shot="C1.S2", grp="G2", why="x"),
                self.seg("s3", a=0, b=48, shot="C1.S1", grp="G1", callback=True, why="x")]
        self.assertEqual(self.E["repeat_report"](segs), [])

    def test_pattern_run_and_missing_why(self):
        segs = [self.seg("s%d" % i, clip="c%d" % i, size="WS", shot="C%d.S1" % i) for i in range(3)]
        out = " ".join(self.E["repeat_report"](segs))
        self.assertIn("3 shots in a row with size WS", out)
        self.assertIn("no `why`", out)

    def test_runtime_cap_in_analyse(self):
        bp = {"expected_fps": 24, "segments": [self.seg("s%d" % i, clip="c%d" % i, a=0, b=48, dur=48 * 8) for i in range(3)]}
        res = self.E["analyse"](bp, {}, 24)
        self.assertTrue(any("above the 30 s maximum" in n for n in res["notes"]))


if __name__ == "__main__":
    unittest.main()
