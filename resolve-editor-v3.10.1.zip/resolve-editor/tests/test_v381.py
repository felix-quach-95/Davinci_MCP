"""v3.8.1: HyperFrames release check against Motion Studio's pin."""
import os
import shutil
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load():
    p = os.path.join(ROOT, "scripts", "install_motion_studio.py")
    g = {"__name__": "offline", "__file__": p}
    exec(compile(open(p, encoding="utf-8").read(), p, "exec"), g)
    return g


class HFVersion(unittest.TestCase):
    def setUp(self):
        self.I = load()
        self.t = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.t)

    def put(self, name, ver):
        os.makedirs(os.path.join(self.t, name))
        open(os.path.join(self.t, name, "SKILL.md"), "w").write("npx hyperframes@%s render" % ver)

    def test_none_ok_mismatch(self):
        self.assertEqual(self.I["hf_check"](self.t)["status"], "NONE")
        pin = self.I["pinned"]()
        self.put("hyperframes", pin)
        self.assertEqual(self.I["hf_check"](self.t)["status"], "OK")
        self.put("media-use", "1.2.3")
        r = self.I["hf_check"](self.t)
        self.assertEqual((r["status"], r["differs"]), ("NEEDS_UPDATE", {"media-use": ["1.2.3"]}))

    def test_move_aside_keeps_files(self):
        self.put("hyperframes", "1.2.3")
        r = self.I["hf_move_aside"](self.t)
        self.assertEqual(r["moved"], ["hyperframes"])
        self.assertFalse(os.path.exists(os.path.join(self.t, "hyperframes")))
        self.assertTrue(os.path.isfile(os.path.join(r["backup"], "hyperframes", "SKILL.md")))
        self.assertIn("--update", r["next"])

    def test_card_asks_first(self):
        t = open(os.path.join(ROOT, "references", "phases", "phase-11.md"), encoding="utf-8").read()
        self.assertIn("--check-hf", t)
        self.assertIn("install.sh --update", t)


if __name__ == "__main__":
    unittest.main()
