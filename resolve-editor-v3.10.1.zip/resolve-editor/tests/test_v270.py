"""v2.7.0: finishing pass after the BoConCN live run — boot.py, preflight warnings, edit_analysis false
flags, frame_probe proxies/range, replace_shot SHOTS, warm_soft look."""
import json
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


def src(name):
    return open(os.path.join(SCRIPTS, name), encoding="utf-8").read()


class Boot(unittest.TestCase):
    def test_boot_marker_matches_loader(self):
        self.assertIn('marker = "\\nimport json\\nimport re\\n"', src("boot.py"))
        self.assertIn("\nimport json\nimport re\n", src("loader.py"))

    def test_boot_settings_follow_the_loader_config(self):
        """The settings boot.py writes after the loader's CONFIG block must win (plain later assignments)."""
        loader = src("loader.py")
        cfg = "MODE='config'\nTOOL=''\nPROJECT=''\nOVERRIDES={}\nPROJECT_DATA={}\nTOOLS_DIR='/x'\n"
        new = loader.replace("\nimport json\nimport re\n", "\n" + cfg + "import json\nimport re\n", 1)
        g = {"__name__": "offline"}
        exec(compile(new, "loader", "exec"), g)
        self.assertEqual((g["MODE"], g["TOOLS_DIR"]), ("config", "/x"))


class Preflight(unittest.TestCase):
    def setUp(self):
        self.I = load("inventory.py")

    def test_empty_pool(self):
        w = self.I["preflight_warnings"]({"timelineFrameRate": 24}, [], [])
        self.assertTrue(w[0].startswith("EMPTY_MEDIA_POOL"))

    def test_fps_mismatch_before_any_timeline(self):
        clips = [{"kind": "video", "FPS": 25.0}] * 5
        ps = {"timelineFrameRate": 24.0, "timelineResolutionWidth": "2160", "timelineResolutionHeight": "3840"}
        w = self.I["preflight_warnings"](ps, clips, [])
        self.assertEqual(len(w), 1)
        self.assertIn("FPS_MISMATCH", w[0])
        self.assertIn("no timeline yet", w[0])

    def test_high_frame_rate_for_slow_motion_is_fine(self):
        clips = [{"kind": "video", "FPS": 50.0}] * 3
        ps = {"timelineFrameRate": 25.0, "timelineResolutionWidth": "1080", "timelineResolutionHeight": "1920"}
        self.assertEqual(self.I["preflight_warnings"](ps, clips, [{"name": "x"}]), [])

    def test_landscape_project(self):
        clips = [{"kind": "video", "FPS": 25.0}]
        ps = {"timelineFrameRate": 25.0, "timelineResolutionWidth": "3840", "timelineResolutionHeight": "2160"}
        self.assertIn("LANDSCAPE_PROJECT", self.I["preflight_warnings"](ps, clips, [])[0])


class EditAnalysisFlags(unittest.TestCase):
    def setUp(self):
        self.E = load("edit_analysis.py")

    def test_far_apart_pov_shots_are_an_ellipsis(self):
        segs = [{"id": "s04", "clip": "A", "src_in": 4440, "src_out": 4465, "size": "WS", "cut": {}},
                {"id": "s05", "clip": "A", "src_in": 9896, "src_out": 9922, "size": "WS", "cut": {}},
                {"id": "s06", "clip": "A", "src_in": 9930, "src_out": 9960, "size": "WS", "cut": {}}]
        flags = self.E["continuity_report"](segs, 0.45, {"A": 25.0})
        self.assertEqual(len(flags), 1)                 # only s05 -> s06 (0.3 s apart) is a jump cut
        self.assertIn("s05→s06", flags[0])

    def test_emotional_payoff_may_cut_slower(self):
        def seg(i, sec, reason, n):
            return {"id": i, "clip": "c", "src_in": 0, "src_out": n, "dur": n, "section": sec,
                    "cut": {"reason": reason}}
        bp = {"arc": {"hook": 2, "payoff": 4},
              "segments": [seg("a", "hook", "rhythm", 25), seg("b", "hook", "rhythm", 25),
                           seg("c", "payoff", "emotion", 50), seg("d", "payoff", "emotion", 50)]}
        r = self.E["analyse"](bp, {"c": 25.0}, 25.0)
        self.assertFalse(any("cuts no faster" in f for f in r["pacing"]["flags"]), r["pacing"]["flags"])
        for s in bp["segments"][2:]:
            s["cut"]["reason"] = "rhythm"
        r2 = self.E["analyse"](bp, {"c": 25.0}, 25.0)
        self.assertTrue(any("cuts no faster" in f for f in r2["pacing"]["flags"]))


class FrameProbe(unittest.TestCase):
    def setUp(self):
        self.F = load("frame_probe.py")

    def test_range_points(self):
        self.assertEqual(self.F["range_points"](1600, 2050, 150), [1600, 1750, 1900, 2050])
        self.assertEqual(self.F["range_points"](5, 5, 0), [5])

    def test_proxy_candidates(self):
        c = self.F["proxy_candidates"]("/f/DJI_0001_D.MP4")
        self.assertEqual(c[0], "/f/DJI_0001_D.LRF")

    def test_budget_and_label_config(self):
        for name in ("BUDGET_SEC", "USE_PROXY", "LABEL", "WORKERS", "RANGE", "MODE"):
            self.assertIn(name, self.F)
        self.assertNotIn("fps=", src("frame_probe.py").split("# ---------------------------------------------------------------------------")[1].split("try:\n    resolve")[0])


class ReplaceAndLook(unittest.TestCase):
    def test_replace_shot_has_shots_list(self):
        g = load("replace_shot.py")
        self.assertEqual(g["SHOTS"], [])
        self.assertIn("targets = [(sh, items[int(sh[\"index\"]) - 1]) for sh in shots]", src("replace_shot.py"))

    def test_warm_soft_look(self):
        g = load("color_look.py")
        self.assertEqual(g["choose_lut"]("rec709", "warm_soft")[0], "MCP/claude_warm_soft_rec709_v1.cube")
        lut, note = g["choose_lut"]("slog3", "warm_soft")
        self.assertIn("conversion only", note)          # LOG still gets its conversion first


class Version(unittest.TestCase):
    def test_versions_agree(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        skill = open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8").read()
        self.assertIn("# Resolve Editor — v%s" % d["version"], skill)


if __name__ == "__main__":
    unittest.main()
