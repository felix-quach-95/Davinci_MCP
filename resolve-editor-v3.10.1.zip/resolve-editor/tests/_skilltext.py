"""v3.0.2: the skill text is the core SKILL.md plus the phase cards and the router (split for token use)."""
import glob
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def skill_text():
    parts = [open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8").read()]
    for p in sorted(glob.glob(os.path.join(ROOT, "references", "phases", "*.md"))):
        parts.append(open(p, encoding="utf-8").read())
    return "\n".join(parts)
