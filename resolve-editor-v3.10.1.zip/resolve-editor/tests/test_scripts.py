"""Offline tests for the helper scripts. Run: python3 tests/test_scripts.py
A small mock of the Resolve API exercises build_from_blueprint.py, qa_audit.py and
the text engine's planning helpers; pure helpers are tested directly. No Resolve needed."""
import math, os, sys, types, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(HERE, "..", "scripts")


def load(name, extra=None):
    g = {"__name__": "loaded"}
    if extra:
        g.update(extra)
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    exec(compile(src, name, "exec"), g)
    return g


def load_with_config(name, replacements, extra):
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    for a, b in replacements:
        assert a in src, "config anchor missing in %s: %r" % (name, a[:40])
        src = src.replace(a, b)
    g = {"__name__": "loaded"}
    g.update(extra)
    exec(compile(src, name, "exec"), g)
    return g


# ----------------------------------------------------------------- mock API
class MPI:
    def __init__(self, name, frames, res="3840x2160", fps=30, typ="Video + Audio"):
        self.name, self.frames, self.res, self.fps, self.typ = name, frames, res, fps, typ
        self.id = "id-" + name

    def GetName(self): return self.name
    def GetMediaId(self): return self.id
    def GetUniqueId(self): return self.id

    def GetClipProperty(self, key=None):
        d = {"File Name": self.name, "File Path": "/src/" + self.name, "Frames": str(self.frames),
             "Resolution": self.res, "FPS": self.fps, "Type": self.typ, "Start TC": "00:00:00:00"}
        return d.get(key) if key else d


class Folder:
    def __init__(self, clips, subs=()):
        self.clips, self.subs = clips, list(subs)
    def GetClipList(self): return self.clips
    def GetSubFolderList(self): return self.subs
    def GetName(self): return "Master"


class Item:
    _n = 0

    def __init__(self, tl, mpi, a, b, s_in, ttype, idx, name=None):
        Item._n += 1
        self.uid = "item%d" % Item._n
        self.tl, self.mpi, self.a, self.b, self.s_in = tl, mpi, a, b, s_in
        self.ttype, self.idx = ttype, idx
        self.props, self.speed, self.fades = {"Scaling": 0, "ZoomX": 1.0}, 100.0, {"FadeIn": 0, "FadeOut": 0}
        self.name = name or (mpi.GetName() if mpi else "Text+")
        self.comp = None

    def GetName(self): return self.name
    def SetName(self, n): self.name = n; return True
    def GetUniqueId(self): return self.uid
    def GetStart(self, *a): return self.a
    def GetEnd(self, *a): return self.b
    def GetDuration(self, *a): return self.b - self.a
    def GetSourceStartFrame(self): return self.s_in
    def GetSourceEndFrame(self): return self.s_in + int(round((self.b - self.a) * self.speed / 100.0))
    def GetMediaPoolItem(self): return self.mpi
    def GetTrackTypeAndIndex(self): return [self.ttype, self.idx]
    def GetProperties(self): return dict(self.props)
    def SetProperties(self, p): self.props.update(p); return True
    def GetSpeed(self): return {"Percentage": self.speed}

    def SetSpeed(self, o):
        old = self.b - self.a
        self.speed = o["Percentage"]
        self.b = self.a + int(round(old * 100.0 / self.speed))
        return True

    def GetFades(self): return dict(self.fades)
    def SetFades(self, f): self.fades.update(f); return True
    def GetFusionCompByIndex(self, i): return self.comp


class Input:
    def __init__(self): self.keys = {}
    def GetKeyFrames(self): return {i + 1: k for i, k in enumerate(sorted(self.keys))}


class TextTool:
    def __init__(self):
        self.vals, self.inputs = {}, {}

    def SetInput(self, k, v, t=None):
        if t is None:
            self.vals[k] = v
        else:
            self.inputs.setdefault(k, Input()).keys[t] = v

    def GetInput(self, k, t=None):
        if k in self.inputs and self.inputs[k].keys:
            ks = sorted(self.inputs[k].keys)
            t = ks[0] if t is None else t
            prev = [x for x in ks if x <= t] or ks[:1]
            return self.inputs[k].keys[prev[-1]]
        return self.vals.get(k)

    def AddModifier(self, inp, mod):
        self.inputs.setdefault(inp, Input()); return True

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        return self.inputs.setdefault(k, Input())


class Comp:
    def __init__(self): self.tool = TextTool()
    def GetToolList(self, sel, regid=None): return {1: self.tool}
    def StartUndo(self, n): pass
    def EndUndo(self, k): pass


class Timeline:
    def __init__(self, name, inclusive=True):
        self.name, self.inclusive = name, inclusive
        self.start = 108000
        self.tracks = {"video": [[]], "audio": [[]], "subtitle": []}
        self.names, self.locks, self.markers = {}, {}, {}
        self.playhead = self.start

    def GetName(self): return self.name
    def GetUniqueId(self): return "tl-" + self.name
    def GetStartFrame(self): return self.start
    def GetStartTimecode(self): return "01:00:00:00"

    def GetEndFrame(self):
        ends = [it.b for t in self.tracks.values() for tr in t for it in tr]
        return max(ends, default=self.start)

    def GetSettings(self): return {"timelineFrameRate": 30.0}
    def GetTrackCount(self, t): return len(self.tracks[t])
    def GetItemListInTrack(self, t, i): return sorted(self.tracks[t][i - 1], key=lambda x: x.a)
    def AddTrack(self, t, sub=None): self.tracks[t].append([]); return True
    def SetTrackName(self, t, i, n): self.names[(t, i)] = n; return True
    def GetTrackName(self, t, i): return self.names.get((t, i), "")
    def GetIsTrackEnabled(self, t, i): return True
    def GetIsTrackLocked(self, t, i): return self.locks.get((t, i), False)
    def SetTrackLock(self, t, i, v): self.locks[(t, i)] = v; return True
    def AddMarker(self, f, c, n, note, d, cd=None): self.markers[f] = n; return True
    def GetMarkers(self): return self.markers

    def DeleteClips(self, items, ripple=False):
        for it in items:
            self.tracks[it.ttype][it.idx - 1].remove(it)
        return True

    def SetCurrentTimecode(self, tc):
        hh, mm, ss, ff = [int(x) for x in tc.split(":")]
        self.playhead = ((hh * 60 + mm) * 60 + ss) * 30 + ff
        return True

    def InsertFusionTitleIntoTimeline(self, name):
        free = [i for i in range(1, len(self.tracks["video"]) + 1) if not self.locks.get(("video", i))]
        if not free:
            return None
        idx = free[0]
        it = Item(self, None, self.playhead, self.playhead + 150, 0, "video", idx, "Text+")
        it.comp = Comp()
        self.tracks["video"][idx - 1].append(it)
        return it


class MediaPool:
    def __init__(self, project, clips):
        self.project, self.root = project, Folder(clips)

    def GetRootFolder(self): return self.root

    def CreateEmptyTimeline(self, name):
        tl = Timeline(name, self.project.inclusive)
        self.project.timelines.append(tl)
        return tl

    def AppendToTimeline(self, infos):
        tl = self.project.cur
        out = []
        for d in infos:
            a, b = d["startFrame"], d["endFrame"]
            n = int(b - a + (1 if tl.inclusive else 0))
            n = int(round(n * 30.0 / float(d["mediaPoolItem"].fps or 30)))   # clip fps -> timeline frames
            mt = d.get("mediaType")
            types_ = ["video"] if mt == 1 else ["audio"] if mt == 2 else ["video", "audio"]
            for t in types_:
                idx = d.get("trackIndex", 1)
                while len(tl.tracks[t]) < idx:
                    tl.tracks[t].append([])
                it = Item(tl, d["mediaPoolItem"], int(d["recordFrame"]), int(d["recordFrame"]) + n,
                          int(a), t, idx)
                tl.tracks[t][idx - 1].append(it)
                out.append(it)
        return out


class Project:
    def __init__(self, clips, inclusive=True):
        self.inclusive = inclusive
        self.timelines, self.cur = [], None
        self.mp = MediaPool(self, clips)

    def GetMediaPool(self): return self.mp
    def GetTimelineCount(self): return len(self.timelines)
    def GetTimelineByIndex(self, i): return self.timelines[i - 1]
    def GetCurrentTimeline(self): return self.cur
    def SetCurrentTimeline(self, tl): self.cur = tl; return True


class Resolve:
    SCALE_FIT = 2.0
    SCALE_FILL = 3.0
    RETIME_OPTICAL_FLOW = 3.0
    RETIME_FRAME_BLEND = 2.0
    RETIME_NEAREST = 1.0


def blueprint_src():
    return '''BLUEPRINT = {
    "timeline_name": "DRAFT_Test_v01", "expected_fps": 30, "target_frames": 240,
    "fit_landscape": True, "retime": "optical_flow", "video_tracks": 3, "audio_tracks": 3,
    "track_names": {"video": {"1": "FOOTAGE"}, "audio": {"2": "MUSIC"}},
    "segments": [
        {"id": "s01", "clip": "A.MP4", "src_in": 0, "src_out": 60, "track": 1, "record": "auto",
         "media": "video", "marker": {"color": "Blue", "name": "HOOK"}},
        {"id": "s02", "clip": "B.MP4", "src_in": 100, "src_out": 160, "track": 1, "record": "auto",
         "media": "video", "speed": 50},
        {"id": "s03", "clip": "A.MP4", "src_in": 200, "src_out": 260, "track": 1, "record": "auto",
         "media": "video", "props": {"ZoomX": 1.15, "ZoomY": 1.15}},
    ],
    "audio": [
        {"id": "m01", "clip": "music.mp3", "src_in": 0, "src_out": 240, "track": 2, "record": 0,
         "volume": -12.0, "fades": {"FadeIn": 6, "FadeOut": 30}},
    ],
}'''


def clips():
    return [MPI("A.MP4", 900), MPI("B.MP4", 900, res="1080x1920"),
            MPI("music.mp3", 5000, res="", typ="Âm thanh"), MPI("HFR.mov", 1000, fps=50, typ="Hình ảnh")]


class BuildTests(unittest.TestCase):
    def build(self, inclusive=True, bp=None):
        proj = Project(clips(), inclusive)
        src = open(os.path.join(SCRIPTS, "build_from_blueprint.py"), encoding="utf-8").read()
        start = src.index("BLUEPRINT = {")
        stop = src.index("DRY_RUN =")
        src = src[:start] + (bp or blueprint_src()) + "\n" + src[stop:]
        g = {"resolve": Resolve(), "project": proj}
        exec(compile(src, "build", "exec"), g)
        return g["result"], proj

    def test_build_inclusive_api(self):
        r, proj = self.build(True)
        self.assertIn("endFrame convention: inclusive", r["log"])
        self.assertEqual(r["status"], "BUILT_READ_BACK", r.get("errors"))
        v1 = r["readback"]["V1"]
        self.assertEqual([x["dur"] for x in v1], [60, 120, 60])     # 50 % doubles s02
        self.assertEqual([x["start"] for x in v1], [0, 60, 180])    # auto placement follows real ends
        self.assertEqual(v1[0]["scaling"], Resolve.SCALE_FIT)       # landscape fitted
        self.assertNotEqual(v1[1]["scaling"], Resolve.SCALE_FIT)    # portrait untouched
        self.assertEqual(v1[2]["zoom"], 1.15)
        self.assertEqual(r["readback"]["A2"][0]["volume"], -12.0)
        self.assertEqual(r["timeline_frames"], 240)
        self.assertEqual(r["markers"], 1)

    def test_build_exclusive_api_detected(self):   # the real 21.1.1 behaviour
        r, proj = self.build(False)
        self.assertIn("endFrame convention: exclusive", r["log"])
        self.assertEqual([x["dur"] for x in r["readback"]["V1"]], [60, 120, 60])
        self.assertEqual(r["status"], "BUILT_READ_BACK", r.get("errors"))

    def test_fill_is_default(self):
        bp = blueprint_src().replace('"fit_landscape": True,', '')
        r, proj = self.build(False, bp)
        self.assertEqual(r["readback"]["V1"][0]["scaling"], Resolve.SCALE_FILL)

    def test_mixed_fps_clip(self):
        bp = blueprint_src().replace('"segments": [', '''"segments": [
        {"id": "h01", "clip": "HFR.mov", "src_in": 0, "src_out": 100, "track": 1, "record": "auto",
         "media": "video", "speed": 60},''')
        bp = bp.replace('"target_frames": 240', '"target_frames": 340')
        r, proj = self.build(False, bp)   # exclusive = measured 21.1.1 behaviour
        self.assertEqual(r["status"], "BUILT_READ_BACK", r.get("errors"))
        v1 = r["readback"]["V1"]
        self.assertEqual(v1[0]["dur"], 100)          # 100 src @50fps = 60 tl frames, at 60 % = 100
        self.assertEqual(r["planned_frames_at_expected_fps"], 340)
        self.assertIn("endFrame convention: exclusive", r["log"])   # detected on the next same-rate clip

    def test_kind_is_language_independent(self):
        g = load("inventory.py")
        self.assertEqual(g["clip_kind"]({"File Path": "/a.mov", "Resolution": "3840x2160",
                                         "Video Codec": "Apple ProRes 4444", "Frames": "148", "Type": "Hình ảnh"}), "video")
        self.assertEqual(g["clip_kind"]({"File Path": "/m.mp3", "Resolution": "", "Frames": "", "Type": "Âm thanh"}), "audio")
        self.assertEqual(g["clip_kind"]({"File Path": "", "Resolution": "2160x3840", "Video Codec": "", "Type": "Timeline"}), "timeline")

    def test_stops_on_bad_range(self):
        bad = blueprint_src().replace('"src_in": 200, "src_out": 260', '"src_in": 880, "src_out": 960')
        r, proj = self.build(True, bad)
        self.assertEqual(r["status"], "STOPPED_BEFORE_WRITE")
        self.assertEqual(proj.GetTimelineCount(), 0)

    def test_unique_name(self):
        r1, proj = self.build(True)
        src = open(os.path.join(SCRIPTS, "build_from_blueprint.py"), encoding="utf-8").read()
        g = {}
        exec(compile(src.split('try:\n    resolve  #')[0], "b", "exec"), g)
        self.assertEqual(g["_unique_name"](proj, "DRAFT_Test_v01"), "DRAFT_Test_v02")

    def test_qa_after_build(self):
        r, proj = self.build(True)
        src = open(os.path.join(SCRIPTS, "qa_audit.py"), encoding="utf-8").read()
        src = src.replace("TARGET_FRAMES = None ", "TARGET_FRAMES = 240 ")
        g = {"resolve": Resolve(), "project": proj}
        exec(compile(src, "qa", "exec"), g)
        q = g["result"]
        self.assertEqual(q["checks"]["runtime"]["ok"], True)
        self.assertEqual(q["checks"]["video_gaps_footage"]["ok"], True)
        self.assertEqual(q["checks"]["audio_continuity"]["ok"], True)
        self.assertEqual(q["verdict"], "STRUCTURAL PASS", q["checks"])

    def test_qa_detects_gap_and_silence(self):
        bp = blueprint_src().replace('"record": "auto",\n         "media": "video", "speed": 50',
                                     '"record": 90,\n         "media": "video", "speed": 50')
        bp = bp.replace('"src_out": 240, "track": 2', '"src_out": 150, "track": 2')
        r, proj = self.build(True, bp)
        src = open(os.path.join(SCRIPTS, "qa_audit.py"), encoding="utf-8").read()
        g = {"resolve": Resolve(), "project": proj}
        exec(compile(src, "qa", "exec"), g)
        q = g["result"]
        self.assertFalse(q["checks"]["video_gaps_footage"]["ok"])
        self.assertIn((60, 90), [tuple(x) for x in q["checks"]["video_gaps_footage"]["holes"]])
        self.assertFalse(q["checks"]["audio_continuity"]["ok"])
        self.assertTrue(q["verdict"].startswith("FAIL"))




class ToolTests(unittest.TestCase):

    def _bmp(self, path, w, h, rects, bg=(0, 0, 0)):
        import struct
        stride = (w * 3 + 3) & ~3
        rows = []
        for y in range(h):
            row = bytearray()
            for x in range(w):
                c = bg
                for (x0, y0, x1, y1, col) in rects:
                    if x0 <= x <= x1 and y0 <= y <= y1:
                        c = col
                row += bytes((c[2], c[1], c[0]))
            row += b"\0" * (stride - w * 3)
            rows.append(bytes(row))
        data = b"".join(reversed(rows))
        hdr = struct.pack("<2sIHHI", b"BM", 54 + len(data), 0, 0, 54) + struct.pack("<IiiHHIIiiII", 40, w, h, 1, 24, 0, len(data), 0, 0, 0, 0)
        open(path, "wb").write(hdr + data)





class PureTests(unittest.TestCase):
    def test_srt_remap_and_grouping(self):
        g = load("srt_from_transcript.py")
        tr = {"segments": [
            {"start": "00:00:01:00", "end": "00:00:03:00", "text": "xin chào các bạn",
             "words": [{"start": "00:00:01:00", "end": "00:00:01:10", "text": "xin"},
                       {"start": "00:00:01:10", "end": "00:00:01:20", "text": "chào"},
                       {"start": "00:00:01:20", "end": "00:00:02:00", "text": "các"},
                       {"start": "00:00:02:00", "end": "00:00:02:15", "text": "bạn."}]},
            {"start": "00:00:05:00", "end": "00:00:06:00", "text": "bị cắt",
             "words": [{"start": "00:00:05:00", "end": "00:00:05:15", "text": "bị"},
                       {"start": "00:00:05:15", "end": "00:00:06:00", "text": "cắt"}]}]}
        words = g["words_from_transcription"](tr, "00:00:00:00", 30)
        rw = g["remap"](words, [{"src_in": 30, "src_out": 90, "record": 0}])
        self.assertEqual([w[2] for w in rw], ["xin", "chào", "các", "bạn."])
        self.assertEqual(rw[0][0], 0)
        cues = g["group_lines"](rw, 30)
        self.assertEqual(len(cues), 1)
        srt = g["to_srt"](cues, 30)
        self.assertIn("00:00:00,000 -->", srt)
        self.assertIn("xin chào các bạn.", srt)

    def test_silence_parse(self):
        g = load("silence_beats.py")
        txt = "[silencedetect @ x] silence_start: 1.25\n[silencedetect @ x] silence_end: 2.5 | silence_duration: 1.25\n"
        self.assertEqual(g["parse_silencedetect"](txt), [(1.25, 2.5)])

    def test_tempo_on_synthetic_clicks(self):
        g = load("silence_beats.py")
        sr, bpm, secs = 11025, 120.0, 12
        x = [0.0] * (sr * secs)
        step = int(sr * 60 / bpm)
        for start in range(int(0.25 * sr), len(x), step):
            for i in range(200):
                if start + i < len(x):
                    x[start + i] = math.sin(i * 0.9) * (1 - i / 200.0)
        env = g["onset_envelope"](x)
        est, off, conf = g["estimate_tempo"](env)
        self.assertTrue(abs(est - 120) < 3 or abs(est - 60) < 2 or abs(est - 240) < 4, est)
        self.assertLess(abs(off % (60 / est) - 0.25 % (60 / est)), 0.03)

    def test_qa_helpers(self):
        g = load("qa_audit.py")
        self.assertEqual(g["holes"]([(0, 10), (12, 20)], 0, 25), [(10, 12), (20, 25)])
        self.assertEqual(g["overlaps"]([(0, 10), (8, 20)]), [(10, 8)])
        reps = g["adjacent_repeats"]([{"name": "a", "clip": "X", "src_in": 0, "src_out": 50},
                                      {"name": "b", "clip": "X", "src_in": 40, "src_out": 90}])
        self.assertEqual(reps, [("a", "b")])

    def test_music_check(self):
        g = load("qa_audit.py")
        A = {2: [{"a": 0, "b": 30, "fades": {}}], 3: [{"a": 0, "b": 382, "fades": {"FadeIn": 0, "FadeOut": 0}}]}
        r = g["music_check"](A, [3], 383)["music"]
        self.assertFalse(r["ok"])
        A[3][0]["fades"]["FadeOut"] = 36
        self.assertTrue(g["music_check"](A, [3], 383)["music"]["ok"])

    def test_auto_frames(self):
        g = load("qc_stills.py")
        fr = g["auto_frames"]([0, 60, 120], [(10, 100)], 240, {"cuts": True, "cut_offsets": [-1, 1],
                                                              "first_last": True, "titles": True, "max_frames": 24})
        self.assertEqual(fr, [0, 24, 59, 61, 119, 121, 239])

    def test_sample_points(self):
        g = load("frame_probe.py")
        p = g["sample_points"](300, 4)
        self.assertEqual(len(p), 4)
        self.assertTrue(p[0] >= 9 and p[-1] <= 290)

    def test_planned_length(self):
        g = {}
        src = open(os.path.join(SCRIPTS, "build_from_blueprint.py"), encoding="utf-8").read()
        exec(compile(src.split('try:\n    resolve  #')[0], "b", "exec"), g)
        bp = {}
        exec(blueprint_src(), {}, bp)
        self.assertEqual(g["planned_length"](bp["BLUEPRINT"]), 240)
        # v2.1: "dur" wins, and a ramp's dur covers all of its steps (HongKong reported 212 for 431)
        ramp = {"segments": [
            {"id": "h", "clip": "c", "src_in": 0, "src_out": 60, "dur": 35,
             "ramp": [{"frames": 40, "speed": 300}, {"frames": 10, "speed": 150}, {"frames": 10, "speed": 60}]},
            {"id": "t", "clip": "c", "src_in": 0, "src_out": 80, "dur": 82, "speed": 46}]}
        self.assertEqual(g["planned_length"](g["expand_ramps"](ramp)), 117)



class LibraryTests(unittest.TestCase):
    """sfx_library.py, fx_library.py, fx_apply.py pure helpers (v1.6.0)."""

    def test_sfx_tags_word_boundaries(self):
        L = load("sfx_library.py")
        t = L["tags_for"]
        self.assertIn("whoosh", t("450 cinematic/Cinematic Whoosh Swoosh Sounds - pack 1/a.wav"))
        self.assertNotIn("hit", t("230 mixed sound effcts/white-tees-rizz.mp3"))      # "white" is not "hit"
        self.assertIn("meme", t("230 mixed sound effcts/white-tees-rizz.mp3"))
        self.assertNotIn("riser", t("misc/surprise.wav"))                              # "surprise" is not "rise"
        self.assertIn("weapon", t("Transition Sound Effects/gun3.mp3"))
        self.assertIn("ambience", t("336 SFX/ELEMENT/WATER/WATER 4.wav"))
        self.assertNotIn("ambience", t("Notification/Stylized/ESM_Waterside_07.wav"))

    def test_sfx_envelope_shapes(self):
        L = load("sfx_library.py")
        hit = [int(30000 * math.exp(-i / 800.0)) for i in range(8000)]
        rise = [int(30000 * i / 8000.0) * (1 if i % 2 else -1) for i in range(8000)]
        self.assertEqual(L["envelope_features"](hit, 8000)["shape"], "hit")
        r = L["envelope_features"](rise, 8000)
        self.assertEqual(r["shape"], "rise")
        self.assertGreater(r["peak_t"], 0.9)

    def test_sfx_rank_mood_filter_and_dedupe(self):
        L = load("sfx_library.py")
        files = {"A/Whoosh soft.wav": {"dur": 1.1, "shape": "swell", "feel": "soft"},
                 "B/Whoosh soft.wav": {"dur": 1.1, "shape": "swell", "feel": "soft"},
                 "memes/whoosh bruh.mp3": {"dur": 1.0, "shape": "swell", "feel": "soft"},
                 "C/whoosh tiny.wav": {"dur": 0.2, "shape": "hit", "feel": "punchy"}}
        got = [r for s, r, e in L["rank"](files, {"role": "whoosh", "mood": "soft", "n": 5})]
        self.assertEqual(got[0].rsplit("/", 1)[-1], "Whoosh soft.wav")
        self.assertEqual(sum(1 for r in got if r.endswith("Whoosh soft.wav")), 1)
        self.assertFalse(any("memes" in r for r in got))

    def test_sfx_placement(self):
        L = load("sfx_library.py")
        self.assertEqual(L["placement"]({"shape": "swell", "peak_t": 0.5}, 100, 24), 88)
        self.assertEqual(L["placement"]({"shape": "hit", "onset_t": 0.05, "peak_t": 0.06}, 100, 24), 99)

    def test_fx_parse_setting(self):
        F = load("fx_library.py")
        txt = ('{ Tools = ordered() { Loc = MacroOperator { Inputs = ordered() { Input1 = InstanceInput { SourceOp = "T", Source = "StyledText", Name = "Text", }, }, '
               'Tools = ordered() { T = TextPlus { Inputs = { StyledText = Input { Value = "NEW YORK", }, \n Font = Input { Value = "Poppins", },\n Style = Input { Value = "Bold", }, '
               'Width = Input { Value = 3840, }, Height = Input { Value = 2160, }, }, }, }, }, }, }')
        e = F["parse_setting"](txt, "Edit/Titles/Video Editor Studio/Free Starter Pack/05. Locations/Location 01.setting")
        self.assertEqual(e["kind"], "Title")
        self.assertIn("location", e["roles"])
        self.assertEqual(e["fonts"], [["Poppins", "Bold"]])
        self.assertEqual(e["design_res"], [3840, 2160])
        self.assertIn("Text", e["pub"])
        plan = F["font_plan"]([["Poppins", "Bold"], ["Roboto", "Black"]], {"Poppins": False, "Roboto": True})
        self.assertEqual(plan[0][2:4], ["Be Vietnam Pro", "Bold"])
        self.assertEqual(plan[1][4], "ok")






class QaEndingHoldTests(unittest.TestCase):
    def test_ending_hold_accepted_only_when_intentional(self):
        Q = load("qa_audit.py")
        f = Q["split_ending_hold"]
        self.assertEqual(f([[335, 378]], 378, 16, [], 48), ([], [335, 378]))
        self.assertEqual(f([[335, 378]], 378, 0, [], 48), ([[335, 378]], None))        # no fade -> real gap
        self.assertEqual(f([[335, 378]], 378, 16, [[340, 378]], 48), ([[335, 378]], None))  # silent -> real gap
        self.assertEqual(f([[100, 110], [335, 378]], 378, 16, [], 48), ([[100, 110]], [335, 378]))
        self.assertEqual(f([[300, 378]], 378, 16, [], 48), ([[300, 378]], None))        # too long


class EndingTests(unittest.TestCase):
    def setUp(self):
        self.E = load("ending_plan.py")
        self.env = [-90] * 3 + [-30, -28, -30, -34, -38, -42, -45] * 5     # a hit every 1.75 s

    def test_hits(self):
        self.assertEqual(self.E["detect_hits"](self.env), [3, 10, 17, 24, 31])

    def test_cut_after_hit_is_flagged_and_ring_out_found(self):
        r = self.E["plan_end"](self.env, 0.25, 4.27, lambda t: int(t * 24))
        self.assertIn("cut off", r["current_end"])
        self.assertEqual(r["HIT_CUT"]["music_s"], 4.25)
        self.assertGreater(r["RING_OUT"]["music_s"], 5.5)

    def test_quiet_end_is_natural_with_margin_warning(self):
        r = self.E["plan_end"](self.env, 0.25, 4.18, lambda t: int(t * 24))
        self.assertIn("natural", r["current_end"])
        self.assertIn("warning", r)
        r2 = self.E["plan_end"](self.env, 0.25, 4.1, lambda t: int(t * 24))
        self.assertNotIn("warning", r2)

    def test_fine_envelope_moves_hit_to_real_onset(self):   # v2.1: HongKong 21.25 -> 21.48 s
        fine = [-47.0] * 100 + [-27.0] * 20                     # real onset at step 100 = 2.00 s
        self.assertEqual(self.E["refine_hit"](fine, 0.02, 1.75), 2.0)
        self.assertEqual(self.E["refine_hit"]([-47.0] * 120, 0.02, 1.75), 1.75)   # no rise: unchanged
        coarse = [-47.0] * 7 + [-30.0] * 3                      # coarse hit reported at 1.75 s
        r = self.E["plan_end"](coarse, 0.25, 1.95, lambda t: int(t * 24), 6.0, fine, 0.02)
        self.assertNotIn("cut off", r["current_end"])           # the end is 0.05 s BEFORE the onset
        self.assertIn("warning", r)



class V2Tests(unittest.TestCase):
    """v2.0: ramps, dur fields, motion_fx planning, ramp-aware repeats."""

    def test_expand_ramps(self):
        B = load("build_from_blueprint.py")
        bp = {"segments": [{"id": "s1", "clip": "a", "src_in": 10, "src_out": 90, "dur": 35,
                            "fades": {"FadeIn": 4, "FadeOut": 6}, "marker": {"name": "X"},
                            "ramp": [{"frames": 40, "speed": 300}, {"frames": 10, "speed": 150}, {"frames": 30, "speed": 60}]}]}
        e = B["expand_ramps"](bp)["segments"]
        self.assertEqual([(x["src_in"], x["src_out"], x["speed"]) for x in e], [(10, 50, 300.0), (50, 60, 150.0), (60, 90, 60.0)])
        self.assertEqual(e[0].get("fades"), {"FadeIn": 4})
        self.assertEqual(e[-1].get("fades"), {"FadeOut": 6})
        self.assertEqual(e[-1].get("dur_total_of_ramp"), 35)
        self.assertEqual(e[1]["record"], "auto")

    def test_bad_ramp_is_a_problem(self):
        B = load("build_from_blueprint.py")
        bp = {"segments": [{"id": "s1", "clip": "a", "src_in": 0, "src_out": 50, "ramp": [{"frames": 10, "speed": 200}]}]}
        e = B["expand_ramps"](bp)
        self.assertTrue(any("ramp frames" in p for p in B["validate_blueprint"](e, {"a": 100})))

    def test_motion_fx_push_pivot_not_center(self):
        M = load("motion_fx.py")
        keys, static = M["fx_points"]({"fx": "push", "t1": 49, "a": 1.0, "b": 1.1, "center": [0.7, 0.55]}, 50)
        self.assertEqual(static[("Xf", "Pivot")], [0.7, 0.55])
        self.assertNotIn(("Xf", "Center"), static)            # Center is a translation, keep 0.5
        keys, static = M["fx_points"]({"fx": "push", "t1": 49, "center": [0.7, 0.55], "drift": [0.1, 0]}, 50)
        path = keys[("Xf", "Center@path")]
        self.assertEqual(path[0][1], (0.5, 0.5))
        self.assertAlmostEqual(path[-1][1][0], 0.6)

    def test_motion_fx_flash_uses_brightness(self):
        M = load("motion_fx.py")
        keys, _ = M["fx_points"]({"fx": "flash", "t": 10}, 40)
        self.assertIn(("Flash", "Brightness"), keys)

    def test_motion_fx_validate_and_mapping(self):
        M = load("motion_fx.py")
        self.assertTrue(M["validate"]([{"index": 1, "fx": "punch", "t": 70, "b": 1.5}], {(1, 1): 64}))
        self.assertEqual(M["validate"]([{"index": 1, "fx": "blur_in", "t1": 6}], {(1, 1): 64}), [])
        m = M["comp_mapper"](0, 24, 50)
        self.assertAlmostEqual(m(49), 24.0)

    def test_motion_fx_all_kinds_plan(self):
        M = load("motion_fx.py")
        for e in [{"fx": "pull", "t1": 30}, {"fx": "shake", "t": 5}, {"fx": "blur_out", "t0": 20, "t1": 30},
                  {"fx": "whip_in"}, {"fx": "whip_out"}, {"fx": "freeze", "t": 12},
                  {"fx": "spotlight", "t0": 2, "t1": 30, "center": [0.6, 0.5]}]:
            keys, _ = M["fx_points"](e, 40)
            self.assertTrue(keys, e["fx"])

    def test_qa_ramp_not_repeat(self):
        Q = load("qa_audit.py")
        items = [{"clip": "c", "name": "c", "src_in": 0, "src_out": 40}, {"clip": "c", "name": "c", "src_in": 39, "src_out": 49}]
        self.assertEqual(Q["adjacent_repeats"](items), [])
        items[1]["src_in"] = 20
        self.assertTrue(Q["adjacent_repeats"](items))



if __name__ == "__main__":
    unittest.main(verbosity=2)
