"""v2.6.2: fixes from the BoConCN live run — ending_plan hits/candidates, audio_presence joint check,
SFX levels from file loudness, sfx_library MODE place helpers."""
import json
import math
import os
import random
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


class EndingPlan(unittest.TestCase):
    def setUp(self):
        self.E = load("ending_plan.py")
        self.flat = [-20.0] * 160            # 40 s of steady music, 0.25 s steps: the detector finds nothing

    def test_catalog_hit_is_used_when_detector_misses_it(self):
        r = self.E["plan_end"](self.flat, 0.25, 30.4, lambda t: int(round(t * 25)), 6.0, extra_hits=[0.75, 19.25, 28.0])
        self.assertEqual(r["hits_s"], [28.0])
        self.assertEqual(r["hit_sources"], {"28.00": "catalog"})

    def test_no_candidate_outside_the_window(self):
        """BoConCN: no hits found -> it offered 'SHORT at 0.12 s / frame 3' for a 30 s video."""
        env = [-60.0] + [-20.0] * 159
        r = self.E["plan_end"](env, 0.25, 30.4, lambda t: int(t * 25), 6.0)
        self.assertNotIn("SHORT", r)
        self.assertTrue(r["current_end"].startswith("NO_HITS_NEAR_END"))

    def test_hit_then_fade_is_natural(self):
        r = self.E["plan_end"](self.flat, 0.25, 30.4, lambda t: int(t * 25), 6.0, extra_hits=[28.0], fade_out_s=1.6)
        self.assertIn("natural (hit + fade)", r["current_end"])
        r2 = self.E["plan_end"](self.flat, 0.25, 30.4, lambda t: int(t * 25), 6.0, extra_hits=[28.0])
        self.assertNotIn("hit + fade", r2["current_end"])

    def test_merge_dedupes_close_hits(self):
        m = self.E["merge_hits"]([28.1], [28.0, 19.25])
        self.assertEqual(m, [(19.25, "catalog"), (28.1, "detected")])


class AudioPresence(unittest.TestCase):
    def setUp(self):
        self.A = load("audio_presence.py")
        rnd = random.Random(7)
        n = 4000
        self.music = [math.sin(i * 0.07) * 0.5 + rnd.uniform(-0.2, 0.2) for i in range(n)]
        self.riser = [rnd.uniform(-1, 1) * (i / 1000.0) for i in range(1000)]

    def test_quiet_sfx_under_music_is_present(self):
        """BoConCN: raw corr 0.09 -> MISSING, although the fitted gain matched the item volume."""
        g_m, g_r = 10 ** (-9 / 20.0), 10 ** (-24 / 20.0)
        placed_r = self.A["place_ref"](4000, self.riser, 1500, 0)
        mix = [g_m * m + g_r * r for m, r in zip(self.music, placed_r)]
        raw, _ = self.A["xcorr_best"](mix[1500:2500], self.riser, 5)
        self.assertLess(abs(raw), 0.35)                       # the old verdict would not say "present"
        rows = self.A["joint_check"](mix, [self.music, placed_r], [-9.0, -24.0])
        self.assertTrue(rows[1]["verdict"].startswith("present"), rows[1])
        self.assertAlmostEqual(rows[1]["gain_db"], -24.0, delta=0.5)
        self.assertAlmostEqual(rows[0]["gain_db"], -9.0, delta=0.5)

    def test_absent_item_is_missing(self):
        placed_r = self.A["place_ref"](4000, self.riser, 1500, 0)
        mix = [10 ** (-9 / 20.0) * m for m in self.music]
        rows = self.A["joint_check"](mix, [self.music, placed_r], [-9.0, -14.0])
        self.assertEqual(rows[1]["verdict"], "MISSING")
        self.assertEqual(rows[0]["verdict"], "present")

    def test_buried_is_reported(self):
        g_r = 10 ** (-40 / 20.0)
        placed_r = self.A["place_ref"](4000, self.riser, 1500, 0)
        mix = [0.35 * m + g_r * r for m, r in zip(self.music, placed_r)]
        rows = self.A["joint_check"](mix, [self.music, placed_r], [-9.0, -40.0])
        self.assertIn("buried", rows[1]["verdict"])

    def test_start_has_fallback_recipes(self):
        src = open(os.path.join(SCRIPTS, "audio_presence.py"), encoding="utf-8").read()
        self.assertIn('"current_format"', src)
        self.assertIn("DeleteRenderJob", src)


class SfxLevelsAndPlace(unittest.TestCase):
    def setUp(self):
        self.S = load("sfx_library.py")
        self.levels = {"whoosh": -15, "riser": -14, "shimmer": -20, "ambience_open_air": -19}

    def test_quiet_file_is_raised(self):
        v, note = self.S["auto_level"]("riser", -28.6, self.levels, {"riser": -9.0})
        self.assertAlmostEqual(v, 5.6, places=1)            # −14 + (−9 − −28.6)
        self.assertIn("typical", note)
        v2, _ = self.S["auto_level"]("riser", -40.0, self.levels, {"riser": -9.0})
        self.assertEqual(v2, 10.0)                          # clamped

    def test_typical_file_keeps_the_table_level(self):
        v, _ = self.S["auto_level"]("whoosh", -10.0, self.levels, {"whoosh": -10.0})
        self.assertEqual(v, -15.0)
        self.assertEqual(self.S["auto_level"]("ambience", None, self.levels, {})[0], -19.0)

    def test_role_reference_is_the_median(self):
        files = {"a/whoosh 1.wav": {"peak_db": -6.0}, "a/whoosh 2.wav": {"peak_db": -10.0},
                 "a/whoosh 3.wav": {"peak_db": -20.0}, "b/riser x.wav": {"peak_db": -12.0}}
        refs = self.S["role_ref_peaks"](files)
        self.assertEqual(refs["whoosh"], -10.0)
        self.assertEqual(refs["riser"], -12.0)

    def test_tc_frames_for_audio_clips(self):
        self.assertEqual(self.S["tc_frames"]("00:00:02;09", 29.97), 69)    # Bells 01 on BoConCN
        self.assertEqual(self.S["tc_frames"]("00:00:01:01", 25.0), 26)

    def test_plan_cue_aligns_peak_and_onset(self):
        swell = {"shape": "swell", "peak_t": 0.22, "onset_t": 0.16, "peak_db": -10.7}
        p = self.S["plan_cue"](swell, {"event": 211, "role": "whoosh"}, 25.0, 25.0, 26, self.levels, {"whoosh": -10.7})
        self.assertEqual(p["record"], 206)                  # peak 0.22 s = 5.5 frames -> peak on 211.0 (by hand: 205 -> 210.5)
        self.assertEqual(p["volume"], -15.0)
        hit = {"shape": "hit", "peak_t": 0.13, "onset_t": 0.0, "peak_db": -19.9}
        p2 = self.S["plan_cue"](hit, {"event": 700, "role": "shimmer", "length": 50}, 25.0, 29.97, 69,
                                self.levels, {"shimmer": -19.9})
        self.assertEqual(p2["record"], 700)
        self.assertEqual(p2["end_src"], 60)                 # 50 timeline frames at 29.97 source fps
        self.assertEqual(p2["length"], 50)

    def test_plan_cue_trims_a_head_before_frame_0(self):
        rise = {"shape": "rise", "peak_t": 2.06, "onset_t": 0.96, "peak_db": -28.6}
        p = self.S["plan_cue"](rise, {"event": 25, "role": "riser", "volume": -4}, 25.0, 25.0, 65, self.levels, {})
        self.assertEqual(p["record"], 0)
        self.assertEqual(p["start_src"], 26)                # 26.5 frames before 0, rounded half to even
        self.assertLessEqual(abs(p["feature_frame"] - 25), 1)
        self.assertEqual(p["volume"], -4.0)

    def test_reference_follows_the_files_own_role(self):
        """BoConCN: a whoosh used as the slow-mo swell was compared with quiet slow-mo files -> −24 dB."""
        sw = {"shape": "swell", "peak_t": 0.27, "onset_t": 0.2, "peak_db": -12.1}
        refs = {"slowmo": -21.4, "whoosh": -10.7}
        p = self.S["plan_cue"](sw, {"event": 532, "role": "slowmo"}, 25.0, 25.0, 28, self.levels | {"slowmo": -15},
                               refs, tags=["whoosh"])
        self.assertAlmostEqual(p["volume"], -13.6, places=1)       # −15 + (−10.7 − −12.1)
        self.assertIn("typical whoosh", p["level_note"])

    def test_free_track(self):
        occ = {3: [(200, 230)], 4: []}
        self.assertEqual(self.S["free_track"](occ, 210, 240, [3, 4]), 4)
        self.assertEqual(self.S["free_track"](occ, 230, 260, [3, 4]), 3)
        self.assertIsNone(self.S["free_track"]({3: [(0, 900)], 4: [(0, 900)]}, 10, 20, [3, 4]))


class ConfigWiring(unittest.TestCase):
    def test_new_config_names_resolve(self):
        L = load("loader.py")
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        cfg = L["effective_config"](d)
        sfx = cfg["scripts"]["sfx_library.py"]
        self.assertEqual(sfx["SFX_TRACKS"], [3, 4])
        self.assertEqual(sfx["LEVELS"]["riser"], -10)
        self.assertTrue(cfg["scripts"]["ending_plan.py"]["MUSIC_CATALOG"].endswith("_music/catalog.json"))


if __name__ == "__main__":
    unittest.main()
