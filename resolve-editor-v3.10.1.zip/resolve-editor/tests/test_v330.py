"""v3.3.0 (replaces the v3.2.1 checks): clear phase and stop names, Music request instead of music previews,
shot_NN names and music/SFX colours. Offline only."""
import json
import os
import re
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STOPS = ("Style choice", "Music request", "Story approval", "Draft review", "Final approval")


def text(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def load(name):
    g = {"__name__": "test"}
    exec(compile(text("scripts/" + name), name, "exec"), g)
    return g


class Names(unittest.TestCase):
    def test_no_abbreviated_stops_in_current_docs(self):
        files = ["SKILL.md", "WORKFLOW.md", "references/options-playbook.md", "references/phases/express-runbook.md",
                 "references/phases/router.md"] + ["references/phases/phase-%02d.md" % n for n in range(1, 11)]
        for f in files:
            self.assertNotRegex(text(f), r"\bE0[ab]\b|\bE[1-3]\b|Gate [0-4]", f)

    def test_phase_table_and_stops(self):
        core = text("SKILL.md")
        for n in range(1, 11):
            self.assertRegex(core, r"### Phase %d — [A-Z]" % n)
        for s in STOPS:
            self.assertIn(s, core)
            self.assertIn(s, text("WORKFLOW.md"))
        self.assertLess(len(core.split()), 2000)

    def test_phase_cards_same_version(self):
        d = json.loads(text("config/defaults.json"))
        self.assertIn(d["version"], ("3.3.0", "3.4.0", "3.5.0", "3.5.1", "3.6.0", "3.7.0", "3.7.1", "3.8.0", "3.8.1", "3.9.0", "3.10.0", "3.10.1"))
        for n in range(1, 11):
            c = text("references/phases/phase-%02d.md" % n)
            self.assertIn("Phase card (v%s)" % d["version"], c)
            self.assertTrue(c.startswith("# Phase %d — " % n))

    def test_every_md_link_in_phase_cards_exists(self):
        for n in range(1, 11):
            c = text("references/phases/phase-%02d.md" % n)
            for m in re.findall(r"`(references/[a-z0-9\-/]+\.md)", c):
                self.assertTrue(os.path.exists(os.path.join(ROOT, m)), m)


class MusicRequest(unittest.TestCase):
    def test_no_previews_in_the_workflow(self):
        p1 = text("references/phases/phase-01.md")
        self.assertLess(p1.index("Style choice"), p1.index("Music request"))
        self.assertIn("wait for the file", p1)
        for f in ("references/options-playbook.md", "references/phases/express-runbook.md",
                  "references/music-analysis.md", "references/free-audio-sources.md"):
            self.assertNotIn("preview_question", text(f), f)
        self.assertIn("Music boundary", text("SKILL.md"))

    def test_music_request_message(self):
        M = load("music_intake.py")
        msg = M["music_request"]({"label": "Ngày êm", "audio": "piano ấm", "ending": "fade"}, 25)
        self.assertTrue(msg.startswith("**Yêu cầu gửi nhạc nền**"))
        for k in ("Ngày êm", "piano ấm", "25 s"):
            self.assertIn(k, msg)
        self.assertIsNone(M["question"]("NONE"))
        self.assertIsNone(M["question"]("USER_MUSIC"))


class TimelineLabels(unittest.TestCase):
    def test_sequence_names(self):
        B = load("build_from_blueprint.py")
        self.assertEqual(B["sequence_names"](3, "shot"), ["shot_01", "shot_02", "shot_03"])
        self.assertEqual(B["sequence_names"](120, "shot")[0], "shot_001")
        self.assertEqual(B["ITEM_NAMES"][1], "shot")

    def test_music_and_sfx_colours_differ(self):
        B = load("build_from_blueprint.py")
        music, sfx = B["audio_role_color"](2), B["audio_role_color"](3)
        self.assertTrue(music and sfx and music != sfx)
        self.assertIsNone(B["audio_role_color"](1))
        self.assertIn('SFX_COLOR = "Yellow"', text("scripts/sfx_library.py"))
        self.assertIn("it.SetName(old_name)", text("scripts/replace_shot.py"))
        self.assertIn("old_color", text("scripts/timeline_ops.py"))


if __name__ == "__main__":
    unittest.main()
