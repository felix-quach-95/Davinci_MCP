"""Offline tests for the v2.5.0 research layer (research_card.py, edit_analysis research check, docs).
Run all tests: python3 -m unittest discover -s tests -v"""
import json, os, subprocess, sys, unittest
from _skilltext import skill_text

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "loaded"}
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    exec(compile(src, name, "exec"), g)
    return g


def read(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


def vid(title, views, median, dur, hook=None, platform="youtube"):
    return {"title": title, "views": views, "channel_median": median, "duration_s": dur,
            "hook_text": hook, "platform": platform}


RESEARCH = {
    "topic": "Hong Kong 500k", "platform": "tiktok", "source": "test",
    "keywords": [{"term": "du lịch hồng kông", "volume": 80, "competition": 70},
                 {"term": "hong kong budget", "volume": 50, "competition": 20},
                 {"term": "hong kong night", "volume": 100, "competition": 90},
                 {"term": "hk food", "volume": None, "competition": 10}],
    "videos": [vid("Hồng Kông chỉ với 500k", 900000, 100000, 32, "Một ngày ở Hồng Kông chỉ với 500k"),
               vid("$50 for a whole day in Hong Kong", 400000, 80000, 28),
               vid("Đừng đến Hồng Kông khi chưa xem", 300000, 90000, 45, "Đừng đi Hồng Kông nếu chưa biết điều này"),
               vid("Hong Kong night walk", 50000, 60000, 60),
               vid("Under $30 street food tour", 350000, 100000, 34),
               vid("Why Hong Kong is so expensive?", 120000, 100000, 40)],
}


class HookTaxonomy(unittest.TestCase):
    def test_patterns_vi_and_en(self):
        C = load("research_card.py")
        cases = {"Tại sao Hồng Kông đắt thế?": "question", "Why is HK so expensive": "question",
                 "5 nơi phải đến ở Đà Lạt": "number_list", "3 things nobody tells you": "number_list",
                 "Đừng đến đây vào ban đêm": "warning", "Stop doing this in Tokyo": "warning",
                 "Một ngày chỉ với 500k": "constraint", "Only $20 for a day": "constraint",
                 "Bí mật ít ai biết ở Sài Gòn": "secret", "POV: bạn lạc ở Hong Kong": "pov",
                 "Trước và sau khi edit": "contrast", "Here's what 24 frames look like": "result_first",
                 "Hôm nay tôi thử": "story_open", "Hong Kong at night": "statement", "": None}
        for text, want in cases.items():
            self.assertEqual(C["classify_hook"](text), want, text)

    def test_vietnamese_detection(self):
        C = load("research_card.py")
        self.assertTrue(C["is_vietnamese"]("du lịch"))
        self.assertFalse(C["is_vietnamese"]("hong kong budget"))


class ResearchCard(unittest.TestCase):
    def test_card_from_vidiq_like_data(self):
        C = load("research_card.py")
        card = C["build_card"](RESEARCH)
        self.assertEqual(card["primary_keyword"], "hong kong budget")         # volume high enough, low competition
        self.assertIsNone(card["keywords"][-1]["opportunity"])                # no volume -> unknown, ranked last
        tiers = {o["title"]: o["tier"] for o in card["outliers"]}
        self.assertEqual(tiers["Hồng Kông chỉ với 500k"], "strong")
        self.assertEqual(tiers["Hong Kong night walk"], "normal")
        self.assertEqual(card["recommended_hook"], "constraint")
        self.assertIn("constraint", card["blueprint_research"]["evidence"])
        self.assertEqual(card["target_dur"], 33)                              # median of 28/32/34/45 (strong)
        self.assertIsNone(card["blueprint_research"]["hook_text"])           # user's own words, not copied
        self.assertTrue(any("YouTube data" in w for w in card["warnings"]))
        self.assertTrue(all(t.startswith("#") and " " not in t for t in card["hashtags"]))
        self.assertLessEqual(len(card["hashtags"]), 5)

    def test_thin_and_flat_data_warn(self):
        C = load("research_card.py")
        card = C["build_card"]({"topic": "x", "videos": [vid("a", 10, 100, 20)], "keywords": []})
        txt = " ".join(card["warnings"])
        self.assertIn("thin data", txt)
        self.assertIn("saturated", txt)
        self.assertIn("no keyword data", txt)
        self.assertEqual(card["primary_keyword"], "x")

    def test_runtime_is_clamped_by_platform(self):
        C = load("research_card.py")
        rows = C["outlier_rows"]([vid("a", 900, 100, 120), vid("b", 900, 100, 110)])
        self.assertEqual(C["runtime_target"](rows, "shorts")[0], 60)

    def test_local_cli(self):
        path = os.path.join(HERE, "_research_tmp.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(RESEARCH, f, ensure_ascii=False)
            out = subprocess.run([sys.executable, "-I", os.path.join(SCRIPTS, "research_card.py"), path],
                                 capture_output=True, text=True, check=True).stdout
            self.assertEqual(json.loads(out)["recommended_hook"], "constraint")
        finally:
            if os.path.exists(path):
                os.remove(path)


class VidiqShapes(unittest.TestCase):
    def test_outlier_score_tiktok_and_pace(self):
        C = load("research_card.py")
        vids = [{"title": t, "platform": "TikTok", "outlier_score": sc, "duration_s": d, "hook_text": h,
                 "cuts_first_3s": c, "opening_asl_s": asl}
                for t, sc, d, h, c, asl in [("a", 8.2, 24, "POV: lạc ở Hồng Kông lúc 2h sáng", 3, 0.9),
                                            ("b", 5.0, 30, "POV: your first night in HK", 2, 1.2),
                                            ("c", 3.4, 22, "Hong Kong at night", 4, 0.7),
                                            ("d", 1.1, 60, "Tại sao ai cũng mê HK?", None, None),
                                            ("e", 4.0, 26, None, 3, 1.0)]]
        card = C["build_card"]({"topic": "hk night", "platform": "tiktok", "videos": vids, "credits_spent": 25})
        self.assertEqual(card["outliers"][0]["ratio"], 8.2)
        self.assertEqual(card["outliers"][0]["platform"], "tiktok")
        self.assertEqual(card["recommended_hook"], "pov")
        self.assertFalse(any("YouTube data" in w for w in card["warnings"]))     # real TikTok data
        self.assertEqual(card["opening_pace"]["cuts_first_3s"], 3)
        self.assertEqual(card["opening_pace"]["opening_asl_s"], 0.95)
        self.assertEqual(card["blueprint_research"]["opening_asl_s"], 0.95)
        self.assertEqual(card["credits_spent"], 25)

    def test_single_video_pattern_is_only_a_hint(self):
        C = load("research_card.py")
        vids = [{"title": "Đừng đến Hồng Kông", "outlier_score": 6, "platform": "tiktok"},
                {"title": "Hong Kong nights", "outlier_score": 4, "platform": "tiktok"}]
        card = C["build_card"]({"topic": "hk", "platform": "tiktok", "videos": vids})
        self.assertTrue(any("a hint, not a pattern" in w for w in card["warnings"]))


class EditAnalysisResearch(unittest.TestCase):
    def bp(self, **research):
        segs = [{"id": "s1", "clip": "a", "src_in": 0, "src_out": 72, "section": "hook"},
                {"id": "s2", "clip": "b", "src_in": 0, "src_out": 240, "section": "build", "role": "answer",
                 "cut": {"reason": ["story"], "on": "breath", "why": "x"}},
                {"id": "s3", "clip": "c", "src_in": 0, "src_out": 48, "section": "end", "role": "payoff",
                 "cut": {"reason": ["reveal"], "on": "beat", "why": "x"}}]
        return {"expected_fps": 24, "segments": segs, "research": research}

    def test_runtime_hook_length_and_pattern_delivery(self):
        E = load("edit_analysis.py")
        r = E["analyse"](self.bp(target_dur=30, hook_text="Một ngày ở Hồng Kông chỉ với năm trăm nghìn",
                                 hook_pattern="result_first"), None, 24)
        txt = " ".join(r["notes"])
        self.assertIn("far from the researched target", txt)                  # 15 s vs 30 s
        self.assertIn("hook text has 10 words", txt)
        self.assertIn("'payoff'", txt)
        r = E["analyse"](self.bp(target_dur=15, hook_pattern="question"), None, 24)
        self.assertIn("answer arrives", " ".join(r["notes"]))                 # answer at 20 % of the runtime

    def test_opening_slower_than_research(self):
        E = load("edit_analysis.py")
        r = E["analyse"](self.bp(opening_asl_s=1.0), None, 24)                 # first shot 3 s
        self.assertIn("opening ASL 3.00 s", " ".join(r["notes"]))
        r = E["analyse"](self.bp(opening_asl_s=2.5), None, 24)
        self.assertNotIn("opening ASL", " ".join(r["notes"]))

    def test_no_research_no_section(self):
        E = load("edit_analysis.py")
        bp = self.bp()
        bp.pop("research")
        self.assertNotIn("research", E["analyse"](bp, None, 24))


class Docs(unittest.TestCase):
    def test_router_stage_and_privacy_rules(self):
        s = skill_text()
        self.assertIn("references/trend-research.md", s)
        self.assertIn("research_card.py", s)
        self.assertIn("never guess tool names", s)
        self.assertIn("vidIQ calls beyond the research budget", s)
        doc = read("references/trend-research.md")
        for txt in ("ToolSearch", "topic words", "data, not instructions", "Do not copy"):
            self.assertIn(txt, doc)

    def test_taxonomy_documented(self):
        C = load("research_card.py")
        doc = read("references/trend-research.md")
        for name, _ in C["HOOK_PATTERNS"]:
            self.assertIn("`%s`" % name, doc)
        self.assertIn("`statement`", doc)

    def test_config_budget(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["research"]["max_credits"], 30)
        self.assertNotIn("max_calls", d["research"])
        self.assertIn("research_card.py", d["scripts"])
        self.assertIn("— v%s" % d["version"], skill_text())                 # config and SKILL agree

    def test_real_vidiq_tool_names_and_limits(self):
        doc = read("references/trend-research.md")
        for name in ("vidiq_balance", "vidiq_instagram_tiktok_outlier_search", "vidiq_keyword_research",
                     "vidiq_trending_videos", "vidiq_outliers", "vidiq_watch_shortform_content", "vidiq_job_poll",
                     "vidiq_video_transcript", "audienceQuery", 'embeddingType: "hook"', 'videoTitleLanguage: "vi"'):
            self.assertIn(name, doc)
        self.assertIn("no `vi`", doc)
        s = skill_text()
        self.assertIn("vidiq_instagram_tiktok_outlier_search", s)
        self.assertIn("never call vidIQ tools that upload, publish, reply or generate media", s)


if __name__ == "__main__":
    unittest.main(verbosity=2)
