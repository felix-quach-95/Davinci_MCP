"""Offline tests for the v2.3.0 additions (ideas adopted from the reviewed GitHub skills).
Run all tests: python3 -m unittest discover -s tests -v"""
import math, os, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "loaded"}
    src = open(os.path.join(SCRIPTS, name), encoding="utf-8").read()
    exec(compile(src, name, "exec"), g)
    return g


def read(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


# words at 30 fps: a retake, an isolated filler, a long pause, a restart cue, an embedded filler
WORDS = [(0, 10, "hôm"), (10, 20, "nay"), (20, 30, "mình"), (30, 40, "đi"),
         (70, 80, "hôm"), (80, 90, "nay"), (90, 100, "mình"), (100, 110, "đi"), (110, 125, "chợ."),
         (140, 150, "ờ"),
         (155, 165, "chợ"), (165, 175, "rất"), (175, 190, "đông."),
         (260, 270, "về"), (270, 282, "thôi.")]


class TranscriptPlanner(unittest.TestCase):
    def test_isolated_filler_cut_embedded_filler_flagged(self):
        T = load("transcript_cut.py")
        drop, flags = T["mark_fillers"](WORDS, 30)
        self.assertEqual(list(drop), [9])
        w = [(0, 10, "mình"), (10, 18, "ờ"), (18, 28, "thích")]          # fluent: no pause around "ờ"
        drop2, flags2 = T["mark_fillers"](w, 30)
        self.assertEqual(drop2, {})
        self.assertEqual(flags2[0][0], 1)
        drop3, _ = T["mark_fillers"](w, 30, mode="all")
        self.assertEqual(list(drop3), [1])

    def test_retakes_and_restart_cue(self):
        T = load("transcript_cut.py")
        sents = T["sentences"](WORDS, 30)
        drop, _ = T["mark_retakes"](WORDS, sents, 4, [9])
        self.assertEqual(sorted(drop), [0, 1, 2, 3])
        w = [(0, 10, "xin"), (10, 20, "chào"), (20, 30, "các."), (40, 50, "làm"), (50, 60, "lại."),
             (80, 90, "xin"), (90, 100, "chào"), (100, 110, "mọi"), (110, 120, "người.")]
        drop2, _ = T["mark_retakes"](w, T["sentences"](w, 30), 4)
        self.assertTrue({0, 1, 2, 3, 4} <= set(drop2))
        self.assertNotIn(5, drop2)

    def test_pause_shortened_not_removed_with_pads_and_scene_room(self):
        T = load("transcript_cut.py")
        drop = {0: "x", 1: "x", 2: "x", 3: "x", 9: "x"}
        p = T["plan_pieces"](WORDS, drop, 30, "story", (), 400)
        self.assertEqual(len(p), 3)
        self.assertEqual(p[0]["a"], 55)                    # 0.5 s scene room before the first kept word
        self.assertEqual(p[0]["join"], "scene")
        # pause 190 -> 260 (2.3 s > 0.55): 40 % of 0.25 s after, 60 % before -> cut, both sides padded
        self.assertGreaterEqual(p[1]["b"], 193)
        self.assertLessEqual(p[2]["a"], 260 - 4)
        self.assertEqual(p[2]["b"], 282 + 18)              # 0.6 s tail after the last word
        # a gap without waveform silence is not a pause (untranscribed sound): no cut there
        q = T["plan_pieces"](WORDS, drop, 30, "story", [(1.4, 2.2)], 400)
        self.assertEqual(len(q), 2)

    def test_never_reaches_into_a_cut_word_and_vlog_keeps_more_air(self):
        T = load("transcript_cut.py")
        drop = {0: "x", 1: "x", 2: "x", 3: "x", 9: "x"}
        p = T["plan_pieces"](WORDS, drop, 30, "story", (), 400)
        self.assertGreaterEqual(p[1]["a"], 150)            # the filler "ờ" ends at 150
        w = [(0, 10, "a"), (10, 20, "b"), (40, 50, "c"), (50, 60, "d.")]   # 0.67 s pause
        self.assertEqual(len(T["plan_pieces"](w, {}, 30, "shorts")), 2)
        self.assertEqual(len(T["plan_pieces"](w, {}, 30, "vlog")), 1)

    def test_punchline_split_and_paced_zoom(self):
        T = load("transcript_cut.py")
        r = T["plan_all"](WORDS, 30, 30, "C1", "Draft_V_v01", "story", (), 400, punchlines=[[13, 14]])
        segs = r["blueprint"]["segments"]
        zooms = [s.get("props", {}).get("ZoomX", 1.0) for s in segs]
        self.assertEqual(zooms[0], 1.0)
        self.assertIn(1.15, zooms)
        self.assertTrue(r["uncovered_jump_cuts"])           # a jump inside the 4 s hold stays same-scale
        self.assertEqual(r["blueprint"]["audio_xfade"], {"track": 1, "frames": 2})
        self.assertIn("~~ờ~~", r["review"])
        self.assertIn("‖", r["review"])
        B = load("build_from_blueprint.py")
        self.assertEqual(B["validate_blueprint"](r["blueprint"], {"C1": 400}), [])
        pieces = [{"a": 0, "b": 60, "words": [0], "join": "scene"}, {"a": 80, "b": 140, "words": [1], "join": "jump"},
                  {"a": 160, "b": 200, "words": [2], "join": "jump"}]
        un = T["assign_zoom"](pieces, 30, "dynamic")
        self.assertEqual([p["zoom"] for p in pieces], [1.0, 1.075, 1.0])
        self.assertEqual(un, [])
        T["assign_zoom"](pieces, 30, "hold")
        self.assertEqual({p["zoom"] for p in pieces}, {1.0})


class BuildAndQA(unittest.TestCase):
    def test_butt_joins_and_xfade_types(self):
        B = load("build_from_blueprint.py")
        self.assertEqual(B["butt_joins"]([(0, 50), (50, 90), (95, 120), (120, 130)]), [0, 2])
        self.assertEqual(B["XFADE_TYPES"][0], "Cross Fade 0 dB")

    def test_av_sync_mismatch(self):
        Q = load("qa_audit.py")
        pairs = [("a", 10, 59, 10, 59, True), ("b", 100, 150, 96, 146, True), ("c", 0, 10, 0, 30, False)]
        self.assertEqual(Q["av_mismatches"](pairs), ["b"])

    def test_adaptive_silence_floor(self):
        S = load("silence_beats.py")
        sr = 2000
        loud = [0.05 * math.sin(i * 0.3) for i in range(sr)]        # quiet mic: peak ~ -26 dBFS
        quiet = [0.0005 * math.sin(i * 0.3) for i in range(sr)]
        x = loud + quiet + loud
        floor = S["adaptive_floor_db"](x, sr, 24)
        self.assertLess(floor, -40)
        self.assertGreater(floor, -60)
        sil = S["silences_from_pcm"](x, sr, "auto", 0.35)
        self.assertEqual(len(sil), 1)
        self.assertAlmostEqual(sil[0][0], 1.0, delta=0.05)
        self.assertEqual(S["silences_from_pcm"](x, sr, -20, 0.35), [(0.0, 3.0)])   # a fixed floor calls it all silence


class VoiceAndPresence(unittest.TestCase):
    def test_parsers(self):
        V = load("voice_audit.py")
        self.assertEqual(V["parse_volumedetect"]("[Parsed] mean_volume: -24.3 dB\n max_volume: -3.1 dB"),
                         {"mean": -24.3, "max": -3.1})
        self.assertEqual(V["parse_volumedetect"]("mean_volume: -inf dB")["mean"], -120.0)
        self.assertEqual(V["parse_silence_total"]("silence_duration: 2.0\n silence_duration: 1.0", 10), 0.3)

    def test_judge_and_rank(self):
        V = load("voice_audit.py")
        good = {"channels": 2, "L": -24, "R": -24.5, "diff": -80, "full": -24, "low": -30, "hf3": -36,
                "hf6": -45, "lufs": -21, "tp": -4, "silent_share": 0.2}
        muffled = dict(good, hf3=-46, low=-24.5)
        dead = dict(good, R=-90, diff=-24)
        comb = dict(good, diff=-21)
        self.assertEqual(V["judge"](good), ["true dual mono (L = R)"])
        self.assertTrue(any("muffled" in i for i in V["judge"](muffled)))
        self.assertTrue(any("boomy" in i for i in V["judge"](muffled)))
        self.assertTrue(any("one channel is silent" in i for i in V["judge"](dead)))
        self.assertTrue(any("comb" in i for i in V["judge"](comb)))
        self.assertGreater(V["score"](good), V["score"](muffled))
        self.assertEqual(V["normalize_report"]({"a": 0, "b": 0}, {"a": 4, "b": 28}), ["b"])

    def test_presence_correlation(self):
        P = load("audio_presence.py")
        ref = [math.sin(i * 0.37) + 0.5 * math.sin(i * 0.11) for i in range(800)]
        mix = [0.0] * 20 + [0.3 * v for v in ref[:780]]                 # source 10 dB down, 20 samples late
        c, lag = P["xcorr_best"](mix, ref, 40)
        self.assertGreater(c, 0.9)
        self.assertEqual(lag, 20)
        self.assertAlmostEqual(P["ls_gain_db"](mix, ref, lag), -10.5, delta=0.6)
        self.assertEqual(P["verdict"](0.05), "MISSING")
        self.assertEqual(P["verdict"](0.8), "present")


class MotionAndFx(unittest.TestCase):
    def test_reframe_path_follows_and_refuses_edges(self):
        M = load("motion_fx.py")
        c = M["reframe_curve"]([[0, 0.40, 0.5], [40, 0.62, 0.5]], 60, 0.5)
        self.assertEqual(c[0][1], (0.6, 0.5))                         # subject 0.40 -> picture moves right 0.10
        self.assertAlmostEqual(c[-1][1][0], 0.38, places=6)
        mids = [x[1][0] for x in c if 0 < x[0] < 40]
        self.assertTrue(all(b <= a for a, b in zip(mids, mids[1:])))   # eased, monotone
        self.assertRaises(ValueError, M["reframe_curve"], [[0, 0.05, 0.5]], 10, 0.5)
        self.assertTrue(M["reframe_curve"]([[0, 0.12, 0.5, 1.4]], 10, 0.2))   # zoom around the subject makes it fit
        keys, _ = M["fx_points"]({"fx": "reframe_path", "points": [[0, 0.45, 0.5], [20, 0.55, 0.5]]}, 30)
        self.assertIn(("Xf", "Pivot@path"), keys)
        self.assertTrue(M["validate"]([{"index": 1, "fx": "push", "t1": 20},
                                       {"index": 1, "fx": "reframe_path", "points": [[0, 0.5, 0.5]]}], {(1, 1): 30}))

    def test_invert_and_resolvefx_plan(self):
        M = load("motion_fx.py")
        keys, _ = M["fx_points"]({"fx": "invert", "t": 10, "n": 2}, 30)
        self.assertEqual([v for f, v, _ in keys[("Inv", "Gain")] if f in (10, 11, 12)], [-1.0, -1.0, 1.0])
        _, st = M["fx_points"]({"fx": "resolvefx", "regid": "filmgrain", "params": {"Blend": 0.3}}, 30)
        self.assertEqual(list(st), [("OFX:ofx.com.blackmagicdesign.resolvefx.filmgrain", "_params")])
        _, st = M["fx_points"]({"fx": "resolvefx", "regid": "ofx.com.example.fx"}, 30)
        self.assertEqual(list(st)[0][0], "OFX:ofx.com.example.fx")
        self.assertIn("Inv", M["ORDER"])

    def test_resolvefx_reference_lists_the_checked_ids(self):
        P = load("picture_tools.py")
        doc = read("references/resolvefx.md")
        for short in P["RESOLVEFX"]:
            self.assertIn(short, doc)


        src = read("scripts/srt_from_transcript.py")
        self.assertNotIn(".AppendToTimeline(", src)
        self.assertIn("File > Import > Subtitle", src)

    def test_track_enable_restored_on_edit_page(self):
        src = read("scripts/fx_apply.py")
        fin = src[src.index("subprocess.run([\"pbcopy\"], input=saved)"):]
        self.assertLess(fin.index('resolve.OpenPage("edit")'), fin.index("draft.SetTrackEnable"))

    def test_duck_envelope_and_file_fps(self):
        D = load("duck_music.py")
        segs = [(0, 100, "normal"), (100, 300, "duck"), (300, 500, "normal")]
        items = D["layout"](segs, 0, 0, 24, 2, 5, -9, -20, 0, 36, fade_up=29, src_ratio=23.976 / 24)
        self.assertEqual(items[0]["end"] - items[1]["rec"], 24)          # fall 1.0 s
        self.assertEqual(items[1]["end"] - items[2]["rec"], 29)          # rise 1.2 s
        self.assertEqual(items[1]["fades"], {"FadeIn": 24, "FadeOut": 29})
        self.assertEqual(items[2]["src_in"], int(round(300 * 23.976 / 24)))

    def test_new_scripts_in_config(self):
        import json
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        for s in ("voice_audit.py", "audio_presence.py", "transcript_cut.py"):
            self.assertIn(s, d["scripts"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
