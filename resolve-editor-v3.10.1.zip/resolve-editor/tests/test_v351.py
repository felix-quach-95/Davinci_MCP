"""v3.5.1: speed ramps long enough to feel, 5 per 30 s."""
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    g = {"__name__": "test"}
    exec(compile(open(os.path.join(ROOT, "scripts", name), encoding="utf-8").read(), name, "exec"), g)
    return g


class RampFeel(unittest.TestCase):
    def setUp(self):
        self.E = load("edit_analysis.py")

    def test_testskill_hook_ramp_is_too_short(self):
        f = self.E["ramp_feel"]({"id": "v01", "ramp": [{"frames": 44, "speed": 100}, {"frames": 14, "speed": 200},
                                                         {"frames": 8, "speed": 400}]}, 29.97)
        self.assertTrue(any("too short" in x for x in f))

    def test_recipe_passes(self):
        hero = [{"frames": 12, "speed": 100}, {"frames": 45, "speed": 300}, {"frames": 12, "speed": 40}, {"frames": 12, "speed": 100}]
        self.assertEqual(self.E["ramp_feel"]({"id": "ok", "ramp": hero}, 30), [])

    def test_flat_and_short_hold(self):
        f = self.E["ramp_feel"]({"id": "x", "ramp": [{"frames": 30, "speed": 100}, {"frames": 12, "speed": 80}, {"frames": 20, "speed": 150}]}, 30)
        self.assertTrue(any("too close" in x for x in f))
        self.assertTrue(any("slow part" in x for x in f))

    def test_count(self):
        self.assertEqual(self.E["RAMPS_PER_30S"], 5)


if __name__ == "__main__":
    unittest.main()
