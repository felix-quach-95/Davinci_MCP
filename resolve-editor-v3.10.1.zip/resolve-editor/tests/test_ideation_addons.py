"""v2.8.0 addendum (2026-10-26): ideation playbook, clip factory, style profiles, text numbers, equal-length runs."""
import json
import os
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


def pos_from(lengths, section="a"):
    out, c = [], 0
    for i, n in enumerate(lengths):
        out.append(({"id": "s%d" % (i + 1), "section": section}, c, c + n))
        c += n
    return out


class EqualRuns(unittest.TestCase):
    def setUp(self):
        self.E = load("edit_analysis.py")

    def test_three_equal_shots_flagged(self):
        f = self.E["equal_run_report"](pos_from([48, 48, 50, 24, 72]), 24)
        self.assertEqual(len(f), 1)
        self.assertIn("s1..s3", f[0])

    def test_varied_lengths_not_flagged(self):
        self.assertEqual(self.E["equal_run_report"](pos_from([48, 24, 72, 36, 96]), 24), [])

    def test_two_equal_is_fine(self):
        self.assertEqual(self.E["equal_run_report"](pos_from([48, 48, 96]), 24), [])

    def test_metric_section_exempt(self):
        self.assertEqual(self.E["equal_run_report"](pos_from([24, 24, 24, 24], "metric_drop"), 24), [])

    def test_across_sections_still_counts(self):
        p = pos_from([48, 48], "a") + [({"id": "s3", "section": "b"}, 96, 144)]
        self.assertEqual(len(self.E["equal_run_report"](p, 24)), 1)

    def test_long_run_reported_once(self):
        f = self.E["equal_run_report"](pos_from([30, 30, 30, 30, 30, 90]), 24)
        self.assertEqual(len(f), 1)
        self.assertIn("5 shots", f[0])

    def test_analyse_includes_it(self):
        segs = [{"id": "s%d" % i, "clip": "c", "src_in": 0, "src_out": 48, "section": "a"} for i in range(1, 4)]
        r = self.E["analyse"]({"expected_fps": 24, "segments": segs}, None, 24)
        self.assertTrue(any("nearly equal length" in n for n in r["notes"]))
        self.assertTrue(r["pacing"]["equal_runs"])


class StyleProfiles(unittest.TestCase):
    NAMES = ["night_cinematic", "airy_vlog", "travel_energetic", "calm_documentary"]


    def test_docs_mention_profiles(self):
        sk = skill_text()
        for needle in ("style-profiles.md", "clip-factory.md", "ideation-playbook.md"):
            self.assertIn(needle, sk)
            self.assertTrue(os.path.exists(os.path.join(ROOT, "references", needle)))

