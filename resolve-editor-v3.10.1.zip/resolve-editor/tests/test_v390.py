"""v3.9.0: newest HyperFrames; rational fps; documented per-layer batch; test fixtures ignored."""
import json
import os
import shutil
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(name):
    p = os.path.join(ROOT, "scripts", name)
    g = {"__name__": "offline", "__file__": p}
    exec(compile(open(p, encoding="utf-8").read(), p, "exec"), g)
    return g


class Install(unittest.TestCase):
    def setUp(self):
        self.I = load("install_motion_studio.py")
        self.t = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.t)

    def test_shipped_pin_is_new(self):
        v = json.load(open(os.path.join(ROOT, "motion-studio", "package.json")))["hyperframesVersion"]
        self.assertEqual(tuple(int(x) for x in v.split(".")) >= (0, 8, 209), True)

    def test_install_sets_requested_pin(self):
        dest = os.path.join(self.t, "motion-studio")
        r = self.I["install"](dest, hf_version="0.8.300")
        self.assertEqual(r["hyperframes"], "0.8.300")
        self.assertEqual(json.load(open(os.path.join(dest, "package.json")))["hyperframesVersion"], "0.8.300")
        self.assertIn("--update", r["next"])

    def test_latest_falls_back_offline(self):
        self.I["latest_hf"] = lambda timeout=20: None
        g = self.I
        dest = os.path.join(self.t, "ms2")
        r = g["install"](dest, hf_version="latest")
        self.assertEqual(r["hyperframes"], g["pinned"]())

    def test_fixture_ignored_and_unpinned_flagged(self):
        d = os.path.join(self.t, "hyperframes", "scripts")
        os.makedirs(d)
        open(os.path.join(d, "plugin-cli.test.mjs"), "w").write('"hyperframes@1.2.3"')
        open(os.path.join(self.t, "hyperframes", "SKILL.md"), "w").write("Run the CLI as `npx hyperframes render`.")
        r = self.I["hf_check"](self.t)
        self.assertEqual(r["installed"]["hyperframes"], ["unpinned"])
        self.assertEqual(r["status"], "NEEDS_UPDATE")


class Request(unittest.TestCase):
    def test_batch_line_and_solo_contract(self):
        H = load("hyperframes_handoff.py")
        el = {"id": "e1", "category": "subtitle", "text": {"vi": "Đi"}, "start": 0, "end": 30, "position": {"x": .5, "y": .7},
              "hierarchy": 3, "animation": {"in": "fade"}, "anchored_to": {"kind": "none"}, "status": "approved", "source": "user"}
        d = H["build_handoff"]({"title": "T", "final_timeline": "F", "fps": 23.976, "width": 1080, "height": 1920,
                                "duration_frames": 240, "style": {"status": "approved", "look": "x"}, "elements": [el],
                                "hf_version": "0.8.209"})
        r = H["hf_request"](d)
        for s in ("--batch layers_rows.json --format mov --fps 24000/1001", '"renders/layers_full/{name}.mov"', "--strict-variables",
                  "opacity 0 on the inner wrapper", "never\n  display/visibility on a .clip", "data-track-kind", "@font-face",
                  "hyperframes@0.8.209"):
            self.assertIn(s.replace("\\n", "\n"), r)

    def test_rows_file_written(self):
        H = load("hyperframes_handoff.py")
        el = {"id": "e1", "category": "title_main", "text": {"vi": "A"}, "start": 0, "end": 30, "position": {"x": .5, "y": .3},
              "hierarchy": 1, "animation": {"in": "fade"}, "anchored_to": {"kind": "none"}, "status": "approved", "source": "user"}
        d = H["build_handoff"]({"title": "T", "final_timeline": "F", "fps": 30, "width": 1080, "height": 1920,
                                "duration_frames": 300, "style": {"status": "approved"}, "elements": [el]})
        t = tempfile.mkdtemp()
        try:
            H["write_files"](d, t)
            rows = json.load(open(os.path.join(t, "layers_rows.json")))
            self.assertEqual(rows, [{"name": "DH01_TieuDeChinh_A", "solo": "DH01_TieuDeChinh_A"}])
        finally:
            shutil.rmtree(t)


class Docs(unittest.TestCase):
    def test_guide_follows_new_flow(self):
        g = open(os.path.join(ROOT, "motion-studio", "GUIDE.md"), encoding="utf-8").read()
        for s in ("SPEC.md", "storylines", "snapshot --review", "newest release on npm"):
            self.assertIn(s, g)
        self.assertNotIn("never write `BRIEF.md`", g)


if __name__ == "__main__":
    unittest.main()
