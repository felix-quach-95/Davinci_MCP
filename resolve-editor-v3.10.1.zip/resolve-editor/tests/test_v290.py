"""v2.9.0: Cache Edit paths, no auto-render, finalize_project (cleanup + Vietnamese names), workflow gates."""
import json
import os
import re
import unittest

from _skilltext import skill_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")
WORK = "/Users/felix/Desktop/Final/Cache Edit"


def load(name):
    g = {"__name__": "offline"}
    exec(compile(open(os.path.join(SCRIPTS, name), encoding="utf-8").read(), name, "exec"), g)
    return g


def text(rel):
    return open(os.path.join(ROOT, rel), encoding="utf-8").read()


class Finalize(unittest.TestCase):
    def setUp(self):
        self.F = load("finalize_project.py")

    def test_classify_keeps_final_and_its_text(self):
        names = ["Probe_HK", "Test_Glow", "Draft_HK_v01", "Draft_HK_v02", "Final_HK_01", "Final_HK_02",
                 "TXT_hk_t01", "TXT_hk_t02", "TXT_old_t01", "My edit", "Draft_Other_v01", "TXT_other_t01"]
        c = self.F["classify_timelines"](names, "Final_HK_02", {"TXT_hk_t01", "TXT_hk_t02"}, "HK", {"TXT_other_t01"})
        self.assertEqual(sorted(c["keep"]), ["Final_HK_02", "TXT_hk_t01", "TXT_hk_t02"])
        self.assertEqual(sorted(c["delete"]), ["Draft_HK_v01", "Draft_HK_v02", "Final_HK_01", "Probe_HK",
                                               "TXT_old_t01", "Test_Glow"])
        self.assertEqual(sorted(c["untouched"]), ["Draft_Other_v01", "My edit", "TXT_other_t01"])

    def test_keep_extra_draft(self):
        c = self.F["classify_timelines"](["Final_HK_01", "Draft_HK_v03", "Draft_HK_v02"], "Final_HK_01",
                                         {"Draft_HK_v03"}, "HK")
        self.assertIn("Draft_HK_v03", c["keep"])
        self.assertEqual(c["delete"], ["Draft_HK_v02"])

    def test_pick_final_highest(self):
        self.assertEqual(self.F["pick_final"](["Final_HK_01", "Final_HK_03", "Final_HK_02", "Draft_HK_v09"], "HK"), "Final_HK_03")
        self.assertIsNone(self.F["pick_final"](["Draft_HK_v01"], "HK"))
        self.assertEqual(self.F["pick_final"](["X"], "HK", "X"), "X")

    def test_fusion_names_ascii_with_vietnamese_comment(self):
        n, c = self.F["fusion_vi"]("MFX_Xf")
        self.assertEqual(n, "HieuUng_KhungHinh")
        self.assertIn("Zoom", c)
        self.assertIn("[claude:MFX_Xf]", c)
        self.assertEqual(self.F["fusion_vi"]("T03")[0], "Chu_03")
        self.assertEqual(self.F["fusion_vi"]("MFX_OFX_FilmGrain")[0], "HieuUng_ResolveFX_FilmGrain")
        self.assertIsNone(self.F["fusion_vi"]("MediaIn1"))
        for pat, new, desc in self.F["FUSION_VI"]:
            self.assertTrue(re.fullmatch(r"[A-Za-z0-9_\\]+", new), new)

    def test_text_names(self):
        self.assertEqual(self.F["text_name"](3, "ĐÊM\nHồng Kông"), "Chữ 03 – ĐÊM Hồng Kông")
        self.assertTrue(self.F["text_name"](1, "x" * 60).endswith("…"))
        taken = {"Chữ 01 – A"}
        self.assertEqual(self.F["unique"]("Chữ 01 – A", taken), "Chữ 01 – A (2)")

    def test_tracks_vi(self):
        self.assertEqual(self.F["track_vi"]("audio", "MUSIC"), "Nhạc nền")
        self.assertEqual(self.F["track_vi"]("video", "footage"), "Hình chính")
        self.assertIsNone(self.F["track_vi"]("video", "My track"))

    def test_token_changes_with_plan(self):
        a = {"final": "F", "timelines": {"keep": ["F"], "delete": ["D"], "untouched": []}, "renames": {}}
        b = dict(a, timelines={"keep": ["F"], "delete": [], "untouched": ["D"]})
        self.assertNotEqual(self.F["make_token"](a), self.F["make_token"](b))

    def test_strip_accents(self):
        self.assertEqual(self.F["strip_accents"]("Đường đêm"), "Duong dem")


class Paths(unittest.TestCase):
    def test_config_paths(self):
        d = json.load(open(os.path.join(ROOT, "config", "defaults.json"), encoding="utf-8"))
        self.assertEqual(d["paths"]["work"], WORK)
        self.assertEqual(d["paths"]["qc_root"], "~/Movies/ClaudeQC")
        self.assertTrue(d["paths"]["tools"].startswith(WORK))
        self.assertEqual(d["scripts"]["qc_stills.py"]["OUT_DIR"], "${paths.work}")

    def test_loader_and_boot(self):
        L = load("loader.py")
        self.assertEqual(L["WORK_ROOT"], WORK)
        self.assertEqual(L["TOOLS_DIR"], WORK + "/_tools")
        self.assertEqual(L["QC_ROOT"], "~/Movies/ClaudeQC")      # prefs stay for later videos
        self.assertTrue(L["project_path"](WORK, "HK").startswith(WORK))
        self.assertIn(WORK + "/_tools", text("scripts/boot.py"))

    def test_no_temp_write_to_qc_root(self):
        for f in ("qc_stills.py", "frame_probe.py", "silence_beats.py",
                  "srt_from_transcript.py"):
            src = text("scripts/" + f)
            self.assertNotRegex(src, r'expanduser\("~/Movies/ClaudeQC"\)', f)
            self.assertIn(WORK, src, f)

    def test_audio_presence_cleans_up(self):
        src = text("scripts/audio_presence.py")
        self.assertIn('RENDER_DIR = "/tmp/ClaudeAudioCheck"', src)
        self.assertIn("DeleteRenderJob(JOB_ID)", src)
        self.assertNotIn(" ", load("audio_presence.py")["RENDER_DIR"])

    def test_motion_fx_maps_back(self):
        self.assertIn("[claude:(MFX_", text("scripts/motion_fx.py"))


class Workflow(unittest.TestCase):
    def test_skill_rules(self):
        sk = skill_text()
        self.assertIn("finalize_project.py", sk)
        self.assertIn("Cache Edit", sk)
        self.assertIn("Final approval", sk)
        self.assertNotRegex(sk, r"(?i)render only on request with `render_deliver.py` \(plan")


if __name__ == "__main__":
    unittest.main()
