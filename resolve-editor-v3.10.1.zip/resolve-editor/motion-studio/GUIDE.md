---
name: motion-studio
description: "Start here when someone wants a new video made in Claude Code (an ad or promo, an animated chart or KPI clip, a product or feature intro, an announcement, an explainer, a social post, in 16:9, 9:16, 1:1 or 4:5): the style comes first, from a gallery of looks or from the user's own reference (screenshots, a website link or a video file), then the user describes the video in plain words, HyperFrames proposes storylines and writes a SPEC the user confirms, builds it, and opens its Studio editor for review, changes and export. Also installs itself from its zip next to the user's other skills (Node.js if missing, FFmpeg, HyperFrames' skills: INSTALL.md), saves looks for reuse, makes a music bed without an account, and makes one video per row of a spreadsheet. Talks to the user in Vietnamese, and fires on Vietnamese requests too ("làm cho mình một video quảng cáo", "video giới thiệu sản phẩm", "biểu đồ động"). Runs before the hyperframes skill and hands over to it; for edits to an existing HyperFrames project, use hyperframes directly. Not for editing filmed footage by hand."
---

# Make a video, style first

The making is done by HyperFrames (HeyGen's open-source video framework: a video is an HTML page, rendered on this
computer, edited in its Studio). This skill is the front door around it, so the process is the same every time:

1. **Style:** the user picks a look from the gallery, or brings a reference.
2. **Describe:** they say what the video is, in plain words, in one go.
3. **Story and SPEC:** HyperFrames proposes three storylines in words (skipped when the request already fixes the story) and writes `SPEC.md`; the user confirms it.
4. **Build:** HyperFrames builds it.
5. **Review, change, export:** in HyperFrames Studio, or by asking here.
6. **Next job:** `/clear`, then ask; the video carries over in its folder.

## Talk in Vietnamese

Everything the user reads is in Vietnamese unless they ask for another language: questions, plans, the storylines and SPEC
summary, progress, Studio tips, errors and the `/clear` line. That holds while following HyperFrames' skills too:
their questions and summaries are written in English, so say them in Vietnamese. Write like a Vietnamese peer talks:
"mình" for Claude and "bạn" for the user, full and plain sentences, English for the words people use at work (video,
brief, SPEC, storyboard, font, preview, render, export, variables, voiceover), "phong cách" for a style, digits for
numbers, a comma before "và" in a list of three or more, no hype. HyperFrames Studio's own panels and buttons are in
English: name them as they appear (Design, Variables, Timeline, Export) and explain them in Vietnamese. The words on
screen follow the SPEC (an ad for Australia stays in English) whatever language the chat is in; quote them as they
will appear. Commands, file names and paths stay as they are.

Don't redo what HyperFrames does: its storylines, SPEC, storyboard, build, checks, Studio and render belong to its
skills (`hyperframes` is the entry). This skill adds the setup, the style step and the library, a complete hand-off,
a music bed with no account, and the batch from a spreadsheet.

Scripts are in this skill's folder (`<skill>` below: `~/.claude/skills/motion-studio` for the usual install, next to
the user's other skills) and run with Node 22 or newer from the folder Claude Code is open in. Each video is a folder
in that folder's `videos/`; if it's the home folder, suggest a folder for videos first (for example
`Documents/Videos`).

| Command | What it does |
|---|---|
| `bash <skill>/scripts/install.sh` | One-time install (below): Node.js if missing, then `setup.mjs`. `--update` fetches HyperFrames' pinned skills again |
| `node <skill>/scripts/styles.mjs gallery --open` | `gallery.html` in the style library: every built-in look and the user's saved ones, opened in the browser |
| `node <skill>/scripts/styles.mjs lib` | Where the style library is (`<skill>/styles` for the usual install, `styles/` in the videos folder for a project install) |
| `node <skill>/scripts/styles.mjs list` / `path <name>` | The looks as text / where a look's `FRAME.md` is |
| `node <skill>/scripts/styles.mjs frames <video> [--count 12]` | Stills from a reference video and a contact sheet, in the library's `_refs/` |
| `node <skill>/scripts/styles.mjs save <FRAME.md> --name "<name>" [--refs a.png,b.png]` | Adds a look to the library (`<library>/<name>/`) |
| `node <skill>/scripts/music.mjs videos/<name> [--mood vibes]` | A music bed made on this computer (`assets/music.wav`), following the scenes. Moods: vibes, pulse, lofi, keys, pluck |
| `node <skill>/scripts/batch.mjs videos/<name> data.csv` | One MP4 per row, in `videos/<name>/renders/batch/` |
| `node <skill>/scripts/sync-text.mjs videos/<name>` | Before every render: a word retyped on Studio's canvas goes into its variable, a Variables edit into the scene. Exit 2 lists the ones to ask about |

## 0. Is it installed?

It is when HyperFrames' `hyperframes` skill sits next to this one (in the same `skills` folder, or the project's
`.claude/skills`) and Claude Code's settings for that place have `HYPERFRAMES_FFPROBE_PATH` and
`HYPERFRAMES_SKIP_SKILLS` in their `env`. If not (the skill was just unzipped), install it the way `INSTALL.md` says:
run `bash <skill>/scripts/install.sh`, then tell the user to start a new Claude Code session (new skills and settings
load at start) and continue there. The install brings a private Node.js 22 into `<skill>/.tools/node` when the
computer has none, FFmpeg and FFprobe from npm into the skill, HyperFrames' skills next to this one, and
`HYPERFRAMES_SKIP_SKILLS=1` so HyperFrames never installs skills anywhere else. It writes `env` into the settings and
a SessionStart hook (`scripts/session-env.sh`) that puts a private Node.js first on PATH for every command (an `env`
PATH doesn't reach commands: they take PATH from the user's shell) and keeps `npx hyperframes` on the pinned version.
It keeps a copy of Claude Code's user settings as `settings.json.before-motion-studio` the first time.

**HyperFrames is pinned** to the release in `package.json` (`hyperframesVersion`). resolve-editor's installer sets it
to the **newest release on npm** at install time (0.8.209 on 2026-10-28) and `install.sh --update` then fetches that
release's skills; every `npx hyperframes` in them names that version. Run the CLI the same way
(`npx hyperframes@<pin> …`). Mid-job never run `npx hyperframes upgrade`, `skills update`, or anything `@latest`: a
project stays on the release `init` gave it. To move to a newer release: re-run resolve-editor's
`install_motion_studio.py`, then `install.sh --update`, between jobs. (Releases from 0.8.19x on use three storylines
and `SPEC.md` instead of the older brief; this guide follows them.)

## 1. Style

Unless the request already names a look or brings a reference, run `styles.mjs gallery --open` (if the page does
not open, `open "<library>/gallery.html"`; `styles.mjs lib` prints `<library>`) and say, **with the clickable link to
the page in the same message** so the user can always reopen the pictures:

> Mình vừa mở trang chọn phong cách trong trình duyệt (có hình minh họa của từng mẫu): file://<library>/gallery.html
> Bạn có 3 cách chọn:
> 1. Chọn một phong cách theo tên hoặc số thứ tự, ví dụ "Dùng phong cách coral".
> 2. Gửi cho mình 3 đến 5 ảnh chụp màn hình, một link website, hoặc một file video có phong cách bạn thích, kèm một
>    câu về điều bạn thích ở đó.
> 3. Hoặc nói "bạn chọn giúp mình".

- **A look from the gallery:** `styles.mjs path <name>` gives its `FRAME.md`. That's the style.
- **A reference:** make a look from it, the way `references/style-from-reference.md` says (images are read
  directly, a website goes through `npx hyperframes capture`, a video through `styles.mjs frames`), save it with
  `styles.mjs save`, reopen the gallery, and ask whether it's right before going on.
- **"Bạn chọn giúp mình"** (or "tuỳ bạn", "you choose"): no style; HyperFrames' design step picks one or shows mood boards (its "design picker").

Never replace the gallery by a text-only list of names, and never pick a look silently: the user chooses from the
pictures.

## 2. Describe

Ask for everything still missing in **one** message, with a recommended answer for each so a "yes" is enough. Skip
what the request already said:

- What it's for: the one thing it must say, and the offer, price or numbers if any.
- Who watches and where: that sets the format (website, YouTube or a meeting screen: 16:9; Reels, TikTok or
  Shorts: 9:16; a feed post: 1:1 or 4:5).
- Length (20 to 30 s for an ad, 15 to 25 s for a chart, under 10 s for a sting or a title).
- Their material: logo, photos, screenshots, a website, data. Only what they give is used.
- The language of the words on screen.
- Review a storyboard first, or build it straight away? (A storyboard for anything over a few scenes.)

## 3. Hand over to HyperFrames

Load the `hyperframes` skill and follow it from "Fresh creation", passing one request that carries the style and
every answer, in the shape of `references/handoff.md`. With the design spec named and the run's shape stated, it
proposes three storylines in words only when the story is still open (the user picks one), then writes `SPEC.md`
(every adjective as a number, the shots by frame) and shows its summary. The request also asks for every word,
number, colour and picture the user might change to be a HyperFrames variable: each then shows as one field in
Studio's Variables panel (retype a price and the video changes), and the same variables drive the spreadsheet batch.
Without them a counting price is eight separate letters in Studio's Design panel. **The user confirms the SPEC before
anything is built**: never write `SPEC.md` yourself, and never skip HyperFrames' summary. Their corrections are
folded in and shown again, as its rules say.

## 4. Build

HyperFrames' workflow builds, checks and opens the Studio preview at its final look. Let it run its own steps. When
it's done, before the user edits anything, run `sync-text.mjs videos/<name> --variables` once: it records every
variable, so the sync before each export can tell a canvas edit from a Variables edit (step 5).

Before the preview is shown as ready, HyperFrames' own work loop runs: `npx hyperframes check --json` (fix every
error) and `npx hyperframes snapshot --review` ending in `REVIEW.md`. Let it run; report what it fixed.

**Preview link, always sent:** the moment the Studio preview is running, send its link exactly as the preview
command printed it (`http://localhost:<port>/…`) as a clickable line, and open it in the browser (`open <url>` on a
Mac) — without waiting to be asked. Keep the preview running in the background; repeat the link whenever you report
a change, and if the preview restarts or its port changes, send the new link at once. Before sending, check it
answers (`curl -s -o /dev/null -w "%{http_code}" <url>` → 200); if not, start the preview again and send that link.

## 5. Review, change, export

When the preview opens, send its link first (step 4), then tell the user what they can do, in plain words (`references/review-and-export.md` has the
short version; a variable retyped in Studio shows in a scene once the preview plays or the playhead moves): click anything to move or resize it, change words, fonts and colours in Design, trim on the
timeline, Export; or ask here. Then:

- **Before any render** (the export, another resolution or format; `batch.mjs` does it itself): run
  `sync-text.mjs videos/<name>`. A word that is a variable sits in two places, the scene file and the variable's
  default on `index.html`. Studio (seen in 0.8.181; still run it on newer releases, it changes nothing when both
  sides agree) saves a word retyped on the canvas or in Design into the scene only, and the
  render (like Studio's preview once it reloads) takes the variable, so the edit would vanish; the script carries
  each change to the side that didn't change. If it exits 2, it wrote nothing for the words it lists: ask the user
  which wording to keep for each (quote both), rerun with `--canvas=<ids>` or `--variables=<ids>`, then render. A
  value retyped in Variables reaches the files only through "Set default", so a Variables change that the export
  lacks was probably never set.
- **Music:** HyperFrames' own music needs a HeyGen sign-in. If the video has none, run `music.mjs` (pick the mood
  with the user: vibes for most ads, pulse for corporate and data) and ask HyperFrames to place `assets/music.wav`
  under the whole video at full volume (it's already leveled to about -16 LUFS); its audio skill fades it and carves
  it under a voiceover. Say that Claude can't hear it: the
  user should listen.
- **Another format** (a 9:16 version of a 16:9 ad): a next job, so `/clear` first (step 7), then ask HyperFrames for
  it as a new version of the same film; it builds a sibling composition (`hyperframes-studio` covers follow-ons).
- **Other export settings:** `npx hyperframes render` (`--resolution`, `--fps`, `--quality draft|looks|delivery`,
  `--format mp4|mov|webm|gif`; MOV keeps transparency for laying over footage).
- **Many versions from a spreadsheet:** a next job, so `/clear` first (step 7). The words that change must be
  HyperFrames variables (the hand-off asks for them). `batch.mjs` takes a CSV whose columns are the variables, by id or by the label Studio shows, plus `name` for
  the file names. Before rendering, check what each row changes: a count or a colour in the words should also change
  the picture (the number of items drawn, text that stays readable on a new colour). If a scene doesn't read it from
  the variable, ask HyperFrames to make it, then batch.

## 6. Keep the look

If the user changed the look along the way (colours, fonts) and likes it, offer to save it for next time:
`styles.mjs save videos/<name>/frame.md --name "<name>"`. It shows under "Phong cách của bạn" in the gallery.

## 7. Start the next job with /clear

**Inside resolve-editor's Phase 11 this section does not apply:** the user's rule is one linked chat, so never
suggest `/clear`, a new chat or a new window there; a next job starts a new build agent in the same chat instead.
What follows is for Motion Studio used on its own.

A video's state lives in its files (`SPEC.md`, `frame.md`, the variables, `STORYBOARD.md`, the scenes), while every
call re-reads the whole conversation so far, so a second job in the same chat costs far more than the first. When
a video is delivered and the user wants another job (another format, a batch, re-rendering every version, or a new
video):

1. Write anything decided in the chat that isn't in the files yet (a new price, a dropped scene) into the project's
   `SPEC.md`, as HyperFrames' write-back rule says.
2. Tell the user, in about these words:

   > Để làm tiếp, bạn hãy gõ `/clear` rồi nhắn yêu cầu kèm tên thư mục của video, ví dụ "làm bản 9:16 của
   > videos/<name>". Brief, phong cách, và các variables đều đã lưu trong thư mục đó, nên không mất gì cả, đồng
   > thời việc tiếp theo cũng tốn ít usage hơn nhiều so với tiếp tục trong cuộc trò chuyện dài này.

Small changes right after delivery (a word, a colour, a scene's timing) stay in the same chat. A new video always
starts with `/clear`.

## Pitfalls

- HyperFrames' skills are fetched again (the same pinned release) only through `install.sh --update`, because HyperFrames' own skill installs are off.
- HyperFrames collects anonymous usage data; `npx hyperframes telemetry disable` turns it off. Setup prints this;
  pass it on once.
- Some Studio releases mark variables "unused" when the scenes read them in their own files (they only look in
  `index.html`). They are in use; say so if the user asks.
- Newer releases call Studio's editor "the HyperFrames desktop app" (with Framey, editing by chat). Pass its line on
  as an option, never as a requirement.
- A website that doesn't load can't be captured; ask for screenshots instead.
- Rendering runs on this computer: slower than a cloud tool, and long or effect-heavy videos take minutes.
- Building counts toward the user's Claude plan. HyperFrames checks remaining usage itself (`npx hyperframes usage`).
