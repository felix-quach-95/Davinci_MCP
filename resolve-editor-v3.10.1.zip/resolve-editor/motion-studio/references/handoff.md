# The hand-off to HyperFrames

One request that carries the style and every answer, so HyperFrames (`hyperframes` → `references/story.md`, then
`references/spec.md`) skips what's settled and goes to its storylines (only if the story is open) and its SPEC summary. It skips a question only when
the request already answered it, so say each answer plainly. Leave out a line the user didn't answer; HyperFrames
will ask it.

```
Make a new video (fresh creation) with HyperFrames.

What it is: <a 25-second promo for ...: the subject in one sentence>
The one message: "<the line the video must land>"
Offer / numbers: <price, dates, figures, exactly as the user gave them; "none">
Who watches and where: <audience>; plays on <destination>, so aspect <1920x1080 | 1080x1920 | 1080x1080 | 1080x1350>
Length: <N>s
Words on screen in: <language code and name, e.g. vi (Vietnamese)>
Talk to me in: Vietnamese (every question, the storylines, the SPEC summary, progress and the Studio tips; the words on screen stay
in the language above, quoted as they will appear)
Material: <paths of the logo, photos, screenshots, data; or "none: invent the visuals">
Website: <URL to capture | "none" | "don't capture">

Design spec: they have one, at <path to FRAME.md>. Adopt it as frame.md at the project root after init, and treat
it as brand truth. <If it came from a reference: "Made from <reference>; what the user likes: <their sentence>.">
(or) Design spec: none; pick a look that fits, or show the design picker.

Editable copy: make every word, number, colour and picture I might change a composition variable (data-var-text,
var(--id), or built from getVariables() for animated text), so each is one field in Studio's Variables panel:
<list them: the headline, the price, the product name, the web address, the accent colour, the logo>.
Give each variable a Vietnamese label, since Studio shows it: "Tiêu đề", "Giá", "Tên sản phẩm", "Màu nhấn".

Run shape: storylines <yes: show me three | no: the story is fixed above>, storyboard <yes | no>.
Ask only what this leaves open, then show me the SPEC summary to confirm before building.
```

Notes:

- **Variables** are what make the video editable like Claude Motion's Tweaks (retype the price, the video changes) and
  what a spreadsheet batch fills in. Name them in plain ids (`headline`, `price`, `cta_url`) with Vietnamese labels;
  a batch column can use either.
- **Music:** HyperFrames' music needs a HeyGen sign-in; without one the video has no sound. Say nothing about music
  here; after the build, `music.mjs` makes a bed and HyperFrames places it.
- **Website capture:** if the user gave a site, HyperFrames captures it and remixes the site's colours and fonts onto
  the preset's layout. When they picked a look on purpose, add "keep the picked look's colours unless the brand's
  are needed" or "use the brand's colours on this layout", whichever they said.
- **Storyboard:** `yes` shows stills of each scene before the full build; `no` builds straight from the confirmed
  SPEC. Anything beyond a couple of scenes is better with `yes`.
- **Storylines:** `yes` for a new film whose story is still open (HyperFrames shows three, the user picks one);
  `no` when the request already fixes the story and the timing (an overlay for an edited film, a single title).
- **Talk to me in** is the chat's language, set by this skill: Vietnamese. HyperFrames' interview and summary are
  written in English; they still reach the user in Vietnamese. It never changes the words on screen.
- **Language:** with non-Latin or accented text (Vietnamese, for one), HyperFrames swaps fonts that can't set it.
  Check the first stills for missing marks anyway.
