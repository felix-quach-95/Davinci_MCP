// The gallery's notes on HyperFrames' built-in presets, in Vietnamese: the mood, when to pick it, and the look.
// Written from the table in hyperframes-creative/references/design-spec.md (HyperFrames 0.8.167). A preset that
// isn't here (a newer HyperFrames) shows HyperFrames' own English notes.
export const PRESETS_VI = {
  'biennale-yellow': {
    mood: 'Tự tin, sâu lắng, tiết chế',
    when: 'Hợp với sản phẩm muốn vẻ sang trọng và có chiều sâu như một catalogue triển lãm.',
    look: 'Nền giấy ấm, một màu mực chàm đậm, vàng nắng làm điểm nhấn, tiêu đề serif mảnh và sát chữ, góc vuông, đường kẻ mảnh, không đổ bóng.',
  },
  blockframe: {
    mood: 'Mạnh, nổi bật, vui nhộn',
    when: 'Hợp với sản phẩm muốn trông tự tin và nhiều đồ hoạ.',
    look: 'Neo-brutalism: viền đen dày, bóng đổ cứng, 5 màu pastel, chữ Inter rất đậm viết hoa, góc vuông, hoạ tiết nghiêng.',
  },
  'blue-professional': {
    mood: 'Điềm đạm, dễ đọc, cao cấp',
    when: 'Hợp với sản phẩm muốn sự chặt chẽ như một báo cáo tư vấn hay báo cáo đầu tư.',
    look: 'Nền kem ấm, chỉ một màu xanh cobalt làm điểm nhấn, chữ Space Grotesk và Inter, thẻ nền nhạt không đổ bóng, nút bo tròn, thanh tiến trình màu cobalt.',
  },
  'bold-poster': {
    mood: 'Mạnh mẽ, chất in ấn, tiết chế',
    when: 'Hợp với sản phẩm muốn uy tín kiểu báo chí và nét cổ điển.',
    look: 'Poster kiểu báo cũ: tiêu đề Shrikhand hơi nghiêng, thân chữ serif, chỉ 4 màu (trắng, nâu đen, đỏ cà chua, trắng ngà), lưới viền đôi, góc vuông.',
  },
  broadside: {
    mood: 'Mạnh, lấy chữ làm chính, dứt khoát',
    when: 'Hợp với sản phẩm muốn gây ấn tượng và có sức nặng.',
    look: 'Poster cổ động: hai mảng phẳng đen và cam lửa, chữ Barlow rất đậm viết thường dùng như hình khối, chữ phụ IBM Plex Mono viết hoa, góc sắc, không đổ bóng.',
  },
  capsule: {
    mood: 'Thân thiện, mềm mại, kiểu tạp chí',
    when: 'Hợp với sản phẩm muốn ấm áp và dễ gần.',
    look: 'Mọi khung đều bo tròn như viên thuốc, viền đen mảnh, nền kem, 9 màu kẹo ngọt, chữ Bodoni Moda và Space Grotesk, bóng đổ mềm.',
  },
  cartesian: {
    mood: 'Thoáng, chất văn chương, tiết chế',
    when: 'Hợp với sản phẩm muốn uy tín một cách lặng lẽ và chỉn chu.',
    look: 'Kiểu catalogue bảo tàng: lưới kẻ mảnh màu nâu xám, 5 màu đá ấm, chữ Playfair Display và Inter, góc sắc, vòng tròn hình học như vẽ bằng compa, không đổ bóng.',
  },
  'code-editorial': {
    mood: 'Chỉn chu, chất văn chương, dành cho developer',
    when: 'Hợp với một bản cập nhật code, một lần ra mắt hay một tài liệu cần vẻ bình tĩnh và phần code hiển thị đẹp.',
    look: 'Nền giấy kem, màu cam đất làm điểm nhấn hiếm hoi, đường kẻ mảnh thay cho bóng đổ, tiêu đề EB Garamond, thân chữ Inter, code JetBrains Mono trên nền xanh navy.',
  },
  'cobalt-grid': {
    mood: 'Tiết chế, có hệ thống, kiểu tạp chí',
    when: 'Hợp với sản phẩm muốn sự rõ ràng và uy tín một cách điềm đạm.',
    look: 'In risograph hai màu: nền kem, mực xanh cobalt, lưới giấy kẻ ô, đường kẻ mảnh trên và dưới, chữ Newsreader, Hanken Grotesk, và DM Mono, góc vuông, hoạ tiết pixel.',
  },
  coral: {
    mood: 'Táo bạo, nhiều cấu trúc, kiểu tạp chí',
    when: 'Hợp với sản phẩm muốn đồ hoạ tự tin và dứt khoát.',
    look: 'Ba mảng màu đặc (cam san hô, đen, kem ấm) gặp nhau ở cạnh sắc, sọc chéo trên nền san hô, chữ Bebas Neue và Inter viết hoa, không bo góc, số cỡ lớn làm nền.',
  },
  'creative-mode': {
    mood: 'Thoáng, nhiều đồ hoạ, mạnh nhưng tiết chế',
    when: 'Hợp với sản phẩm muốn sự hiện diện kiểu tạp chí và hình khối tự tin.',
    look: 'Neo-brutalism: nền kem, viền đen dày, bóng đổ cứng, 4 màu nhấn dùng tiết kiệm, tiêu đề Archivo Black viết hoa, nhãn JetBrains Mono, góc vuông.',
  },
  'daisy-days': {
    mood: 'Vui nhộn, ngây thơ, dễ thương',
    when: 'Hợp với sản phẩm muốn ấm áp và ngộ nghĩnh.',
    look: 'Kiểu sách tranh: viền than chì, bóng đổ cứng, 9 màu pastel như khu vườn nắng, chữ Fredoka One và Quicksand, bo góc lớn, hoạ tiết vẽ tay (hoa cúc, ngôi sao, mây, cầu vồng).',
  },
  'editorial-forest': {
    mood: 'Thoáng, tiết chế, kiểu tạp chí',
    when: 'Hợp với sản phẩm muốn vẻ tự tin lặng lẽ và giọng văn chương.',
    look: 'Bộ ba màu xanh lá, hồng, và kem, tiêu đề serif Source Serif 4, nhãn JetBrains Mono viết hoa, nền phẳng không đổ bóng, đường kẻ mảnh, bo góc nhẹ, con dấu chữ lồng hình tròn.',
  },
};
