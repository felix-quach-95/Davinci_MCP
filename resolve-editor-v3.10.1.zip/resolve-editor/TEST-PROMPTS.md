# Test Prompts — Resolve Short-Form Editor v3.0.0 (`resolve-editor`)

Use these one at a time. v3.1: Express runbook check — "dựng video từ footage trong dự án này": expect stage.py, phase_run p1, a subagent catalogue, three stops (E1, E2, E3), every phase run answered by a short summary, STATUS.md written after each run. v3.0: prompts about titles, text, subtitles and fonts were removed (graphics belong to HyperFrames, Phase 10); use 7, 8 and 10b. Use a disposable/new draft timeline for any mutation test.

## 1. Read-only preflight
Use `resolve-editor`. Do not edit. Inspect Resolve status, active project, timeline, Media Pool, project settings, and live API signatures. Separate tested, unknown, and unsupported capabilities. Do not use `run_script_unsafe` unless a necessary local file operation is identified and explained.

## 2. Local footage discovery
Inventory every Media Pool item and discover source paths through Resolve API. Check local frame extraction options with a read-only capability test. If frame extraction is available, extract a few representative frames locally without changing source media and verify that the images are actually visible to Claude. Report metadata-only versus visually inspected evidence. Do not upload source clips externally or edit the timeline.

## 3. Reference audit
Treat the uploaded reference as style/structure reference and the imported footage as source footage. Inspect the whole reference only if its frames/audio are actually accessible. Produce a Reference Match Plan with OBSERVED / INFERRED / UNKNOWN labels. Do not copy unrelated subject matter, identity, or watermark.

## 4. Source evidence map and duration recommendation
Produce a footage evidence map from inspected frames and metadata. Recommend a teaser duration based on distinct usable moments and shot variety. If visual inspection is unavailable, mark content and usable timecodes unknown/provisional. Do not invent a duration or shot description.

## 5. Blueprint audit
Create a shot-level blueprint/EDL with source identity, source in/out, expected duration in frames, story function, track role, and text/audio requirements. Confirm all section durations sum to the target and source ranges stay within source bounds. Do not edit yet.

## 6. Draft timeline test
On a new draft timeline, assemble a small approved subset. Read back order, source ranges, track placement, frame origin, gaps/overlaps, and total duration. Stop if actual state differs from the blueprint.

## 7. Music analysis
Use `resolve-editor` Phase 2 on the supplied music before touching footage. Report duration, structure, phrases, drop and cut chances; label every tempo/beat value measured or estimated. If a value cannot be measured, say so. Do not invent a BPM.

## 8. Graphics boundary
Ask Claude to "add a title and subtitles". It must not build any text; it should explain that graphics are Phase 10, finish or confirm Phases 1–9, and then ask the Phase 10 graphic questions with concrete options.

## 9. SFX and audio test
Use a known local/free licensed SFX only if the source and terms are verified. Place one test item in a draft timeline, read back track, timing, and volume/fade properties. Do not claim mix quality without listening to playback.

## 10. Save/render test
Inspect current save/render API signatures and confirm output path, format, resolution, fps, audio, and overwrite policy. Verify job status and rendered duration if possible. File existence alone is not proof of correct playback.

## 10a. Final approval (v3.10.0)
Expect exactly two questions (Final name, cleanup) and no graphic question; after the report one question "Final đã xong. Chuyển sang Phase 11 — làm đồ họa với HyperFrames?" with Chuyển ngay / Để sau / Không cần đồ họa, and no new-chat, new-window or `/clear` option.

## 10b. Hand-over brief (Phase 11 §1 C–D)
After "Chuyển ngay": the gallery opens in the browser and its `file://` link is in the chat before any graphic question; after the pick, answer the graphic questions, run `hyperframes_handoff.py` and check: statuses (a Claude proposal is never `approved`), frames inside the Final, anchors near cuts/beats, Vietnamese subtitle lines ≤ 32 characters, safe-zone warnings, Markdown and JSON agree.

## 10c. Phase 11 package and session boundary (v3.6.0)
After 10b with an APPROVED brief: expect `qc_stills.py` stills of each element, a second `hyperframes_handoff.py` run with `stills` + `package_dir`, `HF_REQUEST_<Title>.md` and `START_PHASE11.md` in `<Cache Edit>/<Title>/hyperframes/`, the kickoff line in `STATUS.md` "Next", and the build agent started in the same chat (no `/clear`, no new chat). With any `proposed`/`open` item: no `HF_REQUEST`.

## 10d. Phase 11 build agent (same chat)
Expect: the agent reads only the phase card, `HF_REQUEST` and stills; `motion-studio` installed-check; style from `style.look` (no question); `STOP preview` with a `LINK: http://localhost:…` relayed verbatim and opened before any review question, repeated on later stops; no Describe questions; the `hyperframes` SPEC summary confirmed (no storylines) before the build; no music step; export only when asked; ffprobe shows prores + alpha, the Final's size and frame count, no audio; overlay stills over the Final looked at.

## 10e. Layers and the Phase 11 switch (v3.7.0)
Expect the switch question after the report; "Chuyển ngay" leads to the gallery, the graphic questions and the brief, then one agent whose reports are ≤ 8 lines and whose stops come back as questions here. After "xuất": one MOV per layer, `hf_layers.py` LAYERS_OK, then in a new Draft every layer at its start frame with its `DHnn_…` name, the colour of its kind and a named "ĐH …" track; the Final untouched.

## 11. Final acceptance
Run the full structural audit and reference-match scorecard. Compare target, blueprint, timeline, and render durations. A source identity mismatch, unexplained runtime shortfall, invalid source range, or missing core reference trait blocks acceptance. Separate structural checks from visual/audio checks.

## 12. Blocked-but-productive test
If the reference or footage frames cannot be inspected, continue safe read-only metadata inventory and API-signature checks. Ask only the minimum required follow-up. Explain exactly what is inaccessible and provide a practical fallback. Do not claim analysis from filenames or metadata.

## v1.4.0 additions

### 13. Script self-test (no Resolve needed)
Run `python3 -m unittest discover -s tests` in the skill folder. Expect every test OK (v2.1–v2.4 suites; 1 skipped when no font file is found).

### 14. Live read-only smoke test
Use `resolve-editor`. Run `scripts/inventory.py`, then `scripts/qa_audit.py` with the current timeline's target, then `scripts/qc_stills.py` for 4 frames. Show me the previews you actually looked at and list what you saw. Change nothing in the project.

### 15. Beat grid
List `/Users/felix/Desktop/Asset/Music` with `silence_beats.py` (MODE "list"), pick a calm track, return its BPM, first beat and confidence. Explain whether the grid is strong enough to cut on.

### 16. Dry-run blueprint
Write a blueprint for a 16 s night-city piece from the four Hong Kong clips (fill landscape with Pan, slow motion from 50/100 fps clips), run `build_from_blueprint.py` with `DRY_RUN = True`, and report planned frames vs target. No timeline is created.

### 23. Library scan
Scan my installed templates and my SFX folder. Tell me how many titles/effects need a font swap for Vietnamese, which templates contain sample or promo text, and the SFX role counts. Change nothing in the project.

### 25. Transitions with sound
Add a 10-frame Blur Dissolve where time passes and keep every other cut hard. Put a soft whoosh whose peak lands on that cut at the house whoosh level (−15 dB). Read back the alignment used and the SFX position.

### 26. Footage effect
Add Neo Glow at intensity 0.15 to the night aerial shot only. Save first, confirm the Fusion page opened that clip, and show before/after stills.

## v1.7.0 additions (endings)

### 27. Ending diagnosis
Run `ending_plan.py` on my draft and tell me, in plain words, why the end feels abrupt (or not). Show the last-seconds stills you looked at. Change nothing yet; then ask me how I want it to end.

### 28. Build the chosen ending
Build the ending I chose in a new DRAFT_…_end timeline: cut on the phrase hit, music ending in the quiet, picture fade, closing text if chosen, ambience tail. Re-run `ending_plan.py` and show it reports a natural end.

## v2.0.0 additions

### 29. Full run from a fresh project
"/resolve-editor dựng video từ 4 footage trong dự án này." Expect: inventory + identity check, Probe_ timeline and contact sheets, one creative-plan question round, a blueprint table with chapters on music hits, Draft_<Title>_v01 with cuts exactly on the hit frames, look, effects verified on/off, 2–3 text samples for approval, SFX cue sheet placed by peak/onset, ending_plan natural, QA sheet, review question, then Final_<Title>_01.

### 30. Effects vocabulary
On a Test_ timeline apply push+drift, punch, shake, blur_in/out, whip, flash, freeze and spotlight; show on/off still pairs and the measured differences.

### 31. B-roll from one clip
From one 16:9 4K clip make three vertical framings (Pan) and one detail insert (push on the object); report the Pan values computed from subject positions and the stills.

## v2.1.0 additions

### 32. Off-theme clip
"Dựng video Hồng Kông đêm" with one daytime clip in the pool. Expect: the day clip analysed like the others (ranges: sharp / wipe / defocus), Claude decides its use without asking (e.g. a one-phrase prologue ending on a natural wipe) and the report says why. No clip disappears without a reason.

### 33. Stale stills
Export stills at frames in four different clips in a jumping order (e.g. 41, 160, 405, 60, 300, 480) with `qc_stills.py`; the contact sheet must show the right shot at every frame.

## v2.2.0 additions (all UNTESTED live — the first run of each is a test)

### 34. Config and loader
Stage the scripts and `config/defaults.json`, run `loader.py` MODE "stage_check" and MODE "config" for project "HongKong". Then run `inventory.py` through the loader. Show which values were injected. Change nothing.

### 35. Project wishes
Save the Gate 1 answers of the current project with `loader.py` MODE "project_set" (story, look, ending, music) and read them back with "project_get".

### 36. Music choice
`music_library.py` scan (until remaining = 0), then pick 3 calm tracks of 30–90 s with clear phrases and a button/fade ending. Explain each pick from the measurements; say that nothing was auditioned.

### 37. Talking vlog paper edit
On a talking clip: `transcript_cut.py` transcribe → status → plan. Show the dropped list with reasons and the planned runtime; build the blueprint on a new Draft only after I confirm the drops.

### 38. Ducking
On that Draft with music on A2: `duck_music.py` plan with `RANGES` = speech_ranges, then apply. Read back segments on A2/A5 (source continuous, 8-frame overlaps). I will listen.

### 39. LOG conversion
`color_look.py` plan on a Draft with mixed footage (paste the `list_luts` files). Explain the gamma evidence per clip; for "unknown" clips look at a still and set LOG_OVERRIDE. Apply on a Test_ copy, show before/after stills and the revert info.

### 40. Smooth ramp vs stepped ramp
On a Test_ timeline build the same moment twice: blueprint `ramp` steps and `motion_fx` `ramp_smooth`. Export stills two frames apart around the slow point for both and say which reads smoother.

### 41. Scene cuts, Smart Reframe, Stabilize
Put one long clip on a Probe_ timeline, run `picture_tools.py` scene_cuts and show the shot list with contact sheets. On a Test_ copy compare Smart Reframe with my Pan framing on stills; stabilize one handheld shot and check the edges.

### 42. Render and verify
Render the latest Final_ with `render_deliver.py` (plan → start → status → verify, preset tiktok). Report size, fps, duration, integrated loudness, true peak and the fix if outside −14 ± 1 LUFS / −1 dBTP. Export a cover JPEG and show it.

### 45. Talking cut that breathes
On a talking clip: `voice_audit.py` audit, `silence_beats.py` silence (auto floor), `transcript_cut.py` plan with PROFILE "story" and again with "vlog". Show both reviews (struck-through text), piece counts, runtimes and `uncovered_jump_cuts`; build the one I pick, then read back the audio crossfades.

### 46. Punchline
Pick the strongest line in the transcript, set PUNCHLINES, rebuild on a new Draft version and show stills before/inside/after the punch (100 % → 115 % → back).

### 47. Linked A/V sync
Run `qa_audit.py` on the talking Draft and report `av_sync_linked`.

### 48. Voice levelling
`voice_audit.py` normalize: list the A1 items, normalise only the speech items, report gains and any item raised > 20 dB. Tell me the EQ steps I should do by hand if the audit called the voice muffled.

### 49. Music really there?
`audio_presence.py` start → check over 6 s that contain music and one SFX. Report correlation, lag and gain per item.

### 50. ResolveFX
`picture_tools.py` resolvefx_check on a Test_ item; then add Film Grain to all V1 items of a Test_ copy and Glow to the night shot; on/off stills.

### 51. Follow the subject
On a Test_ timeline, a walking subject in a 16:9 shot: positions from the contact sheet → `reframe_path`; stills at start/middle/end show the subject centred and no black edge.

### 52. Replace one shot
In the latest Draft replace shot 4 with another range of the same clip using `replace_shot.py`; show that the next version keeps every cut time, the LUT and the Pan, and list the motion effects to re-run.

### 53. Scorecard
After QA on a full Draft, fill `review-scorecard.md` from the stills you looked at and name the blockers (or none).

### 55. Paper edit with reasons
"Lên kế hoạch dựng 20 s Hồng Kông đêm từ 4 clip." Expect: spine sentence, act timing, tension arc, montage method per chapter, drop frame, and the paper-edit table where every cut says what it cuts on and why (no "nice shot"), J/L cuts with frames, B-roll layers, retention device per chapter; `edit_analysis.py` notes resolved or accepted.

### 56. Why this frame
"Tại sao cắt ở frame 168?" Expect an answer from the plan: the beat/drop, movement or gaze it cuts on, what the frame before and after would cost, and the Murch priority it serves.

### 57. Framing check
For three hero shots: read subject boxes off stills, run `composition_check.py`, propose Pan changes with the reason (eye line, look room, UI), re-export stills after the change.

### 58. J/L cuts in a talking piece
Add an L-cut over each B-roll insert and a J-cut into each new location; build from `blueprint_split`; read back the A1 rows and show that picture and sound cut points differ by the planned frames.

### 59. Parallel threads
Plan a 30 s piece with two threads converging at the drop; show the alternation lengths shrinking (edit_analysis `parallel`).

## v2.5.0 additions (research before the edit)

### 60. Research pass
"Nghiên cứu hook và từ khoá cho video 30 s du lịch Hồng Kông 500k trước khi dựng." Expect: vidIQ tools found with ToolSearch (no guessed names), `vidiq_balance` first, TikTok/Reels hook search with an audience line, keyword research, `vidiq_trending_videos` with `vi`, one walkthrough polled to completion, ≤ 30 credits reported, only topic words sent; `research_card.py` card with primary keyword, recommended hook pattern and evidence, target runtime, hashtags, warnings (YouTube-only proxy if so); hook examples not copied.

### 61. Research into Gate 1 and the plan
Continue from 60: Gate 1 offers the researched hook pattern as the first option with its evidence; the paper edit carries `bp["research"]` with the user's own hook text (≤ 7 words) and segment roles; `edit_analysis.py` research notes resolved (runtime vs target, payoff in the first 2 s for `result_first`).

### 62. No connector
With vidIQ not connected (or 0 free credits): Claude says so in one line and runs the pass on free sources without asking — Creative Center (Vietnam, 7 days), TikTok/YouTube search pages, Google Trends — then shows the card with its sources; the edit is never blocked.

## v2.6.0 additions (free-first research)

### 63. Partial credits
With 15 free credits left: Claude runs the TikTok hook search and the Vietnamese Shorts trending call (10), skips the walkthrough, covers keyword demand with Google Trends and the walkthrough with 2–3 TikTok search results read in the browser; no request to buy credits; card shows credits left and the source of each part.

### 64. Trending sounds
"Nhạc nào đang hot trên TikTok Việt Nam hợp video đêm Hồng Kông?" Expect Creative Center songs (Vietnam, 7 days) with rank and rising flag, the licence note, a library track of similar mood/BPM from `music_library.py`, and the option to cut to the song's phrases and add the sound in the TikTok app.

## v2.7.0 additions (BoConCN live run)

### 65. Empty pool / wrong fps
Open a new project with no clips: preflight stops and asks where the footage is. Import 25 fps footage into a 24 fps project: inventory warns `FPS_MISMATCH`, Gate 1 asks whether to switch the project to 25 fps (no timeline yet).

### 66. Long clips
Five 10–17 min DJI clips with `.LRF` sidecars: `frame_probe.py` decodes the proxies (`decoded: proxy`), burns frame numbers into the thumbnails, stays inside 45 s (PARTIAL + `remaining` otherwise); then MODE range over the useful stretch before choosing in/out.

### 67. SFX cue sheet
"Thêm whoosh vào cú tăng tốc, riser vào nụ cười, chuông lúc mở cổng": `sfx_library.py` MODE place — peaks/onsets on the event frames (read back, off by ≤ 1), levels by role and file loudness (a quiet riser is raised), first free SFX track; `audio_presence.py` reports the riser present (or "present but buried"), not MISSING.

### 68. Ending check
Music hit 1–3 s before the end and a 1.6 s music fade: `ending_plan.py` says "natural (hit + fade)", uses music_library's phrase hits when its own detector finds none, and never proposes an end outside ±6 s.

### 69. Two picture fixes after review
Two shots need a later source in point: one `replace_shot.py` run with `SHOTS` makes one new version; motion effects re-run on the swapped items.

### 71. Gate 0
"Dựng video Hồng Kông đêm": after the inventory, one question card with intensity (cinematic 5–10 / 15–20 s recommended), text density (nhấn theo nhịp), advanced text (multiSelect) and audio sources; answers in `project.json` and `_prefs.json`; the next video offers them as "như video trước".

### 73. Context SFX levels
Same whoosh on a quiet night shot and on a loud market shot: MODE place reports two different beds and levels (market louder, quiet shot lower); a cue under speech is not raised; MODE bed explains the numbers.

### 74. Free audio
"Thư viện không có nhạc lo-fi buổi sáng": Claude shows 2–3 Pixabay/Mixkit tracks with licence, length and why; nothing is downloaded before approval; `audio_ingest.py` puts them in `_Free/<source>/` with a sidecar; a CC BY-NC track is refused; at delivery MODE credits gives the credit lines.

### 75. Rough-cut checkpoint and alternates
After the picture build: a contact sheet + paper-edit table and one question; "đổi cảnh 4" at review uses the segment's `alt` with `replace_shot.py`; the note becomes a lesson only when it is a taste rule.


## v3.2.0 checks
1. **Opening gates.** "Use resolve-editor. Make a video up to 30 s from the footage in the Media Pool." Expected: Phase 1 + footage scan → numbered message with 5 style options (each citing shot IDs, with a strip image) and option 6 "write your own" → after the answer, 3–5 music styles with one preview MP3 each + "I send my own" → only then Phase 2. No title/subtitle/animation question.
2. **Own music.** Drop a track in the Media Pool first. Expected: E0a asked, E0b skipped with the file named.
3. **Catalogue.** After Phase 3 the catalogue holds shot rows with IDs (`C03.S02`), stages, In/Out from SEEN frames, roles, `grp`, `fx`, and counts `seen/inferred/unverified`; ≥ 1.5× the shots the plan needs.
4. **No repeats.** Put the same range twice in a blueprint → `edit_analysis` reports source-frame overlap; the same `grp` twice → repeat note; three shots with the same `size` → pattern note; total above 30 s → runtime note.
5. **Cinematic.** The hero speed ramp lands on the catalogue's peak frame and a music hit; 1–3 hero ramps; no two strong effects on one shot; on/off stills prove them.
6. **Editorial verdict.** The Phase 6 rough-cut review and Phase 9 report give an editorial verdict separate from `qa_audit`.

## v3.3.0 checks
1. **Music request.** "Use resolve-editor. Make a video up to 30 s from the footage in the Media Pool." (no music in the pool). Expected: Phase 1 footage scan → Style choice (5 options + "Tự viết phong cách của bạn") → one message "Yêu cầu gửi nhạc nền" naming the chosen style and how to send the file → Claude waits. No music styles, previews or downloads.
2. **Own music first.** Drop a track in the Media Pool before starting. Expected: Style choice asked, Music request skipped with the file named.
3. **Shot names.** After the Draft build, V1 items read `shot_01`, `shot_02` … left to right; after `replace_shot.py` on item 5 the new item is still `shot_05`.
4. **Colours.** Music items Green, SFX items Yellow right after they are placed (not only after the Final cleanup).
5. **Names in reports.** Every stop is called by its full name (Style choice, Music request, Story approval, Draft review, Final approval); no "E0a", "E1" or "Gate 3".
