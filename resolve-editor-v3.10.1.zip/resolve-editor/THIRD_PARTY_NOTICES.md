# Third-Party Notices

This skill package was developed for the user's Claude Desktop + DaVinci Resolve workflow. Its staged workflow principles were informed by the public README of `liuluhaixiu/DaVinci-AutoEdit-Agent` (https://github.com/liuluhaixiu/DaVinci-AutoEdit-Agent), which identifies itself as MIT-licensed. This package does not bundle code from that repository. The concepts adapted are general workflow ideas: evidence-grounded media review, staged planning, edit blueprints, immutable source media, approval gates, post-write audits, and delivery verification.

Version 1.4.0 also adapts general workflow concepts (not code) from these MIT-licensed public projects, read on 2026-10-24:
- legionsound/open-fusion-mcp — https://github.com/legionsound/open-fusion-mcp (render-and-look validation, motion-design construction and easing rules, undo/preservation discipline)
- BEMBOOMER/resolve-mcp-bridge — https://github.com/BEMBOOMER/resolve-mcp-bridge (transcript/silence cuts as a fresh timeline, punch-ins, remapped subtitles, markers, music/SFX/beat grid, QA report)
- olegkupshukov/claude-resolve — https://github.com/olegkupshukov/claude-resolve (alpha overlay route, curated fonts)
Concepts were also informed by jordanurbs/venice-video-harness (cut-boundary checks) and bestagentkits/motion-video-skill (beat-grid fitting); see references/github-sources.md. All scripts in scripts/ were written for this package.

Version 1.5.0 adds text styles derived from reference videos the user supplied (grammar only: layout, timing, colour roles — no text, logos or footage copied). Fonts referenced (EB Garamond, Cormorant Garamond, Playfair Display, Be Vietnam Pro, Dancing Script, Great Vibes, Pinyon Script) are SIL Open Font License 1.1 Google Fonts; they are not bundled — `scripts/fonts.py` downloads them from github.com/google/fonts with their licence files. The cmap parser in `fonts.py` is original code.

Version 1.6.0 reads (never copies into this package) the Fusion templates the user installed in Resolve (mTitle Cinematic by MotionVFX, Free Starter Pack 2.0 by Video Editor Studio, NeoFX, MagicAnimate/MagicZoom by MrAlexTech, Smooth Titles, Clean Simple Titles, Text/Glitch/Drawing Text Animation, Call Outs) and the user's own sound-effect files. Their licences are the user's; the skill only catalogues and uses them inside the user's projects. Fonts installed for the templates (Barlow Condensed, Lora, Open Sans) are SIL OFL 1.1 Google Fonts, downloaded with their licence files.

Version 2.3.0 adapts workflow ideas, numbers and reported API behaviour (not code, not text) from these public projects, read on 2026-10-25: appariciojunior/video-editor-skills (CC BY-NC 4.0 — only facts and parameter values are used, no wording; pacing numbers, captions/import traps, music envelope, voice checks, render traps), ChaiWithJai/davinci-resolve-claude-skills (MIT; four-lane review, audio source audit, jump-cut rules), AdamGarceau/resolve-toolkit (no licence file — ideas only: adaptive silence floor, pacing profiles, paced punch-ins, 2-frame crossfades), CiprianSpiridon/davinci-resolve-mcp (MIT; ResolveFX via clip comp, plugin ids list, silence-removal gotchas), guycochran/resolve-mcp-server (MIT; video-only shot replacement, multi-track lessons), voidash/claudepipe (MIT; easing, match cuts, Ken Burns, crop paths), lordhoell/davinci-resolve-mcp (MIT), odaiouattara0022-del/davinci-resolve-skill (MIT), LevyBytes/AI-SKILL-davinci-resolve (Apache-2.0; ResolveFX and Resolve 21 references). All scripts in scripts/ were written for this package.

If code from that repository or another third-party project is added in a future version, preserve the original copyright and license notices and update this file accordingly.

DaVinci Resolve is a product of Blackmagic Design. This package is independent and is not affiliated with or endorsed by Blackmagic Design, Anthropic, or OpenAI.

## Motion Studio (motion-studio/)
The user's Motion Studio skill (built on HyperFrames by HeyGen), from 0.4.1, adapted as 0.5.0 for the newest HyperFrames (guide, hand-off and README text; package.json pin) and its SKILL.md renamed GUIDE.md. Its licence and terms are those of its authors; HyperFrames is fetched by its own installer. Its licence and terms are those of its authors; HyperFrames is fetched by its own installer.
