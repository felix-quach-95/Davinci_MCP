# Editorial decisions and QC — is the story good, not only built right (v3.2.0)

`qa_audit.py`, stills and the audio check prove the timeline is **technically** correct. This module judges the **editorial** quality, separately, so a technically perfect timeline can still fail and a rough one can still be right. Used on the rough cut (Phase 6, before any polish) and again before the Draft review (Phase 9). Companion: `review-scorecard.md`, `edit_analysis.py`.

## Contents
1. Two verdicts, never merged
2. Rough-cut review (Phase 6, before polish)
3. Cut reasons, shot length and rhythm
4. Early cut, late cut, spare shots, even rhythm, too many effects
5. Hook, payoff, peak, release, ending
6. Retention without a formula
7. Fixing by scope — do not re-run the workflow
8. Report format

## 1. Two verdicts, never merged
- **Technical verdict** (`qa_audit.py`, read-back, `audio_presence.py`): runtime, gaps, overlaps, clipping, black frames, tracks.
- **Editorial verdict** (this module): story clarity, emotion, rhythm, variety, effects, ending.
Report both. "Technical PASS, editorial PARTIAL" is a normal and honest result. A Final may not be started with an editorial FAIL on a blocker (§7).

## 2. Rough-cut review (Phase 6, before polish)
When: `Draft_<Title>_v01` is built and read back, **before** accents, SFX, colour. Fixing story here costs one build; after polish it costs every layer (`SKILL.md` layers).
How: the rough-cut sheet (middle frame of each segment, numbered, with shot ID, group, length) + the paper-edit table. Answer in order, with evidence from the sheet/read-back:
1. **Story**: does the sequence read as the contract (`story-decision-framework.md` §1)? Where does a viewer get lost, bored or surprised?
2. **Beats**: does every beat change something? Are hook, peak and ending the chosen shots?
3. **Repeats**: the four levels of `shot-selection-and-continuity.md` §6, including "two thumbnails that look alike".
4. **Rhythm**: ASL per section vs the arc; where the cut speeds up or breathes; equal-length runs (`edit_analysis`).
5. **Variety**: shot sizes, directions, movements, light — no run of 3 the same.
6. **Effects plan**: where will the ramps and zooms live (not yet built)? Do enough shots have the `fx` suitability?
Outcome: `ROUGH-CUT OK` (continue to Phase 7), or a list of fixes with scope (§7). Express: auto-accepted only when `edit_analysis` has no open note **and** the checks above find no blocker; the sheet and verdict are sent as information.

## 3. Cut reasons, shot length and rhythm
Every cut has a reason (`cut: {reason, on, type, why}`): emotion, story, rhythm, eye trace, plane, space, idea, reveal — on a beat, movement, gaze, breath, sound, contrast, ellipsis or structure. Test: "if I delete this cut, what does the viewer lose?" Nothing → the cut or the shot is spare.
**Shot length = time to read the image + one beat of feeling.** Starting values for 9:16 phone viewing: a clear wide 2–3 s; a detail 0.8–1.5 s; a face with emotion 1.5–2.5 s; the peak shot as long as the slow step needs (1.5–2.5 s); the ending shot 2–4 s. Style profiles set ASL ranges; the arc raises or lowers them (`montage-advanced.md` §6). A shot holds longer only if something keeps changing inside it (movement, push, ramp, light).
Rhythm should come from the story, not from the grid: ignore beats with no visual reason (`music-analysis.md`).

## 4. Early cut, late cut, spare shots, even rhythm, too many effects
| Symptom | How to detect | Fix (smallest) |
|---|---|---|
| **Early cut** | the cut leaves before the action's peak/settle registered; thumbnails at −3/0 frames show the action unfinished; the next shot's information arrives before the first is read | extend Out by 4–12 frames (use handle) — `timeline_ops`/trim, then re-run layers 2–3 for that item |
| **Late cut** | the information was delivered ≥ 0.5 s before the cut; the last frames are static, the subject is leaving, or the eye has nothing new | shorten Out; or add a push/ramp so the extra time does something |
| **Spare shot** | removing it changes no beat, no fact, no emotion; or it repeats a group/info | delete; close the gap by extending neighbours or re-fit to the music phrase |
| **Even rhythm** | ≥ 3 consecutive shots of nearly equal length (`equal_runs`); flat ASL across sections | vary one length by ≥ 25 %; let the peak breathe, quicken the build |
| **Same-pattern run** | ≥ 3 same size / move / direction | swap one for the alternate with a different size or direction |
| **Too many effects** | strong effects > the density for the style, two strong on one shot, an effect without a reason or sound, every cut with a transition | remove the weakest; keep strong effects for the peak and phrase turns (`motion-effects.md` §2) |
| **Flat video** | no contrast of scale/speed/light between chapters; B-roll only illustrates | add a contrast beat (wide→detail, slow→fast), a bridge, or a ramp/zoom at the turn |
| **Cut on nothing** | `cut.on` is beat but misses the grid, or no movement/gaze/idea motivates it | move to the true event frame (`edit_analysis` music report) or justify differently |

## 5. Hook, payoff, peak, release, ending
Score each PASS / PARTIAL / FAIL with the frame that proves it:
| Element | Question | FAIL looks like |
|---|---|---|
| **Hook** (first 1.5–3 s) | does frame 1 give a reason to keep watching (motion, striking detail, a question)? is it consistent with the story, not a bait? | a slow establishing wide with no movement and no promise; a hook the video never pays off |
| **Payoff** | is the promise of the hook / contract delivered? | the end answers a different question |
| **Peak** | is there one strongest image, on a music hit/turn, with the strongest effect (ramp/push) and at most one competitor? | two equal peaks; peak in the first third; a peak with no build |
| **Release** | after the peak, does the viewer get at least a phrase of breathing (slower, wider, softer)? | the video ends on the peak or races on |
| **Ending** | does it feel finished (`endings.md`): natural end per `ending_plan`, an image that closes the idea, sound that lands? | stops suddenly; ends on a random shot; music cut mid-phrase |

## 6. Retention without a formula
Retention is a question, not a template: **what new thing does the viewer get every 2–3 seconds, and is there an open question to carry them?** Check:
- a change (scale, subject, direction, speed, light, information) at least every 2–3 s;
- one open loop (a question, a promise, a direction the eye follows) that the ending closes;
- no stretch where nothing changes for > 3 s unless the style is deliberately calm (then something must still move: light, camera, music).
Do **not** force one structure on every video (rapid cuts, "hook in 1 s", a fixed shot count). `calm_documentary` may hold 4 s on a face; `night_cinematic` may open on a slow push. The judgement is "does it fit this video's contract and style and still give the viewer something new", recorded in one line. Platform tricks (loops, trending hooks) are an option from research (`trend-research.md`), never a rule.

## 7. Fixing by scope — do not re-run the workflow
Classify every finding by **severity** and **scope**, then fix at the smallest scope that solves it and re-check only what changed.
| Severity | Meaning | Examples |
|---|---|---|
| **Blocker** | the video fails its contract | repeated footage; no peak; story unclear; clipped meaning; hook/ending missing |
| **Major** | clearly weaker, fixable | early/late cuts on key beats, flat rhythm, effect overload |
| **Minor** | polish | a 3-frame trim, a level, a weaker bridge |
| Scope | Fix with | Re-run |
|---|---|---|
| **One item** (a trim, a swap, one effect) | `replace_shot.py` (same length) · trim in the Draft · `motion_fx` for that item | only that item's layer 2–3 cues, then the check that found it |
| **One section/chapter** | re-order or re-fit that chapter's segments, `build_from_blueprint` for the chapter | layers 1→3 for the chapter's range |
| **Structure** (beats, hook, ending, music) | edit the beat map/blueprint | blueprint → layers 1→2→3→4→QA (the change router in `SKILL.md`) |
| **Sound only** | `set_levels`, SFX file, ducking | layer 3 + `audio_presence` |
| **Colour only** | strength | layer 4 |
Rules: (1) say which layers will re-run **before** doing it; (2) every fix goes in the next `Draft_<Title>_vNN`; (3) re-QA only the touched range ± 1 cut; (4) at most **two** review loops per gate — after that list the remaining notes for the user instead of looping; (5) a taste note ("không dùng flash trên cảnh đêm") becomes a `lessons` entry (`options-playbook.md` §6).

## 8. Report format
`Editorial — Story PASS (contract read in 8 beats) · Repeats PASS (0 of 4 levels) · Rhythm PARTIAL (3 equal shots in the build; s05 lengthened) · Effects PASS (7 accents, 1 strong per shot) · Ending PASS (natural per ending_plan)` · `Technical — qa_audit PASS`. Then blockers (none / list), the one change that would help most, and the layers that were re-run.
