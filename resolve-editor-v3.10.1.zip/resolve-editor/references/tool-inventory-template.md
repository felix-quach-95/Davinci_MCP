# Tool Inventory Template

| Capability | Tool/API method and exact signature | Read-only/mutating | Status | Read-back evidence | Limits/risks |
|---|---|---|---|---|---|
| Resolve status | | | UNKNOWN | | |
| Active project | | | UNKNOWN | | |
| Media Pool enumeration | | | UNKNOWN | | |
| Source paths | | | UNKNOWN | | |
| Metadata | | | UNKNOWN | | |
| Frame extraction | | | UNKNOWN | | |
| Images visible to Claude | | | UNKNOWN | | |
| Create draft timeline | | | UNKNOWN | | |
| Insert source ranges | | | UNKNOWN | | |
| Track assignment | | | UNKNOWN | | |
| Fusion/Text+ | | | UNKNOWN | | |
| Keyframes | | | UNKNOWN | | |
| Subtitle generation | | | UNKNOWN | | |
| Audio/SFX | | | UNKNOWN | | |
| Save | | | UNKNOWN | | |
| Render | | | UNKNOWN | | |
| Output verification | `render_deliver.py` MODE verify (ffprobe + ebur128) | read-only | UNKNOWN | | |
| Transcription | `MediaPoolItem.TranscribeAudio()` / `GetTranscription()` | mutating (analysis) | UNKNOWN | | |
| Scene cuts / Smart Reframe / Stabilize | `picture_tools.py` | mutating (Probe_/Draft_) | UNKNOWN | | |
| Colour version + LUT | `color_look.py` | mutating (version) | UNKNOWN | | |
| Shared config loader | `loader.py` MODE config / stage_check | read-only | UNKNOWN | | |

Status definitions:
- `TESTED`: low-risk operation executed and actual state read back.
- `DOCUMENTED/UNTESTED`: found in docs/stubs but not verified in this environment.
- `UNKNOWN`: insufficient evidence.
- `UNSUPPORTED`: no available route.
- `FAILED`: attempted and failed or read-back contradicted the intended result.
