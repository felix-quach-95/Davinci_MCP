# ResolveFX on clips (v2.3, UNTESTED live)

Resolve's built-in ResolveFX/OFX effects can be added to a clip by script: inside the clip's Fusion comp, `comp.AddTool("ofx.com.blackmagicdesign.resolvefx.<id>")`, wired between the last node and `MediaOut1` (route proven by CiprianSpiridon/davinci-resolve-mcp; there is no Edit-page "apply effect" call). In this skill: `motion_fx.py` effect `"resolvefx"`.

## 1. Check first
`picture_tools.py` MODE `"resolvefx_check"` on a `Test_`/`Probe_` item: adds each id in `RESOLVEFX`, records whether it exists on this Resolve and its **input names** (needed for `params`), deletes it again. Ids below come from the Resolve 19.1 plugin list published with that MCP; names can change between versions — trust the check, not this table.

## 2. Ids useful for short-form mood pieces
| id | Effect | Use | Taste |
|---|---|---|---|
| `filmgrain` | Film Grain | filmic texture over a graded look | subtle; one setting for the whole piece |
| `glow` | Glow | night lights, neon, dreamy | low; LOG footage is graded after Fusion — keep it lower than it looks |
| `lightray` | Light Rays | sun/lamp through haze | one shot, motivated light only |
| `lensflare` | Lens Flare | a reveal with a light source in frame | rare; never on faces |
| `lensreflections` | Lens Reflections | subtle optical life on bright highlights | rare |
| `aperturediffraction` | Aperture Diffraction | star points on street lights | night city |
| `halationplugin` | Halation | film-like red glow around highlights | with grain, very subtle |
| `filmlook` | Film Look Creator | whole film emulation | only if the user asks for "film"; replaces part of the look |
| `vignette` | Vignette | pull the eye to the centre | subtle; spotlight in `motion_fx` is the keyed alternative |
| `motionblur` | Motion Blur | smooth fast pans / speed ramps | check stutter on stills |
| `camerashake` | Camera Shake | impact (alternative to `motion_fx` shake) | short |
| `chromaticaberration` | Chromatic Aberration | glitchy energy | energetic pieces only |
| `invertcolor` | Invert Color | 1–2 frame stutter (alternative to `motion_fx` `invert`) | energetic/rugpull only |
| `defocusbackground` | Defocus Background | separate a subject | check edges on stills |
| `contrastpop` | Contrast Pop | punchier midtone detail | low |
Other ids exist (blur family, keyers, restoration, stylize: `gaussianblur`, `prismblur`, `tiltshiftblur`, `zoomblur`, `noisereduction`, `deflicker`, `dehaze`, `sharpen`, `beauty`, `facerefinement`, `skyreplacement`, `objectremoval`, `stopmotion`, `watercolor`, `sketch` …): only when the brief calls for them.

## 3. How to specify
```python
EFFECTS = [{"track": 1, "index": 5, "fx": "resolvefx", "regid": "filmgrain", "params": {"Blend": 0.35}}]
```
`params` keys are the input names from the check (each `SetInput` result is read back as `params_set`). Node name `MFX_OFX_<id>`; it runs after the other MFX nodes; `REPLACE=True` removes it with them.

## 4. Rules
- Effects follow the look: Fusion runs before the Color page, so a LOG clip is graded after the effect — judge on graded stills, keep glow/flare lower.
- One texture family per piece (grain + halation, or none); never stack several "film" effects.
- On/off still pair for every effect (as for `motion_fx`), and a still at the brightest frame (blown highlights).
- ResolveFX that analyse motion (Motion Blur, Deflicker, Stop Motion) are heavy: one shot first, check render time.
