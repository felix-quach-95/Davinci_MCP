# Resolve API Cookbook (verified against the 21.1.1 stub)

Every signature below was read from `get_scripting_api` (DaVinciResolveScript.pyi, v21.1.1) on 2026-10-24. "Stub-verified" means the method exists with this signature; it does **not** mean it behaves correctly in every case. Behaviour notes come from earlier sessions and are labelled. Re-check with `get_scripting_api(types=[...])` if Resolve updates.

## Contents
1. Conventions
2. Read / inventory
3. Build a timeline from ranges
4. Item properties: fit, zoom, pan, opacity, audio
5. Speed and retime
6. Fades and transitions
7. Titles (Text+)
8. Subtitles and transcription
9. Markers
10. Stills and thumbnails (visual QC)
11. Audio utilities
12. Color
13. Render
14. Known realities

## 1. Conventions
- `run_script`: `resolve` and `project` pre-injected; no `os`, files, network. Set `result = {...}` to return data.
- `run_script_unsafe`: same objects plus filesystem/subprocess. Use only for files/ffmpeg.
- The MCP stops a call at 60 s: plan each call to finish within ~45 s (`config/defaults.json` timeouts.budget_s). Long jobs (render, transcription, library scans): start in one call, poll in the next.
- Frames are numbers; timecodes are strings (`"01:00:02:05"`); enums are `resolve.*` constants.
- Get the media pool: `mp = project.GetMediaPool()`; root folder: `mp.GetRootFolder()`; walk `GetSubFolderList()` recursively, clips via `GetClipList()`.

## 2. Read / inventory (stub-verified)
- `project.GetName()`, `project.GetTimelineCount()`, `project.GetTimelineByIndex(i)` (1-based), `project.GetCurrentTimeline()`, `project.GetSettings()`.
- `timeline.GetName()`, `GetStartFrame()`, `GetEndFrame()`, `GetTrackCount("video"|"audio"|"subtitle")`, `GetItemListInTrack(type, idx)`, `GetSettings()` (frame rate key `timelineFrameRate`, size `timelineResolutionWidth/Height`), `GetMarkers()`.
- `item.GetName()`, `GetStart()`, `GetEnd()`, `GetDuration()`, `GetSourceStartFrame()`, `GetSourceEndFrame()`, `GetMediaPoolItem()`, `GetProperties()`, `GetTrackTypeAndIndex()`, `GetFades()`, `GetSpeed()`, `GetType()`.
- `mpi.GetClipProperty()` → dict with `File Path`, `FPS`, `Frames`, `Duration`, `Resolution`, `Video Codec`, `Type`, `Audio Ch`, `Input Color Space`, `Input Gamma`, `Online Status`, `Start TC`.
- `mpi.GetMediaId()`, `mpi.GetUniqueId()`, `mpi.GetMetadata()`.

## 3. Build a timeline from ranges (stub-verified)
```python
mp = project.GetMediaPool()
tl = mp.CreateEmptyTimeline("Draft_Project_v01")
project.SetCurrentTimeline(tl)
tl.AddTrack("video")             # V2 for titles
tl.AddTrack("audio", "stereo")   # A2 music, A3 sfx
items = mp.AppendToTimeline([
    {"mediaPoolItem": clip, "startFrame": 120, "endFrame": 239,
     "trackIndex": 1, "recordFrame": tl.GetStartFrame() + 0, "mediaType": 1},
])
```
- `AppendClipInfo`: `mediaPoolItem`, `startFrame`, `endFrame` (source frames), `mediaType` (1 video only, 2 audio only), `trackIndex`, `recordFrame` (absolute timeline frame).
- Append video and audio separately (mediaType 1 then 2) when you need control over where dialogue lands; omit `mediaType` to bring both linked.
- **Measured 2026-10-24 (21.1.1): `endFrame` is EXCLUSIVE.** startFrame 0 / endFrame 142 used 142 source frames; `GetSourceEndFrame()` then returns 141 (last frame used, inclusive). Source frames are in the clip's own fps: 142 frames of a 25 fps clip become 136 frames in a 24 fps timeline. Read back `GetDuration()` after the first append anyway.
- There is no razor/trim API for existing items. Build a new timeline from kept segments (BEMBOOMER pattern).
- `mp.CreateTimelineFromClips(name, [CreateTimelineClipInfo])` is the one-call alternative when every item goes to V1/A1 in order.

## 4. Item properties (stub-verified keys of `TimelineItemProperties`)
- Landscape into vertical: `SCALE_FILL` (user default: fill the frame, reframe with `Pan`) or `SCALE_FIT` (whole frame, black bands). `SCALE_CROP` is a centre crop without resizing. Others: `SCALE_STRETCH`, `SCALE_USE_PROJECT`.
- Punch-in: `{"ZoomX": 1.15, "ZoomY": 1.15}` (or `ZoomGang: True`), `Pan`, `Tilt` (pixels, ±4×width/height), `RotationAngle`, `AnchorPointX/Y`, `FlipX/Y`.
- Crop: `CroppingEnabled`, `CropLeft/Right/Top/Bottom`, `CropSoftness`.
- `Opacity` 0–100, `CompositeMode`.
- Dynamic zoom (Ken Burns): `DynamicZoomEnabled: True`, `DynamicZoomEase`.
- Retime: `RetimeProcess` (`resolve.RETIME_OPTICAL_FLOW`, `RETIME_FRAME_BLEND`, `RETIME_NEAREST`), `MotionEstimation` (`resolve.MOTION_EST_SPEED_WARP_BETTER` etc.).
- Audio: `AudioVolume` (dB, −100…+30), `AudioPan`, `AudioVoiceIsolationEnabled/Amount`, `AudioDialogueLeveler*` (active timeline only).
- Always `GetProperties()` after `SetProperties()` and compare.

## 5. Speed and retime (stub-verified)
`item.SetSpeed({"Percentage": 50.0, "PitchCorrection": True, "RippleTimeline": True})`; `item.GetSpeed()`.
- 0.0 = freeze frame. Speed changes the item's timeline length; with `RippleTimeline: True` later items move. Re-read the whole track afterwards.
- Plan slow-motion in the blueprint by source frames: a 2 s slot at 50 % needs 1 s of source.
- Speed *ramps* (curve inside one clip) are not exposed as keyframes in the API. Fake a ramp by splitting the moment into 2–4 consecutive segments with stepped speeds (e.g. 100 → 60 → 30 → 100 %) and optical-flow retime; mark it `INFERRED-SMOOTH` until a frame check confirms no stutter.

## 6. Fades and transitions (stub-verified)
- `item.SetFades({"FadeIn": 12, "FadeOut": 12})` (frames) — video opacity fader or audio fader depending on item type. `GetFades()` to verify.
- `item.AddTransition({"type": "Cross Dissolve", "category": "simple", "position": "end", "alignment": "center", "duration": 12})` → returns the transition item or `None`. Needs handles: check `GetLeftOffset()`/`GetRightOffset()` > half the duration, otherwise it fails.
- Audio crossfade: `category: "audio"`, type `"Cross Fade +3 dB"` (name per Resolve UI; verify the returned item).

## 7. Titles (Text+) — API facts only (v3.0: Claude builds no titles; HyperFrames does. Kept for reference)
```python
tl.SetCurrentTimecode("01:00:00:00")          # playhead decides insert point
item = tl.InsertFusionTitleIntoTimeline("Text+")
comp = item.GetFusionCompByIndex(1)
tool = list(comp.GetToolList(False, "TextPlus").values())[0]   # by type; comp.FindTool("Template") finds by name
tool.SetInput("StyledText", "ĐÊM HONG KONG")
tool.SetInput("Font", "Playfair Display"); tool.SetInput("Style", "Regular")
tool.SetInput("Size", 0.09); tool.SetInput("Center", {1: 0.5, 2: 0.86})
tool.SetInput("Red1", 0.96); tool.SetInput("Green1", 0.92); tool.SetInput("Blue1", 0.84)
```
- Earlier reality: `InsertFusionTitleIntoTimeline("Text+")` worked; `InsertTitleIntoTimeline("Text")` returned `False`.
- The title lands on the selected/first free video track at the playhead. Read `GetTrackTypeAndIndex()`, `GetStart()`, `GetDuration()` and move/re-insert if wrong. Set duration by trimming is unsupported → insert, then if too long, consider building titles before footage on a fresh track, or accept default length and cover with item end via a second title. Verify the current default title duration in read-back before planning.
- Input IDs (Text+): `StyledText`, `Font`, `Style`, `Size`, `CharacterSpacing`, `LineSpacing`, `Center` (point), `HorizontalJustificationNew`, `VerticalJustificationNew`, colour `Red1/Green1/Blue1/Alpha1`, outline element 2 (`Enabled2`, `Thickness2`, `Red2…`), shadow element 3/4 (`Enabled3`, `Offset3`, `Softness3`), `Opacity1`. Confirm names with `tool.GetInputList()` the first time in a session.
- Keyframes (fusion_api stub-verified): `tool.AddModifier("Opacity1", "BezierSpline")` connects an animation spline; then `tool.SetInput("Opacity1", 0.0, 0)` and `tool.SetInput("Opacity1", 1.0, 12)` set keys at comp frames; `tool.GetInput("Opacity1", 6)` reads an in-between. Easing handles via the spline's `SetKeyFrames()` (the v2.x `motion-graphics.md` was removed in v3.0).
- Wrap multi-step comp edits in `comp.StartUndo("claude title")` … `comp.EndUndo(True)` so one Ctrl+Z reverts them; `comp.Lock()`/`Unlock()` around bulk edits.
- There is no `FindToolByID`; use `GetToolList(False, "<RegID>")` or `FindTool("<name>")`.

## 8. Subtitles and transcription (stub-verified)
- Auto captions: `tl.CreateSubtitlesFromAudio({"language": resolve.AUTO_CAPTION_VIETNAMESE, "captionPreset": resolve.AUTO_CAPTION_SUBTITLE_DEFAULT, "charsPerLine": 32, "lineBreak": resolve.AUTO_CAPTION_LINE_SINGLE, "gap": 0})`; poll `project.GetCreateSubtitlesFromAudioStatus()`. Earlier reality: language auto-detect was unreliable → always pass the language.
- Transcription: `mpi.TranscribeAudio()` (or `folder.TranscribeAudio()`), poll `project.GetTranscribeAudioStatus()`, then `mpi.GetTranscription()` → `{"language", "segments": [{"start": "01:00:02:05", "end": …, "text", "speaker", "words": [...]}]}`. `"(...)"` in text marks silence.
- Read subtitles back: `tl.GetItemListInTrack("subtitle", 1)` → each item `GetName()` (text), `GetStart()`, `GetEnd()`.
- SRT import: **do not append an SRT with `AppendToTimeline`** — it lands after the timeline end and passing start/end frames crashed Resolve 21.1 (reported by appariciojunior/video-editor-skills). The UI import (File > Import > Subtitle) places the first cue at the playhead: `srt_from_transcript.py` reports the playhead timecode to use.

## 9. Markers (stub-verified)
`tl.AddMarker(frameId, "Blue", "HOOK", "why this cut", 1, "edit:01")` — frameId is relative to timeline start in current builds (verify once by reading `GetMarkers()` back). Colour convention used by this skill: Blue = section start, Green = beat/music hit, Yellow = needs review, Red = QA failure, Purple = title/text event.

## 10. Stills and thumbnails (stub-verified)
- `project.ExportCurrentFrameAsStill("/abs/path/frame.png")` — exports the frame under the playhead of the current timeline on the **current page**. Set the playhead first with `tl.SetCurrentTimecode(tc)`. Needs `run_script_unsafe` only for the path check; the call itself works from `run_script` if the path is writable.
- `tl.GetCurrentClipThumbnailImage()` → base64 thumbnail of the current clip on the Color page (small, but needs no file access).
- `resolve.OpenPage("edit"|"color"|"deliver"…)` switches page.
- Then **Read the PNG** — only that counts as seeing it.

## 11. Audio utilities (stub-verified)
- `tl.NormalizeAudioLevel(items, {"normalizationMode": "…", "targetLoudness": -14.0})`; list modes with `tl.GetNormalizeAudioModes()`.
- `tl.SetVoiceIsolationState(trackIndex, {"isEnabled": True, "amount": 60})`.
- `item.SetProperties({"AudioVolume": -18.0})`.
- `mpi.PerformAudioClassification()` can tag music/speech/effects in a library.

## 12. Color (stub-verified)
- `item.GetNodeGraph()` → `Graph`: `GetNumNodes()`, `SetLUT(nodeIndex, path)`, `GetLUT()`, `SetNodeEnabled()`, `GetNodeLabel()`, `ResetAllGrades()` (destructive — never without approval), `ApplyGradeFromDRX(path, gradeMode)`.
- `item.SetCDL({"NodeIndex": 2, "Slope": "1.0 1.0 1.0", "Offset": "0 0 0", "Power": "1 1 1", "Saturation": 1.0})`.
- `item.AddVersion("claude_look", 0)` / `LoadVersionByName` — safest way to try a look without touching the user's grade.
- `item.CopyGrades([others])`, `project.AddColorGroup(name)`, `item.AssignToColorGroup(g)`.
- MCP tool `generate_lut(path, size, transform)` writes a .cube into the MCP LUT folder; `project.RefreshLUTList()` before `SetLUT`.

## 13. Render (stub-verified)
```python
project.LoadRenderPreset("H.264 Master")      # optional, check GetRenderPresetList()
project.SetCurrentRenderFormatAndCodec("mp4", "H264")
project.SetRenderSettings({"SelectAllFrames": True, "TargetDir": "/Users/felix/Movies/Exports",
    "CustomName": "Final_Project_01", "FormatWidth": 1080, "FormatHeight": 1920,
    "ExportVideo": True, "ExportAudio": True, "AudioCodec": "aac"})
job = project.AddRenderJob(); project.StartRendering([job])
project.GetRenderJobStatus(job)   # poll: JobStatus, CompletionPercentage
```
- Check `GetRenderFormats()` / `GetRenderCodecs("mp4")` (dict description → codec name) for exact codec names.
- Quick export alternative: `project.RenderWithQuickExport(presetName, {...})`.
- Prefer `scripts/render_deliver.py` (plan → start → status → verify → cover; never overwrites; file + loudness check). Full rules: `delivery.md`.

## 13b. Measured on the user's Resolve 21.1.1 (2026-10-24)
- `InsertFusionTitleIntoTimeline("Text+")` lands on **V1 at the playhead and ripples** V1 (pushes footage 120 frames); with V1 locked it returns `None`. There is no API to choose the destination track. The v2.x route (removed in v3.0; graphics belong to HyperFrames) was nested text timelines: build the title in its own empty timeline, append that timeline (a media pool item) to V2+ with `startFrame/endFrame` = exact length. Composites with transparency.
- Text+ inputs: `StyledText, Font, Style, Size, Center, CharacterSpacing, LineSpacing, Red1/Green1/Blue1, Opacity1, SoftnessX1/Y1` (blur), `SoftnessGlow1`; shadow element 3 appears only after `Enabled3 = 1`: `Opacity3, Red3.., Offset3 {1,2}, Thickness3, SoftnessX3/Y3`. No `Thickness2/WriteOnStart` in this build.
- `Size` is not a fraction of frame width (v2.x calibration scripts were removed in v3.0). `CharacterSpacing` 1.35 is extremely wide.
- `AddModifier(input, "BezierSpline")` keys frame 0 with the current value → always key frame 0 explicitly. `spline.SetKeyFrames(dict, True)` with relative handles `{"RH": {1: dt, 2: dv}}` works.
- Title comp frames 0–119 = item frames. A **clip's** Fusion comp runs in source resolution and source frames (comp 0 = source in-point; retime applied after).
- `ImportMedia(["/abs/path.wav"])` works; the dict form `[{"FilePath": ...}]` returned nothing for audio files.
- `Pan` (item property) is not pixels: on a 16:9 source with `SCALE_FILL` in 2160×3840, +300 moved the view about a third of the frame; black edges appear beyond ~±950.
- `SCALE_CROP` = centre crop without resizing; `SCALE_FILL` = fill the frame (what "fill" means).
- `GetNodeGraph().SetLUT(1, "")` clears a node LUT.
- Fusion Tracker cannot be started from scripts (`SetInput("TrackForward",1)`, `comp.Execute` Lua, ActionManager all fail) (the v2.x own tracker was removed in v3.0; reframe paths use subject positions read off stills).
- `ExportCurrentFrameAsStill` right after `OpenPage("edit")` from the Fusion page failed once; wait ~1 s and verify the file.
- Fonts copied into `~/Library/Fonts` render in Text+ without restarting Resolve.
- Many keyed XYPaths on several Text+ nodes in one call froze Resolve; one Transform with a thin XYPath did not.

## 13c. Effects library and transitions (measured 2026-10-24, v1.6.0)
- `TimelineItem.AddTransition({"type": "Cross Dissolve", "category": "simple"|"fusion"|"ofx"|"audio", "position": "start"|"end", "alignment": "left"|"center"|"right", "duration": frames})` → transition item or `None`. `alignment` is required in practice; "center" needs handles on both clips. English names work in a Vietnamese UI; `GetName()` returns the localized name. Verified name list: `references/effects-library.md` §3. Delete with `Timeline.DeleteClips([transition], False)`.
- `InsertFusionTitleIntoTimeline("<template name as in Effects > Titles>")` inserts installed pack titles (mTitle Cinematic 08, Smooth Title 02, Location 01 [ Free Starter Pack ]); same V1/ripple behaviour → nested timelines. The comp exposes the macro's inner tools (`GetToolList(False, "TextPlus")`, `FindTool("Title")`).
- A Transform added after a template's output **concatenates** with the template's own transforms: Center offsets are not 1:1 (x gain 3.19, y 1.0 on a VES title) → measure the gain (`fx_apply.py`).
- `TimelineItem.SetFades({"FadeIn": 0, "FadeOut": 6})` works on video items (nested title item) — used when a template is cut short.
- No API to apply an Edit-page effect to a clip and no item trim. `comp.Paste()` with the `.setting` text on the clipboard works **only on the comp currently open in the Fusion page**; `comp.Execute("comp:Paste(bmd.readfile(...))")` did nothing. The Fusion page opens the topmost enabled video item at the playhead (`Timeline.GetCurrentVideoItem()` tells which).
- Nested-timeline items have their own Fusion comp (with `Left`/`Right` AudioDisplay tools); Resolve may also add these to clip comps opened in the Fusion page — harmless, unconnected.
- `Timeline.SetTrackEnable("video", n, bool)` / `GetIsTrackEnabled` work and are cheap; restore states in a `finally`.

## 13d. Picture building and clip comps (measured 2026-10-24, v2.0)
- Edit-page `Pan` on 16:9 4K filled into 2160×3840: **+Pan moves the view LEFT**; source shift ≈ 0.00035 × Pan (300 ≈ 0.105 of source width ≈ 1/3 of the frame); black edges near ±950.
- Speed-changed item lengths are rounded (≤ 3 frames per item; 13 frames over 10 shots). `build_from_blueprint.py` converges with `"dur"` (re-`SetSpeed` until exact); ramps get `dur` on the whole ramp.
- A retimed item reports the boundary source frame on both neighbours (ramps): not a repeat.
- `Timeline.DuplicateTimeline(name)` copies items, clip Fusion comps and Color-page LUTs (Final timelines render identical to the Draft, measured).
- Clip comp: `COMPN_GlobalStart = −src_in`, render range 0..N maps linearly onto the item (also when retimed).
- Fusion Transform: **Pivot = zoom point, Center = picture translation** (0.5, 0.5 = none).
- After adding splines to a clip comp the frame cache is not refreshed: toggle `TOOLB_PassThrough` True→False on the node (static input changes do refresh).
- `BrightnessContrast` Gain barely shows on LOG footage before the LUT; use Brightness for flashes.
- `AddMarker` returned False once for a segment start that already had a marker; not fatal.

## 13e. Stub-verified for v2.2 (21.1.1 stub read 2026-10-25; behaviour UNTESTED unless noted)
- `RenderSettings` keys include `SelectAllFrames, MarkIn, MarkOut, TargetDir, CustomName, UseUniqueFilenames, FormatWidth, FormatHeight, FrameRate, VideoQuality ('Best'…), AudioCodec, AudioSampleRate, AudioBitDepth, ColorSpaceTag, GammaTag, EncodingProfile, MultiPassEncode`.
- `GetRenderJobStatus(job)` → `JobStatus` ('Ready', 'Rendering', 'Complete', 'Cancelled', 'Failed'…), `CompletionPercentage`, `Error`, `TimeTakenToRenderInMs`. `GetRenderJobList()` rows carry `JobId, TimelineName, TargetDir, OutputFilename, FormatWidth/Height, FrameRate, VideoCodec, AudioCodec`.
- `Project.GetTranscribeAudioStatus()` → `JobStatus` ('Inactive', 'Initializing', 'Analyzing', 'Cancelling', 'Cancelled', 'Complete'); `MediaPoolItem.TranscribeAudio(useSpeakerDetection=None, transcribeAsNestedClip=False)`; transcription words have `start/end/text`.
- `Timeline.DetectSceneCuts()` → bool ("detects and makes scene cuts along the timeline" — it cuts items: Probe_/Test_ only). `TimelineItem.SmartReframe()`, `TimelineItem.Stabilize()`, `TimelineItem.CreateMagicMask('F'|'B'|'BI')` → bool.
- `Timeline.SetSetting("useCustomSettings", "1")` then `timelineResolutionWidth/Height`, `timelineOutputResolutionWidth/Height` (strings) — custom size per timeline (used by `build_from_blueprint.py` "resolution").
- `TimelineItem.GetVersionNameList(0)`, `GetCurrentVersion()` → `{versionName, versionType}`; `Graph.SetLUT(node, path)` 1 ≤ node ≤ `GetNumNodes()`.
- `Timeline.GetTrackName(type, i)` (used to find the MUSIC track).
- `NormalizeAudioOptions`: `normalizationMode` (from `GetNormalizeAudioModes()`), `targetLevel` (dBFS), `targetLoudness` (LKFS), `setLevelMode`.

## 13f. Traps reported by other Resolve 21 automators (v2.3; adopt, re-test when cheap)
- External scripts start a render only with `StartRendering([job], False)`; wait on `GetRenderJobStatus(job)` ("Complete"), not `IsRenderingInProgress()`; a target folder with spaces left a job "Ready"; restore the Deliver page's format/codec after a test render; `AddRenderJob` switches to the Deliver page.
- `SetTrackEnable` acts only on the Edit page (elsewhere it returns True and does nothing) — `fx_apply.py` now restores track states after switching back to Edit.
- Audio-only `AppendToTimeline`: source frames count at the FILE's own rate (a WAV can report 23.976); at 23.976 a timecode counts 24 frames per second.
- `Timeline.ApplyGradeFromDRX` fails in 21: use `item.GetNodeGraph().ApplyGradeFromDRX(path, 0)` per item (retry once).
- Edit-page transform keyframes (Pan/Zoom/Opacity) are not scriptable — animated moves go through a keyed Fusion Transform in the clip comp (as `motion_fx` does).
- ResolveFX/OFX: `comp.AddTool("ofx.com.blackmagicdesign.resolvefx.<id>")` in a clip comp, image input "Source" (CiprianSpiridon/davinci-resolve-mcp).
- Linked items are new proxy objects on every call: compare by `GetMediaId()`/frames, never with `in`. Save with `resolve.GetProjectManager().SaveProject()`.
- Unlocking a track on a duplicated timeline also unlocked it on the source once (guycochran/resolve-mcp-server): avoid lock changes on copies.
- A track-level AI Music Remixer (UI only) can silence everything on a template's music track: `audio_presence.py` catches it.
- Fusion: issue node connect calls one at a time; a parallel batch deadlocked Resolve (AdamGarceau/resolve-toolkit).

## 13h. Measured on Test_/TNCRoast (Resolve 21.1.1, 2026-10-27, v3.0.1)
- `SetSetting("timelineFrameRate", "30")` and the resolution keys work while the project has no timeline; `timelinePlaybackFrameRate` is refused for "30", "30.0", "29.97" (stays 24): set it in Project Settings > Master Settings if the viewer must play at 30. It does not change the timeline.
- Shortening the music item: `DeleteClips` + `AppendToTimeline(startFrame, endFrame, mediaType 2)` + `SetProperty("AudioVolume")` + `SetFades` — read back exact (mp3, 30 fps timeline: source frames counted 1:1).
- Static `Pan` cannot keep a subject in a handheld pan-across (the plate moved ~30 % of the frame in 52 frames): use `motion_fx` `reframe_path` in Phase 7.

## 13g. Measured on BoConCN (Resolve 21.1.1, 2026-10-25, v2.6.x)
- Save: `resolve.GetProjectManager().SaveProject()`. `Project.SaveProject` does not exist (the attribute is None; calling it raises TypeError).
- Audio item level: `item.SetProperties({"AudioVolume": dB})`; `SetProperty("Volume", …)` returns False. Read with `GetProperties()["AudioVolume"]`.
- Fades: `item.GetFades()` -> `{"FadeIn", "FadeOut"}` in frames; `GetProperties()` has no FadeOut.
- Audio-file clips: `GetClipProperty("Frames")` is empty; use `Duration` (timecode at the clip's own FPS; Bells 01.wav reports 29.97 in a 25 fps project). `AppendToTimeline` start/endFrame are in that fps (`sfx_library.tc_frames`).
- `DuplicateTimeline` keeps clip Fusion comps (MFX_* nodes), V2 nested text items, A3 SFX and colour versions.
- Project fps can be changed with `SetSetting("timelineFrameRate", "25")` while the project has no timeline (with the user's approval).
- `StartRendering([job], False)` once refused a queued audio-only job three times (also on the Deliver page) and a fresh job with the same range rendered at once; it did not repeat later. `audio_presence.py` now tries three recipes and deletes refused jobs.
- Stills/frames from DJI cameras: the `.LRF` sidecar (720p H.264, same fps and frame count) seeks frame-accurately with `ffmpeg -ss` and is ~10x faster than the 4K HEVC master; `frame_probe.py` uses it. Do NOT label contact sheets made with ffmpeg's `fps=` filter by `t` — the labels drifted by a whole cell.
- `motion_fx.py` effect frames are item-relative and inclusive: `t1` ≤ item length − 1 (a 51-frame item ends at 50).

## 14. Known realities (carry forward, re-test when cheap)
- No item trim/razor API → build from kept segments.
- `InsertTitleIntoTimeline("Text")` → False; use Fusion Text+.
- Some transitions return `None` without handles.
- Subtitle auto-language unreliable; pass language.
- MCP returns text/JSON only; images reach Claude only when a PNG is written and then read with the Read tool (or returned base64 thumbnail decoded to a file and read).
- A modal dialog in Resolve can make calls hang; stop and clear it.
- ffmpeg/ffprobe live in `~/.local/bin` since 2026-10-25 (on Resolve's script PATH); still check `shutil.which("ffmpeg")` every session.
