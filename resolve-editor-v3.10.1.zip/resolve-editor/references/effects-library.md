# Effects library — the user's installed titles, effects and Resolve transitions

The user installed 11 template packs in Resolve (Edit page > Effects). Use them **when they fit the video**, Everything below was measured on the user's Resolve Studio 21.1.1 on 2026-10-24 unless marked otherwise.

## Contents
1. What is installed
2. Choosing: which template or transition for which moment
3. Built-in transitions (verified names)
4. Title templates: how to use them in 9:16 (`fx_apply.py` MODE title)
5. Effect templates on clips (`fx_apply.py` MODE effect)
6. Fonts in templates (Vietnamese)
7. Placeholder and promo text
8. Rules and limits

## 1. What is installed
Run `scripts/fx_library.py` (MODE "scan") at the start of a job; it rescans packs the user adds later. Cache: `~/Movies/ClaudeQC/_fx/catalog.json`. 352 templates on 2026-10-24:

| Pack | Kind | Count | Look | Default fonts (Vietnamese?) |
|---|---|---|---|---|
| mTitle Cinematic (MotionVFX) | Title | 50 | film titles: thin tracked caps, blur/tracking reveal, letterbox option; 26–30 place/time cards; 31–50 credits | Barlow Condensed ✓ (installed 2026-10-24), Lato ✗, Lora ✓, Rajdhani ✗ |
| Free Starter Pack 2.0 (VES) | Title 220, Effect 8 | 228 | Clean Motion 2.0/3.0 text animations (fade, focus, typewriter, letter fill…), Locations (pin + tag), Time & Dates, Quotes, Intro Cards, Lower Thirds, Callouts, Arrows, Icons, Social, Infographics, Timers, Backgrounds, Gradients; effects: Continuous Zoom, Animation In & Out, Levitation, Glass, Phone, Icon Mask | Poppins ✗ (most), Montserrat ✓ |
| Smooth Titles | Title | 9 | quote cards, bold/grey emphasis lines, write-on | Roboto ✓ |
| Clean Simple Titles | Title | 9 | bold caps + yellow accent words (energetic) | Red Hat Display ✗ |
| Text Animation | Title | 12 | heavy extended caps, bar wipes, stacked repeats | Hanson ✗ |
| Glitch Text Animation | Title | 12 | glitch / displace caps, boxes | Inter ✓, Unbounded ✓, Anton ✓, Russo ✗, Uni Sans ✗ |
| Drawing Text Animation | Title | 9 | hand-drawn scribbles around text | Bowlby One SC ✗ |
| Call Outs | Title | 12 | dot + line + label callouts | Roboto ✓ |
| NeoFX Starter Pack | Title 3, Effect 3, Gen 1 | 7 | Neo Glow, Light Sweep, Zoom Lite; text pops | Open Sans ✓ (installed) |
| MagicAnimate V2 (MrAlexTech) | Effect | 3 | whip in/out, mid-shot pulse/shake/wobble | — |
| MagicZoom Free | Effect | 1 | zoom with corner points (button-driven, not scriptable) | — |

No transition packs are installed; transitions come from Resolve's built-in list (section 3).

## 2. Choosing (content first)
| Moment | Travel / mood (user's main type) | Energetic vlog / tips |
|---|---|---|
| Opening title | (v3.0: not Claude's job — specify in the Phase 10 hand-over; the v2.x template notes: mTitle Cinematic 01–25 (thin tracked caps + blur reveal: 02, 08, 13, 15, 20, 24 suit night/city; 18, 21 have a serif)) | Clean Simple Titles, Text Animation, Glitch Text 02/07/10 |
| Place / time | mTitle Cinematic 29 (stacked place), 30 ("…LATER"); Call Out Titles for a static pin on a landmark; house label recipe E | VES Locations 01–05 (pin + red tag), VES Time & Dates |
| Narration / quote | House whisper recipe B; Smooth Titles 01–09 for a quote card | Smooth Titles, VES Quotes, Clean Simple Titles |
| Emphasis word | House recipe C (glow); VES Clean Motion "Focus", "Letter Fill" as alternatives | Text Animation 07/08, Glitch Text |
| Outro / credits | mTitle Cinematic 31–50 (name + role) | VES Call to Actions, Social Media |
| Footage look | Neo Glow at 0.10–0.20 on night lights (verified) | MagicAnimate TransitionOnly (whip) — untested |

Rules: one template family per video (with the house style); never mix the red VES brand look with the gold editorial look in one piece; templates are designed 16:9 — always fit them (section 4).

## 3. Built-in transitions — VERIFIED names (TimelineItem.AddTransition)
`fx_apply.py` MODE "transitions". Call by the English name; Resolve reports the localized name back ("Cross Dissolve" → "Chồng mờ Chéo").
- **simple**: Cross Dissolve, Additive Dissolve, Blur Dissolve, Dip To Color Dissolve, Non-Additive Dissolve, Smooth Cut, Box, Edge Wipe, Clock Wipe, Center Wipe, Band Wipe, Spiral Wipe, Venetian Blind Wipe, X Wipe, Radial Wipe, Push, Slide, Split, Barn Door, Heart, Star, Triangle Left, Triangle Right, Oval Iris, Diamond Iris, Cross Iris, Square Iris, Triangle Iris, Arrow Iris, Eye Iris, Hexagon Iris, Pentagon Iris.
- **fusion**: Brightness Flash, Camera Shake, Spin, Zoom In, Zoom In and Out, Glitch, Noise Dissolve, Warp, Rotate, Cross Dissolve.
- Not found by these names: Iris, Spiral, Venetian Blind, Blur Transition, Slide Push Smooth, Dimension, Flash Bang, Burn Away, Lens Flare, Whip Pan, Smooth Zoom, Fall Away, Impact Dissolve, Zoom Out.

Handles decide what works: `alignment` is required. "center" needs spare source frames on **both** clips; "right" (starts on the edit) needs the outgoing clip's tail; "left" (ends on the edit) needs the incoming clip's head. The script tries the requested alignment, then the others, and reports which one it used. Blur Dissolve between s03/s04 was rendered and checked (motion-blur smear across the cut).

Taste: mood pieces are mostly **hard cuts on the beat**; use a 6–12 frame Cross/Blur Dissolve only where time passes or the mood softens; Dip To Color (white) for a chapter; energetic pieces may use Brightness Flash / Zoom In / Camera Shake / Glitch for 6–10 frames with a SFX on the cut. Avoid Heart, Star, Iris shapes, Clock/Barn Door wipes unless the video is playful.

## 4. Title templates — removed in v3.0
Title templates are graphic elements: Claude no longer inserts or fits them (`fx_apply.py` has no title modes). Titles, captions and text overlays are specified in the Phase 10 hand-over (`hyperframes-handoff.md`) and produced by HyperFrames. `fx_library.py` may still catalogue installed templates; use it only for transitions and clip effects.

## 5. Effect templates on a clip — VERIFIED route, effect-specific results
Resolve's API has no "apply effect" call. The verified route (`fx_apply.py` MODE "effect"):
1. `fx_library.py` MODE "extract" copies the template's `.setting` to `~/Movies/ClaudeQC/_fx/settings/` (prefers kind Effect when names repeat, e.g. "Neo Zoom Lite").
2. Save the project first. The script puts the playhead in the target clip, **disables every other video track**, opens the Fusion page and checks `Timeline.GetCurrentVideoItem()` is the target (the first attempt without this pasted into a nested title item on V3 — cleaned up). Only then it copies the `.setting` text to the clipboard, `comp.Paste()`, and restores the user's clipboard.
3. Wires the macro between the last node and MediaOut1 (keeps any existing grade/behind-object nodes), sets controls by name, restores tracks, page and playhead.
Results: **Neo Glow** — verified visually (night lights bloom, Intensity 0.15 default is tasteful; 0.10–0.20). **Neo Zoom Lite** — pasted/wired, but StartZoom 1.0 → EndZoom 1.08 changed the picture by only ~1.3/255: its animation engine needs other controls; for slow pushes use the clip's own Dynamic Zoom / a keyed Transform instead. MagicAnimate, Continuous Zoom, Levitation, Light Sweep: UNTESTED.
The clip comp runs **before** the Color page: on S-Log3 footage keep glow low or move the grade into the comp .

## 8. Rules and limits
- Draft timelines only; save the project before MODE "effect" (Fusion page + clipboard).
- Keep each call within the ~45 s budget (hard limit 60 s); a title fit renders up to ~7 stills.
- Templates are 16:9 designs: always fit; never ship an unfitted template.
- Titles from packs are a second voice next to the house style — use at most one family per video.
- The skill does not install or buy templates; it uses what the user installed.
