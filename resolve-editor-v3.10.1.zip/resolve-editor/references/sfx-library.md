# SFX library — the user's sound-effect folder

Folder: `/Users/felix/Desktop/Asset/Sound Effect` (2,436 audio files, 5.5 GB on 2026-10-24). Never modify it; import only the files a draft uses. The only addition allowed is `_Free/<source>/`, where `audio_ingest.py` puts approved free downloads with their licence sidecars (v2.8, `free-audio-sources.md`); MODE scan catalogues them like the rest.

## Contents
1. Catalogue (`sfx_library.py`)
2. What is in the folder
3. Roles and when to use them
4. Placement: line the sound up with the picture
5. Levels
6. Never

## 1. Catalogue
- `scripts/sfx_library.py` MODE "scan" (resumable, ~1,000 files per 45 s call; 3 calls for the whole folder): duration, sample rate, channels, envelope (peak time, onset, tail, peak/RMS dB) and shape — **hit** (attack first), **rise** (builds to the end), **swell** (peak in the middle), **flat** (beds) — decoded with macOS `afconvert`. Cache `~/Movies/ClaudeQC/_sfx/catalog.json`; re-run "scan" after the user adds files (only new files are processed).
- Role tags come from folder/file names with word-boundary rules (recomputed at pick time, so rule fixes need no re-scan).
- MODE "pick" with `QUERY = {"role", "mood", "min_dur", "max_dur", "shape", "exclude", "prefer", "n"}` → ranked candidates (primary role, preferred shape and duration window per role, feel, duplicates across folders removed).
- MODE "import" with `IMPORT = [relative paths]` → Media Pool bin "SFX" (only those files).

## 2. What is in the folder
| Folder | Content | Use for mood pieces? |
|---|---|---|
| 1000 Sound Effects…/450 cinematic sound effects | whooshes/swooshes (packs 1–6), swishes, sub drops, cinematic impacts, camera, bells, glitch, transitions, horror & tension | yes (best source) |
| 1000…/336 SFX | risers (bell/wind/water), whooshes, hits, slow-motion, elements (fire, water, subway, train), mix | yes |
| 1000…/336 SFX/memes, …/230 mixed sound effcts | meme and pop-culture clips (Bruh, Mario, One Piece, ringtones…) | **no** (tagged meme) |
| 1000…/336 SFX/GUN SFX | guns | **no** (tagged weapon) |
| Filmkid SFX Bundle | whoosh, riser, clicks | yes |
| Fast Cut | 169 sound-design beds and stems (whoosh / suck-back / rhythm) | cinematic intros, trailers |
| Cinetools Cinematic Hits Sci-Fi | 50 sci-fi impacts | tech / trailer only |
| Epic Stock Media – Smart UI | 1,095 UI notifications, buttons, clicks, glitches, melodic/fantasy chimes | tech/tips; melodic chimes softly for labels |
| Just Sound Effects – Renault R4 | car, doors, horn, mechanisms | only when a car is on screen |
| Hiệu ứng âm thanh (SFX) | small mixed set (shutter, page flip, typewriter, cricket…) | case by case |

## 3. Roles — transitions only (v3.4.0, user rule 2026-10-27; density and levels v3.5.0)
**SFX are made only for transitions, never for content.** A cue's event must be a picture cut on V1 or V2 (`sfx_library.py` MODE place refuses an event more than `CUT_TOL` = 3 frames from a cut). No sound for a title, a label, a gesture, a pour, an in-shot push, punch or flash, and no ambience beds; production sound on A1 stays as it is. Research basis: the loudest point of a whoosh lands on the edit point, its length matches the move, and a whoosh ending on a dull hit makes the transition arrive ([Morphic](https://morphic.com/resources/sounds/whoosh-sound-effect), [Motion Array](https://motionarray.com/learn/royalty-free-music/transition-sound-effects/), [Pixflow](https://pixflow.net/blog/cinematic-whoosh-sound-effects/)).
| Transition | Role → example picks | Placement |
|---|---|---|
| Whip, ramp-through, zoom-through join | **whoosh** (swell, length ≈ the move, 0.4–1.2 s): "Whoosh_Short_Deep.wav", "swoosh-026", "whoosh 2.mp3" | **peak on the cut** |
| Cut into the drop or a new chapter | **riser** (rise, 1–3 s) ending on the cut, then **sub drop** or impact (hit) with its onset on the cut | riser peak and hit onset on the cut |
| Hard cut on a strong beat (smash cut) | **hit** / cinematic impact, short | onset on the cut |
| Dissolve, blur or reverse-zoom cut | soft **transition** swell or reverse swell | peak on the cut |
| Glitch or flash transition | **transition** "Glitch transition sounds/T1…T6" | peak on the cut |
- **Selective:** only the cuts that carry a transition effect or a structural turn — about **7–10 SFX in 30 s** (v3.5.0: 5 felt too few): every ramp-through, zoom-through and whip join, the cut into the drop, every chapter turn, and B-roll entries that carry motion, never on every cut, at most one SFX per cut (a riser + hit pair counts as one).
- A whoosh shortened with `length` must keep its peak on the cut; long files (> 2 s) need `length`.
- When a role has < 2 good picks, look online for SFX (`free-audio-sources.md` §2).
- **Levels (v3.5.0, TestSkill):** whoosh −4 and transition −6 in the table (4 dB higher than before: short whooshes measured buried at context level); `PEAK_CEIL_DBFS` = 0 caps any automatic level so the file's own peak stays at or below 0 dBFS (+4 dB on a −1.6 dBFS whoosh clipped the mix). `MODE place` reports `transitions` placed vs the target and flags a short cue sheet.
- Vary the files: no single whoosh on more than two cuts in a row.

## 4. Placement
`placement(entry, event_frame, fps)`: swell/rise → the measured **peak** lands on the event; hit → the **onset** lands on the event. Example: a whoosh with peak 0.50 s for a cut at frame 100 (24 fps) starts at frame 88. `fx_apply.py` (transitions) takes `"sfx": {"clip", "offset", "volume"}` — use `offset = placement(...) − event_frame`.

## 5. Levels — the footage decides, Claude balances (v2.8, user rule 2026-10-25)
**Context levels.** A fixed table cannot fit every video: the same whoosh is buried under a loud market and jumps out of a quiet night street. Since v2.8 `sfx_library.py` MODE place (`LEVEL_MODE = "context"`, `config` → `mix`) measures the **program bed** around each cue — every audio item outside the SFX tracks (footage sound, dialogue, music, ambience), decoded over `bed_window_s` (1 s) around the event and moved by its `AudioVolume`, power-summed — and sets

level = role table level + (typical peak of the role − file peak) + clamp(bed − `bed_ref_dbfs`, −12 … +9 dB)

- `bed_ref_dbfs` (−24 dBFS RMS) is the bed the table below was approved against (a typical music file at −9 dB).
- Speech in the window (`DIALOGUE_TRACKS`): an accent is never raised over words.
- Silent bed (< −55 dBFS: no footage sound, no music): half the downward clamp (−6 dB), so a lone accent is still heard but does not shout.
- The result lists per cue the bed, the items in it and the shift (`plan.bed`, `level_note`). MODE bed (`FRAMES`) reports beds without placing anything — use it to explain levels or to calibrate.
- Calibration: when the user re-sets SFX by ear in a Draft, compare each hand level with the level MODE place had chosen (d = hand − auto, from the place result or the item read-back). If the median d is consistent across roles, set `mix.bed_ref_dbfs` = current − median d in `_prefs.json` config; if it differs per role, move those roles in `levels_db` instead (`options-playbook.md` §6). The next video then starts closer to the user's ear.
- Track faders and Fairlight effects are not readable by script: if the user moved a fader, say the bed may be off by that amount.
- `LEVEL_MODE = "table"` restores the v2.7 behaviour (table + file loudness only).

**Starting table** (music bed at −9 dB; SFX recalibrated by ear on BoConCN 2026-10-25). Other files point here; the same numbers live in `config/defaults.json` → `levels_db`, which the scripts read through the loader.
whoosh −8 · riser −10 · sub drop −7 · slow-mo swell −9 · hit −7 · camera/click −12 · shimmer −17 · ambience bed −19 (wind, open air) to −23 (fire/kitchen under a busy shot). These are levels for a **typical** file of the role; `auto_level` moves each file by its own peak.

History: HongKong v01 table (whoosh −20, ambience −28…) judged "hơi nhỏ", +5 dB → whoosh −15 … shimmer −20 (HongKong v02). BoConCN v03 (2026-10-25): the user re-set the four SFX by ear after the auto levels; the offsets from the auto levels were whoosh +7.3, riser +4.3, slow-mo swell +5.9, shimmer +3.3 dB → those roles take their own offset, the unmeasured accents (sub drop, hit, camera, transition) the median +5; ambience was not judged and stays. Ear levels on BoConCN: whoosh −7.7, riser (file peak −28.6 dBFS) +7.0, whoosh used as slow-mo swell −7.7, bells −7.2 dB, music −9. Check the mix by listening; never claim it sounds good without listening.

**File loudness (v2.6.2).** These levels were approved with typical files. A file that peaks far from the typical peak of its role is moved by the difference: level = table − (file peak − median peak of the role in the catalogue), kept within −30…+10 dB (`auto_level`, used by MODE pick → `auto_level_db` and MODE place). BoConCN: "The wind.wav" peaks at −28.6 dBFS; the plain −14 dB put it ≈ −43 dBFS, inaudible under the music.

**Placing a cue sheet (v2.6.2).** `sfx_library.py` MODE "place" with `CUES = [{file, event, role, align?, length?, volume?}]`: imports into the SFX bin if needed, lays rise/swell peaks and hit onsets on the event frame, uses the first free track of `SFX_TRACKS` (A3, then A4), sets `AudioVolume` (the property is `AudioVolume`, not `Volume`), and reads back each feature frame (`off_by` ≤ 1). Audio clips report `Duration` at their own fps, not `Frames` (Bells 01 is 29.97 in a 25 fps timeline); the script converts.

## 6. Never
An SFX that is not on a cut (v3.4.0); a level that ignores the footage (v2.8): always place with context levels unless the user set a level by hand; meme, weapon, arcade/sci-fi or car sounds in a mood piece unless the picture calls for it; a sound on every text; SFX louder than the music peak; importing the whole library.
