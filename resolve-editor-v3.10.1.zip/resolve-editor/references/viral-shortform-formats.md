# Short-form formats that hold attention (TikTok / Reels / Shorts)

Use as defaults the user asked Claude to apply proactively. For data on what works for this topic right now (outliers, hook patterns, keywords, runtime), run the research pass in `trend-research.md` (v2.5, vidIQ) and let the Research Card override these defaults where it has evidence. Adapt to the footage; do not force a template the shots cannot support.

## The first 2 seconds
- Open on the most striking moving image or the payoff teased — not the establishing shot by default.
- On-screen hook text in the first 0.3–0.5 s, ≤ 7 words, a question, a promise or a tension ("Một ngày ở Hong Kong chỉ với 500k", "Đừng đến đây vào ban đêm…").
- Sound starts on frame 1 (music hit, ambience, or speech). No silent fade-in from black.

## Retention structure
| Format | Shape | Fits |
|---|---|---|
| Curiosity loop | Hook question → steps → answer at the very end | vlog, travel, tips |
| Day-in-the-life | Time stamps / chapter labels ("7:00", "trưa", "đêm") every 4–8 s | daily vlog |
| Mood piece | Slow build → one peak → quiet button; minimal text | cinematic city, night, nature |
| Before → after | Problem frame, process montage, reveal | makeover, cooking, edit demo |
| List | "3 điều…" numbered, each 5–10 s | tips, places |
| Loop ending | Last frame flows into first so the replay feels seamless | short mood pieces < 15 s |

## Pacing defaults (adjust to mood)
- Energetic vlog: shot length 0.6–2.0 s, pattern break every 3–5 s (speed ramp, punch-in, text pop, SFX).
- Calm / cinematic: 1.5–4 s shots, slow motion 50–60 %, long dissolves rare, silence moments allowed.
- Cut dead content: walking with nothing new, repeated angles, setup moments.
- Speed ramps: ramp into action (100 → 30 %) on the decisive moment, out again quickly; whoosh SFX on the ramp.
- Keep one "best shot" for the payoff, not the opening, unless it is the hook.

## Text strategy
- One idea per text card; keep subtitles for speech only.
- Chapter labels / time stamps help day-in-the-life retention.
- End with a soft CTA or a button line, held ≥ 1.2 s; do not copy any creator's watermark or outro identity.

## Length guide
- Mood piece: 8–20 s. Vlog: 30–75 s. Tips/list: 20–45 s. The footage decides — never pad.

## Posting (v2.2)
Caption, hashtags and cover image: `delivery.md` §5–6 (Claude writes VN + EN on request; cover from the hero frame, looked at before it is offered).

## Self-check
Would a viewer know within 2 s why to keep watching? Is there a reason to stay until the end (answer, reveal, payoff)? Is anything on screen > 3 s without a change in image, text or sound (for energetic formats)?
