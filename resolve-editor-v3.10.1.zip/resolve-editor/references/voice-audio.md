# Voice and audio checks (v2.3)

For talking footage and any piece with speech. Measure before treating; LUFS is a gate, not a verdict; listen. Learned from appariciojunior/video-editor-skills (voice-and-audio, music-and-sound), ChaiWithJai/davinci-resolve-claude-skills (audio audit, podcast cleanup) and AdamGarceau/resolve-toolkit (VO finish) — ideas only.

## Contents
1. Audit the sources (`voice_audit.py` audit)
2. Level the voice (`voice_audit.py` normalize)
3. What the API cannot do: EQ and Fairlight FX (UI chain)
4. Music around speech (envelope)
5. Is it really in the mix? (`audio_presence.py`)
6. Jump-cut clicks

## 1. Audit the sources
`voice_audit.py` MODE "audit" (first 60 s of each file, ffmpeg) ranks every clip with audio and says in plain words:
| Finding | Meaning | Action |
|---|---|---|
| one channel silent | lav/recorder on one side only | use the good channel as dual mono |
| channels differ ≥ 10 dB / different signals at similar level | two mics (camera + lav) on L/R; summed = comb filter, "underwater" voice | pick one channel |
| 3 kHz+ band > 18 dB under the total (clean ≈ 10–15) | covered or badly placed mic, muffled | EQ presence by hand, Voice Isolation helps |
| most energy below 300 Hz | boomy | high-pass 80 Hz, −3 dB at 250 Hz |
| true peak > −1 dBTP | clipping risk | lower the item, check for distortion by ear |
| > 60 % silent | not a dialogue source (B-roll, room tone) | do not normalise it |
Choose the dialogue source from the ranking; if the best-ranked is not used, say why.

## 2. Level the voice
`voice_audit.py` MODE "normalize": list the A1 items first (`SPEECH_ITEMS = []` returns them), then normalise only the speech items — ITU-R BS.1770-4, −16 LKFS, −2 dBTP, independent — and optionally `ISOLATION = 50` (Voice Isolation). Never normalise silent B-roll: it was boosted +30 dB into hiss; a clip with radio/music inside should sit ~8 dB lower. The script flags any item raised > 20 dB. If the call returns False, give the user these values for Edit page → select items → Normalize Audio Levels.
Final mix target stays −14 LUFS integrated / ≤ −1 dBTP on the rendered file (`delivery.md`).

## 3. EQ and Fairlight FX (not scriptable)
The API sets volume, Voice Isolation, Dialogue Leveler properties and Normalize; **EQ and Fairlight FX (De-Hummer, Noise Reduction, De-Esser, Ducker) are UI-only.** Offer the steps; drive the UI with computer use only after the user agrees.
1. Inspector → Audio → Equalizer on one dialogue clip: high-pass 80 Hz; −3 dB at 250 Hz (Q ≈ 1.2) if boomy; +3 dB at 3.5 kHz (Q ≈ 1) if muffled; +2 dB high shelf at 10 kHz for air. Copy to the other clips with Paste Attributes → **Equalizer only** (never Volume, it would undo the normalise).
2. Hum: Fairlight FX → De-Hummer at **50 Hz** (Vietnam/Europe/Asia), amount −20…−30 dB, bypass to compare.
3. Broadband noise that survives: Noise Reduction, gently; artefacts are worse than noise.
4. Uneven level inside sentences: AI Dialogue Leveler (Studio).
Headphones for every decision.

## 4. Music around speech
`duck_music.py`: about −20 dB under speech, −9 dB elsewhere; the fall takes ~1.0 s and is finished when the sentence starts, the rise takes ~1.2 s and starts in the speaker's tail room, so the music flows into the B-roll. Under dense speech, music without a busy lead melody (vocals off). Reported on real vlogs: a quieter B-roll level (−19 LUFS) felt timid; give speech-free moments their full level.
SFX with speech: one soft swell into a B-roll (peak on the cut, untuned riser so it never clashes with the music's key), quiet room tone where it sets the place, and the B-roll's own natural sound — literal foley (zips, cloth, jets) read as cheap.

## 5. Is it really in the mix?
`audio_presence.py`: MODE "start" renders a few seconds of audio only (marks, ProRes LT .mov, LPCM; Deliver format restored), MODE "check" correlates the render with each audio item's source file. ~0.9 = present, < 0.15 = MISSING. A missing music bed on a template track is usually a track-level setting the API cannot see (AI Music Remixer, track mute/FX): check the track header Inspector in the UI. Run it once per piece after the sound stage, and whenever the user says "there's no music".

## 6. Jump-cut clicks
Butt joins in speech can click where two waveforms meet at non-zero samples. `transcript_cut.py` sets `"audio_xfade": {"track": 1, "frames": 2}`; `build_from_blueprint.py` adds a 2-frame audio crossfade ("Cross Fade 0 dB", fallbacks +3/−3 dB) on every butt join of A1 and reports joins it could not cover (no handles) — listen there. Keep it short: a long crossfade pulls the removed breaths back in.
