# Footage intelligence — from "what is in the clip" to "what each moment is worth" (v3.2.0)

Phase 3 used to describe clips. This module finds the **editorial value of every moment**: what the moment does, where exactly it starts and ends, which story job it can take, and how many *different* shots a clip can give. It is the reason a 30-second video can be built from a handful of clips without looking flat or repeating itself.

Ideas rewritten for this pack from: Walter Murch's Rule of Six (emotion > story > rhythm > eye trace > 2D plane > 3D space; [No Film School](https://nofilmschool.com/2016/11/6-rules-good-cutting-according-oscar-winning-editor-walter-murch)), the B-roll families in [Neil Chase's guide](https://neilchasefilm.com/b-roll/) (establishing, detail, cutaway/reaction, slow-motion/time-lapse, action) and the continuity basics in [StudioBinder](https://www.studiobinder.com/blog/what-is-continuity-editing-in-film/). Nothing here is a measured "best setting".

## Contents
1. Two passes (scan, then deepen)
2. Evidence labels — SEEN / INFERRED / UNVERIFIED
3. Action in four stages
4. What to read in every moment (emotion, motion, composition, gaze, direction)
5. Finding In / Out and the frames to keep
6. Editorial roles and how to score them
7. Moment mining — getting many different shots out of few clips
8. Effect suitability (speed ramp, zoom in, zoom out)
9. Catalogue schema (short, with IDs)
10. Worked example
11. Done criteria for Phase 3

## 1. Two passes (scan, then deepen)
| Pass | When | Looks at | Produces |
|---|---|---|---|
| **Scan** | end of Phase 1, before the style gate (the Style choice) | overview sheet + one contact sheet per clip (`footage-subagent.md`) | clip rows + 2–6 rough moments per clip, enough to propose styles honestly |
| **Deepen** | Phase 3 | ~2 frames per second around every usable moment (`frame_probe.py` MODE range, `qc_stills.py`), scene cuts on long clips | shot rows with exact In/Out, stages, roles, scores, effect suitability, B-roll mining |
Scan never decides In/Out. A moment whose frames were not seen stays `unseen`.

## 2. Evidence labels — SEEN / INFERRED / UNVERIFIED
Every statement in the catalogue carries one label (field `ev`):
- **SEEN** — visible in a frame or still Claude (or the subagent) opened; the frame number is in the row. In/Out points are allowed only from SEEN frames or the transcript.
- **INFERRED** — editorial reading of SEEN material ("the pause before the pour reads as anticipation"). Allowed for roles and emotion, never for timing.
- **UNVERIFIED** — a guess, something between thumbnails, or something that needs more footage ("probably the owner"). Never used in the blueprint; either check it (one extra range sheet) or drop it.
Report counts in the catalogue summary: `seen / inferred / unverified`. Never turn INFERRED into SEEN by repeating it.

## 3. Action in four stages
Break every moment with movement or change into stages and give each a source frame range:
| Stage | What the frames show | Editing use |
|---|---|---|
| **Begin** | anticipation: the hand reaches, the light starts to change, the head turns | the cut-in point; a hook can open here when the anticipation is visible |
| **Develop** | the action travels; the camera or subject moves with clear direction | body of the shot; where a speed ramp or a push-in can run |
| **Peak** | the decisive instant: contact, pour, reveal, eye contact, sun clears the roofline | the frame the cut, the music hit or the slow step lands on |
| **End / release** | the motion settles, the subject leaves, the look changes, focus drifts | the cut-out, or the breath after the peak (`story-structure.md` §5) |
Static moments (a skyline, a sign) have only develop/hold: say so and rate them by composition and light, not action. A moment without a visible peak cannot be a *peak* beat of the video.

## 4. What to read in every moment
Write one short phrase for each; leave the field out when nothing is visible (do not pad).
- **Emotion** (`emo`): the feeling the picture carries, one word + intensity 1–3 (calm 1 · warm 2 · awe 3). Emotion decides ties (Murch ranks it first).
- **Motion**: subject motion (static · walk · reach · pour · turn…) and camera motion (static · pan L/R · tilt · push · pull · handheld · drone). Note speed: slow / medium / fast.
- **Composition**: shot size (EWS WS MWS MS MCU CU ECU INSERT), subject position in thirds (source x, y), depth layers (foreground / mid / back), leading lines, negative space. For 9:16 add what survives the fill crop (`vertical-frame-checklist.md`).
- **Gaze** (`gaze`): where a person looks or where the eye lands first (screen L/R/up/down/toward camera/away). The gaze target is a ready-made next shot ("they look at X → cut to X").
- **Direction** (`dir`): direction of subject and camera travel in screen terms (L→R, R→L, toward, away, up, down). Keep it for continuity checks (`shot-selection-and-continuity.md` §3).
- **Light** (`light`): time of day, key direction, contrast, colour cast — decides which shots can sit next to each other.
- **Sound** (`snd`): production sound that is usable or that must be replaced (wind, roaster noise).

## 5. Finding In / Out and the frames to keep
1. Locate the **peak** frame first.
2. Walk **back** to the start of the anticipation (Begin). Default **In** = 2–4 frames before the first visible movement, so the cut lands as the motion starts; if the anticipation is the point (a held breath), In = the hold.
3. Walk **forward** to the settle. Default **Out** = the peak + the time the eye needs to register it (0.4–0.8 s at 9:16 phone viewing), not the end of the clip. Stop *before* the subject reaches for the lens, before focus hunts, before a person walks across the frame (unless the occlusion is the planned wipe).
4. Mark **hold frames** (`keep`): peak frame, last sharp frame, the frame of the best expression. These must be on screen long enough to read (≥ 6 frames at 24–30 fps) even after speed changes.
5. Mark **bad frames** (`bad`): blur, flash, focus hunt, bumped handheld, lens cover, black. A shot range must not contain them unless used on purpose.
6. Add **handles** (6–12 frames each side, source permitting): for J/L cuts, speed ramps (the ramp consumes source), and last-minute trims. Record `handle_in` / `handle_out`.
7. Give **usable length** (`len_s`) = Out − In at the clip's native speed. A shot shorter than 0.8 s is a flash cut, not a shot; longer than the plan's maximum ASL for its section needs a plan to stay alive (push, ramp, B-roll cutaway).
8. Write the range as **source frames of the clip's own fps** (`[in, out)`, out exclusive) and the clip fps, never timecodes.

## 6. Editorial roles and how to score them
Score each shot 0–3 for every role it could take (0 = cannot, 1 = weak, 2 = good, 3 = ideal). Keep only the top two roles in the catalogue; the rest are noise.
| Role | Looks like | Signals |
|---|---|---|
| **hook** | works in the first 1.5 s without context | motion or contrast on frame 1, a face, a striking detail, a question the viewer wants answered |
| **setup** | tells where / who / when | readable wide or establishing, stable, light clear |
| **development** | adds one new thing | detail, process step, new angle, change of scale |
| **peak** | the strongest image or action | decisive instant, highest emotion, strongest light or movement, ideal for a ramp or a push |
| **release** | lets the viewer breathe after the peak | slower movement, wider frame, softer light, a gaze away |
| **ending** | closes the idea or the feeling | settled composition, a departure, a mirror of the opening, a pull-back |
| **bridge** | links two ideas/places | wipe, defocus, black-to-black, a shape/motion match |
A footage set with no shot scoring ≥ 2 for *peak* is a finding for the Story approval ("the video has no peak unless a ramp/zoom creates it"), not something to hide.

## 7. Moment mining — getting many different shots out of few clips
The goal is **many different images, each used once**. v3.4.0: mine **at least 2× the V2 cutaways the plan needs** (30 s → about 16) and mark each with `broll_type` (establish · detail · cutaway · reaction · texture · process · transition) and the V1 moment it can cover (`broll.md` §0a). Mine each clip with these techniques (every output becomes its own shot ID):
| # | Technique | How | Check |
|---|---|---|---|
| 1 | **Separate moments** | different source ranges of the same clip | ranges do not overlap by > 2 frames (`qa_audit`, `edit_analysis`) |
| 2 | **Establish → subject → detail** | wide of the place, the person/object, then the hands/texture inside it | three different sizes, not three crops of one size |
| 3 | **Panel reframes** | 16:9 footage in 9:16 shows the centre third; `Pan` reveals left/right thirds | the subject really differs between panels; measure Pan (`picture_tools.py` pan_calibrate) |
| 4 | **Detail insert** | push into an object/gesture inside a wide, ≤ 1.15 (≤ 1.08 from 1080-wide sources) | the detail is sharp enough at the crop; soft = reject |
| 5 | **Gaze target / reaction** | the thing a person looks at, or their reaction to what happens | the link is visible in the frames (gaze direction matches) |
| 6 | **Texture and light** | steam, water, reflections, bokeh, light moving across a surface, shadows | use as release or bridge, short |
| 7 | **Movement through frame** | something crosses the lens or the frame edge (natural wipe), a pass-by, foreground blur | cut on it; the next shot starts on the same side |
| 8 | **Entry / exit** | subject enters or leaves frame | chapter start or end |
| 9 | **Speed variants** | slow-motion of a high-fps range, a ramp on a continuous range | **a speed variant of the same frames is the same shot**, not a second one |
| 10 | **Black-to-black / defocus** | lens cover, bag, pocket, focus pull | free invisible cut; check the neighbours' light |
Mining rules:
- A clip that gives only 1 distinct shot is a **1-shot clip**; do not plan three uses of it.
- Give every shot an **image group** (`grp`): shots that show nearly the same picture (same subject, angle, framing) share a `grp`. Panel reframes of one wide, a push-in on the same subject, and a slow-motion version all stay in the same group **unless the new crop shows a genuinely different subject** (then a new group). Duplicate pool items (`DUPLICATE_MEDIA`) are one clip.
- The video may use **one shot per `grp`** (a deliberate callback — an ending that mirrors the opening — is marked `callback` in the blueprint and never sits next to its twin).
- Over-mining is a fault: a "detail" that is a 1.4× crop of a soft frame is a worse shot than leaving it out.
- B-roll must answer *where / what / how it feels*; if it does none of these, it is filler (see `broll.md` §3).

## 8. Effect suitability (speed ramp, zoom in, zoom out)
The video leans cinematic (`motion-effects.md` §0). So rate every shot for the three effects while cataloguing:
| Effect | Ideal shot | Reject when |
|---|---|---|
| **Speed ramp** (`ramp: true`) | continuous motion with a clear peak and spare source (handles); native fps ≥ 50 for slow steps, otherwise optical flow on calm subjects only | 24–30 fps footage with fast complex motion (judder), no peak, no handles, people turning toward the lens |
| **Slow motion** (`slow: true`) | texture, gesture, light; native high-fps | low fps with detail on the move |
| **Zoom in / push** (`zin: true`) | sharp subject with space around it, stable framing, a face or object the eye should reach | soft or noisy frame, subject near the frame edge, no room for the crop |
| **Zoom out / pull** (`zout: true`) | a detail that becomes a place when the frame widens; the subject can be re-framed at the start | the wide context is not in the source (you cannot pull out of a tight crop that is the whole frame) |
Pairing: ramp/push into a peak, pull/slow at the release. Never plan two strong effects on one shot (`motion-effects.md` §2).

## 9. Catalogue schema (short, with IDs)
One JSON file `Cache Edit/<Title>/footage/catalogue.json`; keys are short on purpose. Clip rows hold what is true of the whole clip; shot rows hold one editable moment.
```json
{"clips": [{"id": "C03", "file": "03 HongKong RAW.mov", "fps": 50, "frames": 640, "size": "3840x2160",
            "content": "dusk skyline, neon signs, ferry crossing", "light": "dusk, sodium + neon", "cam": "static→slow pan R",
            "quality": "usable", "ev": "SEEN", "dup_of": null, "issues": ["soft 410-440"]}],
 "shots": [{"id": "C03.S02", "clip": "C03", "in": 120, "out": 214, "len_s": 1.9, "fps": 50,
            "stages": {"begin": [120, 134], "develop": [134, 176], "peak": [176, 188], "end": [188, 214]},
            "keep": [176, 188], "bad": [], "handle_in": 12, "handle_out": 20,
            "size": "WS", "emo": "awe 3", "motion": "ferry crosses L→R, camera static", "dir": "L→R", "gaze": null,
            "comp": "thirds: ferry on lower-left, neon top-right; clean negative space top", "light": "neon peak",
            "roles": {"peak": 3, "setup": 2}, "grp": "G05", "fx": {"ramp": true, "slow": true, "zin": false, "zout": true},
            "link": "ends with the ferry leaving → good for L→R continuity", "ev": "SEEN",
            "why": "the strongest light + movement in the set; 50 fps gives a native slow step",
            "unseen": []}]}
```
Rules: ID format `C<clip>.S<shot>`; clip ids follow the pool order and never change after Phase 3; `grp` ids are `G..`; `ev` is the strongest label that all the row's timing fields satisfy. A short row is better than a padded one: omit fields with nothing to say. The same IDs are used in the blueprint (`shot`, `grp` fields, `shot-selection-and-continuity.md` §7).

## 10. Worked example (shape, not real footage)
Clip C03, 50 fps ferry shot: peak at the ferry crossing the neon reflection (frames 176–188). Anticipation starts at 134 (the previous ferry has cleared), the camera is static, the ferry leaves at 214. Shot `C03.S02` In 120 (includes 14 frames of handle before anticipation 134), Out 214. Roles: peak 3 (strongest light and movement), setup 2. Effects: native slow step possible (50 fps → 48 % in a 24 fps timeline), a pull is possible because the wide is the whole frame; push is not (subject at the lower left near the edge). The panel reframe to the right third shows only neon signs — a different picture → new shot `C03.S03`, group G06, role development. A second use of `C03.S02` in the same video is refused by `edit_analysis`.

## 11. Done criteria for Phase 3
- Every source (one per duplicate group) has a clip row and ≥ 1 shot row; every shot's In/Out comes from SEEN frames.
- The pool offers **≥ 1.5× the shots the plan needs** (30 s at ASL 2–3 s needs ~10–15 shots → catalogue ≥ 15–22) in **≥ 3 shot sizes**; if not, say it and propose moment mining (§7) or more footage.
- Each shot has `roles` (top two), `grp`, `fx` suitability and, for people, `gaze`/`dir`.
- At least one candidate each for hook, peak and ending, or the gap is listed for the Story approval.
- `seen / inferred / unverified` counts are reported; every `unseen` item is either checked or left out.
