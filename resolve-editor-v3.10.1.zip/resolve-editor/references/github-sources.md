# What this pack took from GitHub (concepts, no code copied)

| Source (license) | Ideas adopted in v1.4.0 | Where |
|---|---|---|
| legionsound/open-fusion-mcp (MIT) | Render-and-look loop (check pixels, not return values); sparse, eased, intentional keyframes; one undo event per build step; preserve existing comps and names when adding; closeout receipt listing frames inspected and what is unverified; stop on modal dialogs (UI_BLOCKED) | `visual-qc-loop.md`, SKILL.md gates 6–7, failure handling |
| BEMBOOMER/resolve-mcp-bridge (MIT) | Transcript + silence driven cuts; cuts built as a fresh timeline from kept segments (API cannot razor); alternating punch-ins via ZoomX/Y + Pan/Tilt; SRT remapped to the re-cut timeline; render_still self-check; edit-decision markers with a colour convention; music bed, SFX, beat grid; mandatory QA report before delivery | `transcript-editing.md`, `audio-music-sfx.md`, `scripts/build_from_blueprint.py`, `scripts/srt_from_transcript.py`, `scripts/qa_audit.py` |
| olegkupshukov/claude-resolve (MIT) | Optional overlay route: animation rendered to ProRes 4444 with alpha and imported to the top track at the playhead; ship/know a small set of reliable fonts | (v2.x `motion-graphics.md`, removed in v3.0) |
| liuluhaixiu/DaVinci-AutoEdit-Agent (MIT, already credited in v1.3.0) | Evidence-first media review, staged gates, edit blueprint, immutable sources, delivery and pickup-gap audit | whole workflow |
| jordanurbs/venice-video-harness (concept) | Programmatic checks at every cut boundary (aspect regressions, frame jumps, caption overlap, audio peaks); "the LLM reads the video rather than watching it" | `qa_audit.py`, `visual-qc-loop.md` sampling table |
| bestagentkits/motion-video-skill (concept) | Fit a beat grid (BPM, first beat) and land cuts/reveals on beats | `scripts/silence_beats.py`, `audio-music-sfx.md` |

Not adopted (and why): paid TTS/LLM endpoints and Higgsfield generation (cost, user rule); whisper.cpp/Playwright installs (Resolve has native transcription; no installs by default); a separate MCP server (the user's Resolve MCP already exposes `run_script`). These connectors can still be used if the user installs them; the skill should then prefer their checked operations for Fusion work.

## v2.3.0 review (2026-10-25) — what was adopted
| Source (licence) | Adopted | Where |
|---|---|---|
| appariciojunior/video-editor-skills (CC BY-NC 4.0, facts only) | pacing profiles and pause shortening, word pads, scene room, zoom only on jump cuts, punchline 115 % for one line, "keep and flag", 2 fps B-roll viewing, music envelope, untuned swell into B-roll / no literal foley, voice spectrum check, speech-only normalise, render traps, SRT import trap, colour tags | `transcript_cut.py`, `duck_music.py`, `voice_audit.py`, `render_deliver.py`, `srt_from_transcript.py`, `voice-audio.md`, `transcript-editing.md`, `broll.md` |
| ChaiWithJai/davinci-resolve-claude-skills (MIT) | four-lane review + blockers, jump-cut prevention, 6–9 s visual reset, audio source ranking, Fairlight cleanup order | `review-scorecard.md`, `voice_audit.py`, `voice-audio.md` |
| AdamGarceau/resolve-toolkit (no licence: ideas only) | peak-relative silence floor, shorts/story/longform profiles, paced punch-ins (≥ 4 s), 2-frame crossfades against clicks, Fusion connect calls one at a time | `silence_beats.py`, `transcript_cut.py`, `build_from_blueprint.py`, `api-cookbook.md` §13f |
| CiprianSpiridon/davinci-resolve-mcp (MIT) | ResolveFX/OFX node in a clip comp, plugin id list, waveform (not caption) silence, source-level A/V sync, no transform keyframes on the Edit page | `motion_fx.py`, `picture_tools.py`, `resolvefx.md`, `qa_audit.py` |
| guycochran/resolve-mcp-server (MIT) | video-only replacement of one shot in a copy, lock gotcha on duplicates | `replace_shot.py`, `api-cookbook.md` §13f |
| voidash/claudepipe (MIT) | never-linear easing, match-cut types, transition pace, invert stutter, Ken Burns parameters, crop paths | `motion_fx.py` (`reframe_path`, `invert`), `motion-effects.md` §3c, `broll.md` |
| LevyBytes/AI-SKILL-davinci-resolve (Apache-2.0) | ResolveFX catalogue / Resolve 21 feature list as lookup | `resolvefx.md` |
| OpenMontage (AGPL-3.0, studied locally 2026-10-26) | intake, design read + dials, tone/hold table, visual-cause beats, but/therefore, slideshow-risk and decision-log audit | `ideation-playbook.md` — ideas only, no code or text copied |
| lordhoell, odaiouattara0022-del | nothing new beyond what the skill had | — |
Not adopted: WhisperX/pyannote installs, Moondream/Gemini/ElevenLabs/Epidemic Sound (cloud or paid), Remotion/Blender overlays, YouTube upload, MotionVFX transition injection via .drt, a second MCP server.
