# Reference Analysis and Match Plan

## 1. Access verification
Record the inspection route actually used:
- Reference identity:
- Can inspect video frames? YES / NO
- Can inspect audio? YES / NO
- Can read metadata? YES / NO
- Route/tool used:
- Any limits:

Do not treat an attachment filename, file size, duration, or contact-sheet file path as proof that the visual/audio content was inspected.

## 2. Full-reference audit
Sample the reference from opening to ending, including every major section and change in visual mode. Do not overfit to the opening few seconds.

| Time range | Structure/function | Visual mode/shot grammar | Typography/graphics | Rhythm/transitions | Audio observations | Evidence status |
|---|---|---|---|---|---|---|
| Opening/hook | | | | | | OBSERVED / INFERRED / UNKNOWN |
| Context | | | | | | |
| Development | | | | | | |
| Payoff | | | | | | |
| Ending/CTA | | | | | | |

## 3. Visual grammar
Record only traits supported by evidence:
- Shot modes: talking head, wide/medium/close, details, screen capture, full-frame typography, graphic examples, cutaways, split layouts.
- Shot cadence: approximate hold lengths and how often the visual mode changes.
- Typography roles: display headline, highlighted keyword, dialogue subtitle, annotation, CTA.
- Hierarchy: relative scale, line length, weight, alignment, placement, contrast.
- Palette: background, primary text, accent, colors reserved for meaning.
- Motion: entrance/exit, tracking, scale, position, masking, speed/easing, frequency.
- Transitions: hard cuts, match cuts, J/L cuts, dissolves, wipes, other.
- Audio: speech/music/ambience/SFX hierarchy, only if genuinely heard or otherwise verified.
- Ending: payoff, CTA, logo/social outro, final hold.

Mark each item OBSERVED, INFERRED, or UNKNOWN. Do not copy creator identity, watermark, copyrighted graphics, or unrelated subject matter.

## 4. Reference Match Plan
Turn the audit into 5–10 rules. Each rule must be concrete and testable.

| ID | Match rule | Evidence | Confidence | Implementation idea | QC test |
|---|---|---|---|---|---|
| R1 | | | High/Med/Low | | |
| R2 | | | | | |

Example rule: “Alternate the anchor shot with full-frame explanatory typography or relevant inserts at major idea changes; avoid one continuous talking-head shot when usable cutaways exist.”

## 5. What not to copy
- Subject matter that does not match the user's footage.
- Creator identity, watermark, branding, or platform handle unless explicitly authorized.
- Compression artifacts or low-resolution defects.
- Specific shots that the user's footage cannot support.
- Exact reference runtime unless the user explicitly asks for it.

## 6. Match scorecard
Score each criterion as PASS / PARTIAL / FAIL / UNVERIFIED:
- Hook/section structure
- Shot/visual-mode variety
- Typography hierarchy
- Subtitle readability and distinct role
- Motion restraint and consistency
- Rhythm/cadence
- Transitions
- Audio hierarchy/SFX
- Ending/payoff
- Overall runtime intent

A result with multiple FAILs in core criteria must be revised or delivered as an explicitly incomplete draft, not called final.
