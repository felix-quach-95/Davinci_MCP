# Technical colour (Phase 8) — creative looks only on request (v3.0)

**v3.0 scope (user rule 2026-10-27):** Phase 8 does only technical correction — LOG/HDR conversion, white balance and exposure, contrast and tonal range, obvious casts, consistency between neighbouring shots and cameras, skin tones, highlight/shadow detail. Sections 5–6 (combined looks, look recipes) are used **only when the user asks for a creative look in words**; there is no look question at any gate. Do not assume a clip is LOG: decide from metadata and a still.

Principle: never overwrite the user's grade. Work in a new colour version (`claude_look`); keep it reversible. LOG footage always needs at least a conversion to be viewable, even when no look was chosen.

## Contents
1. Order
2. Recognise the source: LOG / HDR / Rec.709
3. Conversion LUTs installed on the user's Mac
4. `color_look.py` (detect → plan → apply in a colour version)
5. Combined LOG → look LUTs (e.g. `MCP/cinematic_teal_orange_slog3_v1.cube`)
6. Look recipes
7. Safe mechanics and report

## 1. Order
1. **Input transform for LOG/HDR** (S-Log3, V-Log, D-Log, LogC, Apple Log, HLG…): conversion LUT on node 1 (section 3), or — in a colour-managed project — the clip's input colour space, which is a project/clip setting: ask first.
2. **Balance**: exposure and white balance per shot (CDL Offset/Slope) only when a shot clearly sticks out on the stills.
3. **Match**: make neighbouring shots and cameras consistent (CDL Offset/Slope, skin tone check). A shared creative look (section 5) only if the user requested one; B-roll from a clip gets its parent's treatment.
4. **Check**: before/after stills per shot on the Color page — and read them.

## 1b. Technical balance with `color_look.py` MODE measure / balance (v3.0.1, live on TNCRoast)
- **measure** (read-only): 3 source frames per V1 item → luma median / p2 / p98, clipped and crushed %, near-neutral RGB (saturation < 12 %, luma 60–235) → suggested CDL slope and the reason.
- **balance**: the same, then `SetCDL` node 1 (slope only; offset 0, power 1, saturation 1) in colour version `claude_look`; `previous_version` reported for the revert.
- Rules in the suggestion: WB scales R and B so the neutrals match G, ±6 % max, ignored under 1.5 %; no WB when < 5 % of the frame is neutral; exposure only when a shot's median is < 65 % (or > 154 %) of the sequence median, towards 80 % of it, gain ≤ 1.5 and p98 ≤ 235. `OVERRIDE_SLOPE` for hand values.
- Measured live: a pour shot at median 49 vs sequence 103 → gain 1.5 → Resolve still median 51 → 78, p98 120 → 182; steel neutrals with B −4…−5 % → +4…+5 %. The change was hard to see on 270-px thumbnails: check the numbers on Color-page stills (`qc_stills.py` PAGE "color") and a large side-by-side.
- 8-bit phone sources: a 1.5 gain lifts noise too — look at the shadows on a full-size still before keeping it.

## 2. Recognise the source
`color_look.py` (MODE "plan") reads `Input Gamma`, `Input Color Space`, `Gamma Notes`, the clip name and path. Metadata is often empty (phones, drones): then the result is `unknown` and the decision comes from a still:
| Looks like | Probably | Notes |
|---|---|---|
| very flat, grey, low saturation, no deep blacks | LOG (S-Log3, V-Log, D-Log, LogC, Apple Log, C-Log3) | camera brand from metadata/`Video Codec`/file name (DJI_…, C0001 = Sony, P100… = Panasonic, IMG_…MOV with "Apple Log" in metadata) |
| normal contrast, very bright highlights clipping in Rec.709, file is HEVC 10-bit from an iPhone | HLG / Dolby Vision HDR | needs tone mapping (HLG LUT), check highlights |
| normal contrast and colour | Rec.709 | no conversion; look only |
Record the decision in `LOG_OVERRIDE` and say on which still it was based.

## 3. Conversion LUTs installed (MCP `list_luts`, 2026-10-25)
| Source | LUT (path relative to the LUT folder) | Status |
|---|---|---|
| Sony S-Log3 / S-Gamut3.Cine | `Sony/SLog3SGamut3.CineToLC-709.cube` (soft) · `Sony/SLog3SGamut3.CineToCine+709.cube` (more contrast) | installed |
| Panasonic V-Log | `Panasonic/V-Log to V-709.cube` | installed |
| DJI D-Log (Zenmuse X7 / Phantom 4) | `DJI/DJI_X7_DLOG2Rec709.cube`, `DJI/DJI_Phantom4_DLOG2Rec709.cube` | installed; **D-Log M** (Mini 4 Pro, Osmo, Air 3) is a different curve: DJI's official LUT (download needs approval) or a colour-managed project |
| ARRI LogC | `Arri/Arri Alexa LogC to Rec709.dat` | installed |
| Blackmagic Film | `Blackmagic Design/Blackmagic <camera> Film to Rec709 …` | installed, pick the camera |
| Leica L-Log | `Leica/Leica L-Log to Rec.709 Gamma 2.4.cube` | installed |
| Samsung Log | `Samsung/Samsung Log to Rec709.cube` | installed |
| OM System OM-Log400 | `Olympus/Olympus OM-Log400_to_BT.709_v1.0.cube` | installed |
| HLG (iPhone HDR, HLG cameras) | `HDR Hybrid Log-Gamma/HLG to Gamma 2.4.cube` | installed; rough — highlights can clip, check the sky |
| Apple Log (iPhone 15 Pro+) | — | not installed: Apple's official LUT (approval to download) or colour management |
| Canon C-Log3 | — | not installed: Canon's official LUT (approval) or colour management |
The "LUT Download" folder holds third-party look LUTs (some with CLog3/VLog variants) the user added; use only when the user names one.

## 4. `color_look.py`
- MODE "plan": one row per V1 item — gamma + evidence, suggested LUT, note; paste the `files` list from `list_luts` into `INSTALLED_LUTS` to see whether each LUT exists.
- MODE "apply": `RefreshLUTList()`, for each item: add/load the colour version `claude_look`, `SetLUT(1, lut)`, read `GetLUT(1)` back; `previous_version` is reported for the revert (`LoadVersionByName(previous, 0)`). `SKIP` leaves out shots whose look lives in their Fusion comp (e.g. a clip carrying a Fusion effect).
- LOOK "convert" = conversion only; LOOK "teal_orange" = combined LUT when one exists for that gamma, otherwise conversion only with a note.
- Status: the LUT/version calls are verified (HuongCang, 2026-10-24); the script itself is UNTESTED live — read the result and look at stills.

## 5. Combined LOG → look LUTs
A version starts with one node, so the look must be **one** LUT on node 1 (no guessing at node creation). For LOG sources that means a combined LUT: conversion first, then the look curve.
- Existing: `MCP/cinematic_teal_orange_slog3_v1.cube` (S-Log3 → Rec.709 → teal-orange; used on HuongCang/HongKong) and `MCP/cinematic_teal_orange_v1.cube` (Rec.709 source).
- Making one for another source with the MCP tool `generate_lut`: the transform is (1) the camera's LOG decode to linear, (2) gamut matrix to Rec.709, (3) a gentle filmic tone curve to display, (4) the look function of section 6. Read the tool's own schema for how it takes the transform, write `MCP/claude_<look>_<gamma>_v1.cube` (33³), `RefreshLUTList()`, apply to one shot, compare with the built-in conversion LUT on a still, then the rest.
- S-Log3 decode (Sony's published formula), input x in 0–1 code value:
```python
def slog3_to_linear(x):
    c = x * 1023.0
    if c >= 171.2102946929:
        return (10 ** ((c - 420.0) / 261.5)) * (0.18 + 0.01) - 0.01
    return (c - 95.0) * 0.01125000 / (171.2102946929 - 95.0)
```
  Gamut S-Gamut3.Cine → Rec.709 (linear) ≈ `[[1.6269, -0.5401, -0.0868], [-0.1785, 1.4179, -0.2394], [-0.0444, -0.1959, 1.2404]]` (INFERRED from Sony's documentation; compare against `Sony/SLog3SGamut3.CineToLC-709.cube` on a grey/skin still before using).
- Simpler and safer when unsure: conversion LUT on node 1 of the `claude_look` version, look skipped, and tell the user.

## 6. Look recipes (applied to a Rec.709 image; tune on stills)
**Cinematic teal-orange (night city)** — LUT transform idea:
```python
# r,g,b in [0,1], Rec.709 display referred
l = 0.2126*r + 0.7152*g + 0.0722*b
s = l*l*(3-2*l)                     # gentle S-curve on luma
k = 0.10                            # split strength
r2 = r + (s-l) + k*(l-0.5)*0.9      # warm highlights
b2 = b + (s-l) - k*(l-0.5)*1.1      # teal shadows
g2 = g + (s-l) - k*(l-0.5)*0.15
m = 0.85                            # saturation
out = [l + (c-l)*m for c in (r2,g2,b2)]
return tuple(min(1,max(0,c)) for c in out)
```
Protect skin: if faces appear, reduce k to 0.06 and check the still.

**Clear / soft / airy (bright daily vlog)**: lift shadows slightly (Offset +0.02), lower contrast (Power 0.95–0.97 on luma), small warm white balance (Slope R 1.02, B 0.98), saturation 0.95–1.0, keep highlights below clip. Avoid green-cyan in skin.

**Warm soft (installed v2.7.0: `MCP/claude_warm_soft_rec709_v1.cube`, `color_look.py` LOOK "warm_soft")** — overcast family/daily footage (BoConCN): gentle S-curve, warm white balance, +8 % saturation, lifted blacks, a touch warmer highlights. If the file is missing, recreate it with the MCP tool `generate_lut` (path `claude_warm_soft_rec709_v1.cube`, size 33), transform:
```python
def sc(x):
    return x + 0.10*(x-0.45)*(1-x)*x*2.2
r=r*1.035; g=g*1.005; b=b*0.955
l=0.2126*r+0.7152*g+0.0722*b
s=1.08
r=l+(r-l)*s; g=l+(g-l)*s; b=l+(b-l)*s
r,g,b=[0.018+0.97*sc(min(max(c,0.0),1.0)) for c in (r,g,b)]
k=max(l-0.55,0)*0.06
r+=k; b-=k*0.8
return (min(max(r,0.0),1.0),min(max(g,0.0),1.0),min(max(b,0.0),1.0))
```

**Moody / melancholic**: slight desaturation 0.8, cool shadows, keep blacks at ~0.03 (not crushed to 0), warm practical lights preserved.

**Film print** (only if the user asks for "film"): the installed `Film Looks/Rec709 Kodak 2383 D65.cube` after a conversion — strong; needs its own combined LUT or the user's node tree.

## 7. Safe mechanics and report
- `item.AddVersion("claude_look", 0)` then `LoadVersionByName("claude_look", 0)` — the user's original version stays intact.
- `SetCDL` writes to a node index — confirm `GetNodeGraph().GetNumNodes()` first; with one node, keep the look in the LUT.
- Never call `ResetAllGrades` or delete LUTs/DCTLs the user made.
- Fusion runs before the Color page: effects/text inside a clip comp are graded too (keep glow low on LOG; move the grade into the comp for behind-object text).
- Report: which shots, which version/LUT, stills inspected, how to revert (switch version).
