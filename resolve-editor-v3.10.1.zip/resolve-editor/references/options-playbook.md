# Options playbook — the wording of every stop (v3.3.0)

Each decision is asked **at the stop where it is cheapest**, shown as pictures, with a recommendation, and remembered. No stop asks about titles, subtitles, text or animation — those are asked once, at the Final approval.

**Express mode (default):** the kickoff questions are not asked (answers come from `_prefs.json` and the brief, stated as assumptions; frame rate and size are still asked as blockers), the rough-cut approval and the hero accent choice run on the recommendation, and the Final approval asks the Final name and cleanup in one round (graphic questions come only in Phase 11, `§8b`). Style choice, Music request, Story approval, Draft review and Final approval are asked in both modes.

## Contents
1. Kickoff questions (Phase 1, Standard mode)
2. Style choice (Phase 1)
3. Music request (Phase 1)
4. Story approval (Phase 4)
5. Rough-cut approval (Phase 6, Standard mode)
6. Hero accent choice (Phase 7, Standard mode)
7. Draft review (Phase 9)
8. Final approval (Phase 10)
8b. Graphic questions (Phase 11)
9. Alternates kept in the blueprint
10. Preferences that carry over
11. Known revision causes and how they are prevented

Variant sheet = one image with 2–3 labelled versions (A / B / C) of the same moment, at most 3 variants × 2 frames, answered with a letter. Build variants **on the Draft** (a second `motion_fx` run on one item, colour versions for correction strength), not on Test_ copies.

## 1. Kickoff questions (Phase 1, Standard mode)
Right after the inventory. One AskUserQuestion, at most 4 questions, recommendation first; the last video's choice from `_prefs.json` is the recommendation, labelled "như video trước". Ask only what blocks progress. Style and music are not asked here (sections 2 and 3).
1. **Nguồn SFX** (only if not in `_prefs.json`): Thư viện trên máy (Recommended) · Thư viện trên máy + gợi ý nguồn miễn phí khi thiếu. Accent intensity comes from the chosen style.
2. **Định dạng và độ dài**, only when the brief does not say: 9:16 TikTok/Reels/Shorts 15–25 s (Recommended) · 30 s (the maximum) · 4:5 / 1:1 / 16:9 (then ask the length, at most 30 s).
3. **Frame rate and timeline size**, only when the inventory warns `FPS_MISMATCH` or `LOW_RES_SOURCE`, and always **before** the first Probe_/Draft_ timeline (it locks the project frame rate): e.g. footage 29.97 fps → "Đổi dự án sang 29.97 fps (Recommended)" · "Giữ 24 fps"; 1440p or 720p sources → "Timeline 1080×1920 (Recommended)" · "Giữ 2160×3840".
In Express mode only question 3 is asked, as a blocker. Write the answers with `project_set` and `prefs_set {"choices": …}`.

## 2. Style choice (Phase 1, after the footage scan)
Offer **5 styles for the whole video + a 6th the user writes**. Styles are *editorial* (pace, effect language, sound, ending) — never titles, fonts, graphics or a creative colour look.
1. **Build from evidence.** Pick the 5 archetypes the scan supports best (at least 3 cinematic, at least 1 of a different register). Every option cites at least 2 shot IDs from the scan; an option the footage barely supports is marked "stretch" and says what is missing.
| Archetype | Average shot length | Effect language (speed ramp · zoom in · zoom out) | Sound and ending |
|---|---|---|---|
| **Cinematic slow-burn** | 2.2–3.5 s | slow pushes on most wides, one hero speed ramp at the drop, pull-out at the end | ambient or piano; hit and fade |
| **Emotional memory** | 2.5–4 s | slow motion on gestures and light, soft pulls at the release, blur bridges | warm, sparse; long fade |
| **Beat-drop energy** | 1.2–2 s | ramps into phrase hits, punch-ins on beats, whip bridges | electronic; cut on the hit |
| **Quiet observation** | 3–4.5 s | 2–4 accents only: one slow push, one pull; long holds | natural sound and a soft bed; ring-out |
| **Contrast montage** | 1.5–2.5 s | wide↔detail, match cuts, a ramp at the turn, zoom-through joins | rhythmic bed; hit and fade |
| **Tension → release** | accelerating 3 → 1.2 s | creeping pushes, a silence then a ramp-and-hit, big pull | build or riser; sub drop; fade |
| **Dreamy** | 2.5–4 s | drifting virtual-camera moves, defocus bridges, slow pulls | pads, soft; ring-out |
| **Day-in-the-life flow** | 2–3 s | match-on-action joins, light pushes, one ramp at the high point | light groove; natural end |
2. **Show** (one numbered message, plus one strip image per option via `SendUserFile` with 3–4 stills ≤ 1024 px and shot IDs): number · Vietnamese name · one-line design read · why this footage (shot IDs) · average shot length and expected shot count at ≤ 30 s · cinematic effects (how many speed ramps and where; zoom in and zoom out roles) · sound direction · ending · what it avoids. Option **6 = "Tự viết phong cách của bạn"**.
3. **Record.** The chosen option becomes the project style in the profile format (`style-profiles.md`); option 6 is parsed into the same fields, read back in one line, unspecified fields filled from the nearest archetype and marked "assumed". `project_set {"style": …, "stops": {"style_choice": "<n>"}}`, `prefs_set {"choices": {"style": …}}`.
4. The style sets the register of the story contract (`story-decision-framework.md` §1), the shot-length range, the accent density and the effect recipes of Phase 7.

## 3. Music request (Phase 1, right after the style choice)
The user supplies the music. Claude never proposes, previews or downloads tracks.
1. `music_intake.py` first. Status `USER_MUSIC` (the user already sent music) → no request: name the file and go on to Phase 2. `USER_MUSIC_SEVERAL` → ask which one is the main track. `CHOSEN_BY_CLAUDE` (only a track from an earlier project) → ask: use it, or send another.
2. Status `NONE` → send **one message** built by `music_request(style, runtime_s)`: title "Yêu cầu gửi nhạc nền", the chosen style, what kind of music fits it (mood, pace, ending, from the style's `audio`, average shot length and `ending`), the maximum video length, and how to send it (path, Media Pool, or the footage folder). No options, no previews.
3. **Wait** for the file. Nothing after Phase 1 starts before it arrives. When the user answers, run `music_intake.py` again with `NAMED_PATHS = [their path]`.
4. Record `project_set {"music": {"file", "chosen_by": "user"}, "stops": {"music_request": "received"}}`. Then Phase 2 analyses the track.

## 4. Story approval (Phase 4, paper only)
After the music map (Phase 2) and the footage catalogue (Phase 3). Everything that sets timing is decided here, shown, not named. One AskUserQuestion, at most 4 questions:
- **Structure and runtime**: 2 options, each a 4–7 still chapter strip with runtime and drop time; each beat tagged documented / interpretation / needs more footage.
- **Hook**: 2 openings, each shown as its first frame. No hook *text* design.
- **Ending**: the options from `endings.md` with the frame each ends on.
- **Runtime**: the recommended music window (measured hits) and a shorter alternative.
Then state in one line each the assumptions that need no question (B-roll layers, effect count).

## 5. Rough-cut approval (Phase 6, Standard mode)
- **Rough-cut sheet**: middle frame of every segment, numbered `shot_01` …, with the paper-edit table (chapters, average shot length, drop frame). Options: Ổn, khoá hình (Recommended) · Nhanh hơn (~15 % shorter) · Đổi hook hoặc thứ tự · Thay vài cảnh (list the shot numbers).
- If the blueprint plans a ramp or freeze at the drop (duration-changing), show its 2 variants here.
Timing changes now re-run the picture build only.

## 6. Hero accent choice (Phase 7, Standard mode)
| Question | Variants | Build |
|---|---|---|
| Điểm nhấn tại drop | punch + shake · push + flash · blur pop (all duration-neutral) | second `motion_fx` run on that one item, on/off stills |
The chosen recipe is applied to every accent; no other effect decision is asked later.

## 7. Draft review (Phase 9)
After the quality checks, send the quality-control sheet and the scorecard and ask the user to watch the Draft with sound. One AskUserQuestion:
1. **Cần sửa gì?** (multiple choice): Ổn rồi, chốt Final (Recommended when the scorecard has no blocker) · Nhịp / độ dài · Thay cảnh (name `shot_NN`) · Màu kỹ thuật · Hiệu ứng · Âm thanh (mức nhạc / SFX) — plus free text. No text option: text is handled at the Final approval.
Each note goes through the change router into the next `Draft_<Title>_vNN`; say which layers re-run first. Taste rules → `prefs_set {"lessons": …}`.

## 8. Final approval (Phase 10)
After `Final_<Title>_NN` exists and `finalize_project.py` MODE plan has run, ask once — **only these two questions, no graphic question** (user rule 2026-10-28: graphics are asked only after the switch to HyperFrames):
1. **Tên timeline Final**: two Vietnamese suggestions (Recommended first) · giữ tên hiện tại.
2. **Dọn dự án**: Dọn như danh sách (Recommended: keep / delete counts and names) · Dọn nhưng giữ Draft cuối · Chưa dọn.
Then MODE apply with the plan token (a changed plan means a new token: show the difference), look at stills of the Final, report the backup path and that Cache Edit can be deleted after the graphics are placed (copy the `.drp` backup out first).
Then the switch question (v3.10.0, `phase-11.md` §1), one AskUserQuestion: **"Final đã xong. Chuyển sang Phase 11 — làm đồ họa với HyperFrames?"** · Chuyển sang HyperFrames ngay (Recommended: ngay trong cuộc trò chuyện này — mở thư viện mẫu có hình để chọn, rồi mới hỏi đồ họa) · Để sau · Không cần đồ họa (kết thúc dự án). Never offer a new chat, a new window or `/clear`.

## 8b. Graphic questions (Phase 11 §1 C, after the style is picked in the gallery)
One AskUserQuestion, ≤ 4 questions, each option tied to a frame/beat of the Final (`hyperframes-handoff.md` §2), recommendation first:
1. **Đồ họa cần làm** (multiple choice): tiêu đề mở đầu · nhãn chương / địa điểm · chữ kết · phụ đề (only with speech).
2. **Chữ** for each chosen element: two wordings (vi, or vi+en) · tự viết.
3. **Vị trí và thời điểm**: the recommended anchor (a cut or beat, upper/lower third, clear of faces and the platform UI) · one alternative.
4. **Cảm giác chuyển động**: êm và chậm · gọn và nhanh · nhịp mạnh theo beat.
Skip any question the user already answered. Then the brief (`hyperframes-handoff.md` §4).

## 9. Alternates kept in the blueprint
- Each segment may carry `alt`: `[{"clip", "src_in", "src_out", "why"}]` — the second-best range for the same story job. A review note "đổi shot_05" is then one `replace_shot.py` call with the alt (the new item keeps the name `shot_05`).
- Each SFX cue keeps an `alt_file`.
These fields are ignored by the builder and reported by `edit_analysis.py` as plain data.

## 10. Preferences that carry over
`~/Movies/ClaudeQC/_prefs.json` (loader MODE `prefs_get` / `prefs_set`):
- `choices`: the last answers (style, accent level, ending type, audio sources, format).
- `config`: values the user corrected by hand that should become defaults (a role level in `levels_db`, `mix.bed_ref_dbfs`). Order: defaults.json < prefs config < project.json < overrides.
- `lessons`: one line per review correction that is a taste rule ("không dùng flash trên cảnh đêm"). Read them in Phase 1, apply them and say which.
At the Draft review classify each note as one-off or rule, and say so.

## 11. Known revision causes and how they are prevented
| What the user said or changed | Prevention |
|---|---|
| "dừng đột ngột" (endings) | ending chosen at the Story approval with the end frame shown; `ending_plan.py` must report a natural end |
| SFX "hơi nhỏ" | levels follow the measured footage and music bed (`sfx-library.md` §5) |
| B-roll cuts "weird and wrong" | dense evidence before choosing ranges; alternates in the blueprint |
| Too few accents | default cinematic 5–10 per 15–20 s, from the style |
| Late picture changes after sound | rough-cut review before accents and sound |
| Graphics redone after the cut moved | graphics are specified only after the Final exists and anchored to cuts, beats and markers |
| Music chosen by Claude did not fit | the user always sends the music (Music request) |
