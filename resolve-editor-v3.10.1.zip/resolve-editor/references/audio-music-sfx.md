# Music, SFX and the mix

Adapted from resolve-mcp-bridge (music beds, SFX placement, beat grid, QA) and motion-video-skill (beat-grid fitting, cut-on-beat). Measurement is not listening: report levels as measured, mix as "not auditioned" unless the user listened.

## Track layout (default)
| Track | Role |
|---|---|
| A1 | Production sound / dialogue (from footage) |
| A2 | Music bed |
| A3 | SFX |
| A4 | Ambience / room tone (optional, keeps audio continuous under silent shots) |
| A5 | MUSIC DUCK — second music lane made by `duck_music.py` (crossfaded duck segments) |

Name tracks with `SetTrackName("audio", i, "MUSIC")` etc. (`build_from_blueprint.py` does it from `track_names`; the same layout is in `config/defaults.json` → `tracks`). `ending_plan.py` and `qa_audit.py` find the music by the track name MUSIC (else the audio-file track covering most of the runtime), so keep the names.

## Choosing music
- Library: `paths.music` (`/Users/felix/Desktop/Asset/Music`). `scripts/music_library.py` (v2.2) MODE "scan" catalogues it (duration, BPM + confidence, energy curve, intro length, phrase hits and typical phrase length, ending type button/fade/cut, mood guess from name + tempo/level); MODE "pick" with `QUERY = {"mood", "min_dur", "max_dur", "bpm", "ending", "keywords", "n"}` ranks tracks and says why. Prefer tracks with clear phrases (2–8 s, so chapters can land on hits), a short intro (or start later) and a button/fade ending. Measured, not heard: state it in the Story approval assumptions and let the user veto.
- Free download only when the user asks or library has nothing suitable: Mixkit, Pixabay Music, YouTube Audio Library (attribution-free tracks), Free Music Archive (check per-track license). Record title, URL, license in the report. Save under `~/Desktop/Asset/Music/` (ask before writing elsewhere).

## Beat grid
`scripts/silence_beats.py --beats <music file>` (ffmpeg + numpy if present; pure-python fallback) returns BPM estimate, first-beat offset and a beat list in seconds plus downbeat guesses. Use it to:
- snap major cuts to beats or downbeats (±2 frames), not every cut;
- land title entrances and SFX hits on beats;
- choose a music start offset so the drop meets the payoff shot.
Mark beats you use with Green markers. If detection confidence is low, say so and cut by feel/structure instead.

## Making the music fit the runtime
- Start the track where its energy suits the hook (trim intro via `startFrame`).
- End on a natural phrase end; fade out 0.8–1.5 s with `SetFades`. Do not end mid-bar without a fade.
- If the track is shorter than the edit, use two tracks with a crossfade or a loopable section; never leave silence at the end.

## SFX
v2.8: levels follow the measured footage/music bed around each cue (`sfx-library.md` §5); free online music/SFX fill gaps in the local library after the user approves a shortlist (`free-audio-sources.md`).
- Library: `/Users/felix/Desktop/Asset/Sound Effect` (2,436 files). Catalogue and pick with `scripts/sfx_library.py` (measured duration, peak/onset, shape hit/rise/swell/flat, role tags; memes, weapons and cars excluded from mood pieces) — full guide in `references/sfx-library.md`. Audition is impossible: rely on the measured envelope and clear names.
- Place on: title entrances (pop/whoosh), speed ramps (whoosh), transitions/whip pans (swoosh), reveals (riser → hit), real on-screen actions. Not on every cut. Align the **peak** of a whoosh/riser and the **onset** of a hit/shutter with the picture event (`placement()` in `sfx_library.py`).
- Levels: the one table is `sfx-library.md` §5 (= `config/defaults.json` → `levels_db`): music bed −9 dB without dialogue, about −20 dB under dialogue; dialogue peaks −6 to −3 dBFS; SFX by role (whoosh −8, sub drop −7 … for a typical file; each file moved by its own peak) and never above the dialogue.

## Ducking (`duck_music.py`, v2.2, UNTESTED live)
No sidechain or volume keyframes via the API. `duck_music.py` rebuilds the music item as consecutive segments of the same file (source continuous) alternating between A2 and A5, each overlapping the next by 8 frames with a fade-out/fade-in pair — every level change is a short crossfade, not a dip. Speech comes from `RANGES` (`transcript_cut.py` → `speech_ranges`), the subtitle track, or the A1 items; gaps < 1 s stay ducked (no pumping), the duck starts 6 frames before speech and holds 10 after. MODE "plan" first, then "apply" on a fresh Draft; read back; listen. Alternative: the user enables Fairlight auto-ducking in the UI.

## Voice, presence, clicks (v2.3)
Dialogue sources, levelling, EQ/Fairlight steps, the music envelope around speech, the "is it really in the mix" render check and 2-frame crossfades on jump cuts: `voice-audio.md`.

## Loudness and continuity
- TikTok target ≈ −14 LUFS integrated, true peak ≤ −1 dBTP. `tl.NormalizeAudioLevel(items, {...})` on dialogue items; check `GetNormalizeAudioModes()` for the loudness mode name.
- After a render, `render_deliver.py` MODE "verify" measures the file (ffmpeg `ebur128`) and gives the dB correction (`delivery.md` §3–4).
- `scripts/qa_audit.py` reports any frame range where no audio item exists on any track (continuity gate).
