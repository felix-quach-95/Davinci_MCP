# Resolve API — quick table of calls verified live (21.1.1)

Use this first; Grep `api-cookbook.md` (archive, ~3k words) only for a call not listed here.

| Need | Call | Notes |
|---|---|---|
| project / timelines | `pm = resolve.GetProjectManager(); p = pm.GetCurrentProject(); p.GetTimelineByIndex(i)` | 1-based; `pm.SaveProject()` |
| settings before the first timeline | `p.SetSetting("timelineFrameRate", "30")`, `timelineResolutionWidth/Height` | `timelinePlaybackFrameRate` is refused |
| duplicate | `tl.DuplicateTimeline(name)` | keeps comps, versions, items (`timeline_ops.py` next_draft) |
| append | `mp.AppendToTimeline([{mediaPoolItem, startFrame, endFrame, trackIndex, recordFrame, mediaType}])` | endFrame exclusive; mediaType 1 video, 2 audio; audio counts frames at the file's rate |
| delete items | `tl.DeleteClips(items, False)` | no trim API: re-append (`timeline_ops.py` reappend_audio) |
| tracks | `tl.AddTrack("audio", "mono")`, `tl.SetTrackName(kind, i, name)`, `tl.DeleteTrack(kind, i)` | |
| item props | `it.SetProperty("Pan"/"ZoomX"/"AudioVolume", v)`, `it.GetProperty(...)`, `it.SetFades({...})`, `it.GetFades()` | read back after a moment: a fresh item can return None |
| colour | `it.AddVersion(n, 0)`, `it.LoadVersionByName(n, 0)`, `it.SetCDL({"NodeIndex": "1", "Slope": "r g b", …})`, `it.GetNodeGraph().SetLUT(1, lut)` | |
| Fusion | `it.GetFusionCompByIndex(1)`, `comp.FindTool(name)`, `tool.GetInput(id, frame)` | via `motion_fx.py` |
| stills | `tl.SetCurrentTimecode(tc)` + sleep ≥ 0.6 s + warm-up, `p.ExportCurrentFrameAsStill(path)` | Color page hides Edit-page fades |
| media pool | `mp.ImportMedia([paths])`, `mp.AddSubFolder(root, name)`, `mp.MoveClips(items, bin)`, `mp.DeleteClips(items)`, `mp.DeleteFolders([bins])` | DeleteClips leaves files on disk |
| render (check only) | `audio_presence.py`; deliverables only on request | `StartRendering([job], False)` |
