# Clip factory — one long source, several ranked short clips (v2.8.0 addendum)

Use when the user has **one long recording** (a long vlog take, a talk, a whole travel day) and wants **several vertical shorts** from it, instead of one edited piece. Method adapted from the batch pipeline of the open-source OpenMontage project (AGPL-3.0; ideas rewritten, nothing copied). Everything else in the pack still applies to each clip — `transcript-editing.md` for speech, `story-structure.md` for the arc, `hyperframes-handoff.md` for any graphics (Phase 10), `review-scorecard.md` before the Draft review.

Keep the cost low: **select once, template once, review all clips on one sheet, build only the clips the user approves.**

## 1. Gate and roles
Hard gates 1–3 of SKILL.md first (roles, inventory, visual evidence). State the source duration and ask only: how many clips at most, which platforms, and whether captions are wanted. Everything else is proposed.

## 2. Say a realistic yield before extracting
Guide (from that project; a starting point, not a promise): 15–30 min source → 3–6 strong clips; 30–60 min → 5–10; 60+ min → 8–15 *if the source quality supports it*. A small strong batch beats a padded weak one — never inflate the count to a round number. Say the expected number and why.

## 3. Choose a mix of clip families (not the same energy ten times)
| Family | What it is |
|---|---|
| hook | surprising claim or strong cold open |
| insight | a useful takeaway or lesson |
| story | a moment with an emotional shape |
| proof | a number, a result, a demo that works |
| opinion | a hot take or contrarian point |
For silent/travel footage replace them with: *arrival*, *detail*, *action*, *reveal*, *quiet moment*. Write the intended balance into `project.json` (`clips.families`).

## 4. Ranking criteria — written BEFORE any cutting
Score each candidate 1–5 and show the table (candidate id, source time range, length, hook line or first image, scores, total, evidence = the transcript line or the frame seen):
1. **Hook in the first 2–3 s** — starts on motion, a face or the result; the point is not delayed.
2. **Self-contained** — understandable without the rest of the source.
3. **One idea** — a single point or beat, with a peak.
4. **Clean edges** — can start and end on a sentence or gesture boundary with no clipped word.
5. **Payoff lands** — nothing useful happens after the point; no trailing silence.
6. **Fresh** — not a repeat of another clip's point.
Weights may change with the family (a story clip values the peak more). Discard what scores below 3 on criteria 1, 2 or 4 whatever the total. For speech, candidates come from `transcript_cut.py` (sentences and pauses); for footage without speech from `frame_probe.py` contact sheets and `picture_tools.py` scene cuts.

## 5. Platform fit before extraction
9:16 for TikTok/Reels/Shorts (this pack's default), 1:1 or 16:9 only on request (`delivery.md`). If the source framing will not survive a vertical crop (wide two-shot, slides, a demo needing the full frame) say it now and propose the alternative.

## 6. One shared template for the batch
Lock once, in `project.json` (`clips.template`) and the chosen style profile (`style-profiles.md`): caption recipe, hook-text timing (appears in the first 0.5 s, ≤ 7 words), lower-label timing, audio fade lengths (default 2-frame crossfades), ending type, look. Per-clip overrides only where the clip needs it (hook line, ending line). Every clip then looks like part of one series.

## 7. The first 2–3 seconds, every clip
Start on motion, face or result; hook text immediate if needed; captions begin with the first spoken word; no intro that delays the point; no setup for setup's sake.

## 8. Build, review, deliver
1. Per approved candidate: its own timeline `Draft_<Title>_c01_v01`, `_c02_…` (blueprint from the paper edit, `build_from_blueprint.py`); text and sound as in the normal workflow.
2. **One review sheet for the whole batch** (`options-playbook.md`): first frame and the frame at 3 s of every clip, plus its hook line and score. The user picks which clips go on; revisions are per clip (`_v02`).
3. Approved → `Final_<Title>_c01_01`. Render only on request, one by one with `render_deliver.py`.
4. Report table: clip id · source range · duration · hook · score · status, and what was left out and why (never drop silently).

## 9. Checks
Each clip self-contained · hook fast · same style and fades across the batch · no clipped word at any edge · loudness per clip (`delivery.md`).
