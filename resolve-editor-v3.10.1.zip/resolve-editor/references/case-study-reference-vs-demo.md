# Case Study: User Reference vs Claude Demo (2026-10-23)

This case study is a regression test, not a permanent style preset.

## Reported media facts
| Role | Duration | Frame size | Frame rate | Aspect |
|---|---:|---:|---:|---|
| Demo output `DEMO_Shortform_v04.mp4` | about 5.08 s | 1080 × 1920 | 24 fps | 9:16 |
| Reference `v14044g50000da5scdnog65pemeeglqg.MP4` | about 75.77 s | 576 × 1024 | 30 fps | 9:16 |

The videos depict different speakers/topics. Transfer visual grammar, not unrelated subject matter or exact shots.

## Traits observed in the supplied sample
- Talking-head anchor interleaved with full-frame typography cards, graphic examples, font samples, screen/interface captures, and a desk/laptop insert.
- Strong hierarchy: expressive serif/script words and bold sans-serif, contrasted with smaller explanatory copy and captions.
- Purple/lilac accent against black/white and darker footage; white cards for examples.
- Multiple visual modes: close/medium talking head, text-led cards, interface examples, illustrative inserts.
- Some key words are integrated into the composition; other moments use typography as the whole frame.
- Ending uses a social-platform outro; recreate only the function if appropriate, not the original identity/watermark.

## Visible demo problems
- Output was about 5.08 seconds versus about 75.77 seconds for the reference. The target was not resolved at the time. In the current workflow, the default is a teaser based on usable source footage, so do not compare against the reference runtime unless requested; instead compare against the approved target.
- The demo appeared to use essentially one talking-head shot with little visual-mode variety.
- Text appeared tiny and near the forehead/eye area.
- Display emphasis and dialogue captions lacked a stable hierarchy.
- Reference-like section changes, explanatory examples, and a designed ending were not evident.

## Regression requirements
1. Separate source footage from style reference.
2. Inspect the full reference if accessible.
3. Recommend teaser duration after source inventory.
4. Create a section/coverage plan and shot-level blueprint.
5. Define display typography separately from dialogue subtitles.
6. Include visual-mode variety only when usable footage/assets support it.
7. Verify timeline duration against the agreed target and rendered duration where possible.
8. Run reference-match scorecard.
9. Label visual/audio criteria unverified when tools cannot inspect rendered output.
10. Never call the result final if core requirements fail or runtime is unexplained.

# Case Study 2: Hong Kong night draft (2026-10-24) — structural PASS, visual FAIL

`qa_audit.py` on `DRAFT_Shortform_v01` (historic name, formerly allowed) (24 fps, 383 frames, target 384) returned STRUCTURAL PASS: no gaps, continuous audio, sources within bounds. Two exported stills, viewed by Claude, showed:
1. Subtitle line rendered with missing Vietnamese glyphs ("NH NG" for "NHỮNG"), ran off the right edge, low contrast on the sky.
2. Title spelling "Đêm Hưởng Cảng" (should be "Hương Cảng").
3. Landscape footage filled/cropped to 9:16 although the user asked to keep the full landscape frame.
4. The music item ends 1 frame before the timeline end with no fade-out.

Lesson: the structural audit is necessary, never sufficient. Always run the still check on title hero frames and one frame per shot before calling a draft done. Clips of 25/50/100 fps sat in a 24 fps timeline: use fps-aware lengths (the build script handles it).


# Case Study 3: Hong Kong text system test (2026-10-24) — what changed the skill
Project "Untitled Project 2026-10-24_114503", 4 S-Log3 clips (25/50/100 fps) → `DRAFT_HK_v01_fill` (historic name, formerly allowed; 385 frames, 24 fps), text on nested timelines, LUT teal-orange, music + two whooshes. User approved the samples and chose FILL.
1. Text+ sizes from the old docs rendered 2–3× too small (looked fine in read-back) → width-based sizing + font calibration.
2. Tracked caps at CharacterSpacing 1.35 overflowed both edges → tracking 1.08–1.12 + validation.
3. Emphasis stack overlapped the English line → measured glyph heights + `below` stacking.
4. (v2.x lesson, historical) a gold title on dusk sky measured 2.1:1 — contrast checks for text are now part of HyperFrames' work, not this skill's.
5. Title insert rippled V1 of a probe timeline → nested text timelines only.
6. Behind-object text in the clip comp would have been graded twice → grade moved into the comp (FileLUT) for that shot, Color-page LUT cleared.
7. Tracked pin drifted on a rotating aerial; per-node XYPaths froze Resolve → one Transform path; no pins on rotating shots; save before risky Fusion work.


# Case Study 4: HuongCang from scratch (2026-10-24) — what the v2.0 workflow fixed
Footage: the same four S-Log3 clips (01 street day 25 fps, 02 skyline dusk 50 fps, 03 drone night 25 fps, 04 kitchen 100 fps), ~16.5 s of source in total. Result: `Final_HuongCang_01`, 520 frames, 12 shots / 7 chapters on the music's phrase hits, 5 B-roll framings made from 2 clips, 7 motion accents, 5 text events, 8 SFX cues, STRUCTURAL PASS + 26-frame visual QC + Final = Draft render check.
Lessons:
1. Ask every creative choice at one gate (story, intensity, look, ending): no rebuilds afterwards.
2. Resolve rounds retimed lengths — cuts drifted 13 frames off the music until `dur` convergence.
3. `Pan` sign was assumed wrong — the bouquet and wok B-roll framed the wrong subject until stills were checked; now calibrated.
4. Keyed Fusion effects in clip comps did not render until a node input changed — effects "verified" by `GetInput` alone were invisible; on/off still pairs caught it.
5. Transform Center ≠ Pivot — a push "centred" on the subject shifted the picture and exposed a black band.
6. A moving subject leaves the frame during a push — `drift` follows it.
7. `ending_plan.py` caught music ending mid-decay; extended to the quiet before the next hit.
