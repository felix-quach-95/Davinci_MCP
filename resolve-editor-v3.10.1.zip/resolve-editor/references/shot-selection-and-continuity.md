# Shot selection and continuity — pick the best shot, join it well, never repeat it (v3.2.0)

Used in Phase 5 (choosing) and Phase 6 (joining). Inputs: the beat map (`story-decision-framework.md`) and the catalogue with shot IDs (`footage-intelligence.md`). Priority when criteria conflict follows Walter Murch's Rule of Six, in order: **emotion → story → rhythm → eye trace → 2D plane → 3D space**; give up from the bottom ([source](https://nofilmschool.com/2016/11/6-rules-good-cutting-according-oscar-winning-editor-walter-murch)). Continuity basics (match on action, eyeline match, 180° and 30° rules, screen direction) are summarised from [StudioBinder](https://www.studiobinder.com/blog/what-is-continuity-editing-in-film/).

## Contents
1. Scoring a shot for a beat
2. Comparing two shots for the same beat
3. Continuity between two shots
4. Join vocabulary and when each fits
5. Cinematic joins — speed ramp, zoom in, zoom out
6. Repeat checks (four levels)
7. Recording the choice (blueprint fields)
8. Done criteria for Phase 5

## 1. Scoring a shot for a beat
First apply **hard filters**; a shot that fails one is out for this beat whatever its score:
- bad frames inside the range (`bad`), soft/shaky quality below `usable`;
- its image group is already used elsewhere in the plan (§6);
- it shows a fact that is wrong for the beat, or repeats information already given (ledger);
- not enough source for the planned effect (no handles for a ramp, no room for a push).
Then score 0–3 on five lenses and weight them (weights are a starting point; emotion and story carry the decision):
| Lens | Weight | 0 | 3 |
|---|---|---|---|
| **Emotion** — carries the beat's feeling at the right intensity | 30 % | contradicts or neutral | exactly the feeling, right intensity |
| **Story role** — does the beat's job (hook/setup/dev/peak/release/ending) and answers its viewer question | 25 % | wrong job | ideal for the job (catalogue `roles` ≥ 3) |
| **Action / movement** — visible change inside the shot; a clear peak when the beat is a peak | 20 % | dead frame | motivated movement with a readable peak |
| **Image quality** — sharp, exposed, composed for 9:16, readable at phone size | 15 % | soft / cluttered | clean, strong composition |
| **Fit with neighbours** — continuity (§3) and rhythm with the music | 10 % | clashes | flows from and into the neighbours |
Score = Σ (weight × lens). Keep **ranked alternatives** (A = chosen, B = alternate, C optional), each with its score and one-line reason. The alternate is stored as `alt` (`options-playbook.md` §5), so a review note "đổi cảnh" is one `replace_shot.py` call.
Never choose a shot only because it is pretty: if its best role is *bridge* or *texture*, it can still be a short bridge shot, but it does not take a *peak* or *hook* beat.

## 2. Comparing two shots for the same beat
When A and B both pass the filters and are within 10 points:
1. Which one holds the **stronger emotion** for this beat? (decides, Murch #1)
2. Which one advances the **story** more — a new fact or change? (#2)
3. Which fits the **rhythm** (length it needs, where its peak falls against the music hit)? (#3)
4. Which has the better **eye trace** at the join with the neighbours (§3)? (#4)
5. Which keeps the **2D composition** (position of the subject in the frame) across the cut? (#5)
6. Which keeps **spatial** continuity? (#6, first to sacrifice)
Record the deciding step: "chosen B over A at step 3: B's peak lands on the drop; A peaks 6 frames late".
A tie that survives all six: pick the shot from the **less-used clip** (more variety), then the shorter one.

## 3. Continuity between two shots
Check each join A→B; mark OK / note / intentional break:
- **Gaze** — if a person looks off-screen in A, B should show what they look at, from the matching side (they look screen-right → the object is entered from screen-left of B's frame, or the cut shows the object where the eye would land).
- **Movement direction** — a subject moving L→R should keep L→R across the cut unless the break is the point (a reversal marks a turn; say so with `direction`).
- **Axis (180° rule)** — keep both camera positions on the same side of the line of action between the subjects, or the relative positions flip. For travel/landscape footage the "axis" is the direction of travel.
- **30° / size rule** — two shots of the same subject must change by ≥ 30° of angle **or** ≥ 2 steps of shot size (EWS WS MWS MS MCU CU ECU); otherwise it is a jump cut. Different subjects in the same clip are fine.
- **Eye trace** — where the viewer's eye ends in A (the `subject_out` point, in thirds) should be near, or move predictably toward, where B's first interest is (`subject_in`). `edit_analysis.py` flags jumps > 0.45 of the frame; use the 9:16 safe area (`vertical-frame-checklist.md`).
- **Light and colour** — day/night, warm/cool, exposure steps between neighbours; technical colour (Phase 8) evens small differences, never fixes a day→night cut.
- **Sound** — the join has a reason in the sound too (a hit, a swell, a held ambience, a J/L lead).

## 4. Join vocabulary and when each fits
| Join | Use when | Needs |
|---|---|---|
| **Match on action** | an action starts in A and finishes in B (reach → grasp, turn → look) | cut on the movement's highest velocity; same direction after the cut |
| **Match cut (graphic)** | shape, colour, position or motion of A reappears in B (round lamp → round cup) | similar placement in the frame; declared in `cut.type: graphic_match` |
| **Eyeline match** | a person looks at something | B shows that something |
| **Shot–reverse-shot** | two people or a person and what answers them | same axis, matching eyelines, similar scale |
| **Contrast cut** | light→dark, still→motion, wide→detail, busy→empty | the contrast is the meaning; land on a music hit |
| **Cutaway / insert** | add information or give relief while the main action continues | returns to the main action at a different moment, not a repeat |
| **Meaning-based join (Kuleshov)** | A + B together create a third idea (face → food = hunger) | B must be plausible for A's gaze/context; do not stack unrelated pairs |
| **Bridge** | change of place, time or device | natural wipe, defocus, black-to-black, sound bridge, J/L cut |
| **Jump / smash** | intentional energy or shock | declared in `cut.type`; once or twice per video |
For each cut write `cut: {reason, on, type, why}` (vocabulary in `montage-advanced.md`/`edit_analysis.py`).

## 5. Cinematic joins — speed ramp, zoom in, zoom out
The video's effect language is cinematic (`motion-effects.md` §0). Choose the effect from the **job of the join**, not from a template:
| Job | Effect | Recipe (see `motion-effects.md` for parameters) |
|---|---|---|
| Land a peak | **speed ramp** into the peak | fast steps on low-information frames, slow step on the peak frame on a music hit; step through intermediate speeds (never 1× → 4×; e.g. 100 → 150 → 300 → 150 → 60 %) |
| Draw the eye, build tension | **zoom in / push** 1.00 → 1.06–1.12 over the whole shot, `center` on the subject | ease in-out; a slow push is "light", a punch-in on a hit is "strong" |
| Reveal context, release | **zoom out / pull** | after a detail: start tight, end on the wider frame; or the last shot of the video |
| Connect two shots | **zoom-through cut** | zoom in at the end of A, cut at the highest velocity, zoom out at the start of B (a touch of blur); same direction both sides |
| Soften a time/place jump | blur in/out, defocus bridge | pair with swell/whoosh |
Rules: the effect starts **before** the cut when it is a bridge, and **inside** the shot when it is emphasis; one strong effect per shot and per frame; alternate strong and light so the density does not tire (`motion-effects.md` §2). Only transitions (bridges across a cut) get a sound, placed on the cut (`sfx-library.md` §3); emphasis inside a shot rides the music.

## 6. Repeat checks (four levels)
Run them on the blueprint before the build, and again after every timing change. `edit_analysis.py` (v3.2.0 `repeat_report`) checks levels 1–3 automatically from `shot`, `grp`, `info` and the source ranges.
| Level | What repeats | Test | Rule |
|---|---|---|---|
| **1. Source frames** | the same frames of a clip | source ranges overlap by > 2 frames (stepped-ramp boundary frames are not repeats) | never, except a declared `callback` |
| **2. Same picture** | another range, crop, panel or speed variant of the same image | same `grp`, or same `shot` ID, used twice | one shot per `grp`; variants of a shot count as that shot |
| **3. Same information** | a different picture that tells the same fact | same `info` string / ledger line twice | merge, or the second must show a new consequence |
| **4. Same pattern** | the same size, same camera move or same direction three times in a row | `size`/`move`/`direction` runs of ≥ 3 | change at least one of the three before the third |
Adjacent shots from the same clip must differ by the 30° / 2-size rule (§3); non-adjacent reuse of a clip needs a different `grp`.
Visual proof (hard gate 8): the rough-cut sheet (Phase 6) shows the middle frame of each segment with its shot ID and group; any two thumbnails that look alike are a finding even when the IDs differ (the catalogue's `grp` may be wrong — fix the catalogue).

## 7. Recording the choice (blueprint fields)
Segment fields added in v3.2.0 (plain data for the builder; read by `edit_analysis.py`):
```json
{"id": "s05", "clip": "03 HongKong RAW.mov", "src_in": 120, "src_out": 214, "dur": 48,
 "shot": "C03.S02", "grp": "G05", "info": "ferry crossing the bay at dusk", "size": "WS", "move": "static", "direction": "L→R",
 "score": 84, "why": "peak of the video: strongest light+movement; 50 fps allows a native slow step on the drop",
 "rejected": [{"shot": "C05.S01", "score": 71, "why": "same ferry from the shore, soft after frame 40"},
              {"shot": "C03.S04", "score": 66, "why": "same group G05 as the chosen shot — would repeat the picture"}],
 "link": "contrast", "callback": false}
```
v3.4.0 fields: `fx_plan` on every segment (`["push"]`, `["pull"]`, `["punch"]`, `["snap"]`, `["zoomthrough_out"]`, `["zoomthrough_in"]`, `["ramp_through"]`, `["ramp_hold"]`; `motion-effects.md` §0), and B-roll cutaways as V2 segments:
```json
{"id": "b02", "clip": "...", "src_in": 4660, "src_out": 4690, "track": 2, "record": 270, "media": "video",
 "broll_type": "detail", "grp": "G-grinder", "why": "beans in the hopper while the tamp continues on V1", "fx_plan": ["push"],
 "props": {"Pan": 120}}
```
`why` and `rejected` are one line each; they are the answer to "why this shot and not another" at review. The builder ignores them; `edit_analysis.py` reports missing `shot`/`why` when the blueprint uses them anywhere.

## 8. Done criteria for Phase 5
- Every beat has a chosen shot range (from SEEN frames), its function, a score, a `why`, and ≥ 1 ranked alternative with `rejected` reasons.
- No `shot` or `grp` is used twice (or each repeat is a declared callback); the information ledger has one line per fact.
- All joins checked for gaze, direction, axis, 30°/size and eye trace; breaks are intentional and named.
- Each peak/hook/ending beat has the effect it needs (ramp / push / pull) and the shot's `fx` suitability allows it.
- Footage left unused is listed with a reason.
