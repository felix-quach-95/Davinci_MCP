# Delivery — render, file check, loudness, cover, post text (v2.2.0)

**Claude does not render by default (user rule 2026-10-26):** the job ends with the cleaned Final (after the Final approval) and the user renders it. Use this file only when the user explicitly asks Claude for a file in that message. The deliverable is the latest `Final_<Title>_NN`; never render a Draft as the final file unless the user asks for a preview.

## Contents
1. Formats and presets
2. Render with `render_deliver.py`
3. File check: size, fps, duration, audio, loudness
4. Fixing loudness
5. Cover image
6. Post text: caption and hashtags
7. Other aspect ratios (same story, another platform)
8. Report

## 1. Formats and presets (`config/defaults.json` → `delivery`)
| Preset | Size | Codec | Use |
|---|---|---|---|
| `tiktok`, `reels`, `shorts` | 1080×1920 | H.264 + AAC 48 kHz, quality Best | default upload file |
| `feed45` | 1080×1350 | H.264 | Instagram/Facebook feed |
| `square` | 1080×1080 | H.264 | feed, ads |
| `youtube` / `youtube4k` | 1920×1080 / 3840×2160 | H.264 / H.265 | landscape cut |
| `master` | 2160×3840 | ProRes 422 HQ + LPCM (.mov) | archive / re-encode later |
Frame rate = the timeline's (never changed at render). A preset whose aspect differs from the timeline is refused: build a timeline for that format first (section 7).

## 2. Render (`render_deliver.py`, UNTESTED live)
1. MODE "plan" — timeline, output path (never overwrites: `_2`, `_3`…), codec name matched against `GetRenderCodecs`, aspect check. Writes nothing.
2. MODE "start" — `SetCurrentRenderFormatAndCodec`, `SetRenderSettings` (explicit TargetDir/CustomName/size/fps/audio), `AddRenderJob`, `StartRendering([job])`; returns the job id at once (rendering continues; the 60 s call limit is not a problem).
3. MODE "status" — poll every call or two until `Complete` (or `Failed` with `Error`).
4. MODE "verify" — section 3.
Traps handled (v2.3): `StartRendering([job], False)` from an external script, status polled with `GetRenderJobStatus`, Deliver format/codec restored right after queuing, a warning for target folders with spaces, colour tags "Same as Project" (a mis-tagged Rec.709 file looks faded on Apple devices). Quality "Best" is fine for short pieces; for long videos a bit-rate cap (e.g. 50 Mb/s H.264) avoids huge files.
The job stays in the user's render queue (visible on the Deliver page); the user's other jobs and presets are not touched. Output folder: `paths.exports` (`/Users/felix/Desktop/Final`, v2.9).

## 3. File check (MODE "verify", needs ffprobe/ffmpeg in `~/.local/bin`)
- ffprobe: width/height = preset, fps = timeline, duration = timeline length ± 1.5 frames, audio codec/sample rate.
- ffmpeg `ebur128=peak=true`: integrated loudness (LUFS), loudness range (LU), true peak (dBTP).
- Targets (`loudness` in config): integrated −14 LUFS ± 1 LU, true peak ≤ −1 dBTP for TikTok/Reels/Shorts/YouTube (platforms normalise louder files down; quieter files sound weak next to others).
- Verdict: `FILE CHECK PASS` / `FAIL: <checks>` / `PARTIAL (unmeasured …)`. A file check is not playback: say "file checked, playback/mix not auditioned" unless the user watched it.

## 4. Fixing loudness (before hand-over: in a new Draft → new Final_NN; after hand-over the Final is the user's)
- Too quiet (e.g. −16.4 LUFS, `fix_db` +2.4): raise the music and SFX item volumes by `fix_db` (keep their relative levels), or `Timeline.NormalizeAudioLevel(items, {"normalizationMode": <from GetNormalizeAudioModes()>, "targetLoudness": -14.0})` on the music item when it carries the mix. Re-render and verify.
- True peak above −1 dBTP: lower the loudest SFX (sub drops, hits) 2–3 dB first; re-check.
- Never push the music past −6 dB item volume to win loudness; tell the user if the track itself is quiet.

## 5. Cover image (MODE "cover")
Pick the hero frame (title fully on, subject sharp, calm zone for the platform's own cover text) → MODE "cover" exports it as JPEG at the preset size next to the video → **Read it and look** → offer it. TikTok/Reels let the user choose a cover frame or upload this image; the cover text, if any, is the video's title in the house style (no new claims).

## 6. Post text (Claude writes, VN + EN, only on request or as an offer)
- Caption: 1 hook line (≤ 80 characters, same promise as the video's hook) + 1 context line + optional question to invite comments. Vietnamese first, English second line.
- Hashtags: 3–6, from the content (place, mood, format): e.g. `#hongkong #hongkongnight #cinematictravel #travelvietnam`. No unrelated trending tags, no claims the video does not show.
- Credits when needed: music title/artist and licence for downloaded tracks; template packs if the user plans commercial use (`effects-library.md` §7).

## 7. Other aspect ratios
A different platform shape is a new Draft built from the same blueprint with `"resolution"` set (`build_from_blueprint.py`, v2.2):
| Target | Resolution | Fill of a 16:9 source shows | Notes |
|---|---|---|---|
| 9:16 | 2160×3840 or 1080×1920 | 31.6 % of the width | measured Pan calibration (0.00035/unit) |
| 4:5 | 1080×1350 | 45 % | Pan scale not measured: re-calibrate with two stills |
| 1:1 | 1080×1080 | 56 % | same |
| 16:9 | 1920×1080 | 100 % (vertical footage: 31.6 % of the height, reframe with `Tilt`) | text recipes need new widths/positions |
`fill_geometry()` in `build_from_blueprint.py` gives the axis and visible fraction for any pair. Text positions, safe zones (`config` → `safe_zones.<platform>`) and Pan values change; titles and stills are checked again for every format.

## 8. Report
Final timeline name, preset, output path, file checks (with the numbers), loudness and fix (if any), cover path, what is unverified (playback, mix), one next step.
