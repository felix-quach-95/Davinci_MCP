# Review scorecard — before the Draft review (v2.3)

Structural QA (`qa_audit.py`) and stills prove the draft is built right; this scorecard asks whether it is **good**. Fill it after QA, from the stills and contact sheets Claude actually looked at, and show it with the review question. Adapted from ChaiWithJai/davinci-resolve-claude-skills (four-lane eval, acceptance gate) — ideas only.

## Five lanes (PASS / PARTIAL / FAIL / UNVERIFIED, one line of evidence each)
v3.2.0: the **Editorial** lane below is judged independently of the technical checks (`editorial-decision-and-qc.md`): a build can be technically PASS and editorially FAIL. Show both verdicts.
| Lane | Questions | Evidence |
|---|---|---|
| **Editing craft** | `edit_analysis.py` notes resolved or consciously accepted (reason coverage, pace vs arc, beat/drop, size/direction/eye-trace)? Every cut motivated (beat, new idea, angle/scale change, B-roll, chapter)? No clipped word or half phrase? No mid-thought break? Cuts on the music hits (read-back)? Audio joins crossfaded or bridged by room tone? | `qa_audit`, read-back, stills at cuts ±1 |
| **Creative direction** | Spine visible (a change from start to end)? Pace follows the tension arc, the strongest image on the drop, a release after the peak, B-roll with at least one subtext layer per chapter, J/L cuts where scenes turn (`story-structure.md`)? Hook in the first 1.5 s? One idea per chapter, a peak, a planned ending? The named style target (the Story approval) visible — or does it look "programmatic"? | storyboard vs stills, `storytelling-montage.md` checklist |
| **Visual** | `composition_check.py` on the hero frames: eye line on the upper third, look/lead room, nothing important under the UI? Subject framed in every shot (Fill/Pan, reframe paths)? Technical colour consistent between neighbouring shots and cameras, skin tones natural, highlight/shadow detail kept? Effects visible but not loud? Reserved graphic tracks empty and a safe zone noted for HyperFrames? | stills, on/off pairs |
| **Editorial** (v3.2.0) | Story reads as the contract? Every beat changes something? Repeats at the four levels (source frames · same picture/group · same information · same pattern)? Early/late cuts, spare shots, even-length runs, effect overload? Hook / payoff / peak / release / ending each PASS? Cinematic effects (ramp / push / pull) placed by the beat's job, 1–3 hero ramps, never two strong on one shot? Retention as a question: something new every 2–3 s? | rough-cut sheet, `edit_analysis` repeat report, thumbnails at cuts −3/0/+1, `editorial-decision-and-qc.md` §4–6 |
| **Audio** | Continuous from first to last frame; music present (`audio_presence.py`), ducked under speech, ending in a quiet step; SFX only on transition cuts (none for content); dialogue clean (`voice_audit.py`)? File −14 LUFS / ≤ −1 dBTP if rendered? | `qa_audit`, `ending_plan`, presence check over the whole Draft (`mix_peak_dbfs`, `integrated_lufs`, `clipping`) — **not auditioned unless the user listened** |

## Blockers (any one = not ready for Final)
- Repeated footage: the same source frames, the same image group, or the same information shown twice without a declared callback (v3.2.0).
- No identifiable peak, or a hook/ending that does not match the story contract (v3.2.0).
- A same-scale jump cut inside speech with nothing covering it (B-roll, punch-in) — `transcript_cut.py` lists them as `uncovered_jump_cuts`.
- A clipped word, a sentence fragment, or a cut that changes the meaning (check the struck-through review text).
- A misspelled name or place in the corrected transcript, or a hand-over element positioned over a face or the platform UI.
- A shot showing a black edge or the wrong subject (Pan/reframe), a black/flash frame at a cut.
- Music missing, cut mid-phrase at the end, or masking speech.
- Unexplained runtime difference from the plan.

## Retention checks for talking pieces
- No more than 6–9 s of uninterrupted talking head without a visual reset (punch-in change, B-roll, or a planned graphic slot for HyperFrames).
- Same-camera consecutive cuts must change scale or position (`SWITCHING` paced/dynamic) or be covered.
- B-roll proves what is being said (what/where/how it feels), 1.2–3 s, placed after the phrase lands — never mid-phrase.

## Report format
`Craft PASS — cuts on hits (read-back), 2-frame audio xfades 14/14` · `Creative PARTIAL — hook ok, chapter 3 has no peak` · `Visual PASS — 31 stills` · `Editorial PARTIAL — 3 equal-length shots s04–s06, hero ramp at the drop PASS` · `Audio UNVERIFIED — presence ok (corr 0.93), not auditioned`. Then the blockers (none / list) and the one change that would help most.
