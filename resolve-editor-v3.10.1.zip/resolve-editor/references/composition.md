# Cinematic composition and framing for vertical video (v2.4)

How each frame should read, and how framing carries the eye across cuts. Read at footage analysis (stage 2: subject positions), the paper edit (choosing ranges and Pan) and visual QC. Measured with `composition_check.py`. Principles summarised from cinematography practice (Mascelli's *Five C's of Cinematography*, Bruce Block's *The Visual Story*, Murch's eye-trace), StudioBinder / No Film School framing guides — applied to 9:16.

## Contents
1. The 9:16 frame: grids and power points
2. Shot sizes and what each one says
3. Headroom, eye line, look room, lead room
4. Leading lines, frame within a frame, depth
5. Balance, visual weight and negative space (and text)
6. Contrast and affinity (Block's visual components)
7. Visual anchor across W–M–CU: eye-trace between shots
8. Axis, screen direction and the 30° rule
9. Angles and lens impression
10. Using `composition_check.py`

## 1. The 9:16 frame
- **Thirds**: lines at x = 1/3, 2/3 and y = 1/3, 2/3 (y from the top); the four crossings are power points. In vertical video the horizontal thirds matter most: the **upper third line (y ≈ 0.33)** is where eyes go; the lower third is busy with captions/UI.
- **Golden ratio (phi grid)**: lines at 0.382 / 0.618 — a calmer, more centred alternative to thirds. Golden spiral: the eye ends where the spiral closes (put the subject's face/key object there).
- **Centre** is valid and strong in vertical (symmetry, confrontation, monuments, a person walking toward camera); off-centre gives movement and story space. Choose on purpose: centred for presence, off-centre for direction.
- **Platform UI**: TikTok right column (x > 0.87), bottom captions (y > 0.80), top (y < 0.08): keep faces and key action out (`config` `safe_zones`).
- In a 9:16 fill of a 16:9 source only 31.6 % of the width is visible: the Edit-page Pan decides which third of the source becomes the frame (`broll.md`, `composition_check.py` converts).

## 2. Shot sizes
| Size | Frame contains | Says | Short-form use |
|---|---|---|---|
| EWS | place, figure tiny | scale, isolation, "where" | opening/ending bookends, chapter turns |
| WS | full figure + space | action in context | establishing a chapter |
| MWS / cowboy | knees up | body language | walking, gestures |
| MS | waist up | conversation, neutral | talking pieces, default |
| MCU | chest up | attention, intimacy | speech emphasis (107.5–115 % punch-in) |
| CU | face | emotion | reactions, peaks |
| ECU / INSERT | eyes, hands, object | detail, subtext, tension | B-roll subtext, transitions |
- **Progression**: within a chapter move W → M → C (or C → W for reveals). Cutting between neighbouring sizes of the same subject needs at least one step (MS → CU); same size + same subject + small angle change = jump cut.
- Big jumps (EWS → CU) are strong: use them on beats/peaks on purpose (`cut.reason` includes emotion/reveal).

## 3. Headroom, eye line, look room, lead room
- **Eye line**: eyes on or near the upper third line (y 0.28–0.38 in 9:16). In a CU the forehead may be cropped (eyes still on the line) — better than eyes at the centre.
- **Headroom**: space above the head ≈ 4–10 % of frame height for MS/MCU; less for CU (0–3 %), more for WS; too much headroom makes the subject sink, none (in MS) makes it cramped.
- **Look room / nose room**: when a subject looks left, leave more space on the left: face centre around x 0.60–0.67 when looking left, 0.33–0.40 when looking right. Exception on purpose: short-siding (subject looks toward the near edge) for unease or confinement.
- **Lead room**: moving subjects get space in front of them (2/3 ahead, 1/3 behind); in a follow move (`reframe_path`) keep the lead room constant.
- `composition_check.py` measures these from the subject box and gaze and proposes a Pan.

## 4. Leading lines, frame within a frame, depth
- **Leading lines** (roads, rails, building edges, light streaks, a gaze) should point to the subject; vertical frames favour verticals and diagonals (towers, stairs, escalators, streets receding to the top third). Lines that lead out of frame pull the eye away — avoid at the end of a shot.
- **Frame within a frame**: doorways, windows, arches, mirrors, foreground silhouettes isolate the subject and add depth; strong in vertical because it narrows the frame further. Hold such shots slightly longer (the eye needs to travel in).
- **Depth layers**: foreground (blurred element, passing person = natural wipe), midground (subject), background (context, light). Shots with three layers read as cinematic; flat frames need a move (push, drift) to come alive.
- **Focus and light lead**: the eye goes to the sharpest, brightest, most saturated, highest-contrast area and to faces/text first. Spotlight/vignette (`motion_fx` spotlight, ResolveFX vignette) only reinforce what the frame already does.

## 5. Balance, weight, negative space, text
- Visual weight: large, bright, saturated, high-contrast, isolated, moving and human elements weigh more. Balance a heavy subject with space or a lighter element on the other side; deliberate imbalance creates tension.
- Negative space is where HyperFrames' graphics will go: calm sky, wall, smoke. Note a quiet zone (e.g. upper third) when choosing the range/Pan for a planned graphic slot, and record it in the Phase 10 hand-over.
- Never place text over the eyes/face or on the line the subject looks along (it blocks the look room).

## 6. Contrast and affinity (Block)
For each visual component — space (deep/flat), line (horizontal/vertical/diagonal), shape (round/angular), tone (bright/dark), colour (warm/cool, saturated/muted), movement (static/fast, direction), rhythm (cut rate) — decide per chapter: **affinity** (similar = calm, unity) or **contrast** (different = intensity, attention). The more contrast between consecutive shots, the more intense the sequence. Build intensity toward the climax by increasing contrast in one or two components (e.g. tone and movement) while keeping others in affinity; resolve by returning to affinity. Record the plan per section (`tone`, `direction`, `size` fields).

## 7. Visual anchor across shots (eye-trace)
- At every cut the viewer's eye is somewhere (`subject_out` of the outgoing shot); the incoming shot should place its subject near that point (`subject_in`) unless the cut wants a jolt. Distance < 0.25 of the frame = smooth; 0.25–0.45 = noticeable; > 0.45 = a deliberate jump (smash, contrast, reveal).
- W → M → C: keep the anchor (face, object) in the same region while scale grows; reverse for reveals (detail at the anchor point → wide).
- Movement across the cut: the anchor continues its path (a ball exiting top-right enters bottom-left of the next shot only if that is the intended direction).
- `edit_analysis.py` flags eye-trace jumps > 0.45 not marked as intended.

## 8. Axis, screen direction, 30° rule
- **180° rule**: keep the camera on one side of the line of action/eyeline within a scene; crossing it flips screen direction (use a neutral head-on shot or a visible camera move to cross).
- **Screen direction**: a journey keeps one direction (left → right = forward/outward by convention in left-to-right cultures; reversing = returning). Within a chapter keep `direction` consistent; change it at chapter turns or for contrast.
- **30° rule**: two consecutive shots of the same subject differ by ≥ 30° in angle or ≥ one shot size; otherwise it is a jump cut (fine only on purpose).

## 9. Angles and lens impression
- Eye level: neutral; low angle: power, monumentality (towers, a hero walking); high angle: vulnerability, overview (city from above, a lone figure). Dutch tilt: unease (rarely in mood pieces).
- Wide lens close to subject: energy, distortion, presence; long lens: compression (stacked city layers, crowds), calm, observation. Choose footage ranges by impression, not only content.
- Drone top-down: graphic patterns — strong for intellectual/graphic match cuts.

## 10. `composition_check.py`
Input per shot (from a still Claude looked at): subject box in SOURCE coordinates (x0, y0, x1, y1, y from the top), eyes y, gaze or motion direction, the item's Pan. It converts into the 9:16 frame and reports: nearest power point and distance, eye line vs upper third, headroom, look/lead room ratio, overlap with the platform UI, and a suggested Pan to put the subject on the chosen third with correct look room (clamped to |Pan| ≤ 900). The numbers support the judgement; the still decides. Record `subject_in/out` (frame coords) in the blueprint for `edit_analysis.py`.
