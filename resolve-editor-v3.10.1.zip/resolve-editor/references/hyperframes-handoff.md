# Phase 11 start — graphic questions and hand-over to HyperFrames (v3.0.0; package v3.6.0; moved to Phase 11 in v3.10.0)

User rule 2026-10-27: Claude edits; **HyperFrames makes every title, subtitle, caption, text overlay, motion graphic and decorative element**, and the user places them in the timeline afterwards. Claude's job is to ask the right short questions, offer concrete options, and write a brief HyperFrames can build from without guessing.

## Contents
1. When this phase starts
2. The questions (order, wording, options)
3. Proposals Claude may make (and may not)
4. Spec → files (`hyperframes_handoff.py`)
5. Statuses and the approval rule
6. What the brief must contain
7. Subtitle data from the transcript
8. After hand-over
9. The Phase 11 package, same chat (v3.6.0, v3.10.0)

## 1. When this phase starts
v3.10.0 (user rule 2026-10-28): only after Phase 10 is finished (Final verified, project cleaned) and the user chose "Chuyển sang HyperFrames ngay", **and after the style was picked in Motion Studio's gallery with pictures** (`phase-11.md` §1 B). Before that, do not ask about, mention or prototype graphics (a hook idea may be written in the story as "text opening", with no wording or design). Phase 10 asks no graphic question at all.

## 2. The questions (Phase 11 §1 C; short form in `options-playbook.md` §8b)
Short, specific to this cut, each with 2–3 concrete options tied to a frame/beat/marker of the Final and an "Other" path. One AskUserQuestion per round, ≤ 4 questions, recommendation first. Cover, in order:
1. **Tiêu đề chính + văn bản mở đầu** — whether there is one; wording (vi/en); where in the opening it lands (frame/beat); options e.g. "on the first strong shot at the drop of the intro", "after a 2 s picture-only cold open", "none".
2. **Tiêu đề phần + chữ trên màn hình** — which chapters get a label; which facts/places/names need on-screen text.
3. **Phụ đề + chú thích** — only when there is speech or a need to explain: monolingual or vi+en; the corrected transcript from `transcript_cut.py` is attached for approval of the words.
4. **Đồ họa chuyển động + hoạt ảnh** — whether any, what role (emphasis, map, data, transition ornament), and the feel (calm, snappy, kinetic).
5. **Yếu tố hình ảnh hỗ trợ** — frames, shapes, stickers, grain/light overlays, logos: only if the user wants them.
6. **Phong cách đồ họa** — already picked in the gallery (§1 B, SPEC `style.look`, status approved); ask again only if the user wants another look.
7. **Thời điểm, vị trí, thứ bậc thị giác, cách hoạt ảnh vận hành** — per element: start/end, anchor (upper third, lower third, centre, near subject), hierarchy 1–3, how it enters/leaves, what it must not cover (faces, key action, platform UI).
Skip a question when the user's earlier message already answered it.

## 3. Proposals Claude may make (and may not)
May: suggest *where* graphics would help the story (a place name at the establishing shot; an emphasis moment at the drop), propose timing aligned to cuts/beats/markers, list the safe zone, offer 2–3 directions as words/references, supply the corrected transcript.
May not: choose fonts, colours, layouts or animation styles as final; build or place anything in the timeline; render previews of graphics; write copy as if approved (copy drafted by Claude is `proposed` with `source: claude_proposal`).

## 4. Spec → files
Build the SPEC (see the header of `scripts/hyperframes_handoff.py`) from the Final timeline (fps, size, duration, cuts, markers), the music beats, the cue sheet (`audio_events`), the platform safe zone from `config safe_zones`, and the user's answers. Run locally:
```bash
python3 scripts/hyperframes_handoff.py spec.json "<Cache Edit>/<Title>"
```
or call it in `run_script` with `SPEC = {...}` and write the returned `markdown`/dict with the file tools. Outputs: `handoff_<Title>.md` (the user reads and approves) and `handoff_<Title>.json` (frame-accurate, for HyperFrames). Read the `issues` list aloud to the user; BLOCKERs must be fixed, WARNs explained or resolved.

## 5. Statuses and the approval rule
Element `status`: `approved` (the user said so, `source: user`), `proposed` (Claude's suggestion awaiting an answer), `open` (undecided). Overall: `INCOMPLETE` (a BLOCKER exists) · `AWAITING_USER_APPROVAL` (anything not approved, or the style direction not approved) · `APPROVED`. A Claude proposal can never be marked approved by Claude. Say the status exactly in the report.

## 6. What the brief must contain
Per element: id, category (title_main, opening_text, section_title, onscreen_text, subtitle, caption, motion_graphic, supporting_visual), text vi/en, start/end (frames and timecode), position (anchor + x,y as fractions, y from the top), hierarchy, animation intent (in, out, feel), anchor to a cut/beat/word/marker, notes. Project level: Final name, fps, size, duration, format, safe zone, graphic direction + references, cuts/beats/markers, existing SFX events (so graphic sounds are not doubled), reference video path (the user renders it; Claude never does), open questions.

## 7. Subtitle data from the transcript
`transcript_cut.py` (`kept_for_srt`) + `srt_from_transcript.py` give cues on the new timeline's clock. Correct recognition, spelling, punctuation, remove fillers, keep meaning, add the English line, then put the cues in `subtitle_cues` (frames). The script flags Vietnamese lines over 32 characters, cues under 0.8 s and overlaps. Subtitle *styling* is HyperFrames' job; the SRT is data, not something Claude imports into Resolve.

## 8. After hand-over
**Subtitle readability (live, TestSkill 2026-10-27):** a small second line (English under Vietnamese) vanished on bright food, lanterns and a candle with a 0.32 scrim and 26 px; a text-sized scrim ~0.5 and the second line ≥ 28 px at weight 400 read on every still. Put these numbers in the brief as constraints for HyperFrames; check on real-footage stills after placing.

**Placing HyperFrames output or a voice-over on request (live, TNCRoast v02):** never on the Final — duplicate it to `Draft_<Title>_vNN`, import the renders into bin "Đồ họa (HyperFrames)" and place them on V3–V5 from frame 0 (ProRes 4444, alpha "Straight", same frame count as the Final), voice on a new audio track "VOICE", then `qa_audit.py` with `GRAPHICS_PLACED = True`. Check every overlay on **real-footage stills** (`qc_stills.py` PAGE "edit"), not only on HyperFrames snapshots over a flat background: on TNCRoast a subtitle sat on the real TNC COFFEE plate and English lines vanished on bright steel — fixed with a text-sized dark scrim (~0.55) and a lower position for that sentence. Mix: render-check peak and LUFS (`audio_presence.py`); a voice file peaking at −0.4 dBFS plus a hit SFX clipped the mix until both were lowered. Vietnamese voice without an account: macOS `say -v Linh` (HyperFrames' Kokoro has no Vietnamese; HeyGen needs the user's sign-in); word timings from the known script + silence detection are estimates — say so. Then the Draft review and the Final approval again.

The Final stays untouched. When HyperFrames' output exists the user places it in the reserved tracks ("Đồ họa A/B/C"). A change of wording or timing = edit the SPEC and re-run; a change of cut = new `Draft_<Title>_vNN`, then the Final approval again, then re-check every graphic anchor with the script.

## 9. The Phase 11 package, same chat (v3.6.0, v3.10.0)
User rules 2026-10-28: once the Final is done and the brief approved, the graphics are made **entirely by the user's `motion-studio` skill** (the newest HyperFrames release, pinned per install), **in the same chat** — no new window, new session or `/clear` is ever proposed; the HyperFrames build runs in a fresh-context agent inside this chat (`phase-11.md` §1 E); every object is its own named, coloured layer the user can refine in DaVinci.

**Why the build runs in a fresh-context agent (token cost).** Every model call re-reads the whole conversation. After Phases 1–10 the editing chat carries the skill text, phase cards, footage sheets and stills, tool results, questions and answers — typically well over 100k tokens. HyperFrames' phase is itself call-heavy (its skills, the brief, the build of HTML scenes, checks, Studio, revisions, render: often 40–150 calls). Run there, every one of those calls pays for the editing history it does not need; in a fresh-context agent each call carries only the package (~10–30k tokens with the skills), while the user stays in the same chat. Estimate, not a measurement: roughly 5–10× less usage for Phase 11, fewer automatic compactions (which can drop frame numbers), and less confusion between Resolve's frames and HyperFrames' seconds. (Motion Studio's standalone `/clear` advice does not apply inside resolve-editor: the agent gives the same saving without leaving the chat.)

**Package** (`<Cache Edit>/<Title>/hyperframes/`, written by `hyperframes_handoff.py` with SPEC `stills` + `package_dir`):
| File | For | Written when |
|---|---|---|
| `handoff_<Title>.md` / `.json` | the user's approval; frame-accurate data | always |
| `stills/<id>.png` | what lies behind each element on the Final (`qc_stills.py`, PAGE "edit") | before the second run |
| `HF_REQUEST_<Title>.md` | the request in Motion Studio's hand-off shape (`references/handoff.md`), overlay mode: transparent canvas, no sound, safe zone, readability numbers, every element in seconds that keep the Final's frame count, Vietnamese variable labels, the MOV render line | status APPROVED only |
| `START_PHASE11.md` | the line that resumes the Phase 11 build later, sent in this same chat ("Để sau") | status APPROVED only |
| `layers_<Title>.json` | v3.7.0: one layer per element — name `DHnn_<Loại>_<Chữ>`, colour, named track, span, `solo` rows, the `place_media` list (`plan_layers`) | status APPROVED only |

Frame rates (v3.9.0): HyperFrames' `--fps` takes a rational, so a 29.97/23.976/59.94 Final is rendered at `30000/1001`/`24000/1001`/`60000/1001` with the same frame count; nothing to conform in Resolve.

The package is self-contained: Phase 11 needs nothing from `project.json`, the catalogue or the editing chat. A wording change in Phase 11 stays in HyperFrames (Studio variables); a timing change beyond an element's anchor goes back to Resolve (new Draft → Final approval → re-run this script → new package).
