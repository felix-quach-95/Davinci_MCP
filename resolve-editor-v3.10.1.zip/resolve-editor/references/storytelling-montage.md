# Storytelling and montage for short vertical video

Short entry. The expert depth is in `montage-advanced.md` (cut points, the five methods with recipes, Kuleshov/Pudovkin, rhythm, beat math), `story-structure.md` (three acts at short-form scale, arc vs pace, parallel editing, beat drop, B-roll layers, J/L cuts, ellipsis, retention) and `composition.md` (framing, eye-trace, axis).

How Claude turns a handful of clips into a story. Read at the creative-plan stage (before the blueprint). Sources at the end. Applied and verified on Final_HuongCang_01 (2026-10-24).

## Contents
1. The cut: what decides it (Murch's priorities)
2. Montage methods (Eisenstein) and when to use each
3. Story shapes for 10–60 s
4. Coverage and shot roles (wide → medium → detail)
5. Transitions that carry meaning
6. Music as structure: phrase chapters
7. Checklist before the blueprint

## 1. The cut — what decides it
Walter Murch ranks what a cut must respect: **emotion (51 %)**, then story, rhythm, eye-trace, the 2D plane of the screen, 3D continuity of space. If something must give, give from the bottom of the list. Practical reading:
- Cut when the feeling of the shot has landed, not when the action ends.
- A cut must move the story (new place, new time, new information, new feeling); same-information cuts are padding.
- Rhythm: cut on musical hits/phrases or on motion peaks; vary shot length inside a chapter.
- Eye-trace: put the subject of the next shot where the eye already is (bouquet centred after a centred old man; bright-on-bright, dark-on-dark).
- Screen direction: keep movement direction consistent within a chapter (traffic flow, walking direction) unless the change is the point.

## 2. Montage methods (Eisenstein) — pick one per video, mix sparingly
| Method | What it does | Use when | Build |
|---|---|---|---|
| Metric | cuts by fixed length → tension/acceleration | countdowns, builds, hooks | equal or shrinking shot lengths (e.g. 12-10-8-6 frames) |
| Rhythmic | cuts by the motion/content inside shots | action, traffic, cooking, sport | cut on motion peaks; speed ramps |
| Tonal | arranges by feeling (light, colour, pace) | travel/mood (user's main type) | slow pushes, golden/blue light continuity, soft transitions |
| Overtonal | metric + rhythmic + tonal together | climaxes, the last 5 s | combine phrase cuts + motion + light |
| Intellectual | juxtaposition makes an idea | contrast pieces (old/new, calm/chaos) | A/B pairs, match cuts |
For mood pieces choose **tonal**, cut on **musical phrases** (section 6), use rhythmic cuts only inside a chapter.

## 3. Story shapes (short-form)
- **Time progression** (day → dusk → night → late night) — "Một ngày ở X". Natural order, needs a hook flash-forward. Used for HuongCang.
- **Night piece with a day prologue** — the theme is one time of day but one clip is not (HongKong v02, 2026-10-25): hook (flash-forward) → one phrase of the off-time clip as a "before" (the human moment) → natural wipe on the phrase hit into the themed footage + title → chapters → bookend. Keeps the theme while every good clip earns its place (`broll.md` §4).
- **Hook → context → build → payoff → button** — explainers, reveals.
- **Detail → whole → meaning** — craft, food, places (bouquet → street → city).
- **Character thread** — one person carries the piece; the city is B-roll around them.
- **Contrast** (intellectual) — two worlds alternating.
- **Mood progression** — the change of feeling is the story; minimal text.
Every shape gets: a **hook in 0–1.5 s** (motion, contrast or a question), an **establishing beat** (where/when), **2–4 chapters** with one idea each, a **peak** (strongest image, often slow motion), and a planned **ending** (`endings.md`).

## 4. Coverage and shot roles
Within a chapter aim for wide → medium → detail (or the reverse for reveals). Roles: establishing, subject/anchor, **detail/insert** (hands, object, texture), action/process, reaction/human moment, transition/bridge (natural wipe, defocus, whip), chapter card (text), payoff, ending/CTA. With little footage, manufacture coverage from one clip (B-roll techniques in `broll.md`): a 16:9 4K shot gives three different vertical framings, a detail insert by push-in, a slow-motion variant from high-fps footage.

## 5. Transitions with meaning
- **Hard cut on a hit** — default; invisible, rhythmic.
- **Natural wipe** — someone/something crosses the lens; cut while the frame is covered (HuongCang day chapter opens and closes on passers-by).
- **Focus transition** — blur_out → blur_in (dream, time jump).
- **Match cut** — shape/motion/colour rhymes across the cut (round tower → round wok; traffic flow → stir-fry motion).
- **Whip** — energetic; whoosh on the cut.
- **Dissolve** — time passes; 6–12 frames; rare in short-form.
- **Contrast cut** — light→dark, busy→empty, colour→opposite: the difference itself makes the cut feel deliberate.
- **Movement / scale match** — cut at peak velocity, direction continuous; zoom in → cut → zoom out (`motion-effects.md` §3c).
- **J/L cut** — sound of the next scene arrives early (fire crackle starts 6–10 frames before the kitchen cut) — needs ambience/SFX, which the SFX library provides.

## 6. Music as structure — phrase chapters (verified)
Measure the track's phrase hits (`ending_plan.py` helpers; 20 ms envelope for precision). Give **one chapter per phrase** (Silent Descent: phrases ≈ 3.4 s, accents in between). Choose the music start offset so the hook ends exactly on a phrase hit, then lay each chapter boundary on the next hit. Build with `"dur"` per segment so Resolve's speed rounding cannot drift cuts off the hits (it drifted 13 frames over 10 shots before the fix). Secondary accents inside a phrase are the place for punch-ins or text accents.

## 7. Checklist before the blueprint
- One-sentence story and chosen shape; montage method.
- Hook shot and why it stops the scroll.
- Chapters with their one idea, hero shot and B-roll.
- Where the peak is; where slow motion / speed ramp / zoom serve emphasis (`motion-effects.md`), cinematic pieces 5–10 accents per 15–20 s, ≤ 2 per chapter (v2.8, `motion-effects.md` §2).
- Transitions per boundary (mostly hard cuts on hits; natural wipes where the footage offers them).
- Text slots (title, whisper, emphasis, label, CTA) and SFX cues per event.
- Ending type (decided now with the user, built with the picture).

Sources: Walter Murch, *In the Blink of an Eye* (rule of six; summary at No Film School, https://nofilmschool.com/2016/11/6-rules-good-cutting-according-oscar-winning-editor-walter-murch); Eisenstein's methods of montage (summary at PremiumBeat, https://www.premiumbeat.com/blog/soviet-montage-theory-types); B-roll practice (PremiumBeat, https://www.premiumbeat.com/blog/b-roll-video-edit-guide).
