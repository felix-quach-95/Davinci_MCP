# Endings — finishing a short video professionally

The user's complaint (2026-10-24): videos "stop suddenly". The user wants Claude to **analyse the ending and ask each time** with 2–4 concrete options (chosen: "Có, nhưng hỏi mỗi lần"). Since v2.0 this question is one of the Story approval questions (SKILL.md stage 3), asked once per video together with story, effects and look; ask again only when a later change (new chapter, new music) moves the end. Never leave the end to chance: the last 2–4 seconds decide whether a viewer rewatches or follows.

## 1. Diagnose first (read-only)
1. `scripts/ending_plan.py` on the draft: music phrase hits and quiet points around the end, what the current end lands on, candidate frames SHORT / HIT_CUT / RING_OUT, the last shot's unused source.
2. Export and look at the last ~3 s (every 0.5 s) + the last frame: is there a natural "exit" (subject leaves frame, door closes, light goes out, camera settles), a calm zone for text, a wide shot available elsewhere in the footage?
3. Typical causes: the end lands just after a new musical phrase starts (HK v01: 0.08 s after a hit — sounded cut off even with a fade); hard picture cut at full brightness; music faded mid-phrase; no closing beat in the story.

## 2. Options to offer (in the Story approval AskUserQuestion, recommend one)
| Option | When it fits | Build |
|---|---|---|
| **Cinematic close with text** | mood/travel, a calm last shot | closing line on the HIT_CUT frame, picture fade to black ~0.8–1 s, music rings out to RING_OUT (+2–4 s) |
| **Clean fade, no text** | runtime must stay; story already complete | end at SHORT (quiet before the next phrase), picture fade 12–18 frames, music fade landing in the quiet |
| **TikTok loop** | energetic pieces, rewatch goal | no fade; cut on a beat into a frame that flows into the first frame (match motion/colour/sound) |
| **Wide establishing close (bookend)** | travel/city; a wide shot exists | cut on HIT_CUT to a wide shot (unused part of a wide clip, slowed if needed), closing text/CTA in the sky, fade to black, ambience tail |
| **Freeze / slow tail** | a strong final gesture | slow the last second (optical flow) and fade |
Also ask: closing text (callback to the opening line / farewell / CTA / none) and end sound (music rings out / ambience fades after the music / soft accent on the last hit). Record the user's choice for the project.

## 2b. Hit timing precision (v2.1)
`ending_plan.py` finds phrase hits on a 0.25 s envelope and then places each hit exactly with a 20 ms envelope (`refine_hit`). Before v2.1 the coarse grid reported a hit at 21.25 s whose real onset was 21.48 s, so a natural end was called "cut off". When checking by hand, always use the 20 ms envelope near the end.

## 3. Build rules
- Cut into the closing shot **on the phrase hit** (HIT_CUT); end the music **in the middle of the quiet step** before the following hit (never within 0.1 s of a new hit — `ending_plan.py` warns).
- Picture: `SetFades({"FadeOut": 18–24})` on the last V1 item; text exits 2–4 frames before the picture is black.
- A trailing audio item past the last video item gives a black hold; keep it 0.8–1.5 s with an ambience fade (36 frames) so the end breathes.
- Closing text uses the video's text style (house recipe B whisper for mood pieces; CTA small, bilingual, no emoji). CTA examples: "theo dõi để đi tiếp cùng mình" / *follow for the next journey*. Never invent places or promises.
- Reused footage must be unused source frames (not a repeat of the same frames); grade it like its siblings (copy the Color-page LUT: `GetNodeGraph().GetLUT(1)` → `SetLUT(1, …)`).
- Work in a new draft version (`Draft_<Title>_vNN`, next number) when the user has hand-edited the previous draft.
- Check: stills at the cut, text settled, half-faded, black; `ending_plan.py` re-run must say "in a quiet decay: natural"; audio continuous to the last frame.

## 4. Case: Hong Kong v02 (2026-10-24, verified)
v01 ended at 306 = 0.08 s after a music hit (sounded cut off), hard picture cut. User chose: wide-city bookend + CTA + ambience fading. Built `DRAFT_HK_v02_end` (historic name, formerly allowed; today `Draft_HongKong_v02`): cut on the hit at 306 to the unused head of clip 02 (skyline at dusk, src 0–31 at 25 % optical flow, LUT copied), CTA whisper "theo dõi để đi tiếp cùng mình / follow for the next journey" in the sky 316–366 with halo, picture fade 20 frames, music 8–378 (end in the quiet before the 21.25 s hit, fade 30), "WIND AMBIENT (4).wav" on A3 306–396 at −20 dB (historic level; today ambience −19…−23, `sfx-library.md` §5) (fade 12/36), black hold 366–396; total 16.5 s. Stills checked (f305–f380). The SFX library has no real city-traffic ambience; wind on a viewpoint was the closest. Mix not auditioned.
