# Style profiles — choose a look-and-feel once, reuse it (v3.0.0)

A style profile is one small JSON that bundles what a "kind of video" needs: design read, the three dials (`ideation-playbook.md` §2), tone and pace, effects intensity, audio and ending preferences, and the things to avoid. It saves questions and tokens: at the kickoff questions the user picks a profile (or "none"), Claude copies it into `project.json`, and the rest of the workflow reads the same keys it always did.

Idea adapted from the "playbook" files of the open-source OpenMontage project (AGPL-3.0); contents here are written for this pack and use only recipes, looks and values that already exist in it.

## Where profiles live
| Place | What |
|---|---|
| `config/styles/*.json` | built-in starting points: `night_cinematic`, `airy_vlog`, `travel_energetic`, `calm_documentary` |
| `~/Movies/ClaudeQC/_styles/<name>.json` | the user's own (same format; wins when a name exists in both) |

## Using one (Style choice, `options-playbook.md` §2 — a built-in profile may be one of the five options)
1. Offer the profile that fits the brief and the clip list (inventory) (night footage → `night_cinematic`; a talking day-vlog → `airy_vlog`) plus "no profile". Show its `design_read` in one line.
2. On approval write it with loader MODE `project_set`: `PROJECT_DATA = {"style": <the whole profile>, **profile["project"]}`. `profile["project"]` uses only keys of `config/defaults.json` (`creative` …), so the existing scripts pick them up; the other fields are read by Claude from `project.json` `style`.
3. Anything the user changes afterwards overrides the profile for this project only; the choice itself goes to `_prefs.json` `choices.style`.
4. Profile ≠ command: every field is a default the user can overrule at any stop up to the Draft review. Colour stays technical (`color-look.md`; LOG footage always gets its conversion first); text and graphics are never decided by a profile.

## Saving a new profile from a finished video
Only when the user asks ("lưu phong cách này"): copy the Final's decisions from `project.json` into `~/Movies/ClaudeQC/_styles/<short_name>.json` in the same format; never write into the installed skill folder.

## Fields
`name`, `label` (Vietnamese), `design_read`, `dials` {visual_variance, motion_intensity, information_density}, `tone` (register from `ideation-playbook.md` §3, or `talking`), `asl_s` (target average shot length, `montage-advanced.md` §6), `project` (keys for `project.json`), `look_hint` {name, note} — used **only** if the user asks for a creative grade in words, `graphics_hint` — a hint to react to in Phase 10, never applied by Claude, `audio` {mood, ending}, `ending`, `avoid` (list), `notes`.

## Honesty
The four built-ins are starting points assembled from this pack's own recipes and lessons, not measured "best" settings. Say which profile was used in the final report and mark any field the user changed.

## Style options generated from the footage (Style choice)
The built-in profiles are no longer the only source. At the Style choice (`options-playbook.md` §2) Claude builds **5 options from the scan** (archetype pool in that section) plus the user's own 6th; the chosen one is written to `project.json` `style` in the profile format above. A built-in profile may be one of the five when its `design_read` fits the evidence (e.g. `night_cinematic` for night footage). Saving a chosen option as a reusable profile still happens only on request ("lưu phong cách này").
