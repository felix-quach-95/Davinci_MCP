# Brief and Edit Blueprint Template

## Job brief
- Project:
- Core message:
- Audience/platform:
- Language:
- Desired emotional effect:
- Required facts/moments:
- Avoid:
- CTA/ending:
- Reference role: style / structure / pacing / source / output review
- Target runtime: proposed after footage audit
- Aspect ratio: default 9:16
- Subtitle language:
- Audio/SFX constraints:
- Delivery path and filename:
- Approval status:
- Unknowns:

## Research Card (v2.5, optional — `trend-research.md`, `research_card.py`)
- Sources (vidIQ / Creative Center / TikTok or YouTube search / Google Trends / web, with dates) and free credits spent / left:
- Trending sounds (rank, rising, commercial?) → library match or add in the TikTok app:
- Primary keyword (+ related terms):
- Recommended hook pattern + evidence (e.g. 3/5 strongest outliers):
- Hook text in the user's own words (≤ 7 words, VN + EN):
- Target runtime (median of strong outliers, rounded to a music phrase):
- Hashtags (3–5):
- Warnings (thin data, YouTube-only proxy):

## Evidence status
For every important claim, label:
- OBSERVED — directly inspected or read from a trustworthy source.
- INFERRED — plausible interpretation, not directly established.
- UNKNOWN — not accessible or not verified.

## Footage inventory
| Clip ID | Name/path | Duration/fps/resolution/audio | Visual evidence status | Verified usable moments/timecodes | Potential role | Confidence |
|---|---|---|---|---|---|---|

## Teaser coverage plan
| Section | Purpose | Planned duration | Visual mode | Story beat | Graphic slot (Phase 10 note) | Audio/SFX |
|---|---|---:|---|---|---|---|
| Hook | | | | | | |
| Context | | | | | | |
| Development | | | | | | |
| Payoff | | | | | | |
| Ending | | | | | | |
| TOTAL | | | | | | |

## Shot-level blueprint / EDL
| # | Source clip ID/path | Source in | Source out | Duration frames | Timeline section | Track role | Editorial purpose | Audio needs | Confidence/evidence |
|---|---|---|---|---:|---|---|---|---|---|

Blueprint checks:
- Section durations add up to target.
- Source in/out values are within source bounds.
- Frame rate and frame origin are explicit.
- No source range relies on unverified content.
- No unapproved loop, stock/generated shot, or external API.
- Existing user timeline, grades, audio, and project settings are preserved.
- Any unknowns are explicitly listed.

## Footage evidence map (stage 2) — per clip
| Clip | fps / length | Content & light | Motion | Subject positions (source x,y) over time | Natural wipes / defocus | Slow-mo potential | B-roll candidates (range, technique, role) |
|---|---|---|---|---|---|---|---|

## Kickoff questions — kickoff options (Phase 1, one AskUserQuestion, recommendation first) — `options-playbook.md` §1
1. Editing style profile or emphasis intensity: cinematic 5–10 accents / 15–20 s (recommended) · energetic 10–16 · minimal 2–4 — sounds come with it.
2. Audio sources: local + free suggestions (recommended) · local only · prefer new free sources (`free-audio-sources.md`).
3. Platform/format + length (only if the brief does not say): 9:16 TikTok/Reels/Shorts (default) · 4:5 / 1:1 · 16:9.
No question about titles, subtitles or animation here (Phase 10).

## Story approval — creative plan (Phase 4, one AskUserQuestion, recommendation first)
Ask at most four questions whose answers change the build; put a chapter preview in the story option:
1. Story shape + runtime (see `storytelling-montage.md`).
2. Hook (2 openings as first frame) — intensity was chosen at the kickoff questions.
3. Music: top pick vs runner-up, each with the Phase 2 music map.
4. Ending (wide bookend / clean fade / hit + fade / loop).
State without asking: B-roll layers, effect count, Fill framing. Colour is technical only — no look question.

## Story plan (stage 4, v2.4) — `story-structure.md`
- Spine (one sentence with a change):
- Shape and acts (seconds): Act 1 … / Act 2 (midpoint …) / Act 3 …
- Arc (tension 1–5 per section) → `bp["arc"]`; montage method per chapter; drop frame → `bp["drop_frame"]`
- Leitmotif / bookend image:
- Paper-edit table: # · time · act/section (tension) · shot (size, subject) · cut in on — why · J/L · music (beat/drop) · text · SFX · retention device

## Cue sheet (stage 4) — one row per event, frames on the music grid
| Frame | Chapter | Picture event | Effect (motion_fx / transition) | Graphic slot (note for Phase 10, no design) | SFX role → file | Placement (peak/onset) | Level |
|---:|---|---|---|---|---|---|---|

## Pre-edit approval gate
Story approval replaces open-ended questions later: once the creative plan is approved, build without further questions until the accent sheet (the hero accent choice) and the review (the Draft review); graphics are asked only in Phase 10.
