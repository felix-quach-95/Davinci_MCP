# Music check and analysis — Phases 1–2 (v3.3.0)

Music is analysed **before** the footage decisions so the story, cut grid and B-roll choices are made against known structure. It is a structural and emotional reference, not an order to cut on every beat. **The user always supplies the music** (hard rule 13): Claude never proposes, previews or downloads tracks.

## 0. Music check and Music request (Phase 1)
`music_intake.py` (read-only) looks in the paths the user named, the Media Pool, the footage folders and `project.json`, then returns USER_MUSIC / USER_MUSIC_SEVERAL / CHOSEN_BY_CLAUDE / NONE. Tell the user what was found and where.
- **USER_MUSIC** → name the file and go on to Phase 2 after the Style choice.
- **USER_MUSIC_SEVERAL** → ask which one is the main track (`question`).
- **CHOSEN_BY_CLAUDE** (only a track from an earlier project) → ask: use it, or send another.
- **NONE** → right after the Style choice send one message from `music_request(style, runtime_s)` ("Yêu cầu gửi nhạc nền": the chosen style, what kind of music fits, the maximum length, how to send the file) and **wait**. When the user answers, run the check again with `NAMED_PATHS = [their path]`.

**When the music should arrive** — before Phase 2 (the music sets the cut grid; every later arrival re-does what was cut to it):
| Arrives | What it costs | Verdict |
|---|---|---|
| With the footage or after the Music request (Phase 1) | nothing: Phase 2 maps it before the story is chosen | **required** |
| After the Story approval, before the build (Phases 5–6, paper) | blueprint cut points re-snapped to the new grid, `edit_analysis` again | acceptable |
| After the Draft build | picture build re-run (layer 1) + rough-cut sheet again | costly |
| After accents and SFX (Phase 7+) | layers 1→3 rebuilt: accents and every SFX cue move with the cuts | avoid |
| After the Final | a new Draft version from layer 1, the Draft review and the Final approval again | avoid |

**"Music after the cut"** (only when the user says so, e.g. a documentary-style piece): cut on picture rhythm (`cut.on` movement/gaze/breath, no `beat` claims); when the user's track arrives, move its start (whole bars) so a phrase ends on the last frame. Cuts will not sit on beats; say so. A sound-led edit with no music bed is also the user's call.

## What to report
| Item | Source | Label |
|---|---|---|
| Duration, sample rate | file probe (`music_library.py`, ffprobe) | measured |
| Structure: intro, build, drop/burst, climax, outro | energy envelope at 0.25 s steps from the `music_library.py` catalogue; frame-accurate hits come from `silence_beats.py` MODE beats and `ending_plan.py` (20 ms refine) on the chosen track | measured boundaries; section names are interpretation |
| Tempo / BPM, beat and bar positions | `music_library.py` pick (`bpm_label`, `bpm_octaves`) and `silence_beats.py` MODE beats (`confidence`, `beats_sec`, `downbeats_guess_sec`) — two independent estimates; quote the label, and the half/double alternative when the music could be read either way | `measured` only when `bpm_label` says so (confidence ≥ 0.6) and both tools agree within 2 %; otherwise "estimated" |
| Phrases and rhythm patterns | `hit_spacing_s` = median gap between envelope hits (measured); phrase length in bars is derived from the beat grid (interpretation) | measured / interpretation |
| Energy changes, breaks, silences, contrast chances | envelope + `silence_beats.py` | measured |
| Candidate cut points and visual-sync chances (hits, risers, drops, stops) | derived from the above, converted to timeline frames at the project fps | derived — state the fps |
| Mood / genre / vocals | listening is not possible → from catalogue tags, filename, envelope; say "not auditioned" | estimated |

## Rules
- **Never invent** a BPM, a beat timestamp or a musical event. If measurement fails (ffmpeg/afconvert missing, a clip too short), say `not measured` and give what remains.
- Every number carries its label (`measured` / `estimated`) in the music map, the paper edit and the report.
- Several tracks from the user: map the main track; map a second one only when the user names it as an alternative.
- Music map format (kept in `project.json` `music`): `{file, duration_s, bpm {value, label}, sections [{name, start_s, end_s, label}], hits [{t_s, kind, label}], quiet_points [...], notes}`.
- Cut on a hit when a visual event meets it; ignore beats that have no visual reason (rhythm should come from the story, not the grid).
- No music supplied → send the Music request and wait; never fill the gap with a track Claude chose.
