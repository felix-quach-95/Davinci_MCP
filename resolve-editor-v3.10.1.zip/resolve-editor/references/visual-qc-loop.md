# Visual QC Loop — render and look

Borrowed idea (open-fusion-mcp, resolve-mcp-bridge): the agent checks pixels, not return values. A frame counts as "seen" only after Claude has opened the PNG with the Read tool in this session.

## Where frames go
`/Users/felix/Desktop/Final/Cache Edit/<job>/` (paths.work, v2.9; create with `run_script_unsafe`). Never write next to source media. Delete nothing the user did not create through this skill.

## Getting the image in front of Claude (verified 2026-10-24)
Exported stills are 16-bit PNGs of ~25 MB at 2160×3840 — too heavy to view. `scripts/qc_stills.py` also writes a `_preview.jpg` (≤ 960 px, macOS `sips`, built in). View the preview:
- If Claude can read local files on the Mac (Claude Desktop with file access), Read the preview path directly.
- If Claude runs in a cloud session linked to the Mac, ask once for folder access to `/Users/felix/Desktop/Final/Cache Edit`, stage the previews, then Read the staged copies.
- Otherwise ask the user to drag the contact sheet/preview into the chat.
Never claim a visual check without one of these.

## Route A — Resolve still export (no install)
1. `resolve.OpenPage("edit")` (or keep current page; note `ExportCurrentFrameAsStill` exports what the current page viewer shows — on the Color page that is the graded image).
2. `tl.SetCurrentTimecode(tc)` for each check frame.
3. `project.ExportCurrentFrameAsStill(path)` → read back `True` and confirm the file exists (unsafe script).
4. Read each PNG. Batch 6–12 frames per pass.
`scripts/qc_stills.py` does steps 1–3 for a list of timeline frames and also builds a contact sheet if ffmpeg exists (one image for the whole batch — read the sheet instead of single previews; much cheaper).

**Stale stills (measured 2026-10-25):** exporting right after `SetCurrentTimecode` sometimes returned a black frame or the frame of the **previous** export (a kitchen shot at a drone position; the bouquet at a title frame). Waiting 0.6–0.7 s after each seek fixed it every time; the first export of a run was the most affected. `qc_stills.py` now waits `SETTLE_S` and makes a warm-up export. If a still contradicts the timeline read-back, re-export it before changing the edit.

## Route B — ffmpeg from source files (preferred for footage analysis; ffmpeg in `~/.local/bin`, see INSTALL.md)
`scripts/frame_probe.py` grabs N evenly spaced frames per source clip (plus scene-change frames when cheap) and tiles them into one contact sheet per clip with timecodes burned into the filename. Good for the footage evidence map **before** any edit. LOG footage looks flat — judge content, not colour.

## Route C — thumbnail (fallback)
`tl.GetCurrentClipThumbnailImage()` returns base64 (Color page). Decode to PNG in an unsafe script, then Read. Low resolution; use only for content identification.

If none works, say so and ask the user for one screenshot of the Resolve viewer.

## What to sample
| Stage | Frames |
|---|---|
| Footage evidence | 4–8 per clip + contact sheet |
| After build | first frame, last frame, every cut boundary at −1/0/+1 frame (catches black flashes and one-frame jumps) |
| Titles | entry midpoint, hero (fully visible), exit midpoint |
| Subtitles | 3 representative lines, the longest line |
| Look/grade | one frame per shot, before/after pair |
| Landscape-in-vertical | one frame per shot to check the fit and the band usage |

## What to look for (checklist per frame)
- Black or wrong frame at a cut; flash of a different clip.
- Fill framing: subject cut off at the sides (fix with `Pan`); in fit layouts, titles sitting on the picture instead of the bands.
- Text characters: every Vietnamese letter rendered (missing glyphs show as gaps, e.g. "NH NG" for "NHỮNG"); spelling of names and place names (Hương Cảng, not Hưởng Cảng); no line running past the frame edge.
- Text: readable at phone size (imagine 6 cm wide), contrast against what is behind it, not over a face/eyes/key action, inside TikTok safe zone (top ~8 %, bottom ~20 %, right ~12 % are covered by UI).
- Title and subtitle not colliding.
- Grade: skin natural, no clipped highlights in sky/neon, shots match each other.
- Motion blur/stutter on retimed shots (compare two adjacent frames).

## Scorecard
After the stills: fill `review-scorecard.md` (editing craft, creative direction, visual, audio + blockers) and show it with the Draft review question.

## Reporting
List exactly which frames were inspected (timeline TC) and the verdict per frame. Anything not sampled stays "unverified". Continuous playback and the audio mix are never verified by stills — say so.
