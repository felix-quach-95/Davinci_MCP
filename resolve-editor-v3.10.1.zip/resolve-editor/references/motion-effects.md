# Motion effects — emphasis you can see and hear

What the skill can do to make a moment, object or event stand out, when to use each effect, and the sound that goes with it. Built with `scripts/build_from_blueprint.py` (speed, ramps) and `scripts/motion_fx.py` (inside each clip's Fusion comp). All entries VERIFIED on Resolve 21.1.1 (2026-10-24, Test_MotionFX + Final_HuongCang_01) unless marked.

## 0. Cinematic priority — speed ramp, zoom in, zoom out: the montage toolkit (v3.4.0, user request 2026-10-27: use them more)
The user wants cinematic movement first and **more of it**. These three effects carry the montage; shake, flash, whip, freeze and spotlight only support them. Numbers are starting values from editing guides, to verify on stills — not measured optima. Sources: speed-ramp practice and frame-rate limits ([Kapwing](https://kapwing.com/resources/how-to-use-the-speed-ramp-effect), [Motion Array](https://motionarray.com/premiere-pro/premiere-pro-speed-ramping-tutorial/), [Amateur Photographer](https://amateurphotographer.com/video/how-to/what-is-speed-ramping-and-how-do-i-do-it), [Morphic glossary](https://morphic.com/ai-glossary/speed-ramping)); zoom and punch-in practice ([PremiumBeat](https://www.premiumbeat.com/blog/mastering-zoom-and-punch-in), [CapCut zoom transition guide](https://www.capcut.com/resource/zoom-transition-in-premiere-pro)).

### 0.1 Speed ramp types (v3.5.1: durations are time on screen — a ramp the viewer cannot feel is no ramp)
| Type | Shape: speed % × seconds on screen | Total | Job | Where it goes |
|---|---|---|---|---|
| **Ramp-in-hold** (hero) | 100 × 0.4 → 250–300 × 0.5 → 40–50 × 0.8–1.2 → 100 × 0.4 | 2.1–2.5 s | the moment *lands* | the drop or the peak frame of the best shot |
| **Ramp-through transition** | A: 100 × 0.4 → 250 × 0.4 → 400 × 0.35, cut, B: 400 × 0.35 → 200 × 0.4 → 100 × 0.4 | 1.2 s + 1.15 s | the cut feels like one continuous rush | two shots with motion in the same direction, cut on a beat |
| **Launch (reverse ramp)** | 50 × 0.7 → 100 × 0.35 → 300 × 0.5 | 1.5–1.8 s | stillness breaks into action | start of a chapter, after a quiet hold |
| **Near-freeze** | 100 × 0.4 → 25 × 0.5–0.7 → 100 × 0.4, or `freeze` 0.5–0.8 s | 1.3–1.5 s | "this moment" | one gesture, a pour, a splash |
| **Velocity steps** | 100 × 0.4 / 250 × 0.4 alternating on beats, at least 4 steps | ≥ 1.6 s | energy without new footage | energetic styles, long process shots |
- **Minimums (`edit_analysis.py` `ramp_feel`):** every step ≥ 0.33 s on screen (≈ 10 frames at 30 fps), the whole ramped shot ≥ 1.5 s, the slow part ≥ 0.6 s, fastest/slowest ≥ 2.5×. On TestSkill steps of 0.07–0.23 s at 200–400 % went by unnoticed.
- **Source needed:** a step of `t` seconds at `s` % uses `t × s / 100` seconds of source — 0.5 s at 300 % eats 1.5 s. Pick shots whose usable range covers the whole ramp (blueprint `frames` are source frames: `frames = t × fps × s / 100`).
- **Step through intermediate speeds** (1× → 2× → 4× → 2× → 1×); a jump reads as a glitch. Resolve's speed curves are not scriptable: ramps are stepped items (blueprint `ramp`), `ramp_smooth` only if the steps stutter.
- **Frame-rate limits.** Fast steps work on any footage. Slow steps need source frames: native ≥ 50 fps for 50 % and below; 24–30 fps footage only with optical flow, and only down to about 50–60 % on calm subjects (pours, steam, light, slow walking) — never on fast complex motion, faces turning or hands crossing (judder). Below that use a near-freeze.
- Ramps change duration: they are planned in **Phase 5** (blueprint `ramp`, the slow step on the `keep` peak frame and a measured music hit) and only checked in Phase 7.

### 0.2 Zoom in and Zoom out types
| Type | Curve (Size) | Job | Tool |
|---|---|---|---|
| **Slow push** | 1.00 → 1.06–1.12 over the whole shot, ease in-out, pivot on the subject | attention, tension, discovery | `push` |
| **Slow pull (reveal)** | 1.10–1.15 → 1.00 over the shot | release, context, ending | `pull` |
| **Punch-in** | instant 1.00 → 1.12–1.18 on a beat, optional release | call out a detail on the beat | `punch` |
| **Snap zoom** | 1.00 → 1.12–1.18 over 6–10 frames, ease out | emphasis beat that still reads as movement | `zoom_keys` |
| **Zoom-through exit** | slow push, then the last 6–8 frames accelerate to 1.25–1.3 (+ `blur_out` 4 frames) | carries the eye *into* the cut | `zoom_keys` + `blur_out` on A |
| **Zoom-through entry** | first 6–8 frames 1.25–1.3 → 1.05, then slow settle (+ `blur_in`) | lands the cut | `zoom_keys` + `blur_in` on B |
| **Reverse zoom cut** | A ends on a pull, B starts on a push | tension at the cut | `pull` on A, `push` on B |
| **Push-then-pull** | 1.00 → 1.10 → 1.02 inside one shot | breathe with a phrase | `zoom_keys` |
| **Crash zoom** | 1.00 → 1.3 in 3–5 frames | shock, comedy | `zoom_keys`; energetic or comedic styles only, at most one |
- Zoom-through join = exit on A + entry on B, same pivot area, cut at peak velocity, a whoosh peaking on the cut.
- Moves always ease (never linear); the pivot sits on the subject (source coordinates); keep Size ≤ 1.2 on 16:9 fill footage in 1080 delivery (≤ 1.35 hard limit).

### 0.3 Recipes by story section
| Section | Picture | Transition into the next shot |
|---|---|---|
| Hook (0–2 s) | snap zoom or punch on the first beat; strongest motion | ramp-through or zoom-through |
| Setup | slow pushes on wides, pulls on details | hard cuts on beats, one zoom-through |
| Build | velocity steps or pushes that speed up; shots shorten | ramp-through into the drop |
| Drop / peak | **ramp-in-hold** on the peak frame, punch on the hit | hard cut on the hit |
| Release | slow pulls, longer holds | blur or reverse zoom cut |
| Ending | slow pull-out over the last shot | — (music ending carries it) |

### 0.4 How much (videos up to 30 s)
- **Speed ramps: 5–7 per 30 s** (v3.5.1: was 3–5) — one or two hero ramp-in-holds, 2–4 ramp-through transitions, launches or velocity steps (energetic styles up to 8; quiet styles 2–3), each meeting the minimums of §0.1.
- **Zoom moves on at least 60 % of shots** (push, pull, punch, snap or zoom-through); static holds are a choice for the release or the ending.
- **Zoom-through joins: 2–4 per 30 s.**
- Each shot gets an `fx_plan` in the blueprint (e.g. `["push"]`, `["zoomthrough_out"]`, `["ramp_through"]`); `edit_analysis.py` `fx_report` warns below these counts.
- Variety: never the same effect plan on three shots in a row; alternate push and pull; never two strong effects on one frame (ramp-in-hold + punch is one gesture, not two).
- Do not ramp or zoom soft frames, frames in `bad`, or shots whose subject is already at the crop edge.
- **Sound:** only transitions get SFX (`sfx-library.md` §3) — a ramp-through or zoom-through gets a whoosh peaking on the cut, the drop gets a riser into the cut and a sub drop on it. In-shot pushes, pulls and punches ride the music.
- Prove each effect with an on/off still pair or numbers (`visual-qc-loop.md`).

## 1. Inventory — what exists
| Effect | Tool | Use it to | SFX (only when it is a transition, v3.4.0) | Status |
|---|---|---|---|---|
| Slow motion | blueprint `speed` (+ optical flow) | linger on the peak, show texture (smoke, water, faces) | slow-mo swell, low riser | VERIFIED |
| Speed ramp | blueprint `ramp` steps (e.g. 300 → 150 → 60 %) | hook energy; land on a moment | whoosh/riser ending on the slow step; sub drop on the hit | VERIFIED (stepped; Resolve's retime curves are not scriptable) |
| Reframe path (follow) | `motion_fx` `reframe_path` points [[t, x, y(, zoom)]] | keep a moving subject centred in 9:16 with eased moves; 1-subject "punch-in" from a wide | — | UNTESTED (v2.3) |
| Invert stutter | `motion_fx` `invert` t, n=1–2 | subliminal negative flash that makes a hard cut feel intentional | hit | UNTESTED (v2.3); energetic/rugpull only |
| ResolveFX | `motion_fx` `resolvefx` regid + params | grain, glow, light rays, flare, halation, film look… (`resolvefx.md`) | — | UNTESTED (v2.3) |
| Smooth speed ramp | `motion_fx` `ramp_smooth` profile (TimeStretcher curve in the clip comp) | same, when the stepped ramp visibly stutters | same | UNTESTED (v2.2; same node as freeze, which is verified) |
| Push-in | `motion_fx` push a→b, `center` = subject | draw the eye to a subject, build tension | riser (long), nothing (subtle) | VERIFIED |
| Push + follow | push with `drift` | keep a moving subject framed | — | VERIFIED |
| Virtual camera move | push a=b=1, `drift` | life on static wides | wind/ambience | VERIFIED |
| Zoom-out reveal (pull) | `pull` | show context after a detail, ending | whoosh / swell | VERIFIED |
| Punch-in | `punch` b at t (+`release`) | hit on a beat, call out a detail | — (rides the music) | VERIFIED (same node as push) |
| Zoom curve | `zoom_keys` keys [[t, size(, ease)]] | snap zoom, zoom-through exit/entry, push-then-pull, crash zoom | whoosh on the cut (zoom-through) | UNTESTED (v3.4.0; same Size input as push) |
| Shake | `shake` t, n, amp | impact, bass drop, slam | sub drop, hit | VERIFIED |
| Blur in / out | `blur_in` / `blur_out` | soft entrance/exit, dream, time jump; focus transition pair | swell / whoosh | VERIFIED |
| Whip | `whip_out` + `whip_in` on the next clip | energetic transition | whoosh peak on the cut | VERIFIED (length 0.15 default; 0.25 too strong) |
| Flash | `flash` (Brightness + Gain) | beat hit, photo moment | camera shutter, hit | VERIFIED (Gain alone is invisible on LOG footage) |
| Freeze frame | `freeze` t | "this moment", photo, name a person | shutter + flash | VERIFIED |
| Spotlight | `spotlight` center, r, dark | make the subject clear in a busy frame | — | VERIFIED (subtle at dark 0.5) |
| Glow | `fx_apply.py` effect Neo Glow | night lights, dreamy | — | VERIFIED (effects-library.md) |
| Built-in transitions | `fx_apply.py` transitions | dissolves, flashes, zoom transitions | per type | VERIFIED |

## 2. When to use (taste rules)
- **Every effect needs a reason**: emphasis (look here), clarity (this is the object), emotion (slow down), energy (speed up), transition (time/place change).
- Density (v3.4.0 counts in §0.4 win; the older accent count still applies to the support effects): **cinematic 5–10 accents in 15–20 s** (about one every 2–3 s, ≤ 2 per chapter); energetic 10–16; minimal 2–4. Alternate strong accents (punch + shake, flash, freeze, whip) with light ones (slow push, blur in, glow, a text slam alone) so the density does not tire the eye; land strong ones on phrase hits and the drop, light ones on beats in between; never two strong effects on the same frame. An accent may be marked as a graphic slot for HyperFrames in the Phase 10 hand-over (no text is built here).
- Push-ins 1.05–1.12 over the whole shot (ease in-out); punch-ins 1.12–1.2 on a beat; zoom ≤ 1.15 for 1080 delivery from 4K 16:9 in 9:16 fill (the fill already magnifies 1.78×).
- Slow motion where the picture has texture or a human gesture; native high-fps first (100 fps → 25 %, 50 fps → 48–50 %).
- Speed ramps: fast steps on low-information frames, land the slow step on the moment and on a music hit.
- SFX only on transitions (v3.4.0): the peak of a whoosh or riser and the onset of a hit land on the cut (`sfx-library.md` placement); accents inside a shot have no SFX.

## 3. How to specify (blueprint + EFFECTS)
```json
{"id": "s01", "clip": "03.mov", "src_in": 0, "src_out": 60, "dur": 35,
 "ramp": [{"frames": 40, "speed": 300}, {"frames": 10, "speed": 150}, {"frames": 10, "speed": 60}]}
```
```python
EFFECTS = [{"track": 1, "index": 6, "fx": "push", "t0": 0, "t1": 49, "a": 1.0, "b": 1.10,
            "center": [0.705, 0.55], "drift": [0.12, 0.0], "ease": "inout"},
           {"track": 1, "index": 9, "fx": "flash", "t": 30, "n": 4}]
```
Times are frames relative to the item start; `center` is in SOURCE coordinates (x 0–1 left→right, y 0–1 bottom→top). Subject seen at crop x c under Pan P: `x = 0.5 − P·0.00035 + (c − 0.5)·0.316`.

## 3b. Smooth ramp (v2.2, UNTESTED live)
`{"track": 1, "index": 4, "fx": "ramp_smooth", "profile": [[0, 300], [18, 300], [28, 40], [52, 40], [60, 200]]}` — speeds are relative and normalised over the item, because the clip comp can only replay the item's own source range: the item keeps its average speed (set it with the blueprint `speed`/`dur`, and give it the source frames that average needs), the profile only reshapes time inside it. Keys every 2 frames on the TimeStretcher `SourceTime` spline (the same mechanism as `freeze`, verified). Not on the same item as `freeze`. Check stills two frames apart at the slowest point (optical-flow softness, duplicated frames) and compare with the stepped `ramp`; keep the better one.

## 3c. Moves and transitions that read well (v2.3, from voidash/claudepipe and creator feedback)
- **Never linear.** Moves ease in and out (`reframe_path` uses smoothstep; push/pull `ease: inout`); "anticipation → action → settle".
- **Cut into the movement**: a movement transition cuts where velocity is highest, and the direction before the cut continues after it.
- **Match cuts**: asset (same shape/word in the same place), position (same direction of travel), scale (zoom in on A → cut mid-zoom → zoom out of B, with a touch of blur), rotation (centred round objects only). Plan them in the cue sheet when the footage offers them.
- **Contrast drives a hard cut**: light→dark, busy→empty, colour→opposite.
- **Transition pace**: talking sections 8–10 frames, music sections 4–6, reveals 2–3 frames with contrast (optionally a 1–2 frame `invert` stutter).
- **Reframe path**: subject positions come from the contact sheet (source x,y) or measured on successive stills; keep moves slow enough that the viewer does not notice the camera; `PAN_PER_UNIT` gives the view centre from the Edit-page Pan (9:16 measured); black edges are refused before writing.

## 4. Measured facts (keep)
- Clip comps: render range maps linearly onto the item (comp 0 = source in-point, also for retimed items).
- **Transform: Pivot = zoom point; Center = translation of the whole picture.** Center = Pivot = subject shifted the picture and left a black band.
- **Keyed changes are not re-rendered** until an input of the node changes: `motion_fx.py` toggles pass-through on every MFX node after building (without it, nothing animated showed although `GetInput(..., t)` returned the keys).
- Verify each effect with an on/off pair of stills (toggle the MFX nodes' pass-through): measured mean differences 4–26 at effect frames, ~0 outside.
- Speed-changed lengths are rounded by Resolve (up to 3 frames per item): give every segment a `"dur"`; the builder converges the speed until the length is exact.
- Stepped ramps report the boundary source frame on both sides; that is not a repeat.
