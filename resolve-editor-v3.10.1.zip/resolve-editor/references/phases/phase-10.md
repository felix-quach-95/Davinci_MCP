# Phase 10 — Final and hand-over

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** a verified Final and a clean project with a backup. **No graphic question in this phase** (user rule 2026-10-28): every graphic decision — whether, which elements, style — is asked only after the switch to HyperFrames, in Phase 11.

## Steps
1. **Final copy** — `DuplicateTimeline("Final_<Title>_NN")` from the approved Draft; `timeline_ops.py` compare (Draft vs Final, a few frames, difference 0.0) proves the copy; save.
2. **Cleanup plan** — `finalize_project.py` MODE `plan` (with the Vietnamese Final name when known: the name is part of the plan token).
3. **Final approval** (stop, `options-playbook.md` §8) — exactly two questions, in Express and Standard alike: Final name and cleanup. Never add a graphic question (scope, style, "cần graphic không") here.
4. **Cleanup** — MODE `apply` with the plan token: `.drp` backup, Claude's timelines deleted, Vietnamese track and node names, music Green and SFX Yellow, reserved empty graphic tracks, Deliver page → Desktop/Final; item counts unchanged. Look at stills of the Final.
5. **Final report and the switch question** — Final name, what was built, what is unverified, backup path (≤ 12 lines), then one AskUserQuestion (`options-playbook.md` §8, `phase-11.md` §1): **"Final đã xong. Chuyển sang Phase 11 — làm đồ họa với HyperFrames?"** · Chuyển sang HyperFrames ngay (Recommended) · Để sau · Không cần đồ họa. "Chuyển ngay" → Phase 11 starts **in this same chat**; never propose `/clear`, a new chat or a new window. "Không cần đồ họa" → record "no graphics" in `project.json` and the project ends. "Để sau" → `STATUS.md` "Next" = Phase 11 from step 1.
After hand-over Claude never edits the Final: a new request duplicates it to the next Draft. Cache Edit can be deleted after the graphics are in (copy the `.drp` out first).

**Tools:** `timeline_ops.py` compare, `finalize_project.py`.
**Read when needed:** `references/delivery.md`.
**Done when:** Final duplicated and verified, project cleaned with a new backup, the switch question answered (Phase 11 started, "later", or "no graphics" recorded).
