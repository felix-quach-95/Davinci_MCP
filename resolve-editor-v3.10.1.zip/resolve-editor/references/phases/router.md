# Module router (full list)

Read a module only for the step that needs it, and only the section you need (Contents → offset/limit or Grep a heading). Each phase card already names its modules; this table is the complete index.
| When the step involves | Read |
|---|---|
| Music check and Music request (the user sends the file), music analysis (measured vs estimated) | `references/music-analysis.md` |
| Phase 10: graphic questions, hand-over brief (Markdown + JSON), `hyperframes_handoff.py`, the Phase 11 package | `references/hyperframes-handoff.md` |
| Any Agent call: which agent, which model, brief by reference, depth 1, images in one turn, escalation | `references/agents-and-models.md` |
| Phase 11 (same chat; gallery → graphic questions → brief → build agent with preview link): graphics built and exported by the user's `motion-studio` skill (newest HyperFrames), MOV check, placing on request | `references/phases/phase-11.md` |
| Any API call not verified this session; signatures, measured facts | `references/api-cookbook.md` |
| Wording of every stop: kickoff questions, Style choice, Music request, Story approval, Rough-cut approval, Hero accent choice, Draft review, Final approval; variant sheets, alternates, `_prefs.json` lessons | `references/options-playbook.md` |
| Brief intake, design read + dials, theme/tone/hold table, beats as visual cause, but/therefore, slideshow-risk audit, decision log | `references/ideation-playbook.md` |
| Style profiles (`config/styles/*.json`, user ones in `~/Movies/ClaudeQC/_styles/`) | `references/style-profiles.md` |
| One long source → several ranked short clips | `references/clip-factory.md` |
| Free online SFX (only when the user asks): tiers, licences, shortlist → approval → `audio_ingest.py`, credits. Never for music | `references/free-audio-sources.md` |
| Phase 3: moments, action stages, In/Out, roles, evidence labels, moment mining, catalogue schema | `references/footage-intelligence.md` |
| Phase 4: story contract, beat map, causal vs associative, gaps/repeats/stalls, structure comparison, definition of ready | `references/story-decision-framework.md` |
| Phase 5–6: scoring and comparing shots, continuity, joins, cinematic joins, the four repeat checks, blueprint `shot`/`why`/`rejected` | `references/shot-selection-and-continuity.md` |
| Phase 6 rough-cut review and Phase 9: editorial verdict, early/late cuts, spare shots, hook/peak/release/ending, fixes by scope | `references/editorial-decision-and-qc.md` |
| B-roll discovery and creation | `references/broll.md` |
| Montage in depth: cut-point anatomy, five methods, cut vocabulary, rhythm, beat-grid math, the `cut` field | `references/montage-advanced.md` |
| Story in depth: spine, three acts at 15–90 s, arc vs pace, parallel editing, beat drop, B-roll layers, J/L cuts, retention, the paper-edit table | `references/story-structure.md` |
| Composition: 9:16 grids, shot sizes, eye line, leading lines, depth, eye-trace, axis and 30° rule | `references/composition.md` |
| Story shape, montage method, transitions with meaning, phrase chapters (short entry) | `references/storytelling-montage.md` |
| Hooks, retention, pacing for TikTok/Reels | `references/viral-shortform-formats.md` |
| Research before the plan: hooks, outliers, keywords, sounds, runtime, the Research Card | `references/trend-research.md` |
| Render (only on explicit request), file/loudness check, caption/hashtags, other aspect ratios | `references/delivery.md` |
| ResolveFX on clips | `references/resolvefx.md` |
| Zoom, slow motion, speed ramp, blur, shake, flash, freeze, spotlight, reframe paths, match cuts + sounds | `references/motion-effects.md` |
| Brief, evidence map, creative plan, blueprint/cue sheet format | `references/brief-template.md` |
| Reference video analysis | `references/reference-analysis-and-match.md` |
| Talking/vlog footage: transcript, pacing profiles, punch-ins, corrected transcript for the hand-over | `references/transcript-editing.md` |
| Dialogue sources, voice levelling, EQ/Fairlight, music around speech, "is the music really there" | `references/voice-audio.md` |
| Installed title/effect templates, built-in transitions, Neo Glow | `references/effects-library.md` |
| Choosing and placing SFX | `references/sfx-library.md` |
| The ending | `references/endings.md` |
| Vertical framing, safe areas | `references/vertical-frame-checklist.md` |
| Music choice, beat grid, levels, ducking, loudness | `references/audio-music-sfx.md` |
| Technical colour: LOG/HDR conversion, WB, exposure, matching | `references/color-look.md` |
| Looking at frames, contact sheets, visual QC | `references/visual-qc-loop.md` |
| Is the draft good — before the Draft review | `references/review-scorecard.md` |
| Capabilities, regression lessons, sources | `references/resolve-mcp-capabilities.md`, `references/case-study-reference-vs-demo.md`, `references/github-sources.md` |
