# Phase 5 — Shot selection

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** for every beat of the approved story, the shot that does the beat's job — not the prettiest one — written into the blueprint.

## Steps (`shot-selection-and-continuity.md`)
1. **Hard filters** — bad frames, unusable quality, an image group already used, wrong or repeated information, not enough source for the planned effect, burned-in text, a subject lost in the 9:16 crop.
2. **Score** the survivors on emotion, story role, action, image quality and fit with neighbours (weights in §1); keep a ranked alternative with its reason. When two shots are close, decide with Murch's order (emotion → story → rhythm → eye trace → 2D plane → 3D space) and write the deciding step.
3. **Joins** — check every cut A→B for gaze, movement direction, axis, the 30° and two-size rule and eye trace; choose the join type (match on action, graphic match, eyeline, contrast, cutaway, bridge …).
4. **Cuts on the beat** — place cuts on the measured beat grid; shift the music start by a few frames if a constant offset appears.
5. **Cinematic effects** — an `fx_plan` for every shot from `motion-effects.md` §0: 5–7 speed ramps per 30 s (one or two hero ramp-in-holds on the peak, ramp-through transitions, launches, velocity steps), each meeting the minimums of §0.1 (every step ≥ 0.33 s on screen, ramp ≥ 1.5 s, slow part ≥ 0.6 s, fastest/slowest ≥ 2.5×), zoom moves on at least 60 % of shots, 2–4 zoom-through joins; recipes by section (§0.3). Speed ramps change duration, so they are planned here.
6. **B-roll layer on V2** (`broll.md` §0a) — after the V1 spine is chosen, place cutaways over it: at least 3 and one every ~4 s (30 s → 8), 0.4–2.0 s each, 25–50 % of the runtime, each with `text_checked: true` after its stills are looked at, each with `broll_type`, `why`, its own `grp` and an `fx_plan`.
7. **Four repeat checks** — source frames, same picture or group, same information, same pattern.
8. **Blueprint** — per segment: `shot`, `grp`, `info`, `size`, `move`, `direction`, `score`, `why`, `rejected`, `cut` (reason, on, type, why), `fx_plan`, `props` (Pan, Zoom, Tilt for reframes); V2 cutaways with `track: 2` and an explicit `record`.

**Tools:** `composition_check.py`, `frame_probe.py` MODE range, `edit_analysis.py` (repeat report), `replace_shot.py` (alternates).
**Read when needed:** `references/shot-selection-and-continuity.md` (always), `references/broll.md`, `references/composition.md`, `references/footage-intelligence.md §7–8`.
**Done when:** each beat has a chosen range, its function, a score, a `why` and a ranked alternative; no `shot` or `grp` is used twice; joins and effects are planned (`edit_analysis.py` `fx_report` and `broll_report` without open notes); unused footage is listed with a reason.
