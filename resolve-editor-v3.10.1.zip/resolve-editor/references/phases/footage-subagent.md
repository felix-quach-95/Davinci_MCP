# Footage review by a subagent (Phase 1 scan, Phase 3 deepen; token plan T3, v3.2.0 schema)

Why: contact sheets are the largest token cost of a project, and every image Claude opens stays in the main context for every later call. A subagent opens the images, returns **text only** (JSON in the schema of `footage-intelligence.md` §9), and its context is discarded.

## When
- Express mode, or any project with more than ~4 sources: delegate. A 1–3 clip project: read the overview sheet yourself.
- Two calls per project: **scan** (end of Phase 1, feeds the Style choice) and **deepen** (Phase 3, exact shots). Never delegate the story or shot decisions (Phases 4–6): the subagent only reports what is in the frames.

## How (Agent tool)
- `subagent_type`: general-purpose · `model`: **"haiku" for the scan (A1), "sonnet" for the deepen pass (A2)** (`agents-and-models.md`; escalation of a weak scan clip to sonnet in §4) · `description`: "Footage scan" / "Footage deepen".
- **Brief by reference:** the Agent prompt names this file's Pass 1 or Pass 2 and gives the paths and numbers (≤ 12 lines, `agents-and-models.md` §5). Do not paste the templates below into the prompt; the agent reads them here.
- **Images in one turn:** the agent reads all its sheets in a single message (parallel Reads), never one by one. More than ~8 sheets in the deepen pass → parallel agents of ≤ 4 sources each, started in one message; merge their arrays into `catalogue.json`.
- Before calling: `phase_run.py` p1 has written `overview.jpg` and one `<clip>_contact.jpg` per source (frame numbers burned into every thumbnail) under `Cache Edit/<Title>/footage/`; its summary `overview.sources` lists each source's sheet, fps and frames — fill the prompt from it, never from `p1.full.json`. For the **deepen** pass, also pass the range sheets from `frame_probe.py` MODE range (≈ 2 fps around the usable moments).

### Pass 1 — scan prompt (Phase 1)
```
Read these images with the Read tool: [overview path], then [per-clip sheet paths].
Each thumbnail shows its SOURCE frame number (top-left). Sources and fps: [name: fps, frames, size].
Return a JSON array, one object per source, nothing else:
{"id": "C01", "file": name, "content": ≤ 20 words, "cam": static|pan|push|handheld|drone…, "light": …, "quality": usable|soft|shaky|over/under-exposed + why,
 "moments": [{"from": frame, "to": frame, "what": ≤ 12 words, "size": EWS…ECU, "emo": word+1-3, "role": hook|setup|development|peak|release|ending|bridge, "ev": "SEEN"|"INFERRED"}],
 "dup_of": id or null, "issues": [...]}
Describe only what you see. For anything between thumbnails write "unseen". Return 2-6 moments per source.
Burned subtitles often start mid-shot and can be small: a range is "text-free" only when every thumbnail inside it was looked at for text at the bottom centre; otherwise write "text unchecked" (v3.5.0: two ranges called clean had subtitles).
```
The scan is only used to propose style options honestly (the Style choice) and to plan the deepen pass; it never sets In/Out.

### Pass 2 — deepen prompt (Phase 3)
```
Read these images with the Read tool: [range sheet paths]. Thumbnails are ≈ 2 per second and show SOURCE frame numbers.
Sources and fps: [name: fps, frames, size]. Scan result for context: [id: moments].
For every usable moment return ONE shot object (nothing else, a JSON array):
{"id": "C03.S02", "clip": "C03", "in": frame, "out": frame (exclusive), "len_s": n,
 "stages": {"begin": [a,b], "develop": [a,b], "peak": [a,b], "end": [a,b]}  (omit a stage you cannot see),
 "keep": [[a,b]], "bad": [[a,b]], "handle_in": frames, "handle_out": frames,
 "size": EWS…ECU|INSERT, "emo": word+1-3, "motion": subject + camera, "dir": L→R|R→L|toward|away|up|down|null, "gaze": … or null,
 "comp": thirds position, depth, negative space; what survives a 9:16 fill crop,
 "light": …, "roles": {top two of hook/setup/development/peak/release/ending/bridge: 0-3},
 "grp": picture group (same subject+angle+framing = same group; panel reframe/push/slow-motion of the same picture = same group),
 "fx": {"ramp": bool, "slow": bool, "zin": bool, "zout": bool}, "link": next-shot idea (≤ 10 words),
 "ev": "SEEN"|"INFERRED"|"UNVERIFIED", "why": ≤ 15 words, "unseen": [what could not be seen]}
Mine B-roll: from each clip also list distinct detail / gaze-target / texture / entry-exit / bridge shots (footage-intelligence.md §7).
In/Out only from frames you saw. If a bound is not visible, narrow the range to what you saw and add it to "unseen".
```
- Save the answer to `Cache Edit/<Title>/footage/catalogue.json` (`project_set {"footage": …}` for the short form). The scan result is kept as `scan.json`.
- The main session opens **one** image only when a decision depends on a detail the catalogue marks "unseen" or soft (`frame_probe.py` MODE range on that stretch, then that one sheet).

## Honest reporting
Say that the catalogue was written by a subagent from contact sheets; every in/out point used in the blueprint is still checked on the Draft's read-back and mid-segment stills (hard gates 3 and 8). Report `seen / inferred / unverified` counts.
