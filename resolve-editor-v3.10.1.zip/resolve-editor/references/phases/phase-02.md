# Phase 2 — Music analysis

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** a music map of the user's track, with every number labelled measured or estimated, before any footage decision.

## Steps
1. Analyse the track the user sent: `music_library.py` MODE `analyse` (any path) and `silence_beats.py` MODE `beats`. Tempo counts as **measured** only when both tools agree (half or double allowed); otherwise it is **estimated**.
2. Map: duration and structure (intro, build, drop, peak, break, ending); beat grid and downbeats; measured hits; phrase lengths; energy curve (RMS every 2.5 s); ending type (hit, fade, ring).
3. Candidate music windows of at most 30 s that start and end on measured hits, with the drop time inside each.
4. Record `project_set {"music": {…map…}}`.
Music is a structural and emotional reference, **not an order to cut on every beat**.

**Tools:** `music_library.py` analyse, `silence_beats.py` beats.
**Read when needed:** `references/music-analysis.md`, `references/audio-music-sfx.md`.
**Done when:** the music map is in `project.json` with every number labelled measured or estimated.
