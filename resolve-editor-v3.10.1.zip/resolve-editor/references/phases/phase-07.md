# Phase 7 — Accents and sound

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** one consistent system of motivated accents and selective sound on the Draft, each checked, with a natural ending and a clean mix.

## Steps
1. **Zoom moves and accents** (`motion_fx.py`, duration-neutral): build every `fx_plan` of the blueprint on V1 and V2 — push, pull, punch, snap zoom and zoom-through exit/entry (`zoom_keys` + blur), whip, flash or shake at the drop (`motion-effects.md` §0). Speed ramps were planned in Phase 5; here they are only checked. Give every effect of one item in the same run. Check each accent with stills (on/off or numbers).
2. **Hero accent choice** — Standard mode asks (`options-playbook.md` §6); Express uses the style's default and checks it.
3. **Sound**, in order: footage without speech → `project_set {"mix": {"dialogue_tracks": []}}`; `voice_audit.py` and `duck_music.py` when there is speech; SFX **only on transitions** from one cue sheet (`sfx_library.py` MODE place refuses an event that is not on a cut): whoosh on ramp-through, zoom-through and whip joins, riser + sub drop into the drop, a hit on a smash cut — about 7–10 in 30 s (MODE place flags fewer), none for content, no ambience beds (`sfx-library.md` §3); placed SFX are Yellow, the music stays Green; long files shortened with `length`.
4. **Ending** — `ending_plan.py` must report a natural end (a hit, or a fade the music carries).
5. **Audio check** — `audio_presence.py` render: no clipping, peak and loudness reported; fix levels with `timeline_ops.py` set_levels and check again. Report audio as "not auditioned" until the user listens.

**Tools:** `motion_fx.py`, `fx_apply.py`, `voice_audit.py`, `duck_music.py`, `sfx_library.py` place, `ending_plan.py`, `audio_presence.py`, `timeline_ops.py` set_levels / reappend_audio.
**Read when needed:** `references/motion-effects.md`, `references/sfx-library.md`, `references/audio-music-sfx.md`, `references/voice-audio.md`, `references/effects-library.md`, `references/resolvefx.md`, `references/endings.md`.
**Done when:** accents checked, one cue sheet placed, ending natural, audio check without clipping.
