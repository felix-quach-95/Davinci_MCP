# Phase 11 — Graphics with HyperFrames (Motion Studio)

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md. Phase 11 runs **in the same chat as the edit** (user rule 2026-10-28: no new window, no new session, no `/clear` — the work must stay linked in one place) and is carried out by the user's `motion-studio` skill on the **newest HyperFrames release** (0.8.209 on 2026-10-28; pinned per install so a job never changes release midway). The HyperFrames build runs in a fresh-context agent *inside this chat* to save usage; the user never switches windows.

**Goal:** every approved title, subtitle and motion graphic as its **own named layer**: one MOV per element (ProRes 4444 with alpha, the Final's size, trimmed to the element's span), named `DHnn_<Loại>_<Chữ>`, coloured by kind, on named Vietnamese tracks in a new Draft — so the user can keep refining each object in DaVinci.

## 1. Order inside Phase 11 (user rules 2026-10-28)
The graphic questions start only here, after the switch — never in Phase 10. Order:
**A. Install check → B. Style gallery with pictures → C. Graphic questions → D. Brief + package → E. Build in HyperFrames (preview link sent at once) → F. Review, export, layers, placing.**
A–D run in the main chat (they need the edit's cuts and beats and are cheap); E–F run in the build agent.

### A. Installed? — §3 step 0 (ask once before installing).

### B. Style gallery with pictures (always first, Motion Studio §1)
- Run `node ~/.claude/skills/motion-studio/scripts/styles.mjs gallery --open` from the package folder. It writes `gallery.html` (every HyperFrames built-in look rendered live from its `frame-showcase.html`, plus the user's saved looks) and opens it in the Mac's browser. If the command printed no error but the page did not open (the user says so, or the app has no browser hand-off), open it yourself: `open "<library>/gallery.html"` (`styles.mjs lib` prints `<library>`).
- **In the same message**, send the clickable link `file://<library>/gallery.html` and Motion Studio's three choices in Vietnamese (pick by name/number · send 3–5 screenshots, a link or a video · "bạn chọn giúp mình"), with 2–3 looks recommended for this Final and why (mood of the footage, night/day, pace). Then wait for the user's pick: never choose a look silently and never replace the gallery by a text-only list.
- A reference instead of a pick → Motion Studio's `references/style-from-reference.md` (the Final stills are the default reference), save the look, reopen the gallery, ask once.
- The pick goes into SPEC `style.look` (status approved).

### C. Graphic questions (`options-playbook.md` §8b, `hyperframes-handoff.md` §2)
One AskUserQuestion round, ≤ 4 questions, each option tied to a frame/beat of the Final, recommendation first: which elements (tiêu đề mở đầu · nhãn chương/địa điểm · chữ kết · phụ đề), wording, placement, feel of the animation. Skip what the user already said. "Không cần đồ họa" here still ends the project cleanly.

### D. Brief and package (`hyperframes-handoff.md` §4–§9)
`hyperframes_handoff.py` → `handoff_<Title>.md`; show it; APPROVED only when nothing is `proposed` or `open`. Then the stills (`qc_stills.py` PAGE "edit", middle frame of each element, ≤ 1080 px; the main chat does not open these stills) and the second run with `stills` + `package_dir` → `HF_REQUEST_<Title>.md`, `layers_<Title>.json`, `START_PHASE11.md` (the resume line for "later").

### E. Build — the fresh-context agent in this chat
- Launch one agent (Agent tool, general-purpose, foreground, **`model: "sonnet"`** — A6 in `agents-and-models.md`, escalated to `opus` only by its §4) with the **agent brief** below, paths filled in, name `phase11-<Title>`. It starts with an empty context; the user keeps talking in this chat.
- The agent works until a stop, then returns `STOP <kind>` with at most 8 lines, the options, and **every link and file the user must see** on `LINK:` lines. The main chat relays it: **first the links, verbatim and clickable, then the question** (AskUserQuestion, options unchanged), and passes the answer back with SendMessage to the same agent. The main chat never reads the agent's files or images, only its short reports.
- **Only 3 stops** (v3.10.1, to keep relay turns few — each one re-reads this long chat): ① HyperFrames' SPEC summary · ② **preview + review in one** (`STOP preview`: the link, the Studio tips, then one question: "Sửa xong trong Studio" · "Mình nhắn các chỗ cần sửa" · "Ổn rồi, xuất luôn") · ③ **export + placing in one** ("Xuất và đặt vào DaVinci?" · Xuất, Claude đặt vào Draft mới (Recommended) · Xuất, tôi tự đặt · Chưa, còn sửa). Nothing else stops the agent; progress needs no report.
- **Edits: Studio first, then one message.** The review stop tells the user to change words, colours, sizes and positions directly in Studio (free: no relay) and to put every chat change in **one** message; the agent applies the whole list, re-checks, and returns to stop ② once with the same link. Ask for a second list only if something is still open.
- **Lean relay:** the main chat relays the agent's report as is (links first) and passes the answer back word for word; it adds no reading, no summary and no extra question of its own.
- **Preview link rule (user rule 2026-10-28):** the moment the HyperFrames Studio preview is running, the user gets its link without asking — `STOP preview` carries `LINK: http://localhost:<port>/…` exactly as the preview command printed it; the main chat sends it at once and also opens it in the browser (`open <url>`). Every later stop while the preview runs repeats the link; after a rebuild or restart the new link is sent again. Before relaying, check it answers (`curl -s -o /dev/null -w "%{http_code}" <url>` → 200); if not, start the preview again from `videos/<name>` (the command the hyperframes skill uses) and send the new link. Never wait for the user to say they cannot see it.
- No Agent tool in this app → run E–F directly in this chat (say once that it uses more usage); never ask the user to open a new chat or window.
- Cost note (estimate): the agent never reads the edit chat; the edit chat is re-read (at the cheap cached rate) only on the relay turns — 3 stops plus one per batch of changes — not on the 40–150 calls of the build.

### Agent brief (copy, fill the paths)
```
You run Phase 11 (build) of resolve-editor for "<Title>". Your context is fresh on purpose: read ONLY
<skill>/references/phases/phase-11.md (§1 E, §2–§4), <package>/HF_REQUEST_<Title>.md, <package>/layers_<Title>.json
and the stills in <package>/stills (≤ 1024 px). Do not read project.json, catalogues or anything of the edit.
The style is already chosen (in HF_REQUEST); do not reopen the gallery unless the user asks for another look.
Follow the user's motion-studio skill (load it, or read ~/.claude/skills/motion-studio/SKILL.md; before it is
installed, <skill>/motion-studio/GUIDE.md is the same text) and the hyperframes skill it hands over to.
Stop only 3 times (phase-11.md §1 E): SPEC, preview+review, export+placing; apply a list of changes in one go.
You cannot talk to the user: at each stop return "STOP <kind>", ≤ 8 lines in Vietnamese, the options, and one
"LINK: <url or absolute path>" line for everything the user must open (Studio preview URL as printed, gallery,
renders, REVIEW.md). As soon as the Studio preview runs, return "STOP preview" with its LINK before anything else,
and repeat that LINK on every later stop. Start the preview as a background process so it keeps running.
Wait for the answer that comes back as a message. Work folder: <package>. Never suggest /clear or a new chat.
Never start another agent (depth 1): do any step HyperFrames would delegate yourself. Read each image once.
```

## 2. Where it runs
- **Recommended: Claude Code on the Mac** (Motion Studio's SessionStart hook pins `npx hyperframes` and puts its Node.js on PATH; HyperFrames' skills load as skills).
- **Claude app linked to the Mac** works through the shell tools (Desktop Commander `start_process` for the long-running Studio preview), with three adjustments: put `~/.claude/skills/motion-studio/.tools/node/bin` first on PATH if it exists; export the `env` block of `~/.claude/settings.json` (HYPERFRAMES_FFMPEG_PATH, HYPERFRAMES_FFPROBE_PATH, HYPERFRAMES_SKIP_SKILLS=1, HYPERFRAMES_NO_UPDATE_CHECK=1) in the same command; always type `npx hyperframes@<pin>` (`hyperframesVersion` in `~/.claude/skills/motion-studio/package.json`). HyperFrames' skills are then files: read `~/.claude/skills/hyperframes/SKILL.md` and follow it.
- `cd` into the package folder before any Motion Studio command (its `videos/` is created there).

## 3. Steps (Motion Studio's own steps, in its order)
0. **Installed?** — Motion Studio §0: `~/.claude/skills/motion-studio/SKILL.md` plus `~/.claude/skills/hyperframes/` on the Mac. Missing → ask once, then install the copy that ships **inside this skill** (`<skill>/motion-studio/`, its guide kept as `GUIDE.md` so the upload holds one SKILL.md):
   - Skill files on the Mac (Claude Code): `python3 -I <skill>/scripts/install_motion_studio.py` → copies it to `~/.claude/skills/motion-studio` with `SKILL.md` restored (keeps saved styles on an update) and pins **the newest HyperFrames on npm** (`--hf-version x.y.z` for a fixed one; offline → the shipped 0.8.209).
   - Skill files in the cloud, Mac linked (Claude app): `--pack <outputs>/motion-studio.tar.gz`, move it to a connected folder on the Mac (`device_commit_files`), then `tar -xzf … -C ~/.claude/skills` there.
   - Then its own installer **with `--update`**: `bash ~/.claude/skills/motion-studio/scripts/install.sh --update` (Node.js 22 if missing, FFmpeg, settings, and HyperFrames' skills of the pinned release — `--update` matters: without it setup keeps any `hyperframes` skills already there, e.g. the unpinned ones on the user's Mac from 27 Oct). Install ends with "Xong" → **continue in this same chat** (never ask for a restart, `/clear` or a new window): skills and settings installed now load only in a later session, so this run uses the "files" route of §2 (Node.js path, the settings `env` exported in each command, `npx hyperframes@<pin>`, HyperFrames' `SKILL.md` read as a file). "LỖI" lines → explain and fix, run again.
   - Every later Phase 11: `install_motion_studio.py --check-hf` → `OK` goes on; `NEEDS_UPDATE` (skills of another release, or unpinned) → `install.sh --update` (it replaces those skills), say so in one line. A newer release on npm than the pin is taken only by a re-install between jobs, never mid-job.
1. **Style** — chosen in §1 B from the gallery with pictures, so `style.look` is in the request → use it (`styles.mjs path <name>`), no question. Only if it is missing (a resumed job): run the gallery exactly as §1 B (open it, send the link) before anything else.
2. **Describe** — **skipped**: every answer is in `HF_REQUEST`.
3. **Hand over to HyperFrames** — load `hyperframes`, pass the fenced block of `HF_REQUEST` unchanged. It skips the three storylines (the story is the locked edit), writes `SPEC.md`, and asks for **one top-level layer per element** with the exact names of `layers_<Title>.json`, a `solo` variable, and transparent silent output. The user confirms HyperFrames' SPEC summary before anything is built.
4. **Build** — Motion Studio §4 (HyperFrames' `check --json` clean, `snapshot --review` → `REVIEW.md`), then `sync-text.mjs videos/<name> --variables` once. **Preview:** start HyperFrames Studio's preview in the background as soon as the first build renders and return `STOP preview` with its `LINK:` (§1 E preview link rule) — the user watches it while HyperFrames finishes and during every change. Check in `index.html` that every layer name exists once and that `solo` hides the others (one test render of a short layer with `--variables '{"solo":"<name>"}' --quality draft`, or by eye in the preview).
5. **Review and change** — Motion Studio §5 (Studio tips in Vietnamese, opening with the preview link). Words, colours, sizes, positions: in Studio or by chat. A move in **time** beyond the element's anchor is a cut change → back to a new Draft in Resolve. **No music step.**
6. **Export — when the user says so** (stop ③, or "xuất", "render đồ họa"), then steps 6–9 run without stopping:
   a. `sync-text.mjs videos/<name>` (exit 2 → ask which wording to keep).
   b. The whole overlay for review: the render line in `HF_REQUEST`.
   c. **One MOV per layer**, full length, `solo` = the layer name, into `videos/<name>/renders/layers_full/<layer name>.mov`: copy `<package>/layers_rows.json` into the project, then the batch line in `HF_REQUEST` (`render --batch layers_rows.json --format mov --fps <render_fps_arg> --output "renders/layers_full/{name}.mov" --strict-variables`; HyperFrames' `compare-and-batch.md`). Its `manifest.json` lists each row's status; a failed row → that layer alone with `--variables '{"solo":"<layer name>"}' --output renders/layers_full/<layer name>.mov`.
   d. **Trim and check:** `python3 -I <skill>/scripts/hf_layers.py <package>/layers_<Title>.json <package>/videos/<name>` cuts each to its span into `<package>/layers/<layer name>.mov` (stream copy, frame-exact) and checks prores, alpha, size, frame count, no audio. Any problem → re-render that layer, never "close enough".
   Studio's Export button is the user's alternative for the whole overlay only (it must be MOV with transparency). Claude never renders the Final film.
7. **Look** — 3–4 frames of the layers laid over the matching Final stills (`ffmpeg -i still -i layer -filter_complex overlay`), to check readability on real footage.
8. **Placing in DaVinci** — already answered at stop ③ (no separate question): Claude đặt vào Draft mới, or Tôi tự đặt.
   "Tôi tự đặt" → Claude only imports the files into bin "Đồ họa (HyperFrames)" with their colours (no timeline change) and lists start frames and tracks. Otherwise, never on the Final: `timeline_ops.py` next_draft (duplicate of the Final), then MODE `place_media` with `MEDIA` = the `media` list of `layers_<Title>.json`. Each layer lands at its start frame on its named track (V3 up: "ĐH Chuyển động", "ĐH Chữ", "ĐH Tiêu đề", "ĐH Phụ đề", a "2" track when two of one kind overlap), with its name and colour on the item and the pool clip, bin "Đồ họa (HyperFrames)". The MOVs are rendered at the Final's exact rate (`--fps 30000/1001` for 29.97), so no Clip Attributes change is needed. Then `qa_audit.py` with `GRAPHICS_PLACED = True` and `GRAPHICS_TRACKS` = the layer tracks, `qc_stills.py` PAGE "edit", then the Draft review and the Final approval again.
9. **Report** (≤ 12 lines) — the layer list (name · colour · track · frames), check numbers, what was looked at, what is unverified, and the colour key below. Another job (a 16:9 version, a second language) continues in this chat through a new build agent with the folder name; never propose `/clear` or a new chat.

## 4. Names and colours (fixed, so the user recognises them anywhere)
| Kind | Name part | Clip colour | Track |
|---|---|---|---|
| Tiêu đề chính | `TieuDeChinh` | Orange | ĐH Tiêu đề |
| Văn bản mở đầu | `MoDau` | Apricot | ĐH Tiêu đề |
| Tiêu đề phần | `TieuDePhan` | Purple | ĐH Tiêu đề |
| Chữ trên hình | `ChuTrenHinh` | Blue | ĐH Chữ |
| Chú thích | `ChuThich` | Navy | ĐH Chữ |
| Phụ đề (one layer per cue) | `PhuDe` | Teal | ĐH Phụ đề |
| Đồ họa chuyển động | `DoHoaDong` | Pink | ĐH Chuyển động |
| Hình hỗ trợ | `HoTro` | Tan | ĐH Chuyển động |
Green (music) and Yellow (SFX) are never used for graphics. A name is `DH` + order of appearance + kind + the first words without marks, e.g. `DH01_TieuDeChinh_HuongCang`; the same name is used in HyperFrames (layer id), for the file, the pool clip and the timeline item. To change one object later: edit it in the HyperFrames project, render only that layer (`solo`), re-run `hf_layers.py`, replace that clip in a new Draft.

**Tools:** the `motion-studio` skill (shipped in `<skill>/motion-studio/`, installed by `install_motion_studio.py`) and the `hyperframes` skills; `hf_layers.py`; ffprobe/ffmpeg from Motion Studio; `timeline_ops.py` next_draft / place_media, `qa_audit.py`, `qc_stills.py` for step 8.
**Read when needed:** Motion Studio `SKILL.md`, `references/handoff.md`, `references/review-and-export.md`, `references/style-from-reference.md`; `references/hyperframes-handoff.md` §8–§9.
**Done when:** every layer MOV passes `hf_layers.py`, overlay stills were looked at, and the layers are placed with names and colours in a Draft (or the user chose to place them), and the report is sent.
