# Phase 9 — Quality control and draft review

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** a technical verdict and a separate editorial verdict, then the user's review of the Draft.

## Steps
1. **Technical verdict** — `qa_audit.py` (runtime, gaps, black frames, silence, overlaps, source bounds, graphic tracks empty, music coverage) and a quality-control sheet (first frame, the frame after every cut, last frame) with `qc_stills.py`; audio check (`audio_presence.py`).
2. **Editorial verdict** (`editorial-decision-and-qc.md`) — the B-roll layer (V2 cutaways present and meaningful), the speed-ramp and zoom plan built, SFX only on transitions, cut reasons, early or late cuts, spare shots, even rhythm, effect overload, hook / payoff / peak / release / ending, retention, repeats. Report both verdicts, never merged. Main session not Opus-class → the editorial verdict comes from the judgement agent A5 (`opus`) reading the QC sheet, blueprint and contract by path.
3. **Scorecard** (`review-scorecard.md`) — story clarity, shot choice, pacing, continuity, music sync, sound, effects, colour, open issues.
4. **Draft review** (stop, `options-playbook.md` §7) — the user watches the Draft with sound. Each note goes through the change router into the next `Draft_<Title>_vNN` (`timeline_ops.py` next_draft), naming shots by `shot_NN`; check only what changed; at most two loops. Taste rules → `prefs_set {"lessons": …}`.

**Tools:** `qa_audit.py`, `qc_stills.py`, `audio_presence.py`, `timeline_ops.py` next_draft.
**Read when needed:** `references/editorial-decision-and-qc.md` (always), `references/review-scorecard.md`, `references/visual-qc-loop.md`.
**Done when:** `qa_audit` STRUCTURAL PASS, the editorial verdict has no blocker, scorecard written, Draft review answered.
