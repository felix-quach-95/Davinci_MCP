# Express runbook — the call sequence (v3.10.1)

One line per tool call unless marked. Read only the summaries; open only the images listed in `look`. Maximum video length: 30 seconds. Stops are in **bold**.

| # | Phase | Call | Stop |
|---|---|---|---|
| 0 | — | New session: `STATUS.md` exists → read it and `project.json`, jump to its "Next" | — |
| 1 | 1 Intake and footage check | `python3 -I <skill>/scripts/stage.py` | — |
| 2 | 1 | `phase_run.py` MODE p1 (blockers only: empty pool, wrong footage, frame rate or size before the first timeline) | ask only if blocked |
| 3 | 1 | Footage subagent: scan (`footage-subagent.md` pass 1) | — |
| 4 | 1 | Five style options from the scan, one strip image each (`options-playbook.md` §2) | **Style choice** |
| 5 | 1 | `music_intake.py`; the user's music found → skip. Otherwise send `music_request(style)` and wait (`options-playbook.md` §3) | **Music request** |
| 6 | 2 Music analysis | `music_library.py` analyse + `silence_beats.py` beats | — |
| 7 | 3 Footage catalogue | Footage subagent: deepen (`footage-subagent.md` pass 2) | — |
| 8 | 4 Story decision | Story contract, two structures compared, one strip per structure | **Story approval** |
| 9 | 5 Shot selection | Blueprint (V1 spine, `fx_plan` per shot, V2 B-roll cutaways) → `phase_run.py` MODE p6 (analysis incl. `broll_report` and `fx_report`, dry run) | — |
| 10 | 6 Draft build and rough-cut review | `phase_run.py` MODE p6 `build: true` (names `shot_01` …, ramp steps `shot_03a/b`, music Green), burned-text stills of every B-roll → `text_checked`, reframe, rough-cut sheet | — |
| 11 | 7 Accents and sound | `phase_run.py` MODE p7 (zoom moves and accents from `fx_plan`, 7–10 transition SFX only in Yellow, ending, audio check) | — |
| 12 | 8 Technical colour | `phase_run.py` MODE p8, then MODE p8 `apply: true` | — |
| 13 | 9 Quality control and draft review | `phase_run.py` MODE p9 | **Draft review** |
| 14 | 10 Final and hand-over | `phase_run.py` MODE p10 `draft` (Final copy, compare, cleanup plan) | **Final approval** |
| 15 | 10 | `finalize_project.py` apply (plan token) | — |
| 16 | 10 | `hyperframes_handoff.py` → brief (only for approved graphics) | brief approval |
| 17 | 10 | `qc_stills.py` (element frames) → `hyperframes_handoff.py` again with `stills` + `package_dir` → `HF_REQUEST`, `START_PHASE11.md`; kickoff line into `STATUS.md`, `layers_<Title>.json` | report + **Phase 11 question** (`phase-11.md` §1) |
| — | 11 (same chat) | gallery with pictures (main chat) → graphic questions → brief + package → build agent: `hyperframes` SPEC (one named layer per element, `solo`) → build → Studio review → export on request: overlay + one MOV per layer → `hf_layers.py` trim + check → overlay stills → place in a new Draft (names, colours, named tracks) | relayed stops: brief, review, export, placing |

A PARTIAL result is resumed by repeating the same call. If the same step stays PARTIAL (a step estimated over the time budget), call its tool directly. The MCP reply times out after 10 s; a longer step still finishes in Resolve — on "timed out" read `STATUS.md`, never re-run the step blindly. Standard mode adds the kickoff questions (after call 2), the rough-cut approval (after call 10) and the hero accent choice (inside call 11). Lists longer than 4 options are a numbered message.
