# Phase 3 — Footage catalogue

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** turn the Phase 1 scan into a catalogue of **shots with IDs** (`C03.S02`): action stages (begin, develop, peak, end), emotion, motion, composition, gaze and direction, exact in/out points from SEEN frames, frames to keep, handles, role scores (hook, setup, development, peak, release, ending, bridge), image group (`grp`), effect suitability (speed ramp, slow motion, zoom in, zoom out) and several *different* B-roll shots mined from each clip (`footage-intelligence.md` §7). Every statement is labelled SEEN / INFERRED / UNVERIFIED.

## Steps
1. Read the scan; mark clips that need a closer look (many moments, B-roll-rich, ramp or zoom candidates, people and gaze).
2. Dense frames (about 2 per second) on those stretches — `frame_probe.py` MODE `range`, or ffmpeg at subclip positions — then the footage deepen agent A2 (`sonnet`, parallel batches of ≤ 4 sources when there are many; `footage-subagent.md` pass 2) returns shot rows; the main session keeps only that text.
3. Scene cuts on long clips (`picture_tools.py`), `transcript_cut.py` for talking footage, `composition_check.py` on hero candidates, `color_look.py` plan (gamma per clip).
4. Mine each clip (reframes, detail inserts, gaze targets, textures, entries and exits, bridges) and assign image groups; speed or crop variants of one picture stay in one group. Mine **at least 2× the B-roll cutaways the plan needs** (30 s → about 16), each with a `broll_type` and the V1 moment it can cover (`broll.md` §0a).
5. Report counts: shots, SEEN / INFERRED / UNVERIFIED, shots per size, hook / peak / ending candidates, burned-in text, subjects lost in the 9:16 crop, gaps for the Story approval. Never invent content, timestamps or visual details.

**Tools:** `frame_probe.py`, `qc_stills.py`, `picture_tools.py` scene_cuts, `color_look.py` plan, `transcript_cut.py`, `composition_check.py`, footage subagent.
**Read when needed:** `references/footage-intelligence.md` (always), `references/broll.md`, `references/visual-qc-loop.md`, `references/transcript-editing.md`, `references/reference-analysis-and-match.md`.
**Done when:** every source has a clip row (one per duplicate group) and shot rows with IDs, in/out from SEEN frames, roles, `grp` and `fx`; at least 1.5× the shots the plan needs in at least 3 sizes (or the shortfall is reported); hook, peak and ending candidates exist or the gap is listed.
