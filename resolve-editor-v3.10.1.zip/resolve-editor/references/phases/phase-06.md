# Phase 6 — Draft build and rough-cut review

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** `Draft_<Title>_v01` built from the blueprint, read back, named and coloured, and judged as a story before any polish.

## Steps
1. **Analysis and dry run.** `project_set {"blueprint": bp}` then `phase_run.py` MODE `p6` with `ARGS = {"beats_s": [...]}`: `edit_analysis.py` notes (cut reasons, even rhythm, size runs, repeats) and a dry run. Resolve every note or accept it with a reason.
2. **Build.** The same mode with `"build": true` (or `build_from_blueprint.py` directly). The build reads back every item and then **names the video items left to right** (V1 `shot_01`, `shot_02` …, V2 `broll_01` …) and colours the music Green. V2 cutaways are built in the same call (`broll_01` …).
3. **Reframe.** New timeline or source size → `picture_tools.py` MODE `pan_calibrate` first (the Pan constant is not portable); then Pan, Zoom and Tilt per shot, written back into the blueprint `props`.
4. **Burned-text check** — stills of the first, middle and last frame of every V2 cutaway (and of any V1 shot from a subtitled clip), read by the stills-check agent A3 (`sonnet`, `agents-and-models.md`) so these images never enter the main context; `unsure` → open that one still; text found → another range or zoom/tilt it out, check again; then set `text_checked: true` on the segment.
5. **Rough-cut review** (`editorial-decision-and-qc.md` §2): middle-frame sheet of every shot; judge story, beats, repeats, rhythm, variety, the B-roll layer (stills of every V2 cutaway) and framing (subject in frame, no burned-in text) before any accent, SFX or colour exists. Fix by the smallest scope (§7). The main session reads the one middle-frame sheet; it does not re-open the A3 stills. Main not Opus-class → the verdict comes from A5 (`opus`).
6. **Rough-cut approval** — Standard mode asks (`options-playbook.md` §5); Express auto-approves when the analysis has no open note, the read-back matches and the review finds no blocker, and sends the sheet as information.

**Tools:** `edit_analysis.py`, `build_from_blueprint.py`, `qc_stills.py`, `picture_tools.py` pan_calibrate, `replace_shot.py`, `timeline_ops.py`.
**Read when needed:** `references/editorial-decision-and-qc.md §2–4, §7`, `references/shot-selection-and-continuity.md §6`, `references/montage-advanced.md`, `references/composition.md`, `references/brief-template.md`, `references/vertical-frame-checklist.md`.
**Done when:** Draft_v01 built and read back with `shot_NN` names; analysis notes resolved or accepted; the rough-cut review says ROUGH-CUT OK; rough cut approved.
