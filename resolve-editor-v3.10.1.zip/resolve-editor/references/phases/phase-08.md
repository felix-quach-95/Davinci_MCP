# Phase 8 — Technical colour

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** a clean, consistent picture as a base for the user's later creative grade — no look.

## Steps
1. **Plan** — `color_look.py` MODE `plan`: source gamma per item; LOG or HDR → conversion LUT (MODE `apply`).
2. **Measure** — MODE `measure`: luma median, 98th percentile, clipped and crushed share, near-neutral pixels, suggested slope per item.
3. **Decide** — white balance only from enough neutral pixels and only when the cast is a real error (an even, intentional cast across a graded source stays); exposure only for outliers against the sequence, capped below clipping. A softer slope than suggested is fine when it keeps a day/night feeling.
4. **Apply** — MODE `balance` with `ITEMS` and `OVERRIDE_SLOPE`, in colour version `claude_look`.
5. **Verify with numbers** on stills (mean luma, highlights, no clipping), before and after.

**Tools:** `color_look.py` plan / apply / measure / balance, `timeline_ops.py` compare, `qc_stills.py`.
**Read when needed:** `references/color-look.md`.
**Done when:** every item measured; corrections applied in `claude_look` and verified with numbers; skipped corrections explained.
