# Phase 4 — Story decision

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** the story chooses the shots — never the other way round. Everything that sets timing is decided on paper and approved before anything is built.

## Steps (`story-decision-framework.md`)
1. **Story contract** — subject and message, how the viewer changes, emotional line (first → peak → last feeling, in the register of the chosen style), boundaries, runtime at most 30 s.
2. **Runtime budget** on the music map: hook, setup, development, peak, release and ending placed on measured phrases and hits.
3. **Story spine and beat map** — each beat's job, what changes, its *but/therefore* link, candidate shot IDs, label (documented / interpretation / needs more footage), and the paper edit.
4. **Mode** — causal or associative, with the named linking device for associative chapters.
5. **Checks** — missing information, repeated information, repeated footage, stalls, flat arc, late hook, two stories.
6. **Two structures compared** on the real catalogue (scoring matrix), each shown as a still strip. Main session not Opus-class → the judgement agent A5 (`opus`, `agents-and-models.md`) builds and scores the two structures from the files; the main session presents them.
7. **Story approval** (stop, `options-playbook.md` §4): structure, hook, ending, runtime. Style and music are only confirmed. Nothing is built.

**Tools:** `edit_analysis.py` (story check, repeat report), loader `project_set`.
**Read when needed:** `references/story-decision-framework.md` (always), `references/story-structure.md`, `references/storytelling-montage.md`, `references/viral-shortform-formats.md`, `references/endings.md`.
**Done when:** the definition of ready in `story-decision-framework.md` §7 is checked and recorded (`story.ready`): contract, mode, complete beat map with shot candidates or explicit gaps, runtime at most 30 s with the drop time, no repeated fact or shot group, hook / peak / ending shots exist, Story approval answered.
