# Phase 1 — Intake and footage check

Phase card (v3.10.1): read it when the phase starts; the core rules stay in SKILL.md.

**Goal:** know what footage exists, fix blockers before the first timeline, then get the two opening answers: the **Style choice** and the user's music (**Music request**).

## Steps
1. **Resume check.** `Cache Edit/<Title>/STATUS.md` exists → read it and `project.json`, continue from "Next". Otherwise stage the tools: `python3 -I <skill>/scripts/stage.py`.
2. **Intake call.** `phase_run.py` MODE `p1` (`ARGS.named_paths` = any path the user named): stage check, lessons, inventory, music check, overview sheet — one summary. Read `_prefs.json` (`prefs_get`) and apply its lessons; say which.
3. **Blockers only.** Empty pool → stop and ask. Frame-rate mismatch or low-resolution sources → ask **before** the first timeline exists (it locks the project frame rate). Duplicate media → use one item per group. Confirm the project and footage identity (hard rule 2). Standard mode asks the kickoff questions here (`options-playbook.md` §1). Never ask about titles, subtitles or animation.
4. **Runtime and format.** At most 30 seconds (`workflow.max_runtime_s`); 9:16 unless the brief says otherwise.
5. **Research (optional, `trend-research.md`)** when the video aims at reach or the hook is open — free-first: vidIQ only on the plan's **free credits** (`vidiq_balance` first; budget min(30, renewable); priority: `vidiq_instagram_tiktok_outlier_search` hook mode, Vietnamese Shorts momentum, keyword demand, one shortform walkthrough; ToolSearch `vidiq`, never guess tool names); whatever free credits do not cover → **switch to the free sources on your own** (TikTok Creative Center, TikTok/YouTube search pages, Google Trends, web; TikTok Studio retention only with the user's OK); never ask to buy credits, never block the edit; topic words only; read-only; never call vidIQ tools that upload, publish, reply or generate media. `research_card.py` → the Research Card. Run it in the research agent A4 (`haiku`, `agents-and-models.md`): only the card comes back, the raw results stay out of the main context.
6. **Footage scan.** The overview sheet plus a first scan of every clip by the footage scan agent A1 (`haiku`, `footage-subagent.md` pass 1). The scan never sets in/out points. Media Pool subclips: extract frames with ffmpeg at each subclip's Start/End (`frame_probe.py` reads subclips from frame 0 of the file).
7. **Style choice** (stop). Five style options built from the scan, one strip image each, plus option 6 "Tự viết phong cách của bạn" (`options-playbook.md` §2). Record `project_set {"style": …, "stops": {"style_choice": "<n>"}}` and `prefs_set {"choices": {"style": …}}`.
8. **Music request** (stop). `music_intake.py`: the user's music already found → name it and go on. Otherwise send one message from `music_request(style, runtime_s)` and **wait for the file** (`options-playbook.md` §3). Never propose, preview or download music. Record `project_set {"music": {"file", "chosen_by": "user"}, "stops": {"music_request": "received"}}`.

**Tools:** `stage.py`, `phase_run.py` p1, `inventory.py`, `music_intake.py`, `research_card.py`, the footage subagent, loader `prefs_get` / `project_set` / `prefs_set`.
**Read when needed:** `references/options-playbook.md §1–§3`, `references/footage-intelligence.md §1–2`, `references/style-profiles.md`, `references/ideation-playbook.md §1`, `references/trend-research.md`.
**Done when:** blockers resolved, footage scanned, style chosen, the user's music file received, and both answers recorded in `project.json`.
