# Resolve MCP Capabilities — Reported Baseline and Verification Plan

This document records historical user-reported information. It is not a guarantee for the current session. Discover current tool schemas and re-check API signatures every run.

## Previously reported tools
- `get_resolve_status`, `launch_resolve`
- `run_script`: sandboxed Python with pre-injected `resolve` and `project`; filesystem/network/process access blocked.
- `run_script_unsafe`: filesystem/network/subprocess access.
- `get_scripting_api`, `search_scripting_api`, `get_scripting_docs`, `get_whats_new`
- `list_luts`, `list_dctls`, `generate_lut`, `update_dctl`, `delete_lut`, `delete_dctl`

## Historically reported operations
- Read project, timeline, media-pool clips, clip properties, and project settings.
- Create empty timeline and append sub-clips using source in/out.
- Delete timeline clips, add tracks, change speed with ripple, create compound clips, apply CDL grades, set some properties, add some transitions.
- `InsertFusionTitleIntoTimeline("Text+")` worked in one reported session; `InsertTitleIntoTimeline("Text")` returned `False`.
- Fusion tools, inputs, and keyframes were manipulated and read back.
- `CreateSubtitlesFromAudio` and `GetCreateSubtitlesFromAudioStatus` were used; language detection can be unreliable.
- Audio track creation, music import/placement on A2, `AudioVolume`, and an audio transition were reported working.
- Metadata, frame-export/thumbnail, save, and render APIs appeared in stubs but were not fully tested.

## Status in v2.2 (2026-10-25)
- Images reach Claude by writing a JPEG/PNG and reading it with the Read tool (Claude Desktop with file access, or a linked cloud session with folder access to `~/Movies/ClaudeQC`) — verified since v1.4 (`visual-qc-loop.md`). The MCP itself still returns text/JSON only.
- ffmpeg/ffprobe are installed in `~/.local/bin` (2026-10-25); re-check each session.
- Verified live: inventory, build from ranges (fps-aware, exclusive endFrame), speed/ramps, Fill/Pan, fades, transitions, Text+ in nested timelines, clip-comp effects, LUTs/versions, stills, SFX/music placement, DuplicateTimeline. Stub-only (v2.2 scripts): render/verify, transcription-driven cuts, ducking, scene cuts, Smart Reframe, Stabilize (`api-cookbook.md` §13e).

## Important limitations (historic baseline, kept for context)
- MCP output returned text/JSON and had not demonstrated image content delivery to Claude. A file on disk is not equivalent to an image Claude can inspect (solved by the Read route above).
- A prior environment did not have `ffmpeg`/`ffprobe` (solved 2026-10-25).
- No dedicated edit/save/render tool was listed; these actions used Resolve scripting and require runtime verification.
- Timeline item end-trimming was reported unsupported; construct source ranges deliberately or verify another route.
- Some transitions returned `False`; do not assume success.
- Subtitle appearance, many OpenFX effects, title track placement, and render playback may be unverified.

## Required live capability inventory
For each operation record: tool/API method, exact signature, read-only or mutating, test result, read-back evidence, visual verification status.

Check:
- Resolve status and project identity
- Media Pool enumeration and source paths
- Clip metadata and duration conversion
- Frame extraction and actual image handoff
- New timeline creation
- Source-range insertion
- Track assignment
- Fusion Text+ insertion and node/input/keyframe control
- Subtitle generation/status/read-back
- Audio import/placement/volume/fade
- Save, render settings, render queue/status
- Output path and duration verification

Never mark an operation tested because it appears in a stub or documentation. Mark `TESTED` only after a low-risk call and state read-back; otherwise `DOCUMENTED/UNTESTED`, `UNKNOWN`, `UNSUPPORTED`, or `FAILED`.

## v1.4.0 additions (stub-verified 21.1.1, behaviour untested unless noted)
- `MediaPoolItem.TranscribeAudio()` / `GetTranscription()` (word timings) and `Project.GetTranscribeAudioStatus()`.
- `Timeline.CreateSubtitlesFromAudio(AutoCaptionSettings)` with `resolve.AUTO_CAPTION_VIETNAMESE`.
- `TimelineItem.SetFades/GetFades`, `AddTransition(TransitionOptions)`, `SetSpeed/GetSpeed`, `SmartReframe()`, `Stabilize()`.
- `Project.ExportCurrentFrameAsStill(path)`, `Timeline.GetCurrentClipThumbnailImage()` (base64).
- `Timeline.NormalizeAudioLevel`, `SetVoiceIsolationState`, `DetectSceneCuts`.
- `Project.GenerateSpeech` (native TTS; off by default).
- Fusion: `Operator.AddModifier(input, "BezierSpline")`, `SetInput(id, value, time)`, `GetInput(id, time)`, `Composition.StartUndo/EndUndo`, `GetToolList(selected, regid)`, `FindTool(name)`. No `FindToolByID`.
Full recipes: `api-cookbook.md`.
