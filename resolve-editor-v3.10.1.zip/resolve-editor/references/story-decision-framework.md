# Story decision framework — the story picks the shots (v3.2.0)

Order of authority: **story contract → structure → beat map → shot selection**. A shot is never chosen first because it is beautiful and then forced into a story. If a beautiful shot has no job, it is cut or kept as a bridge, and the report says so. Complements `story-structure.md` (spine, acts, arc, retention) and `storytelling-montage.md`; this module is the decision procedure that runs in Phase 4 and ends with a checklist that must be green before Phase 5.

## Contents
1. The story contract
2. Runtime budget for videos up to 30 s
3. Story spine, beat map and paper edit
4. Causal story vs associative montage
5. Finding gaps, repeats and stalls
6. Comparing structures on the real footage
7. Definition of ready (exit criteria for Phase 4)
8. What to show at the Story approval

## 1. The story contract
Write it before looking at structures. Four lines, each one sentence, in the user's language:
1. **Subject and message** — what the video is about and the one thing it says ("a roastery at dawn is a ritual, not a factory").
2. **Viewer change** — what the viewer knows, feels or wants at the end that they did not at the start ("from curiosity to wanting to be there").
3. **Emotional line** — first feeling → last feeling, plus the **peak** feeling in between (calm → tension → awe → warm). Pick from the style chosen at the Style choice (`style-profiles.md`): the style decides the register, the contract decides the arc.
4. **Boundaries** — what is deliberately left out and the maximum runtime (**≤ 30 s** unless the user said otherwise).
Mark each line **documented by the footage** (the catalogue shows it), **interpretation** (a reading of the footage) or **needs more footage**. A contract with a "needs more footage" message line is the Story approval question, not something to paper over.

## 2. Runtime budget for videos up to 30 s
Short pieces have no room for a second idea. A starting budget (adjust to the music phrases, `music-analysis.md`):
| Runtime | Hook | Setup | Development | Peak | Release + ending | Shots (ASL 1.8–3 s) |
|---|---|---|---|---|---|---|
| 15 s | 0–2 s | 2–5 s | 5–10 s | 10–12.5 s | 12.5–15 s | 6–9 |
| 20–25 s | 0–2.5 s | 2.5–6 s | 6–15 s | 15–19 s | 19–25 s | 9–13 |
| 30 s | 0–3 s | 3–8 s | 8–19 s | 19–24 s | 24–30 s | 11–16 |
Rules: one idea per video; the first image must work without context (§1 of `footage-intelligence.md` role *hook*); the peak sits on a music hit or phrase turn; the release is at least one phrase long; the ending never stops suddenly (`endings.md`).

## 3. Story spine, beat map and paper edit
**Spine** (one line, "because/therefore", not "and then"): *We start at ___; because ___, we move to ___; therefore ___; the video ends at ___.*
**Beat map** — one row per beat, 5–9 beats for 30 s:
| Beat | Time | Job (hook/setup/dev/peak/release/ending) | Viewer question it answers | What changes (info · scale · emotion · place · time) | Link to previous (but/therefore/and-then) | Evidence |
Rules for every row:
- **What changes** must be filled. A beat that changes nothing is a stall (§5).
- **Link** must be *but* or *therefore* (causal) or a named associative device (§4). "And then" alone is a list, not a story.
- **Evidence**: shot IDs from the catalogue that could serve it (2–3, ranked later in Phase 5) and a label *documented / interpretation / needs more footage*. A beat with no candidate is a gap.
**Paper edit** (`story-structure.md` §10): the beat map plus planned length, cut-on reason and sound per beat. It is the only thing shown at the Story approval; no timeline is touched.

## 4. Causal story vs associative montage
| | Causal (narrative) | Associative (montage of ideas) |
|---|---|---|
| Links | each beat is the result or complication of the last (*but / therefore*) | each beat is tied to the last by a **device**: shape, colour, motion direction, sound, theme, a repeated gesture, contrast |
| Good for | process, journey, a day, a reveal | mood pieces, cities, travel, many short images and one feeling |
| Risk | needs enough information shots in order | feels random if the device changes every cut |
Decide per video (and per chapter, never per cut):
1. State the mode in the contract: *causal*, *associative* or *causal frame with associative middle*.
2. In associative sections name the device (`link` field in the blueprint: `shape`, `colour`, `motion`, `sound`, `theme`, `contrast`, `callback`) and keep it for ≥ 3 cuts before changing; at a change of device put a bridge (wipe, defocus, sound).
3. Do not mix inside one chapter without a bridge: a causal beat followed by an unrelated pretty image reads as a mistake.
4. Associative montage still needs **progression**: intensity, scale, speed or light must move in one direction across the chapter, or the chapter is wallpaper.

## 5. Finding gaps, repeats and stalls
Run these checks on the beat map before choosing shots. Each failure produces a named note, not a silent fix.
| Check | Question | Fix |
|---|---|---|
| **Missing information** | would a first-time viewer ask where / who / what / why at any beat? | add a setup or detail beat; or remove the claim that needs it; list "needs more footage" |
| **Repeated information** | is the same fact or image idea shown twice (information ledger: one line per fact → beat)? | merge beats; make the second show a *different consequence*, or cut |
| **Repeated footage** | does a catalogue shot, its image group or a speed/crop variant of it appear twice? | one shot per group (`shot-selection-and-continuity.md` §6); a deliberate callback is declared |
| **Stall** | does the beat change nothing (info, scale, emotion, place, time)? | cut it, shorten it, or give it a job (a ramp into the next beat, a push that reveals) |
| **Flat arc** | is the intensity the same in every beat? | assign tension 1–5 per beat (`bp["arc"]`); the peak must be the highest; a release must follow |
| **Late hook / no payoff** | does the first beat promise something the last beat delivers? | rewrite the contract or move the payoff earlier |
| **Two stories** | are there two messages? | keep the stronger one; the other becomes B-roll detail or goes |

## 6. Comparing structures on the real footage
Offer 2–3 structures (not templates): e.g. *hook → context → development → result*; *problem → tension → discovery → resolution*; *set-up → escalation → turn → conclusion*; *chronological*; *thematic/associative*; *reverse (result first, then how)*. Fill this matrix from the catalogue, **before** showing anything:
| Criterion (0–3) | A | B | C |
|---|---|---|---|
| Real hook shot exists (role hook ≥ 2) | | | |
| Real peak shot exists (role peak ≥ 2) | | | |
| Beats covered by *different* shots (no group used twice) | | | |
| Ending shot exists and mirrors/answers the hook | | | |
| Effect opportunities that serve the style (ramp / push / pull on shots with `fx`) | | | |
| Footage left unused with a reason | | | |
| Fit with the contract's emotional line | | | |
Pick the structure with the best evidence, not the most familiar one; show the top two as 4–6 still strips with runtime and drop/peak time (`options-playbook.md` §2), each beat tagged documented / interpretation / needs more footage. If every structure scores 0 on a row, that row is a finding for the user.

## 7. Definition of ready (exit criteria for Phase 4)
Phase 5 (shot selection) may start only when all are true; record them in `project.json` (`story.ready`):
- [ ] Story contract written (4 lines) and the style from the Style choice named.
- [ ] Mode stated (causal / associative / mixed) and, for associative parts, the device.
- [ ] Beat map complete: every beat has job, what-changes, link, ≥ 1 candidate shot ID or an explicit gap.
- [ ] Runtime ≤ 30 s (or the user's number); beat times sum to it; peak and drop time set on music phrases.
- [ ] Information ledger has no repeated fact; no shot group is needed twice.
- [ ] A hook shot, a peak shot and an ending shot exist, or the gap is listed.
- [ ] Gaps are resolved, accepted by the user, or turned into questions.
- [ ] Hook, music (already chosen at the Music request), ending and runtime are confirmed at the Story approval.

## 8. What to show at the Story approval
Two structures as strips (≤ 6 stills each, shot IDs under the stills), the contract in four lines, runtime and peak time, the list of gaps, and the question set (≤ 4): structure · hook · ending · runtime. No timeline exists yet; changes are free here and costly later (`options-playbook.md` §7).
