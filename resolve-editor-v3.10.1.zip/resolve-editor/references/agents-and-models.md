# Agents and models (v3.8.0) — who runs what, on which model

One page, the single source for agent use. Model names are the Agent tool's: `haiku` (cheapest, simple reading), `sonnet` (vision detail, building, routine judgement), `opus` (story and editorial judgement). `fable` is never used here. Config: `config/defaults.json` → `models`.

## 1. Roster
| ID | Agent | Phase / step | Model | Input (paths, never pasted content) | Returns |
|---|---|---|---|---|---|
| A0 | Main session (orchestrator) | all of session A; relays in Phase 11 | the user's choice (recommended below) | — | — |
| A1 | Footage scan | 1 · step 6 | `haiku` | overview + per-clip contact sheets | scan JSON (≤ 6 moments per clip) |
| A2 | Footage deepen | 3 · step 2 | `sonnet` | range sheets + the scan rows of those clips | shot JSON (catalogue) |
| A3 | Stills check (burned text, subject in frame) | 6 · step 4; after every `replace_shot` | `sonnet` | still paths + segment ids | one line per segment: `none` / `text: where` / `unsure` |
| A4 | Research | 1 · step 5 (optional) | `haiku` | topic words, credit budget, `trend-research.md` | the Research Card (≤ 30 lines) |
| A5 | Judgement (only when A0 is not Opus-class) | 4 · step 6; 6 · step 5; 9 · step 2 | `opus` | contract, `catalogue.json`, music map, blueprint, the sheet | structures / verdict JSON |
| A6 | Phase 11 builder | 11 (option 1) | `sonnet` | the package | `STOP <kind>` reports (≤ 8 lines) |

Not delegated (A0 always): the stops and every question to the user, Resolve writes and read-backs, the change router, `project.json`/`STATUS.md`, and — when A0 is Opus-class — story, shot selection and editorial verdicts. Scripts (`phase_run.py`, music and audio analysis, `edit_analysis.py`, `hyperframes_handoff.py`, `hf_layers.py`) need no model.

## 2. Main-session model (the user sets it; the skill cannot)
- **Session A (Phases 1–10):** Opus-class gives the best story and editorial judgement in one context (A5 is then skipped). Economy profile: Sonnet main + A5 on `opus` for the three judgement steps — most calls are tool calls and short summaries, so this is usually the cheaper setup; the judgement still runs on Opus.
- **Phase 11 without the Agent tool (run in the same chat):** no new session is ever proposed; the main session runs the build itself.
- Claude reads its configured model from its system prompt; unknown → treat A0 as not Opus-class.

## 3. Rules that keep tokens down (every agent)
1. **Depth 1.** Only A0 starts agents. An agent never starts another agent; if a skill it follows (e.g. HyperFrames) suggests subagents, the agent does those steps itself.
2. **Brief by reference.** The Agent prompt is ≤ 12 lines: which section of which file to follow (`footage-subagent.md` Pass 1, `phase-11.md` agent brief …) plus the paths and numbers. Never paste a template, a catalogue or a JSON file into a prompt — it would stay in A0's context for the whole session.
3. **Images once, in one turn.** Downscale to ≤ 1024 px first; read all images of a job in a single message (parallel Read calls) and never re-read. More than ~8 sheets → split into parallel agents of ≤ 4 sources each (one message, several Agent calls), not one long agent.
4. **Return only what A0 uses.** Compact JSON or ≤ 8 lines; everything else goes to a file under `Cache Edit/<Title>/` and is named by path. A0 opens an agent's file only through a script or `project_set`.
5. **A0 never opens images that an agent or a later phase owns** (Phase 10 package stills, layer renders). A0 opens only the `look` list of a phase run, one image at a time, and only for a decision.
6. **Finish in ≤ 3 turns** (A6 excepted). A failed or half answer is re-run once on the same model; then escalate (§4).

## 4. Escalation (quality guard)
| From | Escalate when | To |
|---|---|---|
| A1 `haiku` | a clip comes back without moments, "quality" unknown, or > 25 % of thumbnails "unseen" | that clip only, `sonnet` |
| A2 `sonnet` | a needed in/out is UNVERIFIED | A0 opens that one range sheet (`frame_probe.py` range) |
| A3 `sonnet` | `unsure` | A0 opens that one still |
| A4 `haiku` | the card has no hook pattern or no sources | `sonnet`, once |
| A5 `opus` | — | (top tier) |
| A6 `sonnet` | the user rejects the build's design twice for the same element, or the composition fails its own checks twice | a new A6 on `opus`, from the package and the HyperFrames project files (not the old agent's context) |

## 5. Prompts (≤ 12 lines each)
- **A1:** "Follow `<skill>/references/phases/footage-subagent.md` Pass 1. Read in ONE message: <overview>, <sheets>. Sources: <name: fps, frames, size>. Return only the JSON array."
- **A2 (per batch):** "Follow `footage-subagent.md` Pass 2. Read in ONE message: <range sheets>. Sources: <…>. Scan rows: path <scan.json> ids <…>. Return only the JSON array."
- **A3:** "Read in ONE message: <stills>. For each segment id (<id: still paths>) look at the whole frame, bottom centre and top for burned subtitles, captions, watermarks, logos, and whether the main subject is in frame. One line per id: `id · none` | `id · text: <where>` | `id · subject cut: <how>` | `id · unsure: <why>`. Nothing else."
- **A4:** "Follow `<skill>/references/trend-research.md` (free-first; vidIQ only within <budget> free credits; read-only; topic words only: <words>). Run `research_card.py`; return only the card."
- **A5:** "Follow `<skill>/references/<story-decision-framework.md | editorial-decision-and-qc.md> §<n>`. Read: <paths>. Return only <the structures JSON | the verdict JSON>."
- **A6:** the agent brief in `phase-11.md` §1.
