# Montage and rhythm — the lead editor's toolkit (v2.4)

Read at the paper edit (stage 4) together with `story-structure.md` and `composition.md`. `storytelling-montage.md` is the short entry; this file is the depth. Every rule ends in something buildable in this skill (blueprint fields, `motion_fx`, `edit_analysis.py`). Sources (summarised in our own words): Eisenstein's essays on montage methods; Kuleshov's and Pudovkin's experiments and linkage types; Walter Murch, *In the Blink of an Eye*; Edward Dmytryk, *On Film Editing*; Karen Pearlman, *Cutting Rhythms*; Bruce Block, *The Visual Story*; ACE / American Cinema Editors talks; StudioBinder, No Film School and Blackmagic Design training material.

## Contents
1. The editor's question: why cut here, why now
2. Cut-point anatomy: where inside the shot
3. The five montage methods with short-form recipes
4. Kuleshov and Pudovkin: meaning made by juxtaposition
5. Modern cut vocabulary
6. Rhythm: timing, pacing, trajectory
7. Music as the metric grid (frame math)
8. Writing it down: the `cut` field and `edit_analysis.py`

## 1. The editor's question
A cut is a decision with a reason. Before any cut is written into the blueprint, state:
- **What the cut does** (Murch's order of priority): emotion (the feeling of the moment is preserved or changed on purpose) > story (it moves the story: new place, time, information, feeling) > rhythm (it lands at the rhythmically right frame) > eye-trace (the viewer's eye finds the new subject without searching) > the 2-D plane (screen direction/axis respected) > 3-D space continuity. When two conflict, the higher one wins — a cut that breaks screen direction but keeps the emotion is right; the reverse is wrong.
- **What it cuts on** — one of: a **beat** (music hit/phrase), **movement** (action within the frame), a **gaze** (where a character looks), a **breath/thought end** (Murch's "blink": the moment a thought completes), a **sound** (a door, a word), a **contrast** (light/dark, still/moving), an **ellipsis** (time removed on purpose).
- **Why not one frame earlier or later.** Earlier = the feeling has not landed / the movement has not started; later = the viewer has already understood and is waiting (dead frames). In short-form the usual mistake is "later".
Dmytryk's rules, applied: never cut without a reason; when undecided between longer and shorter, choose shorter; cut on movement rather than on stillness; a fresh shot is better than a stale one; substance first, then form.

## 2. Cut-point anatomy
| Cut on | Exact frame | Why it works |
|---|---|---|
| Action (match on action) | outgoing: 1/3 into the movement (the hand starts to rise); incoming: the same phase of the same movement, overlapping 1–3 frames | the eye follows the movement and does not register the cut; a small overlap compensates the frames the eye "loses" at a cut |
| Movement through frame (exit/entry) | outgoing: when the subject's leading edge touches the frame edge (not after it has left); incoming: subject already 1–4 frames inside | empty frames after an exit are dead time |
| Gaze / eyeline | outgoing: the moment the eyes settle on the off-screen point; incoming: the object, placed where the gaze pointed | eyeline match creates space and intention (and the Kuleshov effect) |
| Emotion (reaction) | hold the outgoing face 4–12 frames after the line/realisation lands, then cut | the reaction is where the feeling is; cutting on the last word kills it |
| Beat | the cut frame = the beat's onset frame (±1); for a heavy downbeat, cut 1 frame BEFORE the onset so picture and sound are perceived together | the brain fuses picture change and sound attack |
| Breath / thought (speech) | in the pause after the thought, keep 4–8 frames of breath (`transcript_cut.py` pads) | cutting mid-breath feels like an interruption |
| Camera movement | during the move (pan/tilt/whip at peak velocity), not on its start or settle | movement-to-movement cuts read as one move |
| Static to static | when the information is read (≥ words × 0.3 s for text in frame; 0.8–1.5 s for a simple image) | — |

## 3. The five montage methods (Eisenstein) — short-form recipes
**Metric** — length alone, regardless of content; creates tension by acceleration.
- Recipe: lengths in whole beats on the music grid, shrinking toward the peak: 8-8-4-4-2-2-1-1 beats (or 4-4-2-2-1-1 at high BPM), then one long held shot as release. Lengths can also stay equal for a "march" feeling.
- Build: `section` "metric" segments with `dur` = beats × frames-per-beat (section 7); `edit_analysis.py` checks the ratios.
- Use: hooks, build-ups before a drop, countdown energy. Content still matters: put the strongest frame of each shot inside its slot (choose src_in so the action peak falls in the slot).

**Rhythmic** — cuts follow movement inside the shots; continuity of motion carries the eye.
- Recipe: cut on motion peaks; carry direction across cuts (left-moving → left-moving); vary lengths with the action, not the grid; a speed ramp lands its slow step on the action's peak.
- Use: traffic, cooking, sport, walking, hands at work.
- Build: `cut.on = "movement"`, segment `direction` ("L"/"R"/"up"/"down"/"in"/"out"); `edit_analysis.py` flags direction breaks inside a chapter unless the reason is `contrast`.

**Tonal** — shots are arranged by their emotional "tone": light, colour temperature, softness, speed of motion, sound texture.
- Recipe: sequence by gradual change of one tonal axis while the others stay close (affinity) — e.g. dusk blue → deeper blue → first warm window light → neon. A tonal *break* (contrast) marks a chapter change.
- Use: mood/travel pieces (the user's main type). Build: segment `tone` tags (e.g. "cool-dark-slow"); look stage keeps the grade consistent so the tone comes from the footage.

**Overtonal** — metric + rhythmic + tonal together; the sum creates a "feeling of the whole" (Eisenstein's overtone).
- Recipe: the climax chapter: shot lengths on the beat grid (metric), each cut on a motion peak (rhythmic), tone moving toward its extreme (tonal), sound layers thickening (riser → hit). Usually the last 20–30 % of a short piece.

**Intellectual** — A + B produce an idea C that neither shot contains.
- Recipe: pair a concrete image with another concrete image of a different world: crowd → herd, old hands → old tree bark, flickering neon → a heartbeat. Keep the pair short and clean (each ≥ 0.6 s so both are read), similar framing/position (graphic match) so the comparison is forced.
- Use: once per piece at most, at a turning point; it must not be obvious enough to feel like a joke unless that is the tone.
- Build: `cut.reason` includes `idea`; `cut.type` "graphic_match" or "contrast".

## 4. Kuleshov and Pudovkin
- **Kuleshov effect**: the same neutral face reads as hunger, grief or desire depending on the shot next to it. In a travel/mood piece the "face" is often the city: the same skyline after an old man reads as nostalgia, after a party crowd as excitement. Use it to make B-roll mean something: the shot BEFORE determines how the next one is read.
- **Pudovkin's linkage types** (constructive editing): contrast (rich/poor), parallelism (two unrelated lines shown side by side), symbolism (an image stands for an idea), simultaneity (two actions at once — cross-cutting toward a meeting), leitmotif (a repeated image/sound that returns with grown meaning — e.g. the bouquet seen early returns in the ending).
- Leitmotif is the most useful in short-form: plant an image in the first 20 %, return it in the last 20 % (bookend), slightly changed (closer, slower, other light).

## 5. Modern cut vocabulary (when, why, how to build)
| Cut | Use when | Build |
|---|---|---|
| Hard cut | default; invisible when motivated | blueprint boundary |
| Match cut — graphic | two shapes/positions rhyme (round tower → round wok) | place the shapes at the same frame position (`composition_check.py`), `cut.type` "graphic_match" |
| Match cut — action / position / scale / rotation | continue a movement or zoom across the cut | `motion-effects.md` §3c |
| Smash cut | abrupt contrast (quiet → loud, dark → bright) for surprise or comedy | no transition, sound changes on the same frame |
| Jump cut | time compression in one setup; intentional only with a change of scale/position or a beat | `transcript_cut.py` paced zoom; otherwise cover |
| Cross-cut / parallel | two lines of action, alternating with shrinking intervals toward convergence | sections A/B alternating; `story-structure.md` §4 |
| Cutaway / insert | a detail that informs or covers a seam | B-roll layer (`story-structure.md` §6) |
| Montage sequence | time passing / process / mood in 4–10 shots | metric or tonal recipe, music-led |
| Elliptical cut | remove the middle of an action (arrival → already inside) | `cut.on = "ellipsis"`; keep direction and sound continuous |
| J-cut | next scene's sound starts 4–10 frames before its picture: pulls the viewer forward, anticipation, scene change | segment `audio_lead` (frames) → `edit_analysis.py` split edits |
| L-cut | outgoing sound continues 6–15 frames over the new picture: lets a feeling linger, shows the listener | segment `audio_tail` (frames) |
| Invisible cut | hide a cut in a whip, a dark frame, a passing foreground (natural wipe) | `broll.md` natural wipes, `motion_fx` whip |
| Dissolve | time passes or two images should be read together | 6–12 frames, rare in short-form |

## 6. Rhythm: timing, pacing, trajectory (Pearlman)
- **Timing** = which frame you cut on (section 2). **Pacing** = how often you cut (shot length, ASL). **Trajectory phrasing** = the shape of energy across a group of shots: rise, peak, release — like a musical phrase.
- A sequence needs **variation**: constant lengths (unless metric on purpose) feel mechanical; alternate a long breath shot after 2–4 short ones.
- **Phrase by energy**: each chapter is a phrase — start with an establishing breath, build, peak (strongest image), release (a held shot or a pause before the next chapter).
- **ASL guides for short vertical video** (average shot length): calm/cinematic 1.8–3.5 s; travel montage 1.0–2.2 s; energetic 0.5–1.2 s; talking head segments 2–6 s with resets every 6–9 s. Climaxes run ~30–50 % shorter than the piece's ASL; the shot after the climax runs 2–3× the ASL (release).
- **Hold for the eye**: a new composition needs ~0.5 s (12 frames at 24 fps) before it is read; shots under 8 frames are flashes (accents), not information.
- `edit_analysis.py` reports ASL per chapter, its trend against the planned arc, and where tension and pace disagree.

## 7. Music as the metric grid (frame math)
- Frames per beat = fps × 60 / BPM. 24 fps: 70 BPM = 20.57 f · 90 = 16 f · 100 = 14.4 f · 120 = 12 f · 128 = 11.25 f. 25 fps: 120 BPM = 12.5 f. 30 fps: 120 BPM = 15 f.
- Never round the beat length once and multiply: cut on the **beat grid** (`silence_beats.py` beats, `ending_plan.py`/phrase hits 20 ms), accumulating real beat times → frames, so cuts do not drift (13 frames over 10 shots was measured with rounded lengths).
- Bars and phrases: 4 beats = 1 bar (most pop/cinematic), 4–8 bars = 1 phrase ≈ the chapter length. Chapters change on phrase hits; metric accents on beats; rhythmic cuts may sit between beats when the movement says so (not every cut on a beat — that feels mechanical).
- **Beat drop / main hit**: the reveal or strongest image starts ON the drop frame; the shot before it ends with energy rising (a ramp, a push, a riser peak) — see `story-structure.md` §5.

## 8. Writing it down
Every blueprint segment carries its reasoning (v2.4):
```json
{"id": "s05", "clip": "03.mov", "src_in": 40, "src_out": 88, "dur": 36, "section": "build",
 "size": "MS", "direction": "R", "tone": "cool-dark-slow",
 "subject_in": [0.48, 0.42], "subject_out": [0.62, 0.40],
 "cut": {"reason": ["rhythm", "story"], "on": "movement", "type": "action_match",
         "why": "cut as the scooter enters frame right; carries the rightward motion of s04 into the market"},
 "audio_lead": 6}
```
- `cut.reason` ⊂ {emotion, story, rhythm, eye_trace, plane, space, idea, reveal}; `cut.on` ∈ {beat, movement, gaze, breath, sound, contrast, ellipsis, structure}; `cut.type` optional (hard, action_match, graphic_match, eyeline_match, smash, jump, cross, insert, ellipsis, j_cut, l_cut, invisible, dissolve).
- `size` ∈ {EWS, WS, MWS, MS, MCU, CU, ECU, INSERT}; `direction` of dominant motion; `subject_in/out` = where the eye is (frame coords 0–1, y from top) at the first/last frame — from stills.
- `audio_lead` (J) / `audio_tail` (L) in timeline frames; `edit_analysis.py` turns them into split edits.
`edit_analysis.py` (MODE "plan") checks reason coverage, pacing vs arc, beat alignment, size progression, screen direction, eye-trace jumps and expands J/L cuts before `build_from_blueprint.py`. The paper-edit table shown to the user gets a "why this cut" column.
