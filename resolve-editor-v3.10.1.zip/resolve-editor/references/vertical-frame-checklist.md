# Vertical Frame and Mobile Readability Checklist

## Framing
- Confirm actual timeline aspect ratio and resolution before editing.
- Keep faces, eyes, hands, and key action visible within the 9:16 crop.
- Do not assume a landscape source is suitable for a vertical crop; inspect the actual frame.
- Use position/zoom only when the API and property read-back are verified.
- Avoid covering a face or focal action with display text.

## Safe areas and hierarchy
- Keep essential text away from extreme top/bottom edges where platform UI may overlay.
- Use readable line lengths and intentional line breaks.
- Separate display titles from dialogue subtitles.
- Keep subtitle baseline and margins consistent across shots.
- Ensure text contrast against the actual footage/background; do not assume a color is readable on every shot.
- Do not use color alone to encode hierarchy.

## Timing and motion
- Keep titles on screen long enough to read at normal speed.
- Avoid animation that completes before the text is legible.
- Prefer short, consistent reveals over unrelated motion presets.
- Avoid overlapping text events unless intentionally designed and verified.
- Ensure subtitle events do not collide with title cards or critical visual information.

## QC evidence
- Structural API read-back can verify text item presence, duration, and some values.
- Visual QC requires a genuinely inspectable rendered frame or playback.
- If visual inspection is unavailable, report the limitation and ask the user to inspect the draft in Resolve.

## Landscape footage in a vertical timeline
**User default since 2026-10-24: FILL** (the user compared fill vs fit samples and chose fill, like the reference videos).
- `Scaling = resolve.SCALE_FILL`; only ~31.6 % of a 16:9 source width is visible (x 0.342–0.658).
- Reframe each shot so the subject is in view with `Pan`: **+Pan moves the view left** (the picture slides right), ≈ 0.00035 of the source width per unit; +300 ≈ a third of the frame; black edges beyond ~±950. Subject at source x → Pan ≈ (0.5 − x) / 0.00035 (same wording as `broll.md`). Check the first and last frame of the shot — subjects move.
- Fit (`SCALE_FIT`, black bands) only when asked; then the notes below apply.

### Fit layout (only when asked)
- Set `Scaling = resolve.SCALE_FIT`. Read back `GetProperties()["Scaling"]`.
- A 16:9 clip fitted into 1080×1920 occupies a 1080×608 band centred vertically (y ≈ 656–1264); the rest is black (≈ 656 px above and below).
- Use the bands deliberately: title/hook in the top band (around y 0.70–0.80 in Text+ Center units, where 0 = bottom, 1 = top), subtitle or caption in the bottom band (y 0.20–0.28) — still inside the TikTok safe zone.
- Optional fill only if the user wants it: a blurred, darkened copy of the same clip on V1 behind the fitted clip on V2 (ZoomX/Y ≈ 3.2, Opacity 100, a blur needs a Fusion/OFX effect — verify availability first). Default is clean black.
- Punch-ins on a fitted shot shrink the black bands; keep the zoom ≤ 1.25 and re-check that titles in the band are still on black.

## Other platforms and aspect ratios (v2.2)
Safe zones per platform are in `config/defaults.json` → `safe_zones` (top-origin fractions). TikTok is measured from the app UI; **Reels and Shorts values are INFERRED** from their published UI overlays — check one still in the app before relying on them. For 4:5, 1:1 and 16:9 deliveries build a separate Draft with `"resolution"` (`delivery.md` §7); `fill_geometry()` gives how much of the source is visible and on which axis to reframe (`Tilt` for vertical sources in a landscape timeline). Pan calibration is measured only for 16:9 in 9:16: re-measure with two stills in other shapes.

## TikTok safe zone (1080×1920)
- Keep key text between y ≈ 160 px from top and ≈ 380 px from bottom; right edge ≥ 140 px clear (like/comment/share column); left edge ≥ 60 px.
- In Text+ Center units: x 0.06–0.87, y 0.20–0.92.
