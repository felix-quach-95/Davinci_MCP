# Transcript-driven editing (talking, vlog, speaking-to-camera)

Adapted from resolve-mcp-bridge (transcribe → keep segments → new timeline → punch-ins → remapped subtitles) and DaVinci-AutoEdit-Agent (evidence-first). Uses **Resolve's own transcription**, so nothing is installed and nothing leaves the Mac.

## Contents
1. Transcribe
2. Paper edit with `transcript_cut.py`
3. Jump cuts that feel intentional
4. Subtitles remapped to the cut
5. Music under speech
6. End-to-end: talking vlog (worked plan)
7. Verify

## 1. Transcribe
`transcript_cut.py` MODE "transcribe" (→ `mpi.TranscribeAudio()`), then MODE "status" until `Complete` (`project.GetTranscribeAudioStatus()` → JobStatus `Inactive / Initializing / Analyzing / Complete`). The result (`mpi.GetTranscription()`) is `{"language", "segments": [{start, end, text, speaker, words: [{start, end, text}]}]}`, timecodes in the clip's own timecode; `"(...)"` marks silence. Wrong language → say so; never "fix" what was said.

## 2. Paper edit (`transcript_cut.py` MODE "plan", v2.3, UNTESTED live)
Claude decides **what** stays; the planner decides **where** each cut lands. Learned on real edits by other creators (appariciojunior/video-editor-skills, AdamGarceau/resolve-toolkit, CiprianSpiridon/davinci-resolve-mcp):
- **Cut from words, refine with the waveform.** A volume-only silence cut gave ~800 choppy pieces on a 34-min class; the word cut gave 120. Run `silence_beats.py` MODE "silence" (`SILENCE_DB = "auto"`: 24 dB under the loudest windows — a fixed −30 dB called quiet speech silence on a −26 dB mic) and pass the result as `SILENCES`: a gap counts as a pause only when ≥ 85 % of it is silent (an untranscribed sound is not a pause), and edges move to where the voice really starts/stops (≤ 0.25 s before / 0.30 s after the word).
- **Pauses are shortened, not removed.** Gaps longer than `max_pause` keep `pause_keep` (40 % after the last word, 60 % before the next). Profiles: `shorts` 0.28/0.14 s (tight tips) · `story` 0.55/0.25 s (default, calm personal shorts) · `vlog` 1.0/0.6 s (0.5/0.3 felt "popping" on vlogs) · `class` 0.5/0.3 s. Choose at the Story approval.
- **Word pads** −0.08 s before / +0.12 s after; never reaching into a cut word. **Scene room**: 0.5 s before the first word of the clip, 0.6 s after the last (stop before the speaker reaches for the camera — check a still).
- **Retakes**: a sentence whose first 4 words start one of the next two sentences is an earlier take (the later is kept); a restart cue ("làm lại", "nói lại", "để mình nói lại") drops itself and the abandoned take. Similar but not identical openings are **flagged, not cut**.
- **Fillers** (`FILLER_MODE = "isolated"`): "ờ, ừm, ơ…" standing in a pause or opening a sentence are cut (user rule); fillers inside fluent speech are flagged and kept — cutting them forces a visible jump. `all` / `keep` are the alternatives. "à", "ạ", "nhé" are not fillers.
- **Unsure? Keep it and flag it.** A wrong cut is invisible to the user; a flagged keep is a 5-second decision.
Outputs: `review` (the transcript with ~~cut words~~ and ‖ at every cut — read it once: struck text must be only what was meant), `dropped`, `flags`, `uncovered_jump_cuts`, `blueprint` (media "both", zoom per piece, `audio_xfade` 2 frames), `kept_for_srt`, `speech_ranges`.
Keep: the hook sentence, emotional reactions, laughs, a deliberate pause before a point (add frames back by hand if the planner shortened it).

## 3. Jump cuts that feel intentional (`SWITCHING`)
- Zoom changes **only on jump cuts inside one scene**; a new scene (new clip, after B-roll) opens at 100 %. Zooming on scene changes added "pops".
- `paced` (default): alternate 100 % / 107.5 % but hold each framing ≥ 4 s — alternating on every seam ping-pongs the picture about once a second. `dynamic`: every jump alternates (high-energy tips). `hold`: one framing.
- **Punchlines** (`PUNCHLINES = [[first_word, last_word]]`, about one every 2–3 min): 115 % for that line only, split right after it (without the second split one punch-in held 83 s).
- Jumps left at the same scale are listed in `uncovered_jump_cuts`: cover them with B-roll (smash cut to what the sentence describes), a text card, or accept them consciously (review-scorecard blocker otherwise).
- In a fitted landscape shot punch carefully — it eats the bands. B-roll is always 100 %.
- J/L cuts: start the next shot's audio 4–8 frames early (append audio with `mediaType: 2` on its own track) — only if read-back confirms placement.
- Every butt join on A1 gets a 2-frame audio crossfade (`build_from_blueprint.py` `audio_xfade`) so cuts don't click; the read-back lists joins without handles.

## 4. Corrected transcript for the hand-over (v3.0)
Subtitles are HyperFrames' job. `srt_from_transcript.py` with `KEPT = kept_for_srt` writes cues on the new timeline's clock (only words inside kept ranges, times shifted) as **data**: correct recognition, spelling and punctuation, remove fillers, keep the meaning, add the English line, and pass the cues as `subtitle_cues` to `hyperframes_handoff.py` (`hyperframes-handoff.md` §7). Claude does not import the SRT or style subtitles. Cue rules the script checks: Vietnamese line ≤ 32 characters on 1080-wide vertical, ≥ 0.8 s on screen, no line across a cut if avoidable.

## 5. Music under speech
Music at −9 dB fights speech. After picture lock: `duck_music.py` with `RANGES = speech_ranges` (plan → apply) lowers it to about −20 dB under speech with crossfades (`audio-music-sfx.md`). Dialogue: `NormalizeAudioLevel` on A1 items, peaks −6 to −3 dBFS; `AudioVoiceIsolation` only for noisy footage and only after listening to a sample with the user.

## 6. End-to-end: talking vlog (worked plan, not yet run live — v2.3)
1. Preflight + `inventory.py`; identify talking clips (audio channels, people on the contact sheet) and B-roll clips (0 words, or "words" that are radio/background talk). Watch B-roll at ~2 frames per second (contact sheet) — 5 frames per clip missed the story.
2. `voice_audit.py` audit → choose the dialogue source; `silence_beats.py` silence (auto floor) → `SILENCES`.
3. `transcript_cut.py` transcribe → status → plan; read `review`, `dropped`, `flags`; runtime = `target_frames` (vlog 30–75 s; if longer, propose cuts at the Story approval: which sentences go).
4. Story approval: story (hook sentence first? flash-forward?), pacing profile + switching, music, ending (subtitle needs are asked only in Phase 10).
5. `build_from_blueprint.py` with the blueprint (+ B-roll rows on V2 `B-ROLL` — V3–V5 stay empty for HyperFrames — where sentences describe something visible, chosen from the evidence map).
6. `voice_audit.py` normalize (speech items only), effects only for emphasis moments, technical colour (`color_look.py`); no text is built — the corrected transcript goes to the Phase 10 hand-over.
7. Music (`music_library.py` pick, calm/low-mid energy, no vocals under speech), `duck_music.py`, SFX sparingly (a soft swell into B-roll; no literal foley).
8. `qa_audit.py` (incl. linked A/V sync), `audio_presence.py`, visual QC, `review-scorecard.md`, the Draft review, Final.

## 7. Verify
Check one jump cut at −1/0/+1 frames for a visible jump in framing (it should read as a punch-in, not an accident).
