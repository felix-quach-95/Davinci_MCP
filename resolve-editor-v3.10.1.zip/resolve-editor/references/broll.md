# B-roll — finding and making supporting shots from the footage you have

B-roll adds information (where, what, who), emotion (texture, faces, light) and rhythm (variety, cover for cuts). Short-form projects often have 3–6 short clips; the job is to **find every distinct usable image inside them** and use each source frame only once.

## 0a. The B-roll layer on V2 (v3.4.0, user request 2026-10-27)
**Why the CozyDay run had no B-roll:** every shot went into one V1 sequence and no rule asked for a V2 layer, so detail shots were used as main shots and nothing was ever layered. From v3.4.0 every video has two picture layers:
- **V1 = the spine** — the story shots in order, on the music (hook, setup, development, peak, release, ending), named `shot_01` …
- **V2 = B-roll cutaways** over the spine, named `broll_01` …: short shots that show *where / what / how it feels* while the V1 action carries on underneath. When the cutaway ends the picture returns to V1 later in its action, so time is compressed without a jump cut.
Rules (starting values; research basis: B-roll resets attention and covers cuts, cutaways of a few seconds, punctuate rather than dominate, wide-medium-tight variety — [PremiumBeat](https://www.premiumbeat.com/blog/b-roll-video-edit-guide), [Neil Chase](https://neilchasefilm.com/b-roll/), [VEED](https://www.veed.io/learn/what-is-b-roll), [Captions](https://captions.ai/blog/practical-guide-b-roll-video)):
| Rule | Value |
|---|---|
| How many | at least 3, and one every ~4 s of runtime (30 s → 8; v3.5.0, 6 s gave too few) |
| Length | 0.4–2.0 s each (montage: 0.5–1.2 s; a reaction is a flash) |
| Coverage | 25–50 % of the runtime |
| Burned text | check stills of the first, middle and last frame of every cutaway's own range before the build; set `text_checked: true` (v3.5.0: the catalogue called two subtitled ranges clean); text found → another range, or zoom/tilt it out of frame and check again |
| Where | over a V1 shot whose action continues (a process, a walk, a pour), on a beat; not over the hook's first second or the peak frame |
| Types (`broll_type`) | establish · detail · cutaway · reaction · texture · process · transition |
| Content | a *different* picture from V1 and from each other (own `grp`), related to the V1 shot it covers (the product being used, the place, the hands, the result) |
| Effects | B-roll carries effects too: slow push on details, snap zoom on a beat, a pull on an establish |
| Audio | none of its own (video only); SFX only when the cutaway itself is a transition |
Blueprint: V2 segments have `"track": 2`, an explicit `"record"` frame (inside the V1 span), `"media": "video"`, `broll_type`, `why`, `grp`, `fx_plan` and `props` (Pan / Zoom for the reframe). `edit_analysis.py` `broll_report` flags too few cutaways, coverage outside the range, wrong lengths, overlaps, missing type or reason, and any picture repeated from V1 or V2.
Catalogue: Phase 3 must mine **at least 2× the cutaways the plan needs** (30 s → about 16) (`footage-intelligence.md` §7); Phase 5 assigns them after the V1 spine is chosen.

## 0. v3.2.0 — mine first, then choose (read `footage-intelligence.md` §7 and `shot-selection-and-continuity.md` §6)
B-roll is made by **moment mining**: every clip is searched for *different* usable images — separate moments, establish → subject → detail, panel reframes, detail inserts, gaze targets and reactions, texture and light, movement through frame (natural wipes), entries and exits, bridges (defocus, black-to-black). Each result is a catalogue shot with an ID and an image group (`grp`). Rules that keep a 30-second video from looking flat or repeating itself:
- **One shot per image group.** A speed variant, a crop or a panel reframe of the same picture is the *same* shot; only a genuinely different subject earns a new group.
- **Vary scale on purpose.** Each chapter changes size or subject at least once; no run of three shots with the same size, move or direction.
- **B-roll answers *where / what / how it feels*.** If it answers none, cut it (it is filler). Types: establishing · detail · cutaway/reaction · slow-motion/time-lapse · action ([B-roll families](https://neilchasefilm.com/b-roll/)).
- **Do not over-mine.** A 1.4× crop of a soft frame is worse than leaving it out; say "this clip gives 1 distinct shot".
- Use B-roll to carry cinematic effects too: a detail insert with a slow push, a texture shot in slow motion at the release, a wide that ends with a pull.

## 1. Analyse every clip (stage 2)
B-roll clips are watched closely: about **2 frames per second** around the usable parts (5 frames per clip led to cuts the creator called "weird and wrong"); a clip with 0 transcribed words, or "words" that are radio/background talk, is B-roll.
1. `Probe_<Title>`: each clip whole, `"landscape": "fit"` (see the full 16:9 frame), one still every ~1/3 s (`qc_stills.py` or the loop in this job), contact sheet per clip with the fill window drawn (centre 31.6 % of a 16:9 source in 9:16).
2. Per clip write an evidence row: content, light/time of day, motion (static / pan / drone rotation / handheld), subject positions over time (source x, y), frame rate (slow-motion potential), focus changes, occlusions (people crossing = natural wipes), usable ranges with source frames.
3. List B-roll candidates (section 2) with their source range and role.

## 2. B-roll techniques (verified on HuongCang unless marked)
| Technique | How | Notes |
|---|---|---|
| **Unused ranges** | different source ranges of the same clip | never reuse the same frames; `qa_audit` flags overlaps > 2 frames |
| **Panel reframes** | 16:9 4K in 9:16 fill shows only the centre third; Edit-page `Pan` reveals left/right thirds = 3 different vertical shots | **+Pan moves the view LEFT**; source shift ≈ 0.00035 × Pan (≈ 0.105 per 300); keep \|Pan\| ≤ ~900 (black edges near ±950); subject at source x needs Pan ≈ (0.5 − x)/0.00035 |
| **Detail insert** | panel reframe on the object + `push` 1.0→1.08–1.12 with `center` on the object | bouquet from a street shot; wok cook from a kitchen wide; keep zoom ≤ 1.15 for 1080 delivery (≤ 1.35 hard limit) |
| **Follow a moving subject** | `push` with `drift` | the bouquet walked out of frame; drift +0.12 kept it centred for 2 s |
| **Virtual camera move** | `push` a = b = 1.0 with small `drift` (±0.02–0.04) | gives life to a static skyline |
| **Slow-motion variant** | high-fps clips at native slow speed (100 fps → 25 %; 50 fps → 48–50 %) | peak moments; 25 fps footage only via optical flow (fine for static/aerial scenes) |
| **Natural wipe** | cut on frames where someone covers the lens | opens/closes a chapter invisibly |
| **Defocus moment** | out-of-focus frames as a soft bridge | pairs with blur_in/out |
| **Speed ramp** | `ramp` steps in the blueprint | hook energy without new footage |
| **Exit / entry** | subject leaves or enters frame | natural chapter end (cook walks out → ending) |

## 3b. Analysing a clip in detail
`frame_probe.py` (ffmpeg) gives a 12–16 frame contact sheet per clip with source frame numbers — one image per clip, read it first. For exact usable ranges sample every ~0.25 s around the interesting parts and write the ranges as source frames: sharp / occluded (wipe) / defocus / subject leaving. Without ffmpeg: `qc_stills.py` on the fit `Probe_` timeline, then crop the 16:9 band out of the 9:16 still (`sips -c 1215 2160 <png>` for 2160×3840) and downsize to 320 px.

## 3c. Other source shapes (v2.2)
- **Vertical footage (9:16 phone clips)** in a 9:16 timeline: no reframing room; B-roll comes from unused ranges, push-ins (≤ 1.15 at 1080 delivery from 1080-wide sources: ≤ 1.08) and slow-motion variants. In a 16:9 timeline it fills only with a 3.16× magnification — use Fit + blurred background only on request.
- **1080p landscape sources** in a 2160×3840 timeline: Fill already magnifies ~3.6× (soft); prefer a 1080×1920 timeline, keep push-ins ≤ 1.05, and say the picture is soft if it is.
- **Stills (photos)** — Ken Burns: treat the photo as a master shot (wide, medium, detail inside it); a small vocabulary of moves (slow zoom in to a face/object, slow zoom out to reveal context, horizontal pan across a group/landscape), 1.0 → 1.05–1.15, eased in and out; start where the eye should go first, end on what the line/music is about; quick context 3–5 s, detail 5–7 s, establishing 10–15 s (shorter in short-form: one music phrase). If the move is noticed, it is too fast. Build with `motion_fx` push/drift or `reframe_path`; grade stills like the footage.
- **Natural black-to-black transitions**: a camera going into a bag/pocket (frames go dark) and the next clip starting dark is a free invisible cut — look for it on the contact sheets.
- **Long clips (> 1 min, many shots inside)**: put them whole on a `Probe_` timeline and run `picture_tools.py` MODE "scene_cuts" (Resolve's `DetectSceneCuts`, UNTESTED) to get a shot list; then contact sheets per shot.
- **Smart Reframe** (`picture_tools.py` MODE "smart_reframe", UNTESTED): Resolve's own subject reframing for the timeline aspect — compare with the measured Pan route on stills and keep the better framing; never both on one item.
- **Handheld walking shots**: `picture_tools.py` MODE "stabilize" (UNTESTED) before effects; it crops — check edges.

## 4. Clips that do not fit the theme (user rule 2026-10-25)
Analyse every clip; a clip with beautiful or purposeful moments is normally used. Claude **decides** the best use itself and reports it with the reason (no question):
| Option | Use when | Build |
|---|---|---|
| **Prologue / time bridge** | the clip is a different time of day but carries a person or feeling the rest lacks | one music phrase before the title; end it on a natural wipe or defocus cut into the theme (day → dusk → night) |
| **B-roll detail** | one object/gesture in it supports a chapter | panel reframe + push (+drift to follow) |
| **Transition material only** | only its wipes/defocus frames are usable | 6–12 frames as a bridge, graded toward the neighbouring shots |
| **Leave out** | nothing in it serves the story, or it contradicts it | say why in the report |
Do not grade daylight to fake night: flat shadows, bright sky and daylight skin give it away.

**Case HongKong v02 (2026-10-25, VERIFIED stills):** night piece, clip 01 = overcast day street, old man carrying a bouquet (25 fps). Evidence: src 0–9 sharp face with neon behind, 10–28 passer covers the lens, 29–40 walking, 41–57 defocus then full cover, 58–87 bokeh, 90–112 sharp bouquet detail, 110–143 occlusions. Used as a "chiều tàn" prologue (one phrase, 35–117): face 0–12 (Pan −100) → bouquet 90–112 at 51 % with push 1.10 + drift 0.06 (Pan −430) → walk 29–41 (Pan 230) → wipe 41–57 → hit cut to the dusk skyline + title, sub drop on the cut. The only human moment in the footage; 51 % optical flow on a walking subject is slightly soft but acceptable.

## 3. Using B-roll in the edit
- Each chapter: establish → subject → detail (or detail first as a hook). The detail insert is where the eye rests and where a whisper line fits.
- B-roll is never filler: it must answer *where / what / how it feels*. If it doesn't, cut it.
- Keep screen direction and light consistent inside a chapter.
- Label each segment's `purpose` in the blueprint ("B-roll: bouquet detail, push in").
- Grade B-roll exactly like its parent clip (copy the Color-page LUT).
