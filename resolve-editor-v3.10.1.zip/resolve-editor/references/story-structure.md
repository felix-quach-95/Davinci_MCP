# Story structure, emotional arc and retention (v2.4)

How a 10–90 s vertical piece is built as a story, not a sequence of nice shots. Read at the Story approval (story shape + runtime) and the paper edit. Companion files: `montage-advanced.md` (how to cut), `composition.md` (how each frame reads), `storytelling-montage.md` (short entry), `viral-shortform-formats.md` (platform patterns). Principles summarised from classic screen-story practice (three-act structure, setup/payoff), Murch, Pearlman, ACE editors' talks, StudioBinder and No Film School material — adapted to short-form.

> **v3.2.0:** the decision procedure that uses this module — story contract, beat map, causal vs associative, gap/repeat/stall checks, structure comparison and the Phase 4 exit checklist — is `story-decision-framework.md`. Read it first; come back here for the craft (acts, arc, B-roll layers, J/L cuts, retention).

## Contents
1. The spine: one sentence, one change
2. Three acts at short-form scale (timing table)
3. The emotional arc and how pace follows it
4. Parallel editing (cross-cutting)
5. Beat drop, peak and release
6. B-roll in layers: literal, context, subtext, proof
7. J-cuts and L-cuts: where and how long
8. Elliptical editing: removing time
9. Retention mechanics, second by second
10. The paper-edit table (what Claude shows)

## 1. The spine
Before structure: write the **spine** — one sentence with a change in it: "a quiet street becomes a city that never sleeps", "an old man's bouquet carries the day into the night", "a 3-step recipe turns into dinner". If the footage cannot support a change, the piece is a mood loop (tonal montage + loop ending), and that is said at the Story approval.
Every chapter must move the spine: new place, new time, new information or new feeling. A chapter that does none of these is cut, however beautiful.

## 2. Three acts at short-form scale
| Runtime | Act 1 — set up | Act 2 — escalate | Act 3 — climax + resolution |
|---|---|---|---|
| 15 s | 0–4 s: hook (0–1.5 s) + where/who | 4–11 s: 2 chapters, rising | 11–15 s: peak (1 shot, often slow-mo) + button/ending |
| 30 s | 0–7 s | 7–22 s (midpoint turn ≈ 15 s) | 22–30 s |
| 60 s | 0–12 s | 12–45 s (midpoint ≈ 30 s) | 45–60 s |
| 90 s | 0–18 s | 18–68 s | 68–90 s |
- **Act 1** — establish rhythm and world: the hook (most striking motion or a flash-forward of the peak), then orientation (wide/establishing), then the subject (person, object, light). Establish the editing rhythm the viewer will feel deviations from.
- **Act 2** — escalate: each chapter raises one variable (pace, scale, light, density, music layer). Use **parallel editing** when two threads exist (§4). Midpoint = a turn (day → night, alone → crowd, preparation → action).
- **Act 3** — climax: overtonal montage (all rhythms together, `montage-advanced.md` §3), then **resolution**: one held shot (2–3× ASL), elliptical cuts remove anything between the peak and the meaning (§8), ending as planned (`endings.md`).
- Talking pieces: Act 1 = hook sentence + promise; Act 2 = the points, each with proof (B-roll layer "proof"); Act 3 = the strongest point/punchline + recap/CTA ("tell them what you told them").

## 3. The emotional arc
- Give every chapter a **tension value 1–5** in the blueprint (`bp["arc"] = {"hook": 3, "setup": 2, "build": 3, "turn": 4, "peak": 5, "release": 2}`, keyed by `section`).
- **Pace follows tension**: higher tension → shorter shots, more movement, denser sound; lower → longer shots, stillness, air. `edit_analysis.py` compares ASL per section with the arc and reports sections where they disagree (e.g. a 5 that cuts slower than a 2).
- **Contrast before the peak**: a short dip (2 → after 4, before 5) makes the peak hit harder — a held quiet shot or a moment of silence 0.5–1 s before the drop.
- **Release after the peak**: never end on the most intense frame; give one breath (held wide, ambience) so the feeling settles, then the button/ending.
- Shapes worth knowing (pick one at the Story approval): rise (rags to riches: build to the end), fall-rise (problem → resolution), rise-fall-rise (the classic: hook, dip, triumph), steady with one spike (mood piece with one peak), loop (mood, ends where it began).

## 4. Parallel editing (cross-cutting)
- Two threads (A: the old man walking; B: the city lighting up) alternate. Rules: each switch must leave A at a moment of tension (an unfinished action) so the return pays off; **shorten the alternation interval** toward convergence (A 3 s / B 3 s → 2/2 → 1/1 → meeting); keep each thread's screen direction and tone consistent so the viewer always knows which line they are in; converge with a match cut or a shared sound.
- Short-form: 2 threads maximum; 3–6 alternations; converge at the peak.
- Build: `section` "A1/B1/A2/B2…" with `thread` field; `edit_analysis.py` checks the intervals shrink.

## 5. Beat drop, peak and release
- **Where**: the main musical hit/drop carries the strongest image (the "money shot"). In 15–30 s pieces it usually sits at 55–75 % of the runtime; in loops it can be the opening hook (flash-forward) and return at the end.
- **Before the drop**: 1–2 bars of rising energy — metric acceleration, a push-in or speed ramp landing its slow step on the drop, a riser peaking on the drop frame; or the opposite: a short silence/dip (contrast).
- **On the drop**: hard cut on the onset frame (−1 frame for heavy hits, `montage-advanced.md` §2), picture and sound change together; a sub drop/hit SFX if the music drop is soft.
- **After the drop**: hold the payoff shot long enough to be seen (≥ 1.5 s, slow motion if high-fps), then the release.
- Build: `bp["drop_frame"]` (from `ending_plan`/phrase hits) and the payoff segment `section` "peak"; `edit_analysis.py` checks the peak starts within ±1 frame of the drop.

## 6. B-roll in layers
B-roll must serve the story's subtext, not just cover a cut. Tag each B-roll segment with its layer (`broll_layer`):
| Layer | What it does | Example |
|---|---|---|
| literal | shows what is said or happening | "the market opens" → shutters rising |
| context | where/when/who | wide skyline at dusk before the street chapter |
| subtext | shows the feeling or idea under the words (Kuleshov) | "I missed home" → a single lit window |
| proof | evidence for a claim | "it was packed" → the crowd from above |
| rhythm | keeps the pace/covers a seam (only as a side effect of one of the above) | — |
A piece made only of literal B-roll feels like an illustration; one subtext insert per chapter gives depth. A B-roll that fits no layer except "rhythm" is cut. Duration 1.2–3 s, placed after the phrase lands, never mid-phrase; screen direction and light consistent with its chapter.

## 7. J-cuts and L-cuts
| Use | Cut | Length (24/25 fps) |
|---|---|---|
| Scene/chapter change, pull the viewer forward | J: next sound (ambience, first word, music hit) starts before its picture | 4–10 frames (ambience up to 12–24) |
| Emotion lingers, show the listener/the place after the line | L: outgoing sound continues over the next picture | 6–15 frames |
| Dialogue → B-roll | L: the sentence finishes over the B-roll | to the end of the phrase |
| B-roll → dialogue | J: the voice starts on the B-roll | 4–8 frames |
| Mood piece chapter turn | J ambience: kitchen fire crackle 6–10 frames before the kitchen cut | 6–10 frames |
Build: segment `audio_lead` (J) / `audio_tail` (L) on the INCOMING segment (lead) or OUTGOING segment (tail). `edit_analysis.py` MODE "plan" turns them into split edits: picture and sound rows with their own record frames on the dialogue track (no overlap — the audio edit point moves), for `build_from_blueprint.py`. Ambience J-cuts on A4 use the ambience bed's own record frame.

## 8. Elliptical editing
- Remove the middle of an action and trust the viewer: walking to the door → hand on the handle → already inside. Keep three things continuous so the ellipsis reads as intended: screen direction, sound (ambience carries across), and the subject's position/eye-trace.
- Use in Act 3 to accelerate toward the climax and after it to jump to the meaning (peak → resolution without the walk back).
- Time-compression montage (a process in 4–8 shots) is an ellipsis of a whole action: each shot one stage, lengths on the beat grid.
- Build: `cut.on = "ellipsis"`; `edit_analysis.py` accepts the direction/size jumps such cuts imply.

## 9. Retention, second by second
- 0–1.5 s: the hook is visual motion or contrast + sound on frame 1; text promise if any in the first 0.5 s (`viral-shortform-formats.md`).
- Open a loop early (a question, a glimpse of the peak) and close it late — viewers stay for answers.
- **Pattern interrupt**: energetic pieces every 3–5 s (new shot size, ramp, text, sound accent); calm pieces every 4–8 s (new light, new chapter, music layer). Never more than 6–9 s of unchanged talking head.
- Peak in the last third; the loop or button in the last 1–2 s; nothing after the payoff that the viewer has already understood.
- The plan table states for each chapter: what keeps the viewer watching through it.

## 10. The paper-edit table (shown to the user at stage 4)
| # | Time | Act/section (tension) | Shot (size, subject) | Cut in on — why | J/L | Music (beat/drop) | Text | SFX | Retention device |
|---|---|---|---|---|---|---|---|---|---|
Fill it before building; every row's "why" must be specific ("cut as the scooter's front wheel enters right, carrying s04's rightward motion" — not "nice shot"). `edit_analysis.py` checks the table's blueprint.
