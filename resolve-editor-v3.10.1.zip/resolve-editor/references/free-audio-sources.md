# Free SFX from outside the Mac (v3.3.0)

**Music is never searched, previewed or downloaded here (hard rule 13, user request 2026-10-27):** the user sends the background music after the Style choice (`options-playbook.md` §3). This file covers sound effects only: online sources fill gaps in the local SFX library — an SFX role with weak picks (e.g. no "neon buzz", "market crowd", "temple bell"), or the user asked for something new at the kickoff questions. The local library stays first.

Licence facts below were read from the sources' pages and press/guides on 2026-10-25. **Licences change: read the licence line on the file's own page at download time** and store it in the sidecar. The music columns of the tables are kept for reference only.

## Contents
1. Tiers
2. When to look online
3. Search and preview (read-only)
4. Approval and download
5. Ingest, catalogue, use
6. Credits in the post
7. Never

## 1. Tiers
**Tier A — commercial use, no credit (preferred for monetised TikTok/Reels/Shorts)**
| Source | Has | Licence notes | Access |
|---|---|---|---|
| Pixabay Music & Sound Effects (pixabay.com/music, /sound-effects) | large music + SFX catalogue, mood/genre/duration filters | Pixabay Content License: free, commercial ok, no attribution. Some tracks are registered with Content ID → automated claims can still happen: keep the page URL in the sidecar as proof | free; downloads may ask to sign in (the user signs in, never Claude) |
| Mixkit (mixkit.co/free-stock-music, /free-sound-effects) | curated music by mood/genre, SFX by category (whoosh, transition, cinematic…) | Mixkit Free License: social media, YouTube, ads ok, no credit; music not for broadcast/CD; never resell or register a track | no account; direct file links |
| Sonniss GameAudioGDC bundles (sonniss.com/gameaudiogdc) | many GB of professional SFX (ambiences, foley, impacts, whooshes) | royalty-free, commercial, no credit; recent licences forbid AI training | large ZIPs: ask with the size first; ingest only the files a draft needs |
| Freesound (freesound.org) with the **CC0** filter | field recordings, ambiences, foley, rare sounds | CC0 = no conditions | download needs a free account (the user's) |

**Tier B — free with credit (allowed; credit goes in the caption/description)**
| Source | Notes |
|---|---|
| Freesound CC BY | credit sound name, author, link, licence |
| Incompetech (Kevin MacLeod) | CC BY 4.0: "Music by Kevin MacLeod (incompetech.com), CC BY 4.0"; paid no-credit licence exists |
| YouTube Audio Library | per-track licence ("License type" column); CC BY tracks need credit; use outside YouTube is not guaranteed for every track — prefer Tier A for TikTok |
| Uppbeat free plan | one credit code per video in the description, individuals only (no brand/sponsored content), small monthly download cap; tell the user about the code |

**Never for these videos**: BBC Sound Effects (RemArc licence: personal, educational, research only), any CC BY-NC / -ND file, "no copyright music" re-uploads without a licence page, audio ripped from TikTok/YouTube/Instagram, and trending TikTok sounds as files (add trending sounds **inside the TikTok app** when posting — the research card notes them).

## 2. When to look online
- The `_prefs.json` choice "Nguồn âm thanh" = suggest (default) or prefer-new, for SFX.
- `sfx_library.py` MODE pick returns < 2 good candidates for a cue role, or the picture needs a specific sound the folder lacks (`sfx-library.md` §2 lists what is there).
- Kickoff questions answer "Chỉ thư viện trên máy" → never look online.

## 3. Search and preview (read-only)
In the built-in browser (or Claude in Chrome if the user asked for it): search the source with mood/genre/tempo/duration words from the brief — topic words only, no footage, no project names. Read the result pages; play the preview only to read its length/BPM shown on the page (Claude cannot judge the sound). Note for each candidate: title, artist, source, page URL, duration, BPM if shown, licence line from the page, why it fits (mood, phrase length vs the chapter plan, ending type).
Shortlist: SFX 1–2 per missing role. Prefer Tier A.

## 4. Approval and download
Downloads are never silent. Show the shortlist in one table (title · source · licence · length · why) and ask once: "Tải các file này vào thư viện?" (approve all / choose / none). Then:
- Direct file link shown on the source page (Mixkit, Pixabay CDN): `audio_ingest.py` MODE fetch (https, allowed hosts, size cap).
- Download button that needs the browser or sign-in: the user (or Claude in the browser after approval) downloads to `~/Downloads`; then `audio_ingest.py` MODE ingest with the paths.
- Sonniss ZIPs: ask with the size; unzip into a temporary folder, ingest only the chosen files.

## 5. Ingest, catalogue, use
`audio_ingest.py` copies each approved file into `<music or sfx folder>/_Free/<source>/` (never overwrites, never touches the rest of the library) with a sidecar `<file>.licence.json` (title, artist, page URL, licence, credit needed, date, approved). It refuses blocked or unknown licences. Then `music_library.py` / `sfx_library.py` MODE scan (only new files) → pick/place as usual: online files get the same peak-based and footage-relative levels as local ones.

## 6. Credits in the post
At delivery: `audio_ingest.py` MODE credits on the Final timeline → credit lines for Tier B files and warnings (Uppbeat code, per-track licences). Put them in the caption/description text offered in `delivery.md` §6 and in the report. Tier A files need no credit; the report still lists their source and licence.

## 7. Never
- Sign in, create accounts or accept terms on the user's behalf (the user does it).
- Upload footage or audio anywhere to "match" music.
- Use a file whose licence line was not read on its own page.
- Download more than the shortlist the user approved; bulk-download a catalogue.
- Pay for, subscribe to or start a trial of any service.
