# Ideation playbook — brief, theme, script beats, plan audit (v2.8.0 addendum)

Methods distilled from a study of the open-source OpenMontage skill files (AGPL-3.0). **Ideas only, rewritten for footage-first editing in Resolve; no code or text copied.** What the pack already does well (hooks, arc, montage, J/L cuts, previews, four-lane scorecard) stays where it is: `story-structure.md`, `montage-advanced.md`, `storytelling-montage.md`, `options-playbook.md`, `review-scorecard.md`. This file adds only what was missing. Read it in stages 1, 3 and 4 and before the Draft review.

Order that never changes: **footage evidence first** (stage 2), then the ideas below, then the blueprint.

## 1. Intake — ask only what is missing (stage 1, feeds the kickoff questions)
Seven things decide a piece: purpose, audience, platform, tone, reference, outcome (what the viewer does or feels), constraints. Skip everything the user already said; mark each answer *stated* or *inferred* in `project.json` `notes`; never invent an answer. Ask the single most important gap first, then the next. A reference video replaces the "tone" question — extract tone from it (`reference-analysis-and-match.md`). Never open with a numbered survey.

## 2. Design read + three dials (the kickoff questions or the Story approval)
Write one specific sentence on what the piece must feel like and why, tied to audience, platform and footage ("night-city travel teaser: calm, glowing, unhurried — not hype"). Adjectives alone ("modern, cinematic") are not a read.
Then set three 1–10 dials; every later choice must be explainable by them:
| Dial | Drives |
|---|---|
| visual_variance | how many distinct shot families / looks; need recurring anchors (type, palette, sound motif) when high |
| motion_intensity | accents per 20 s (`config creative.accents_per_20s`), transition vocabulary, hold lengths |
| information_density | how much happens per shot/second: cuts, accents and sound events (graphics are decided in Phase 10) |
Anti-default check: same transition on every cut when variance ≥ 4; dense text when density ≤ 4; kinetic motion that hides the picture; a piece that could carry any other title and still work (too generic).

## 3. Theme and tone for montage pieces (the Story approval)
- **Thematic question in one line**, sensory not abstract: "What does the city do at 4 a.m.?" (good) / "a video about cities" (too vague) / "eight shots of neon" (a shot list, not a theme).
- **One tone register** from a short list, each with a hold table to start the paper edit (adjust with the music):
| Register | Base hold | Min–max | Use |
|---|---|---|---|
| elegiac | 4.0 s | 2.5–7.0 | memory, loss, home |
| reverent | 3.5 s | 2.0–6.0 | nature, scale, ritual |
| dreamlike | 3.0 s | 1.5–5.5 | repeated motifs, dissolves |
| wry | 2.0 s | 1.0–4.0 | ironic juxtaposition |
| urgent | 1.2 s | 0.5–2.5 | city, crisis, now |
Hero shots (2–3 per piece: opening, turn, last image) get the max hold; compress non-heroes first, never cut a hero short to fit time. Holds must sum to the target length within ±10 %.
- **Thesis line for the ending** (3–9 words, a claim not a summary): write 3 options, recommend one, hand it to `endings.md`.
- **No silent major change after approval**: swapping the approved music, stretching the length, or adding narration the brief ruled out is a Gate question, not an edit decision. Log reorders of the approved chapter order with the reason.

## 4. Writing beats — visual cause, not feeling (stage 4)
Rule: a beat, hook or cue describes **what is seen or heard**, not the emotion it should cause. "Epic reveal" → "wide pull-back, subject in silhouette against the rising light". "Moody" → "low key, shadows lifted ~2 stops". "Powerful swell" → "music drops at 0:42, 1.5 s of silence, returns low". Give every beat one **camera-intent line** (shot size, move, focus) — it is consumed by `composition_check.py` and `motion-effects.md`.
Name the **subject transition** on every cut where focus moves: *revealing* (new subject enters or is uncovered), *disappearing* (leaves or is covered), *switching* (focus jumps A→B), *complex-alternating* (several subjects trade focus). It goes in the segment's `cut.why`.

## 5. Narrative connectors and pacing add-ons (talking, vlog, tips, 30–90 s)
- **But / therefore, never "and then".** Each chapter joins the next by a turn (*but* it was not what they expected / *therefore* we did X). A chapter list that only says "and then" is a catalogue — fine for a montage, wrong for a story.
- **Misconception first** for tips and explainers: show what people assume, then the turn.
- **Hook type** (pick one, from the footage, with evidence): contrarian ("everyone does X wrong"), outcome ("by the end you will…"), mystery (a strange fact or image first), stakes (what this costs/gains), result-first (show the finished thing, then the how).
- **Palette cleanser**: after a dense run, one quiet beat (wide shot, silence, empty frame) of 1–2 s every 45–60 s of a longer piece; in 15–30 s pieces the release after the peak does this job.
- **Deliberate silence**: after the key reveal let 1–3 s breathe (`silence_beats.py` can find the spots). One new idea per 30–45 s for explanation; a visual change at least every 1–3 s for short-form.
- Retention checkpoints quoted by that project (3 s ≥ 70 %, 15 s ≥ 60 %, 30 s ≥ 50 %) are **its sources' claims — not verified here**; use them as targets to compare against the user's own TikTok Studio numbers, never as facts in a report.

## 6. Shot descriptions for finding footage (stage 2, `broll.md`)
Describe a needed insert like a location scout, in nouns and adjectives: *subject, action or pose, environment, light, texture* — "rain streaking sideways across a bus window, passengers soft, red and green light bleeding through the glass". No emotion words, no intentions ("a moment of hesitation"), no category words ("home", "city"). If you cannot picture one photograph, you cannot find it in the Media Pool. Each wanted insert gets 2–3 search phrasings (literal, lateral, associative) when it will be searched in free sources (`free-audio-sources.md` style approval flow for any download).

## 7. Plan audit before the build (stage 4, after `edit_analysis.py`)
Six slideshow risks — score each 1–5 (5 = bad) from the blueprint, report the average; **≥ 4 = revise before building, 3–4 = fix the dimensions ≥ 3.5**:
1. **Repetition** — one shot size in more than half the segments, or 3+ consecutive segments of the same size/angle.
2. **Decorative visuals** — a segment with no stated purpose (`purpose`, `cut.why` empty).
3. **Weak motion** — camera move/zoom/ramp with no story reason.
4. **Weak intent** — segments missing size or intent: why does this frame exist?
5. **Text over-reliance** — a story that only works if on-screen text carries it (picture must tell it; graphics are added in Phase 10).
6. **Unsupported "cinematic" claim** — the Story approval says cinematic but no hero moment, no light/move variety, no drop.
Also scan for **generic words** in beats/copy ("stunning", "amazing", "dynamic", "a beautiful…", "in today's world") and replace them with something seen.
**Decision log** (`project.json` `decisions`): for each major choice (story shape, music, ending, off-theme clip use) record the option picked, **at least two options considered**, a real reason (never "best option"), and a confidence 0–1; if everything is 1.0 the log is not honest. Show only the ones the user would care about.

## 8. Review findings must be accurate, complete, constructive
(already in `review-scorecard.md` spirit) — every finding names the frame/segment/field it comes from, scans for the same mistake elsewhere before reporting, and proposes the fix; if no fix can be proposed, label it "investigation", not "blocker".

## Not taken from that project (and why)
Pipelines that make video from a prompt alone, paid generation APIs, stock-footage corpus building, TTS/avatar/lip-sync, its own render runtimes: they contradict *evidence before story* and the free-first, no-upload rules of this pack.
