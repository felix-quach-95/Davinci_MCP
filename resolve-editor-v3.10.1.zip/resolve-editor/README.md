# Resolve Editor — Unified Skill v3.10.1

Skill name: `resolve-editor`. One Claude skill that works as a senior film editor in DaVinci Resolve Studio through the Resolve MCP: music analysis, footage analysis, story, B-roll selection, montage, transitions and sound, **technical** colour, QC, a clean Final timeline — and a structured hand-over of every title, subtitle and graphic to **HyperFrames**, which produces them.

## Designed for
- Claude Desktop on macOS, DaVinci Resolve Studio 21.1.x, Resolve MCP (`run_script`, `run_script_unsafe`, `get_scripting_api`, LUT tools)
- **Multi-format, 9:16 by default** (TikTok/Reels/Shorts; 4:5, 1:1, 16:9 supported); landscape footage fills a vertical frame (Fill + Pan) unless Fit is asked for
- Music/SFX from the user's own library, plus free licensed sources after the user approves a shortlist
- No paid APIs, no footage uploads (optional vidIQ research uses only the free credits of the user's plan; topic words only); ffmpeg/ffprobe in `~/.local/bin` are installed when missing

## What's new in v3.10.1
- **Fewer relay turns in Phase 11:** the build agent stops only 3 times (SPEC · preview + review · export + placing), takes all changes in one message, and the main chat relays word for word without extra reading. The agent never reads the edit chat; only these few relay turns re-read it, at the cheap cached rate.

## What's new in v3.10.0
- **Graphic questions only after the switch to HyperFrames:** Phase 10's Final approval asks just the Final name and the cleanup; then one question "Chuyển sang HyperFrames ngay?". Every graphic question comes in Phase 11.
- **No new window or new session:** the "phiên mới hoàn toàn" option is gone; Phase 11 runs in the same chat (the build in a fresh-context agent inside it, to save usage). `/clear` is never proposed.
- **Style gallery with pictures first:** Phase 11 opens Motion Studio's gallery (every HyperFrames look rendered live) in the browser, sends its link in the chat, and waits for your pick before the graphic questions.
- **Preview link sent at once:** as soon as HyperFrames Studio's preview runs, its link is sent (and opened) without asking, repeated on every later step and re-sent after a restart.

## What's new in v3.9.0
- **Newest HyperFrames.** Installing Motion Studio pins the newest HyperFrames on npm (0.8.209 on 2026-10-28) instead of 0.8.181; a project keeps its release while it is made. Motion Studio's guide follows the new flow: three storylines (skipped for an overlay of a locked edit), `SPEC.md`, `check`, `snapshot --review`, the HyperFrames desktop app.
- **Exact frame rates:** overlays render at the Final's rate (`--fps 30000/1001` for 29.97), so nothing is conformed in Resolve.
- **One MOV per layer through HyperFrames' documented batch render** (`--batch layers_rows.json --format mov --output "renders/layers_full/{name}.mov"`), `--variables` for a single layer.

## What's new in v3.8.1
- Phase 11 checks which HyperFrames release the installed HyperFrames skills use and refreshes them to Motion Studio's pin when they differ.

## What's new in v3.8.0
- **Model per agent** (`references/agents-and-models.md`): footage scan and research on Haiku; footage deepen, stills check and the Phase 11 builder on Sonnet; story and editorial judgement on Opus (in the main session when it runs Opus, otherwise in a judgement agent). Escalation rules keep quality: a weak cheap answer is redone one tier up, only for that item.
- **Less context:** agent prompts point to their template instead of pasting it; images are read once, in one turn, by the agent that owns them; burned-text stills and the Phase 10 stills never enter the main context; only the main session starts agents.

## What's new in v3.7.1
- **One skill file:** Motion Studio 0.4.1 now ships inside this skill as a folder (`motion-studio/`, its guide as `GUIDE.md`), not as a nested zip, so the upload is accepted. `scripts/install_motion_studio.py` installs it on the Mac when Phase 11 first needs it.

## What's new in v3.7.0
- **Claude asks and switches context itself** at the end of Phase 10: a fresh-context agent runs Phase 11 right away (you answer in the same chat), or a whole new session, or later.
- **Every graphic is its own layer in DaVinci:** one MOV per element (alpha, trimmed to its span, frame-exact), named `DHnn_<Loại>_<Chữ>`, coloured by kind (title Orange, subtitle Teal, motion graphic Pink …), on named tracks "ĐH Chuyển động / Chữ / Tiêu đề / Phụ đề" in a new Draft. New `hf_layers.py`; `timeline_ops.py` place_media sets names, colours, track names and the clip fps.

## What's new in v3.6.0
- **Phase 11 — graphics with Motion Studio.** After the Final and the brief are approved, titles, subtitles and motion graphics are built entirely by the user's `motion-studio` skill (HyperFrames 0.8.181) as one transparent MOV with the Final's size and frame count. `hyperframes_handoff.py` now writes a self-contained package (`HF_REQUEST_<Title>.md` in Motion Studio's hand-off shape, overlay rules, stills of the Final, `START_PHASE11.md`).
- **New session for Phase 11** to save usage: the editing chat ends with one line to send after `/clear` or in a new chat; Phase 11 reads only the package.


## What's new in v3.5.1
- **Speed ramps you can feel:** 5–7 per 30 s, every speed step at least 0.33 s on screen, the ramp at least 1.5 s, the slow part at least 0.6 s; recipes rewritten with times on screen; `edit_analysis.py` flags ramps that are too short or too flat.

## What's new in v3.5.0
- **More B-roll:** one cutaway every ~4 s (30 s → 8), 25–50 % of the runtime; every cutaway checked for burned subtitles on stills before the build.
- **More transition SFX:** 7–10 per 30 s; whoosh and transition levels 4 dB higher with a per-file peak ceiling so the mix does not clip.
- **Ramp naming:** the steps of one speed ramp are `shot_03a`, `shot_03b` …
- **Subtitle readability lesson** in the HyperFrames hand-over (scrim ~0.5, second line ≥ 28 px).

## What's new in v3.4.0
- **SFX only on transitions** — whoosh, riser, sub drop or hit exactly on a cut; nothing for content.
- **More speed ramps and zooms** — five ramp types, nine zoom types, recipes per story section; 3–5 ramps per 30 s and zoom moves on most shots, planned per shot (`fx_plan`) and checked.
- **A real B-roll layer** — V2 cutaways over the V1 story spine, at least one every ~6 s, checked by `edit_analysis.py`.

## What's new in v3.3.0
- **You send the music.** After you choose the style, Claude sends one "Yêu cầu gửi nhạc nền" message and waits for your file — no music options or previews.
- **Clear names.** Ten phases with full names, and stops named Style choice, Music request, Story approval, Draft review, Final approval (Standard mode adds Kickoff questions, Rough-cut approval, Hero accent choice).
- **Timeline names and colours.** Shots are named `shot_01`, `shot_02` … from left to right; music clips are Green and SFX clips Yellow.

## What's new in v3.2.1
Workflow consolidation: Phase 1 as one ordered procedure, no duplicate Gate 0 questions, `WORKFLOW.md` one-page map. See CHANGELOG.

## What's new in v3.2.0 (2026-10-27) — editorial intelligence, 30 s, two opening choices
- **Up to 30 s.** After the footage check: **E0a** five style options built from your footage + one you write, then **E0b** 3–5 music styles with one preview track each + your own file. Then the run continues from Phase 2.
- **Four new core modules:** `footage-intelligence.md` (shots with IDs, action stages, In/Out, B-roll mining), `story-decision-framework.md` (the story chooses the shots), `shot-selection-and-continuity.md` (scoring, continuity, joins, repeat checks), `editorial-decision-and-qc.md` (editorial verdict separate from technical).
- **No repeats:** four levels (source frames, same picture, same information, same pattern) checked by `edit_analysis.py` `repeat_report`.
- **Cinematic first:** speed ramp, zoom in, zoom out recipes in `motion-effects.md` §0.

## What's new in v3.1.0 (2026-10-27) — token plan T1 + T2 + T3
- **T2 `scripts/phase_run.py`**: one call per phase (p1 intake, p6 build, p7 accents + sound, p8 colour, p9 QC, p10 Final) — runs the phase's tools, keeps full results in `phase_run/<mode>.full.json`, returns a short summary and the images worth opening; resumes when a phase needs more than one call.
- **T3**: `STATUS.md` per project (rewritten by every phase run) so each project runs in its own session; footage frames reviewed by a subagent that returns a text catalogue (`references/phases/footage-subagent.md`).
- **T1**: one overview sheet for all sources (`frame_probe.py`, ≤ 1024 px), QC sheets capped at 1024 px, reports ≤ 12 lines, `references/api-quick.md` before the 3k-word cookbook.

## What's new in v3.0.2 (2026-10-27) — speed and token use (option A)
- **Express mode by default** (`workflow.mode`): three stops — E1 story + music, E2 review, E3 Final + graphics in one round; Gate 0, 1b and 2 run on stated assumptions (Standard mode on request keeps every gate). Hard gates and approvals are unchanged.
- **SKILL.md split**: a ~1,750-word core (was ~4,600) + ten phase cards in `references/phases/` (each with tools, modules to read and a "done when") + the full module index in `references/phases/router.md`.
- **`scripts/timeline_ops.py`**: next_draft, place_media, reappend_audio, set_levels, compare — the timeline jobs that were hand-written on the TNCRoast run.
- **`scripts/stage.py`**: one-command staging with obsolete-tool clean-up and md5 check.
- **`inventory.py` compact output** by default (about half the characters on the TNCRoast pool).
- 222 offline tests.

## What's new in v3.0.1 (2026-10-27) — fixes from the first live run (project Test_, TNC Coffee footage)
- Loader found no config when it was staged as `_tools/config/defaults.json` → every script silently ran on in-file defaults. It now reads both places; `stage_check` reports `config_version`, `NO_CONFIG` and stale removed tools (`OBSOLETE_FILES_STAGED`).
- `inventory.py`: `DUPLICATE_MEDIA` (13 pool items were 7 sources), `LOW_RES_SOURCE` (720p into 2160×3840 = 5.3× upscale); fps question moved to Gate 0, before the first Probe_ timeline locks the project fps.
- `frame_probe.py`: decodes one item per duplicate group (6 of 13 skipped), canonical names, thumbnails fitted by the long edge (portrait sheets 1460×1930 → 1240×732).
- `music_library.py` picks carry `bpm_label` (measured / estimated with confidence), half/double alternatives and `hit_spacing_s` — a 0.43-confidence tempo was shown as a plain number.
- Track layout: V2 = B-roll, V3–V5 reserved for HyperFrames (V2 was both); `qa_audit.py` checks the graphics tracks stay empty and no longer subtracts B-roll as "titles".
- 201 offline tests.

## What's new in v3.0.0 (2026-10-27) — editor first, graphics handed to HyperFrames
- **Ten phases in a fixed order**: 1 intake · 2 music analysis · 3 footage analysis · 4 story · 5 B-roll and shot selection · 6 montage · 7 transitions and sound · 8 technical colour · 9 QC · 10 HyperFrames hand-over. Gates 0 → 1 → 1b → 2 → 3 → 4 are mapped onto them.
- **Graphics are no longer built here.** Removed: `text_fx.py`, `text_qa.py`, `calibrate_fonts.py`, `fonts.py`, `track_point.py`, the title modes of `fx_apply.py`, and the references `text-system`, `beat-text-fx`, `advanced-text-fx`, `motion-graphics`, `design-directions`. Video tracks above V1 stay empty and are named "Đồ họa A/B/C (HyperFrames)".
- **Phase 10** (`references/hyperframes-handoff.md`, `scripts/hyperframes_handoff.py`): after the Final is locked Claude asks short graphic questions with concrete options (main title and opening text, section titles and on-screen text, subtitles and captions, motion graphics and animation, supporting visuals, graphic style and references, timing/position/hierarchy/animation behaviour), never decides a design on its own, and writes `handoff_<Title>.md` + `.json` (frames and timecode, vi/en text, position, hierarchy, animation intent, anchors to cuts/beats, existing SFX, technical specs). Status is `APPROVED` only when nothing is `proposed` or `open`.
- **Music analysis first** (`references/music-analysis.md`): structure, phrases, drop and cut chances, each number labelled measured or estimated; no invented BPM or beat times.
- **Colour is technical only**: LOG normalisation, white balance, exposure, contrast, casts, shot-to-shot and camera matching, skin tones. No look question at any gate; creative looks only when asked in words.
- **Kept as before**: motion accents in Resolve (speed ramp, push/pull, punch, shake, flash, freeze) with matching sound; research (vidIQ free credits + free sources); style profiles (editing fields only); montage, story, composition, SFX, ending, QA, finalize and Vietnamese names; no render by Claude.
- Offline tests updated (`tests/test_v300.py`); new code UNTESTED live.

Earlier versions: see `CHANGELOG.md`.

## Package
- `SKILL.md` — entry point: mission and scope boundary, defaults, folders, gates, layers, ten phases, change router, hard gates
- `config/defaults.json` — shared settings (single source of truth)
- `references/` — 40 modules listed in the router table of SKILL.md
- `scripts/` — helper scripts + `scripts/README.md` (loader, config, blueprint schema)
- `tests/` — offline tests: `python3 -m unittest discover -s tests`
- `WORKFLOW.md` — one-page map of the workflow
- `INSTALL.md`, `TEST-PROMPTS.md`, `CHANGELOG.md`, `THIRD_PARTY_NOTICES.md`

## Important
A skill is instructions, not a guarantee. Every write is read back; every visual claim needs a frame Claude actually saw; audio is never claimed "good" without someone listening; a file check is not playback.
