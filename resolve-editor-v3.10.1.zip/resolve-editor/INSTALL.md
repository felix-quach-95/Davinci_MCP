# Install — Resolve Editor v3.10.1 (skill name `resolve-editor`)

## Install in Claude Desktop
1. Download `resolve-editor-v3.10.1.zip`.
2. The ZIP contains one folder `resolve-editor/` with `SKILL.md`, `config/`, `references/`, `scripts/`, `tests/` and `motion-studio/` (Motion Studio 0.4.1 for Phase 11, unchanged except its guide is named `GUIDE.md`). It is one upload: no separate skill to add.
3. In Claude Desktop, open the Skills/customization area (the exact location can vary by app version).
4. Add/upload the skill ZIP if supported; otherwise select the unzipped skill folder.
5. Enable the skill. If Claude asks to enable code execution for the skill, review and enable it only if that is part of your intended setup.
6. Start a new conversation and run the read-only preflight prompt below.

Official Claude help:
- https://support.claude.com/en/articles/12512198-how-to-create-custom-skills
- https://support.claude.com/en/articles/12512180-use-skills-in-claude

## First test: read-only preflight
> Use `resolve-editor`. Do not edit anything. Check Resolve status and current project read-only. Inventory every Media Pool item and its actual source path/metadata. Determine whether local frame extraction is possible and whether extracted images can actually be inspected in this Claude session. Analyze the full reference only if its video frames/audio are genuinely accessible. Do not upload footage externally, modify source files, change project settings, or mutate any timeline. Separate observed facts from unknowns and report the next smallest required step.

## First editing run
1. Import the intended source footage into Resolve yourself.
2. Upload the reference video directly into Claude Desktop, if the interface can accept and expose it.
3. Ask Claude to run the skill. Let it inventory the media pool, analyze the reference if accessible, and prepare a teaser duration recommendation plus an edit blueprint.
4. Review/approve the proposed design direction and blueprint only if a meaningful decision is unresolved.
5. Let Claude build a new draft timeline in small batches, with read-back checks.
6. Review the draft in Resolve. Do not treat structural verification as proof of visual/audio quality.

## Upgrading
- From v2.x: replace the skill folder (same name `resolve-editor`). On the next run Claude re-stages the scripts and `config/defaults.json` into `/Users/felix/Desktop/Final/Cache Edit/_tools/` (new md5; v2.9).
- From v1.x: remove or disable the old skill (it was called "resolve-shortform-editor") first, then add this one. Your projects are not affected.
- If you changed paths or levels by editing scripts before, move those values into `config/defaults.json` (or a project's `project.json`).

## Free music and SFX (v2.8, optional)
- When your library lacks a fitting track or sound, Claude proposes free files with their licences (Pixabay, Mixkit, Sonniss, Freesound CC0; credit-required sources marked) and downloads only what you approve. Files go to `_Free/<source>/` inside your Music / Sound Effect folders, each with a `.licence.json` file. Sites that need an account: you sign in yourself.
- Preferences and lessons from your reviews are kept in `~/Movies/ClaudeQC/_prefs.json` so the next video starts from your last choices.

## Research connector (v2.5, optional)
- For trend/hook/keyword research before the edit, connect **vidIQ** in Claude (Settings → Connectors → vidIQ, sign in with your vidIQ account). Connecting is free on every vidIQ plan; research calls spend vidIQ credits (most tools 5, a short-video walkthrough 10, the balance check 0); the skill checks your balance first and uses only your plan's free renewable credits, at most 30 per research pass (`config/defaults.json` → `research`). When they run out it switches to free sources by itself (TikTok Creative Center, TikTok/YouTube search pages, Google Trends, web) — it never asks you to buy credits.
- Only topic words are sent to vidIQ — never footage, transcripts or project names.
- Without the connector the skill still researches, from the free sources above (read only, in the built-in browser).

## Motion Studio for Phase 11 (v3.6.0)
- Phase 11 (graphics) uses Motion Studio (the newest HyperFrames release at install time), which ships inside this skill. The first time Phase 11 runs, Claude asks once and installs it on the Mac by itself (`scripts/install_motion_studio.py`, then its own `install.sh`: Node.js 22 if missing, FFmpeg, HyperFrames' skills into `~/.claude/skills`), then continues in the same chat. Nothing to download separately.
- Phase 11 runs in the same chat as the edit (v3.10.0): after the Final, Claude asks "Chuyển sang HyperFrames ngay?", opens the style gallery with pictures in the browser, then asks the graphic questions; the HyperFrames build runs in a fresh-context agent inside the same chat and the Studio preview link is sent the moment it runs. No `/clear`, no new chat.

## Fonts (v3.0.0)
- Claude no longer builds text, so no fonts are installed by this skill (v2.x `fonts.py` was removed). Fonts for titles and subtitles belong to the HyperFrames project.

## Effects and SFX libraries (v2.0.0)
- Template packs are read from `~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates` (including `.drfx` bundles); nothing there is changed. Add new packs any time — ask Claude to rescan.
- Music and SFX folders, export folder, track layout, levels, safe zones and render presets are set in **`config/defaults.json`** (`paths`, `levels_db`, `delivery` …). Edit that file (or ask Claude to) instead of the scripts.
- The first SFX scan takes ~3 short calls (cache `~/Movies/ClaudeQC/_sfx/`); the music scan a few calls (cache `~/Movies/ClaudeQC/_music/`).
- **Temporary files (v2.9)**: working copies of the scripts, per-project choices (`<Title>/project.json`), contact sheets, stills and the backup made before cleanup all go to `/Users/felix/Desktop/Final/Cache Edit`. Delete that folder after the Final; the next video recreates it. `~/Movies/ClaudeQC` keeps only what the next video reuses (preferences, styles, music/SFX/FX catalogues, font calibration) — keep it.
- **No render by Claude (v2.9)**: Claude stops at a clean Final timeline (Vietnamese names, tidy node trees, only the Final and its text timelines left, Deliver page pointed at Desktop/Final). You fine-tune and render.

## ffmpeg (v2.1.0 — installed by Claude when missing, no admin password)
Footage contact sheets (`frame_probe.py`), QC contact sheets (`qc_stills.py`), faster audio analysis and the delivery file/loudness check (`render_deliver.py` verify) use ffmpeg/ffprobe. Resolve's script PATH includes `~/.local/bin`, so a signed static build placed there works without Homebrew or sudo:
1. Download the notarized arm64 builds: `https://ffmpeg.martin-riedl.de/redirect/latest/macos/arm64/release/ffmpeg.zip` and `.../ffprobe.zip` into an empty folder (Intel Macs: `.../macos/amd64/...`).
2. Unzip; verify before installing: `codesign -dv` must show `Developer ID Application: Martin Riedl (KU3N25YGLU)` and `spctl -a -vv -t install` must say `accepted, source=Notarized Developer ID`. Stop if not.
3. `mkdir -p ~/.local/bin && cp ffmpeg ffprobe ~/.local/bin/`, remove the quarantine attribute, run `ffmpeg -version`.
4. Check from Resolve: `shutil.which("ffmpeg")` inside `run_script_unsafe` returns `~/.local/bin/ffmpeg`.
Installed on the user's Mac 2026-10-25 (ffmpeg 9.0.2). With Homebrew, `brew install ffmpeg` works too.

## Optional, for richer QC (not required)
- Visual checks need Claude to see exported previews. In Claude Desktop with file access this works directly; in a cloud session linked to the Mac, approve folder access to `/Users/felix/Desktop/Final/Cache Edit` when asked.
- Without ffmpeg the skill still works (macOS `afconvert`/`sips`), but footage analysis costs more: see `references/broll.md` §3b for the fallback.

## Cost and privacy
- No extra paid API is required by this skill.
- Only pre-approved dependencies are installed automatically: OFL fonts and ffmpeg/ffprobe (above), always reported.
- The workflow prefers local analysis and Resolve-native tools.
- Do not upload footage to external services without explicit user approval.
- If `ffmpeg`/`ffprobe` cannot be installed (no network, refused signature check), use the Resolve still route and report the limitation.

## Offline self-test (no Resolve needed)
```
python3 -m unittest discover -s tests
```
Expect every test OK (v2.1–v2.4 suites; one test is skipped on purpose when no font file is found).

## Camera LUTs (v2.2)
Conversions for Sony S-Log3, Panasonic V-Log, DJI D-Log (X7/Phantom 4), ARRI LogC, Blackmagic Film, Leica L-Log, Samsung Log, OM-Log and HLG ship with Resolve and are used directly. Apple Log, Canon C-Log3 and DJI D-Log M need the camera maker's official LUT: Claude asks before downloading one (into the Resolve LUT folder) or uses conversion in a colour-managed project instead.
