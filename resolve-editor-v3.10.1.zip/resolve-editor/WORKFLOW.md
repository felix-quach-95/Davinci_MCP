# Workflow map — resolve-editor v3.10.1 (one page)

Not loaded automatically; a human-readable map of how a project runs. The rules live in `SKILL.md`, the details in the phase cards (`references/phases/`).

## Flow (Express mode; Standard adds the kickoff questions, rough-cut approval and hero accent choice)
```
 STATUS.md exists? ──yes──▶ resume at "Next"
     │ no
 Phase 1  Intake and footage check: stage tools ─▶ inventory ─▶ blockers ─▶ footage scan (subagent)
          ─▶ ◆ Style choice (5 options + your own) ─▶ ◆ Music request (you send the file)
 Phase 2  Music analysis: tempo, beats, phrases, energy (measured or estimated)
 Phase 3  Footage catalogue: shots with IDs, stages, in/out points, roles, image groups, effects, B-roll
 Phase 4  Story decision: story contract ─▶ beat map ─▶ two structures compared ─▶ ◆ Story approval
 Phase 5  Shot selection: V1 spine ─▶ fx_plan per shot ─▶ V2 B-roll cutaways ─▶ repeat checks ─▶ blueprint
 Phase 6  Draft build and rough-cut review: Draft_v01 (shot_01 … names, music Green) ─▶ read-back ─▶ review
 Phase 7  Accents and sound: zoom moves, zoom-throughs ─▶ transition SFX only (Yellow) ─▶ ending ─▶ audio check
 Phase 8  Technical colour: conversion, white balance, exposure, matching
 Phase 9  Quality control and draft review: technical and editorial verdicts ─▶ ◆ Draft review ─▶ fixes
 Phase 10 Final and cleanup: Final copy ─▶ ◆ Final approval (name + cleanup, no graphic question) ─▶ cleanup ─▶ report
 ════════ same chat: ◆ "Chuyển sang HyperFrames ngay?" (no new window, no /clear) ════════
 Phase 11 Graphics (motion-studio): ◆ style gallery (pictures) ─▶ ◆ graphic questions ─▶ ◆ brief ─▶ build agent ─▶ preview link ─▶ ◆ Studio review ─▶ ◆ export MOV ─▶ ffprobe check
 ◆ = the user answers. Claude never renders the Final; the graphics MOV is rendered in Phase 11 when the user says so.
```

## Phase table
| Phase | Input | Output (in `project.json` or files) | Stop | Main modules |
|---|---|---|---|---|
| 1 Intake and footage check | footage, brief | inventory warnings · scan · `style` · `music` | Style choice, Music request | `options-playbook` §1–§3, `footage-intelligence` §1, `footage-subagent` |
| 2 Music analysis | the user's track | music map (measured or estimated) | — | `music-analysis` |
| 3 Footage catalogue | scan, range sheets | `catalogue.json`: shots with IDs, `grp`, `fx`, SEEN / INFERRED / UNVERIFIED counts | — | `footage-intelligence`, `broll` |
| 4 Story decision | catalogue, music map, style | contract · beat map · paper edit · `story.ready` | Story approval | `story-decision-framework`, `story-structure` |
| 5 Shot selection | beat map, catalogue | blueprint with `shot`, `grp`, `info`, `score`, `why`, `rejected`, `cut` | — | `shot-selection-and-continuity`, `composition` |
| 6 Draft build and rough-cut review | blueprint | `Draft_<Title>_v01`, rough-cut sheet, editorial verdict | (Rough-cut approval) | `editorial-decision-and-qc` §2–4, `montage-advanced` |
| 7 Accents and sound | Draft | accents checked on/off, SFX placed, natural ending | (Hero accent choice) | `motion-effects` §0, `sfx-library`, `endings` |
| 8 Technical colour | Draft | colour version `claude_look`, numbers | — | `color-look` |
| 9 Quality control and draft review | Draft | scorecard · technical and editorial verdicts · notes → next Draft | Draft review | `review-scorecard`, `editorial-decision-and-qc` |
| 10 Final and cleanup | approved Draft | `Final_<Title>_NN` · backup | Final approval, switch question | `delivery` |
| 11 Graphics (same chat) | Final + answers → package | `handoff_<Title>.md/.json` · package `hyperframes/` · `videos/<name>/` HyperFrames project · one MOV per layer (alpha) | style gallery, graphic questions, brief, SPEC, Studio review, export | `phase-11`, `hyperframes-handoff`, Motion Studio `SKILL.md` |

## Fixing by scope (any review note)
One item → `replace_shot` / trim / one effect · one chapter → re-fit its segments · structure → blueprint → layers 1 → 2 → 3 → 4 → quality checks · sound only → layer 3 · colour only → layer 4. Say which layers re-run first; every fix goes into the next `Draft_<Title>_vNN`; at most two loops per stop (`editorial-decision-and-qc.md` §7).

## Where each requirement lives
| Requirement | Where |
|---|---|
| Model per agent, depth 1, briefs by reference, escalation | `agents-and-models.md`, config `models` |
| Graphics made entirely by `motion-studio` (HyperFrames) after the Final, in the same chat | `phases/phase-11.md`, `hyperframes-handoff.md` §9, `hyperframes_handoff.py` `hf_request` |
| Video at most 30 seconds | `workflow.max_runtime_s`, `edit_analysis.py`, hard rule 5, `story-decision-framework` §2 |
| 5 style options plus your own, after the footage check | Phase 1, `options-playbook` §2 |
| One music request after the style choice; the user sends the file | Phase 1, `options-playbook` §3, `music_intake.py` `music_request`, hard rule 13 |
| Shots named left to right (`shot_01` …); music Green, SFX Yellow | `build_from_blueprint.py` `label_timeline`, `replace_shot.py`, `sfx_library.py` `SFX_COLOR` |
| B-roll layer on V2 (one every ~4 s, 25–50 %, text-checked) | `broll.md` §0a, `edit_analysis.py` `broll_report`, Phase 5 step 6 |
| More speed ramps (5–7 per 30 s, long enough to feel) and zoom moves | `motion-effects.md` §0.4, `edit_analysis.py` `fx_report` |
| SFX only on transitions, 7–10 per 30 s, peak ceiling | `sfx-library.md` §3, `sfx_library.py` `TRANSITION_ONLY` |
| Better B-roll, no flat video | `footage-intelligence` §7, `broll` §0, `shot-selection-and-continuity` §6 |
| No repeated footage | four repeat levels, `edit_analysis.py` `repeat_report`, `editorial-decision-and-qc` §4 |
| Cinematic effects: speed ramp, zoom in, zoom out | `motion-effects` §0, `shot-selection-and-continuity` §5 |
| The story chooses the shots | `story-decision-framework`, Phase 4 exit checklist |
| Editorial quality judged apart from technical quality | `editorial-decision-and-qc` §1, scorecard editorial lane |
