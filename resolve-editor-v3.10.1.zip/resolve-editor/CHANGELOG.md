# Changelog

## 3.10.1 — 2026-10-28
User question: does the Phase 11 agent re-read the edit chat? It does not (it starts empty and reads only the package); the remaining cost is the relay turns in the main chat. To cut them:
- Phase 11 build agent stops only 3 times: SPEC summary · preview + review in one · export + placing in one (the separate "placing" question is gone).
- Changes: direct edits in Studio first (no relay), chat changes in one message applied in one go.
- Lean relay rule: the main chat passes reports and answers word for word, no extra reading or questions.
- Studio tips ask for all changes in one message. Tests: `tests/test_v3101.py`.

## 3.10.0 — 2026-10-28
User test in Claude Code (TestSkill, Đêm Montpellier): four fixes to the Phase 10 → 11 hand-off.
- **Graphic questions moved to Phase 11.** Phase 10's Final approval asks only the Final name and the cleanup (Express and Standard); then one switch question "Final đã xong. Chuyển sang Phase 11 — làm đồ họa với HyperFrames?" · Chuyển sang HyperFrames ngay · Để sau · Không cần đồ họa. Graphic scope, wording, placement and feel are asked in Phase 11 (`options-playbook.md` §8b), after the style.
- **No new window / new session option.** "Phiên mới hoàn toàn" and the scheduled-task new session are removed; `/clear` and new chats are never proposed (also after installing Motion Studio: the same chat continues through the "files" route). The HyperFrames build still runs in a fresh-context agent *inside the same chat* to save usage; without the Agent tool it runs directly in the chat.
- **Style gallery with pictures first.** Phase 11 opens Motion Studio's gallery (HyperFrames' built-in looks rendered live from their showcase pages, plus saved looks) in the browser and sends its `file://` link in the chat, recommends 2–3 looks, and waits for the pick; never a text-only list, never a silent choice. Phase 10 no longer pre-fills `style.look`, which is why the gallery never appeared in the v3.9.0 test.
- **Preview link sent at once.** The build agent returns `STOP preview` with a `LINK:` as soon as HyperFrames Studio's preview runs (started in the background); the main chat relays links first, opens the preview, checks it answers (HTTP 200) and re-sends it after a restart; every later stop repeats it. `HF_REQUEST` asks HyperFrames for the link; Motion Studio's guide and Studio tips open with it.
- Phase 10 and 11 cards, `hyperframes-handoff.md` §1–§2 and §9, SKILL.md, WORKFLOW, router, runbook, agents note, config (`phase11.same_chat`, `switch_question`, `order`, `send_links`), `phase_run.py` STATUS "Next", `hyperframes_handoff.py` (START_PHASE11.md = resume line in the same chat), `install_motion_studio.py` "then", INSTALL, README, TEST-PROMPTS.
- Tests: `tests/test_v3100.py`; earlier tests follow the new wording.

## 3.9.0 — 2026-10-28
User request: use the newest HyperFrames for the skill. npm `latest` = 0.8.209 (27 Oct); its skills (tag v0.8.209) were read for this change. Offline only.
- **Correction of 3.8.1:** "HyperFrames 1.2.3" on the user's Mac was a version string in HyperFrames' own test files, not the installed release; the skills there call an unpinned `npx hyperframes`. `--check-hf` now ignores `*.test.*` files and reports `unpinned`; status `OK` / `NEEDS_UPDATE` → `install.sh --update` (which replaces those skills). `--move-hf-aside` stays as an optional backup.
- `install_motion_studio.py`: pins the newest HyperFrames on npm at install (`--hf-version latest|x.y.z|shipped`; offline → shipped 0.8.209) and tells to run `install.sh --update`.
- Embedded Motion Studio → 0.5.0 (from the user's 0.4.1): `hyperframesVersion` 0.8.209; guide, hand-off and README follow the new flow (three storylines when the story is open, `SPEC.md` confirmed instead of the brief, `check --json` + `snapshot --review` → `REVIEW.md`, the HyperFrames desktop app); how to move to a newer release between jobs. Scripts unchanged except a comment.
- `hyperframes_handoff.py`: `render_fps` gives the rational rate (`30000/1001`), no conform note; times to the millisecond with frames as the truth; storylines off, SPEC summary; `solo` via opacity on inner wrappers (HyperFrames' contract forbids display/visibility on a `.clip`), track kinds; per-layer renders through the documented `render --batch … --format mov --output "{name}.mov" --strict-variables`, rows in `layers_rows.json`; Vietnamese font line for the Latin-only bundle; SPEC `hf_version` for the installed pin.
- `hf_layers.py` unchanged; frame-exact trim re-tested at 29.97 fps (frames 37, 299, 541: md5 equal).
- Phase 11 card, `hyperframes-handoff.md` §9, router, config, INSTALL, README, TEST-PROMPTS.
- Tests: `tests/test_v390.py`; v3.6–3.8 tests follow the rational fps and the new wording.

## 3.8.1 — 2026-10-28
Audit of the user's Mac (`~/.claude`): HyperFrames skills 1.2.3 were already installed, while Motion Studio pins 0.8.181 and its setup skips fetching when a `hyperframes` folder exists, so Phase 11 would have run on the wrong release.
- `install_motion_studio.py`: `--check-hf` (installed HyperFrames release vs the pin) and `--move-hf-aside` (moves `hyperframes`, `hyperframes-cli`, `hyperframes-registry`, `media-use` into `.backup-hyperframes-<time>/`, nothing deleted). Phase 11 step 0 asks before replacing.
- Tests: `tests/test_v381.py`.

## 3.8.0 — 2026-10-28
User request: review every skill, agent, workflow, subagent and model setting, then reassign models to cut tokens and cost without losing any rule or feature. Offline only.
Audit (v3.7.1): two agent uses — the footage subagent (one model line, "sonnet") and the Phase 11 agent (no model: it inherited the main model, Opus-class when the user runs Opus, for 40–150 calls). Context costs found: footage prompt templates pasted into Agent calls (they stay in the main context), one deepen agent reading many sheets one by one, ~24 burned-text stills opened in the main context in Phase 6, raw vidIQ/web results in the main context, Phase 10 package stills open to the main session, no rule against nested agents.
- New `references/agents-and-models.md`: roster A0–A6 with model, inputs by path, outputs; main-session model guidance (Opus-class for session A, or the economy profile Sonnet + A5 on Opus); rules (depth 1, briefs by reference ≤ 12 lines, images once in one turn, ≤ 4 sources per deepen agent, return only what is used, ≤ 3 turns); escalation table.
- Wired into `footage-subagent.md`, Phase 1 (A1 haiku, A4 haiku), Phase 3 (A2 sonnet, batches), Phase 4 / 6 / 9 (A5 opus when the main session is not Opus-class), Phase 6 (A3 sonnet), Phase 10 (stills not opened), Phase 11 (A6 sonnet, depth 1), router, SKILL.md (word-neutral), config `models`.
- Nothing removed: every phase, stop, hard rule, script and Phase 11 feature is unchanged; only who reads what, and on which model.
- Tests: `tests/test_v380.py`; `test_v310` now checks the deepen pass is on sonnet (the scan moved to haiku).

## 3.7.1 — 2026-10-28
The skill upload refused v3.7.0 ("Zip cannot contain nested zip files"); the user wants one skill file.
- Motion Studio 0.4.1 is embedded as the folder `motion-studio/`, unchanged except `SKILL.md` → `GUIDE.md` (one SKILL.md per upload). The nested zip is gone.
- New `scripts/install_motion_studio.py`: copies it to `~/.claude/skills/motion-studio` with `SKILL.md` restored (keeps `styles/`, `.tools/`, `node_modules/`; refuses a linked destination), or `--pack` a tar.gz for a cloud-side skill with a linked Mac. Tested offline: the installed copy is byte-identical to the user's original.
- Phase 11 step 0 and the agent brief, config `handoff.phase11.bundled`, INSTALL, README, THIRD_PARTY_NOTICES.
- Tests: `tests/test_v371.py`.

## 3.7.0 — 2026-10-28
User requests: Claude asks and switches the session itself before Phase 11; every HyperFrames object must be separate and named, so it can be refined in DaVinci and recognised by its colour on the timeline. Offline only; the ProRes trim was tested on a generated ProRes 4444 alpha clip (frame-exact, md5 equal), nothing was run in Resolve or HyperFrames.
- **Phase 11 switch** (`phase-11.md` §1): one question at the end of Phase 10 — fresh-context agent now (default; stops relayed through the main chat with SendMessage), a whole new session (a one-time scheduled task where the app has one, else `/clear` + the line), or later. Agent brief included.
- **Layers:** `hyperframes_handoff.py` `plan_layers` (names `DHnn_<Kind>_<Words>` in order of appearance, colour by kind, track groups bottom→top Chuyển động / Chữ / Tiêu đề / Phụ đề with extra lanes for overlaps, `solo` rows, the `place_media` list) → `layers_<Title>.json`; `HF_REQUEST` asks HyperFrames for one top-level layer per element with those exact names and a `solo` variable. New `hf_layers.py`: trims each full-length per-layer render to its span (stream copy) and checks prores, alpha, size, frame count, no audio.
- `timeline_ops.py` place_media: `name`, `color` (item and pool clip), `track_name`, adds video tracks up to the number asked, `fps` on the pool clip for a 30 fps render on a 29.97 Final (not yet run live).
- Phase 10 card step 7, `options-playbook.md` §8, runbook, `hyperframes-handoff.md` §9, SKILL.md, config `handoff.phase11.layers`.
- Tests: `tests/test_v370.py`.

## 3.6.0 — 2026-10-28
User request: integrate the user's Motion Studio skill (motion-studio 0.4.1, HyperFrames 0.8.181) so the HyperFrames work after the Final runs entirely with it, and handle the token cost of running it after a long editing chat. Offline only; nothing run live in Resolve or HyperFrames.
- **Phase 11** (`references/phases/phase-11.md`): new session only; Motion Studio's own steps (install check, style, hand-off to `hyperframes`, build, Studio review, export) with Describe skipped, no music step, export only when asked, MOV ProRes 4444 with alpha, ffprobe check against the Final (size, frame count, alpha, no audio), overlay stills over the Final, placing on request on a Draft. How to run it in Claude Code (recommended) or in the Claude app via the linked Mac's shell.
- `hyperframes_handoff.py`: `hf_request` (the request in Motion Studio's hand-off shape, overlay rules, seconds from frames at a whole render rate with the same frame count, variables with Vietnamese labels, the pinned render line) and `start_phase11`; both written only when the status is APPROVED. New SPEC keys `stills`, `package_dir`, `style.look`.
- Session boundary: SKILL.md "Two sessions per project", `hyperframes-handoff.md` §9 (why, package table, frame rates), Phase 10 card steps 6–7, `options-playbook.md` §8 (style from Motion Studio's library; the last message of the editing session), `phase_run.py` STATUS "Next", runbook rows 17 and Phase 11, router, `WORKFLOW.md`, config `handoff.phase11`.
- Motion Studio is not bundled (skill upload refuses nested zips); Phase 11 asks for its zip when missing.
- Tests: `tests/test_v360.py`; version checks moved to 3.6.0; `test_v310` now checks "Two sessions" (the one-session rule became two sessions).

## 3.5.1 — 2026-10-27
User review of TestSkill: the speed ramps were too short to feel; the v3.5.0 SFX levels are fine. Offline only.
- `edit_analysis.py`: `RAMPS_PER_30S` 3 → 5; new `ramp_feel` (in `fx_report`) flags a ramp with a step under 0.33 s on screen, a total under 1.5 s, a slow part under 0.6 s, or fastest/slowest under 2.5×. On TestSkill v01 it flags the hook ramp (steps of 0.23 and 0.07 s).
- `motion-effects.md` §0.1 rewritten with speed × seconds on screen for each ramp type and the source each step uses; §0.4 5–7 ramps per 30 s. `SKILL.md`, Phase 5 card and `WORKFLOW.md` follow.
- Tests: `tests/test_v351.py`.

## 3.5.0 — 2026-10-27
From the first full live run of v3.4.0 (project "Test skill", TestSkill, Final_NghiThucCaPhe_02 with HyperFrames subtitles). Offline tests pass; the changes below are not yet run live.
- **More B-roll.** `edit_analysis.py` `BROLL_EVERY_S` 6 → 4 s (30 s → 8 cutaways), `BROLL_COVER` 0.15–0.45 → 0.25–0.50; Phase 3 mines about 16 for 30 s. The user found 6 cutaways too few.
- **Burned-text check on B-roll.** Every V2 segment needs `text_checked: true` (set after stills of its first, middle and last frame); `broll_report` flags it otherwise. Phase 6 has a burned-text step; the footage subagent prompt says a range is text-free only when every thumbnail was checked. Live: the catalogue called S63 and S65 clean, both had subtitles.
- **More transition SFX.** 7–10 per 30 s (was 3–6): every ramp/zoom-through/whip join, the drop, chapter turns, B-roll entries with motion. `sfx_library.py` reports `transitions` placed vs `TRANSITIONS_PER_30S` and flags a short cue sheet.
- **SFX levels.** whoosh −8 → −4, transition −10 → −6 (`levels_db` and `LEVELS`); `PEAK_CEIL_DBFS` = 0 caps automatic levels by the file's own peak. Live: whooshes were "buried" at −4 dB and clipped the mix at +4 dB; 0..+1 dB worked.
- **Ramp naming.** `build_from_blueprint.py` `grouped_names` / `segment_keys`: the steps of one speed ramp share a number (`shot_01a`, `shot_01b`, `shot_01c`); falls back to plain numbers when the item count does not match the blueprint.
- **Subtitle readability** lesson in `hyperframes-handoff.md` (scrim ~0.5, second line ≥ 28 px at weight 400).
- Tests: `tests/test_v350.py`.

## 3.4.0 — 2026-10-27
Requested by the user after reviewing the CozyDay result. Offline: all 262 tests pass; nothing below was run live in Resolve.
- **SFX only for transitions.** `sfx_library.py` MODE place refuses a cue whose event is not within `CUT_TOL` = 3 frames of a V1/V2 cut (`TRANSITION_ONLY`, `timeline_cuts`, `on_a_cut`). `sfx-library.md` §3 rewritten: whoosh on ramp-through, zoom-through and whip joins, riser + sub drop into the drop, hit on a smash cut, swell on dissolves; about 3–6 per 30 s; no SFX for titles, gestures, in-shot accents or ambience beds. `motion-effects.md`, `shot-selection-and-continuity.md`, `review-scorecard.md`, Phase 7 card and `SKILL.md` follow.
- **More speed ramps and zoom moves.** `motion-effects.md` §0 rewritten from editing guides: five speed-ramp types (ramp-in-hold, ramp-through transition, launch, near-freeze, velocity steps) with frame-rate limits for 24–30 fps footage; nine zoom types (slow push, slow pull, punch-in, snap zoom, zoom-through exit and entry, reverse zoom cut, push-then-pull, crash zoom); recipes by story section; density 3–5 speed ramps per 30 s, zoom moves on ≥ 60 % of shots, 2–4 zoom-through joins. New `motion_fx.py` effect `zoom_keys` (any zoom curve, negative times from the end). Every blueprint segment gets an `fx_plan`; `edit_analysis.py` `fx_report` warns below the counts or when one plan repeats three times.
- **B-roll layer on V2.** Root cause on CozyDay: every shot went into one V1 sequence and nothing asked for V2. Now V1 is the story spine and V2 carries B-roll cutaways (`broll.md` §0a): at least 3 and one every ~6 s, 0.4–2.0 s each, 15–45 % of the runtime, each with `broll_type`, `why`, its own `grp`. Phase 3 mines ≥ 2× the cutaways needed; Phase 5 places them; `edit_analysis.py` `broll_report` checks count, coverage, length, overlap, type, reason and repeats against V1.
- Fixes to v3.3.0 found by the test suite: the vidIQ research rules and the phase-card paths had dropped out of Phase 1 / `SKILL.md` and are back; `build_from_blueprint.py` labelling tolerates items without `SetName`/`SetClipColor`.
- Tests: `tests/test_v340.py`; earlier tests updated to the v3.3.0 names.

## 3.3.0 — 2026-10-27
Requested by the user after the CozyDay live test (offline only; nothing below was run live).
- **Music request replaces music previews.** After the Style choice Claude sends one message "Yêu cầu gửi nhạc nền" (`music_intake.py` `music_request(style, runtime_s)`) and waits for the user's file. No music styles, previews, library picks or downloads; hard rule 13 "Music boundary". `preview_question` removed; `music-analysis.md` §0, `free-audio-sources.md` (now SFX only), `options-playbook.md` §3 rewritten.
- **Clear names, no abbreviations.** Ten phases kept, each with a full name (1 Intake and footage check … 10 Final and hand-over). Stops renamed: Kickoff questions, Style choice, Music request, Story approval, Rough-cut approval, Hero accent choice, Draft review, Final approval (were Gate 0, E0a, E0b, E1/Gate 1, Gate 1b, Gate 2, E2/Gate 3, E3/Gate 4). `SKILL.md`, `WORKFLOW.md`, every phase card, the runbook, the router and `options-playbook.md` rewritten short; other references renamed in place.
- **Shot names on the timeline.** `build_from_blueprint.py` `label_timeline`: after every build, V1 items are named left to right `shot_01`, `shot_02` …, V2 items `broll_01` …; `replace_shot.py` gives the new item the old name and colour.
- **Music and SFX colours.** Music Green, SFX Yellow from the moment they are placed (`build_from_blueprint.py` `CLIP_COLORS`, `sfx_library.py` `SFX_COLOR`, `timeline_ops.py` reappend_audio keeps the colour) — not only at the Phase 10 cleanup.
- Known tool limits from the live run written into `SKILL.md` (phase_run PARTIAL loop on long steps, frame_probe and Media Pool subclips); `project.json` records answers under `stops`.
- Tests updated to the new names; `tests/test_v330.py` replaces `test_v321.py`. **Tests were not run** (user request).

## 3.2.1 — 2026-10-27
Workflow consolidation (no feature removed; offline only). A consistency pass over v3.2.0.
- `phase-01.md` rewritten as one ordered procedure (8 steps: resume, intake call, blockers, runtime, optional research, scan, E0a, E0b) with the answers recorded in `project.json` (`gates`, `style`, `music`).
- `options-playbook.md` §1: Gate 0 no longer asks style or music (they are E0a/E0b in both modes); format offers 30 s as the maximum; `style-profiles.md`, `music-analysis.md`, `free-audio-sources.md`, `phase-02.md`, `SKILL.md` no longer describe the old Gate 0 music/style flow.
- `phase-07.md`: speed ramps are planned in the blueprint (Phase 5–6) and only checked in Phase 7; E3 wording "graphic style" so it cannot be confused with the E0a style.
- `phase_run.py`: STATUS.md now keeps `gates`, `style`, `story`, `footage`, and its p1 "Next" line names scan → E0a → E0b → Phase 2.
- New `WORKFLOW.md` (one-page map, phase table, requirement traceability); all phase cards carry v3.2.1.
- Tests: `tests/test_v321.py`.

## 3.2.0 — 2026-10-27
Editorial intelligence release (offline only; new text and `repeat_report` are UNTESTED live). Requested by the user after the TNC/HongKong tests: B-roll that stops the video looking flat, no repeated footage, montage that avoids boredom, cinematic effects first, videos up to 30 s, and two opening choices.
Workflow
- **Max 30 s** (`workflow.max_runtime_s`, `edit_analysis.py` `MAX_RUNTIME_S`).
- **E0a — style gate** after the footage check: 5 style options built from the scan (each with shot IDs as evidence, pace, cinematic-effect plan, sound, ending, a strip image) + option 6 written by the user. **E0b — music gate**: 3–5 music styles for the chosen style, one preview track each + "I send my own". Both asked in Express and Standard, before Phase 2 (`options-playbook.md` §0a–§0b, `phase-01.md`). Lists longer than 4 are numbered messages (AskUserQuestion allows 4).
- Footage subagent has two passes: **scan** (Phase 1, feeds E0a) and **deepen** (Phase 3).
New references (all linked from `router.md` and the phase cards)
- `footage-intelligence.md` (Phase 3): action stages, emotion/motion/composition/gaze/direction, In/Out and frames to keep, role scoring, SEEN/INFERRED/UNVERIFIED, **moment mining**, effect suitability, catalogue schema with shot IDs.
- `story-decision-framework.md` (Phase 4): story contract, ≤ 30 s budget, spine/beat map/paper edit, causal vs associative, gap/repeat/stall checks, structure comparison on real footage, definition of ready.
- `shot-selection-and-continuity.md` (Phase 5–6): weighted shot score, A/B comparison (Murch order), continuity (gaze, direction, axis, 30°/size, eye trace), join vocabulary, cinematic joins, four repeat levels, blueprint fields `shot/grp/info/size/move/direction/score/why/rejected/link/callback`.
- `editorial-decision-and-qc.md` (Phase 6, 9): rough-cut review before polish, early/late cuts, spare shots, even rhythm, effect overload, hook/payoff/peak/release/ending, retention as a question, fixes by scope, separate editorial and technical verdicts.
Changed
- `motion-effects.md` §0 cinematic priority (speed ramp, zoom in, zoom out recipes, combinations, limits, density for 30 s); `broll.md` §0 mine-first rules; `review-scorecard.md` Editorial lane + repeat blockers; `story-structure.md` pointer; phase cards 1–7, 9 and the runbook (17 calls); `scripts/README.md` blueprint fields.
- `edit_analysis.py`: `repeat_report` (overlapping source frames, same `shot`/`grp`/`info`, runs of 3 same size/move/direction, missing `why`) and the 30 s runtime check; tests in `tests/test_v320.py`.
Honest notes: sources for the new craft rules are public editing guides (Murch's Rule of Six, continuity basics, B-roll families, speed-ramp guidance), rewritten; starting values are taste defaults, not measured.


## 3.1.3 — 2026-10-27
First live Express run on a new project (Test / TNCCoffee, 7 sources): stage, p1, fps/size blocker, music flow 3 previews, footage subagent, E1, p6 analysis + dry run + build (Draft_TNCCoffee_v01, 584/584 frames read back, 9/9 cuts on the beat grid). Stopped before Phase 7 at the user's request — p7–p10 and the `timeline_ops` write modes remain unverified live. 236 offline tests.
- `phase_run.py`: BUDGET_S 40 → 8. The MCP reply times out after 10 s; the p6 build kept running in Resolve and finished, but its reply was lost. On "timed out" read `STATUS.md` (documented in SKILL.md and the runbook).
- `music_library.py` rank: a library pick put "mixkit-comical-2" first for a coffee brief and left out "Cold Coffee" → brief keywords weigh more than a tempo-only mood guess; new "funny" mood words; a name that says another mood is penalised.
- `music_library.py` analyse: ignored SECOND_BPM and labelled a one-tool tempo "measured" (98.7 vs 96.3 from silence_beats) → same tempo_label rule as preview.
- `tests/test_v313.py`.

## 3.1.2 — 2026-10-27
Full static review (no live run, as asked): compile + undefined-name scan of every script, link check of SKILL.md and the cards, version agreement, stale-text scan — all clean except the items fixed here.
- `phase_run.py`: a finished mode re-run (e.g. p9 on the next Draft) returned the previous summary instead of measuring again, and a changed blueprint did not restart p6 → `input_sig` + `fresh_state` (restart on changed inputs or after a complete run; `build`/`apply` still continue a run). The audio step waited 25 s for a render job that was refused (non-Draft timeline) → returns the refusal at once. p10 skips the compare when the Final could not be created.
- SKILL.md: fps/size removed from E1 (it is a Phase 1 blocker — the first Probe_/Draft_ timeline locks the project fps).
- options-playbook.md: Express note (which gates are asked, merged or automatic); free-audio-sources.md §2 Express wording; scripts/README.md row for phase_run.py; TEST-PROMPTS Express check.

## 3.1.1 — 2026-10-27
Refinement of T1–T3 (offline only, as asked).
- `phase_run.py` p1: sheets now land in `Cache Edit/<Title>/footage/` (was `…/footage/footage/`, off the subagent card's path); the summary lists every source's sheet, fps and frames so the subagent prompt is filled without opening `p1.full.json`.
- Phase cards 1, 3, 6, 7, 8, 9, 10: a "Fast path" line with the phase_run mode and ARGS; card 1 resumes from `STATUS.md`.
- `references/phases/express-runbook.md`: the whole Express project as ~15 calls with the three stops; pointer in SKILL.md.

## 3.1.0 — 2026-10-27
Token plan T1 + T2 + T3. 228 offline tests; `stage.py` checked live. `phase_run.py` could not be run live: the Test_ project was deleted in Resolve (log 10:01:25) before the live check — first live run on the next project.

Added
- `scripts/phase_run.py` (T2): p1/p6/p7/p8/p9/p10 in one call each, time-budgeted with resume, full results to `phase_run/<mode>.full.json`, short summary + `look`; rewrites `STATUS.md` (T3).
- `references/phases/footage-subagent.md` (T3): footage frames reviewed by a subagent (model sonnet) that returns a JSON catalogue only.
- `references/api-quick.md` (T1): verified calls in one table; `api-cookbook.md` becomes the Grep-only archive.
- `tests/test_v310.py`.

Changed
- `frame_probe.py`: overview sheet of all sources (rows of 8 × 128 px cells); `qc_stills.py`: sheet capped at 1024 px, 6 columns for long lists.
- SKILL.md token rules: one session per project via STATUS.md, one call per phase, subagent footage review, image caps (`sips -Z 1024`), reports ≤ 12 lines, api-quick first. Phase 3 card points to the subagent.

## 3.0.2 — 2026-10-27
Option A after the TNCRoast run (priority: project speed and low token use). 222 offline tests; `stage.py`, compact `inventory.py` and `timeline_ops.py` compare checked live; the timeline_ops write modes (next_draft, place_media, reappend_audio, set_levels) are offline-tested and replace code that ran live by hand in this session.

Added
- Express workflow mode (default; `config` `workflow.mode`), stops E1/E2/E3; Standard keeps Gates 0–4.
- `references/phases/phase-01.md` … `phase-10.md` (phase cards) and `references/phases/router.md`.
- `scripts/timeline_ops.py`, `scripts/stage.py`, `tests/test_v302.py`, `tests/_skilltext.py` (tests read core + cards).

Changed
- SKILL.md rewritten as the core (rules, modes, phase index, layers, router, token rules, hard gates, approvals, failures); details moved verbatim to the phase cards.
- `inventory.py` `COMPACT` (default) + `compact_rows`, `source_dirs`; description shortened (880 chars).

## 3.0.1 — 2026-10-27
First live run of v3.0 on Resolve Studio 21.1.1 (project `Test_`, 13 pool items from `Desktop/Footage/Coffee`), Phases 1–3 live, Phases 4–6 on paper (`edit_analysis.py`, build `DRY_RUN`), no timeline written. 201 offline tests.

Fixed
- `loader.py`: config staged as `config/defaults.json` was not found (scripts ran on in-file defaults with only a warning); reads flat or `config/`; `stage_check` returns `config_version`, `obsolete`, status `NO_CONFIG` / `OBSOLETE_FILES_STAGED`. `defaults.json` `removed_tools`.
- `inventory.py`: `duplicate_groups` + `DUPLICATE_MEDIA`, `LOW_RES_SOURCE`; FPS_MISMATCH asks at Gate 0 (the first Probe_ timeline locks the fps). SKILL Gate 0 and options-playbook §1 item 4.
- `frame_probe.py`: one decode per duplicate group (`skipped_duplicates`), canonical representative, long-edge thumbnail fit, 6 columns for portrait.
- `music_library.py`: `tempo_label` in picks (`bpm_label`, `bpm_conf`, `bpm_octaves`, `hit_spacing_s`); music-analysis.md corrected (catalogue envelope is 0.25 s, not 20 ms; two-tool tempo rule).
- Tracks: V2 `B-ROLL`, V3–V5 graphics (`broll_track`, `graphics_tracks`); `qa_audit.py` `GRAPHICS_TRACKS` + `graphics_tracks_empty` check (it counted V2 B-roll as titles); `finalize_project.py`, blueprint examples, transcript-editing.md.
- SKILL: v2.x text choices/lessons in `_prefs.json` are kept as Phase 10 hints, not applied; staging instruction.

Second live session (Draft_TNCRoast_v01 built at 30 fps 1080x1920, Phases 4–7):
- `picture_tools.py` MODE `pan_calibrate`: the Pan constant is not portable (0.00035 on 2160-wide/DJI; measured 0.000923 on 1080-wide with 1280x720 sources, two items, correlation 0.999); `profile_shift` helper. `motion_fx` reframe_path verified live with the measured value (TNC plate whole through a handheld pan).
- `sfx_library.py`: speech tracks from config `mix.dialogue_tracks` (roaster noise on A1 was treated as speech, capping every accent); `pick` skips files missing on disk and reports `stale_entries` (849 stale in the user's catalogue); `place` says "file missing on disk" instead of "import failed".
- `audio_presence.py` check reports `mix_peak_dbfs`, true peak and `clipping` from the full-rate render.
- Second hand-over (Final from Draft_v04): `finalize_project.py` never overwrites an earlier `.drp` backup (`_2`, `_3`…), makes the "Chữ (Text)" bin only when text timelines exist and deletes it when empty, moves timelines that landed in media bins (Music, SFX, Đồ họa, Giọng đọc) into bin "Timeline".
- Story overlay + Vietnamese voice-over on request (live, Draft_TNCRoast_v02): `qa_audit.py` `GRAPHICS_PLACED` (placed HyperFrames renders are no longer a FAIL); hyperframes-handoff.md §8 recipe (Draft only, bins, V3 from frame 0, VOICE track, real-footage overlay check, clipping from voice + hit, macOS Linh voice, estimated word timings).
- Phase 10 (live): Final duplicated (pixel diff 0 vs Draft), finalize_project apply DONE (item counts equal, .drp backup, Vietnamese tracks/nodes/colour version), hand-over APPROVED (logo animation 2 s + tagline). `hyperframes_handoff.py` Markdown: groups in order of appearance, per-element notes listed, anchor shown as "kind: ref".
- Phase 9 (live, Gate 3 approved): `audio_presence.py` check reports `integrated_lufs` (the Draft measured -17.4 LUFS vs TikTok -14 — no tool reported it before); `qc_stills.py` PAGE note: the Color page hides Edit-page fades (a faded last frame looked full bright) — QC on "edit", grade comparisons on "color"; review-scorecard: loudness line.
- Phase 8 tooling (the v3.0 spec asked for WB/exposure/consistency, the tool only applied LUTs): `color_look.py` MODE measure / balance with `frame_stats`, `merge_stats`, `suggest_slope` (WB from near-neutral pixels, skipped when too few; exposure only for outliers; capped); live on Draft_TNCRoast_v01: s01 +0.6 stop, steel neutrals ±2–5 %, two shots untouched; color-look.md §1b.
- Flow 3 (user rule 2026-10-27: no music sent → find and download free music, read trends, send previews): free-audio-sources.md §0 (live-run facts: Creative Center → TikTok One needs sign-in for songs; Mixkit genre/mood pages + direct links; Pixabay licence line + CDN link, security verification after ~4 pages — never solved); `audio_ingest.py` `download_name` (files named `<artist>-<title>-<id>`, not `640.mp3`); `music_library.py` preview reads licence sidecars (title, source, licence in the options), `SECOND_BPM` + `tempos_agree` (a 117.2 vs 80.6 disagreement is now "estimated"); removed-by-user rule (sidecar without audio = do not offer again); trend-research.md §7.1 URL.
- Music previews (user rule 2026-10-27: music comes with the footage; if missing, Claude offers tracks to listen to): `music_library.py` MODE `preview` + `choose_excerpt` (excerpt of the planned length, ending on a measured phrase hit), `music_intake.preview_question`; status NONE no longer asks before previews exist.
- Music intake (user request): new `scripts/music_intake.py` (Phase 1, read-only: named paths, Media Pool audio, footage folders, project.json → USER_MUSIC / USER_MUSIC_SEVERAL / CHOSEN_BY_CLAUDE / NONE + the Gate 0 question); `music_library.py` MODE `analyse` for tracks outside the library; `project.json` music `chosen_by`; music-analysis.md §0 (when music should arrive: with the footage, at the latest Gate 1; cost table; "music after the cut"); SKILL Phase 1/2 + Gate 0, options-playbook §1. Root cause: Gate 0 asked only about audio sources and Phase 2 went straight to the library, so a user's track could be missed and Claude's pick looked like theirs.
- `qc_stills.py` no title stills by default; `motion_fx.py` REPLACE scope documented; api-cookbook §13h (playback fps refused by the API, music re-append recipe, static Pan vs handheld pans).

## 3.0.0 — 2026-10-27
User brief 2026-10-27: Claude is a senior editor/montage specialist; titles, subtitles, captions and motion graphics go to HyperFrames in a later step; strict 10-phase order. Decisions: motion accents stay in Resolve; research stays as is; multi-format with 9:16 default; hand-over as Markdown + JSON. New code UNTESTED live.

Added
- `scripts/hyperframes_handoff.py`, `references/hyperframes-handoff.md` (Phase 10), `references/music-analysis.md` (Phase 2), `tests/test_v300.py`.
- SKILL.md: scope boundary, ten-phase workflow, hard gates 11 (graphics boundary) and 12 (creative colour boundary), reserved graphic tracks.

Removed
- Scripts `text_fx.py`, `text_qa.py`, `calibrate_fonts.py`, `fonts.py`, `track_point.py`; `fx_apply.py` modes `title` / `title_inspect` and their helpers.
- References `text-system.md`, `beat-text-fx.md`, `advanced-text-fx.md`, `motion-graphics.md`, `design-directions.md`.
- Gate 1b look sheet, Gate 2 text/subtitle variants, text density / advanced-text questions at Gate 0.

Changed
- Layers: timing → motion accents/transitions → sound → technical colour → QA → hand-over (text layer removed).
- `config/defaults.json`: version, tracks `GRAPHICS A/B/C` + `graphics_tracks`, `creative` without text keys (+ `creative_look: false`, `default_format`), `handoff` section; script entries for removed tools dropped. Style profiles: `text`/`look` replaced by non-binding `graphics_hint`/`look_hint`.
- `color-look.md` is technical-only by default; `transcript-editing.md` §4 produces corrected transcript data for the hand-over; `options-playbook.md`, `brief-template.md`, `review-scorecard.md`, `style-profiles.md`, `effects-library.md` (title templates removed), `finalize_project.py` track names.

## 2.9.0 — 2026-10-26
User rules: no render by Claude; after the Final only the Final timeline stays, with tidy, Vietnamese-named text/Fusion/nodes; temp data in Desktop/Final/Cache Edit; more option gates, no overlapping edits, token review. Offline: 210 tests (`tests/test_v290.py`); new code UNTESTED live.

Added
- `scripts/finalize_project.py` (Gate 4): MODE plan (keep/delete/untouched, renames, token) and apply (backup .drp, delete Claude's timelines of this title, Vietnamese names and node comments, FlowView layout, text bin, Deliver page → Desktop/Final, item-count read-back).
- SKILL.md: Folders, Decision map (Gates 0, 1, 1b, 2, 3, 4), Layers (one owner each), Change router, Token rules.
- options-playbook.md §1–4, §8 Gate 3 structured review, §9 Gate 4.

Changed
- `config/defaults.json` `paths.work`, `paths.final_dir`; `tools`, `exports` moved; scripts table injects WORK_DIR/OUT_DIR into qc_stills, frame_probe, text_qa, track_point, silence_beats, music_library, srt_from_transcript, fx_apply.
- `loader.py`/`boot.py`: tools and project.json in Cache Edit; `_prefs.json` stays in ~/Movies/ClaudeQC.
- `audio_presence.py`: renders to /tmp/ClaudeAudioCheck, check deletes the file and the queue job, Deliver TargetDir → Desktop/Final.
- `motion_fx.py`: maps nodes renamed by finalize (`[claude:MFX_…]` comment) back before REPLACE.
- `qc_stills.py` PREVIEW_MAX 960 → 720; `text_fx.py` event `sfx` documented as unused (layer 5 places all sound).
- Look moved from Gate 1 to Gate 1b; music becomes a Gate 1 question; style profile at Gate 0; delivery.md, INSTALL.md, color-look.md, transcript-editing.md, style-profiles.md, visual-qc-loop.md, effects-library.md, scripts/README.md updated.

## 2.8.0 addendum — 2026-10-26
Ideation pass: methods studied from the open-source OpenMontage skill files (AGPL-3.0; ideas rewritten, nothing copied). One script change (`edit_analysis.py`); new code UNTESTED live.

Added
- `references/ideation-playbook.md`: intake (ask only what is missing), design read + three dials, thematic question + tone registers with hold table, thesis line, no-silent-major-change rule, beats as visual cause + subject-transition labels, but/therefore, misconception-first, hook types, palette cleanser, shot-description template, six-dimension slideshow-risk audit, decision log.
- `references/clip-factory.md`: one long source → several ranked clips (realistic yield, clip families, ranking table written before cutting, platform fit, shared template, first 2–3 s, one batch review sheet).
- `references/style-profiles.md` + `config/styles/` (`night_cinematic`, `airy_vlog`, `travel_energetic`, `calm_documentary`): a look-and-feel chosen once at Gate 1 and written to `project.json`; user profiles in `~/Movies/ClaudeQC/_styles/`.
- `text-system.md` §6b: dwell after the entrance, typical durations, reference bezier curves (Remotion/CSS), reveal techniques (mask reveal and character stagger as UNTESTED recipes).
- `edit_analysis.py`: `equal_run_report` (3+ consecutive shots of nearly equal length; metric sections exempt) → `pacing.equal_runs` and `notes`; constants `EQUAL_RUN`, `EQUAL_TOL`.
- `tests/test_ideation_addons.py`.
- SKILL.md: router rows and one-line pointers in stages 1 and 4 and Gate 1.

## 2.8.0 — 2026-10-25
User requests after three live runs (HongKong, HuongCang, BoConCN). Offline: 186 tests (`tests/test_v280.py`); new code UNTESTED live.

Changed
- Emphasis density: cinematic 5–10 accents in 15–20 s (was 3–5, ≤ 1 per chapter), energetic 10–16, minimal 2–4 (SKILL.md, motion-effects.md §2, storytelling-montage.md, brief-template.md, sfx-library.md §3, `config` `creative`).
- SFX levels depend on the footage: `sfx_library.py` `LEVEL_MODE = "context"` measures the bed (all non-SFX audio items around the cue, after AudioVolume) and shifts the role level by bed − `BED_REF_DBFS` (−12…+9 dB; never up under speech; silence −6); MODE bed; `config` `mix`; sfx-library.md §5 rewritten.
- Workflow: Gate 0 kickoff (intensity, text density, advanced text, audio sources), previews at Gate 1, variant sheets, rough-cut checkpoint, alternates, `_prefs.json`.

Added
- `references/beat-text-fx.md`, `references/options-playbook.md`, `references/free-audio-sources.md`.
- `text_fx.py`: anims `slam`, `blur_pop`, `stretch_in`, `flicker`; exits `blur_out`, `shrink`, `flicker`; `pulse`; `beat_frames`, `kinetic_line`, `TEXT_DENSITY`, `text_density_plan`; unknown anim/exit names are reported before writing.
- `loader.py` MODE `prefs_get` / `prefs_set`, `merge_prefs`; prefs `config` sits between defaults.json and project.json.
- `scripts/audio_ingest.py`: ingest / fetch (https, allowed hosts, size cap) / credits; licence sidecars; blocked NC/ND/RemArc/unknown licences.

## 2.7.0 — 2026-10-25
Finishing pass after the first full live run (BoConCN). Offline: 162 tests (`tests/test_v270.py`). Includes 2.6.1 and 2.6.2 below.

Added
- `scripts/boot.py`: run any staged tool through the loader in three lines (used throughout the live run).
- `inventory.py` `warnings`: EMPTY_MEDIA_POOL, FPS_MISMATCH (says whether the project fps can still change), LANDSCAPE_PROJECT.
- `frame_probe.py`: decodes a matching camera proxy (DJI `.LRF`), burns the source frame into each thumbnail, extracts in parallel, stops at `BUDGET_SEC` (PARTIAL + `remaining`), MODE range for dense scans.
- `replace_shot.py` `SHOTS`: several swaps in one new version.
- `color_look.py` look `warm_soft` (+ the generate_lut recipe in color-look.md §6).
- api-cookbook §13g: SaveProject lives on ProjectManager, AudioVolume, GetFades, audio Duration/fps, DuplicateTimeline keeps comps/text/SFX, refused StartRendering, LRF proxies, motion_fx inclusive frames.

Fixed
- `audio_presence.py` start: the Deliver page kept its CustomName ("presence_…") and marks, so the user's next queued render (BoConCN, Desktop/Final) was named presence_….mp4. Now reset to the whole timeline and the timeline name after the job is queued (CustomName "" is refused by the API). `frame_probe.py`: ffprobe prints "18291," for DJI files — the frame count is parsed with a regex.

Changed
- `edit_analysis.py`: same-clip shots ≥ `ELLIPSIS_GAP_S` (10 s) apart in the source are a time cut, not a jump cut; a section cut mostly for emotion may cut slower than a calmer one.
- SKILL.md stages 1, 2, 11 and the staging note; README, INSTALL, TEST-PROMPTS 65–70.

## 2.6.2 — 2026-10-25
P1 fixes from the BoConCN live run. Offline: `tests/test_v262.py` (148 tests in all). Live on `Test_SfxPlace` (copy of Draft_BoConCN_v03), Resolve 21.1.1:
- MODE place: 4 cues PLACED_READ_BACK, feature frames off by ≤ 0.5; re-run replaced the same items (no duplicates); levels whoosh −15, riser +2.7 (file peak −28.6), whoosh-as-slowmo −13.6, bells −10.5.
- ending_plan: catalogue hit 28.0 used (detector found none), fade read with `GetFades()` (GetProperties has no FadeOut) -> "hit 2.40 s before the end, then a 1.6 s fade-out: natural".
- audio_presence: start rendered with the first recipe this time (the earlier refusal is not explained; the fallbacks stay); check: riser "present" (residual 0.18, gain within 1.1 dB of its volume), was MISSING. Open: the music still shows a 100 ms lag and −7 dB vs its AudioVolume (mp3 decoder offset? track level?).

Fixed
- `ending_plan.py`: phrase hits = own detection merged with music_library's catalogue hits (`MUSIC_CATALOG`; the coarse detector missed 28.0 s); every candidate lies inside `LOOK_AROUND_S` (it offered "SHORT at frame 3"); no hits -> `NO_HITS_NEAR_END`; a hit followed by the music item's fade-out (≥ `MIN_FADE_S`) is "natural (hit + fade)".
- `audio_presence.py` check: all items fitted together (least squares), each judged on the residual after the others are removed, fitted gain compared with its AudioVolume; "present but buried" below −20 dB in the mix. Start: three render recipes in turn (explicit LPCM -> ProRes without audio codec -> current format), failed jobs deleted, attempts reported.
- SFX levels follow the file's loudness: `auto_level` = table level + (typical peak of the role − file peak), clamped −30…+10 dB (was +6; the BoConCN riser needed +7 by ear).

Changed
- `levels_db` recalibrated from the user's hand levels on BoConCN v03 (whoosh −15→−8, riser −14→−10, slowmo −15→−9, shimmer −20→−17; subdrop/hit −12→−7, camera −17→−12, transition −15→−10 by the median +5; ambience unchanged). `sfx_library.py` MODE place: an item of the same file overlapping the cue is replaced (was ±2 frames from its start).

Added
- `sfx_library.py` MODE "place": cue sheet -> aligned, levelled, read-back SFX items on the first free SFX track; MODE pick reports `auto_level_db`. Config: `LEVELS` = levels_db, `SFX_TRACKS` = [sfx_track, ambience_track].

## 2.6.1 — 2026-10-25
Live run BoConCN (5 DJI 4K 25 fps clips → Draft_BoConCN_v03). Live-tested for the first time: color_look, replace_shot, edit_analysis, music_library, audio_presence (start FAILED, see review).

Fixed
- `loader.py`: overrides are injected before the first top-level `def`/`class` (was: just before `try: resolve`), so default arguments bound to CONFIG names (`looks=LOOKS`, ~20 functions in 13 scripts) see them. Found live: color_look ignored an overridden LOOKS. `tests/test_v261.py`.

Open (see ~/Movies/ClaudeQC/BoConCN/skill-review-v2.6.md): ending_plan hit detection, audio_presence start/verdict, SFX levels vs file loudness, SFX cue placement mode, frame_probe proxies/speed.

## 2.6.0 — 2026-10-25
Free-first research (user rule: use vidIQ while it is free, otherwise research from free sources on your own). Offline-tested only; browser reading of the free sources untested live.

Added / changed
- `references/trend-research.md`: free-first rule; free-credit budget (plan Free 150/month checked with `vidiq_balance`, budget = min(30, renewable − reserve), priority order for partial budgets, no purchase prompts); §7 free sources with URLs and reading steps — TikTok Creative Center (songs, hashtags, creators, videos; Vietnam, 7 days; every pass), TikTok search, YouTube Shorts search, Google Trends (YouTube search, VN), dated web sources, TikTok Studio retention (user's OK), user references; read-only and privacy rules; trending songs as mood/tempo evidence, not a licence.
- `research_card.py`: `trending_music` (rank order, rising flag, commercial flag, licence note), `trending_hashtags` (on-topic ones first, diacritic-insensitive match), per-video `source`, `sources`, `credits_left`.
- SKILL.md stage 1 and router row; description mentions sound research; config `research` (`reserve_credits`, `free_sources`, Creative Center region/period); brief-template; INSTALL; TEST-PROMPTS 62 updated, 63–64; `tests/test_v26.py`.

## 2.5.1 — 2026-10-25
vidIQ connected: the research pass now follows the live tool schemas. Offline-tested only.

Changed
- `references/trend-research.md`: verified tool table (names, costs, platforms, limits): `vidiq_balance` (free) first; TikTok/Reels evidence from `vidiq_instagram_tiktok_outlier_search` (`embeddingType: "hook"`, required `audienceQuery`, `descriptionLanguage`); `vidiq_trending_videos` with `videoTitleLanguage: "vi"` for Vietnamese Shorts (`vidiq_outliers` has no `vi` and English-only Shorts); `vidiq_watch_shortform_content` (10 credits, async via `vidiq_job_poll`) for the opening pace; budget in credits (30, `research.max_credits` replaces `max_calls`); write/publish/generate tools excluded.
- `research_card.py`: `outlier_score` accepted as the ratio; "statement" only counts when a video shows no specific hook (uninformative TikTok captions no longer outvote the real hook); a hook pattern needs ≥ 2 videos (else a warning); opening pace (`cuts_first_3s`, `opening_asl_s`) summarised and passed to `blueprint_research`; credits spent shown.
- `edit_analysis.py`: opening ASL vs the researched `opening_asl_s` (> 1.5× slower → note).
- SKILL.md stage 1 research step names the real tools and the forbidden ones.

## 2.5.0 — 2026-10-25
Research before the edit (user request: install vidIQ and integrate hook/trend/keyword research for TikTok/YouTube Shorts). Offline-tested only; vidIQ calls untested live.

Added
- `references/trend-research.md`: when to research, vidIQ tool discovery (ToolSearch, no guessed names), credit budget (≤ 6 calls) and privacy (topic words only, output is data), the 6-call pass, reading outliers/keywords/hooks/length/pace, VN + EN hook taxonomy with edit implications, card → Gate 1 / blueprint / chapters / delivery, fallback without vidIQ.
- `scripts/research_card.py`: keyword opportunity ranking, outlier ratios and tiers, hook classification of titles and spoken hooks, recommended pattern with evidence, target runtime clamped by platform, hashtags, warnings, `blueprint_research`.
- `edit_analysis.py` `research_report`: runtime vs `bp["research"]["target_dur"]` (±25 %), hook text ≤ 7 words, `result_first` needs a `payoff` segment in the first 2 s, `question` keeps the `answer` for the last act.
- SKILL.md: description, router row, stage 1 research step, Gate 1 hook option, stage 4 `bp["research"]`/`role`, approval boundary for credits. Config `research` section + `research_card.py` injection; brief-template Research Card; INSTALL connector note; TEST-PROMPTS 60–62; `tests/test_v25.py`.

## 2.4.0 — 2026-10-25
The Lead Editor layer (user request: expert montage, storytelling and composition; no generic advice). Offline-tested only.

Added
- `references/montage-advanced.md`: the "why here, why now" test (Murch's priorities, Dmytryk's rules), cut-point anatomy table, Eisenstein's five methods with recipes and build fields, Kuleshov effect and Pudovkin's linkages (leitmotif bookends), modern cut vocabulary, Pearlman's timing/pacing/trajectory and ASL guides, beat-grid frame math, the `cut` field.
- `references/story-structure.md`: spine, three acts at 15/30/60/90 s, tension arc vs pace, parallel editing, beat drop/peak/release, B-roll layers, J/L-cut table, elliptical editing, retention, the paper-edit table.
- `references/composition.md`: 9:16 grids, shot sizes, eye line/headroom/look and lead room, leading lines, frame-in-frame, depth, weight/negative space and text, contrast & affinity, eye-trace across cuts, 180°/30° rules, angles and lens impression.
- `scripts/edit_analysis.py`: rationale coverage, ASL per section vs arc, mechanical lengths, release after the peak, metric acceleration, beat grid and drop, jump cuts, large size jumps, screen-direction breaks, eye-trace jumps, parallel intervals, J/L split edits (`blueprint_split`).
- `scripts/composition_check.py`: frame-space box, power points, eye line, headroom, look/lead room, UI overlap (head/upper body), suggested Pan.
- SKILL.md: Lead Editor mission and response rules (cut reason, J/L, beat drop, B-roll layer, retention device); router rows; stage 2 framing check; stage 4 story plan + `edit_analysis.py` + paper-edit table; stage 5 builds from `blueprint_split`. brief-template story plan; review-scorecard craft/creative/visual lanes; blueprint schema fields; config PAN_PER_UNIT for motion_fx/composition_check; TEST-PROMPTS 55–59; `tests/test_v24.py`.

## 2.3.0 — 2026-10-25
Compared with 9 public DaVinci Resolve skills/MCP servers (analysis: `so-sanh-skill-tham-khao.md` delivered with this version; credits in `references/github-sources.md`, ideas only). The user chose all four groups. New code is offline-tested only (UNTESTED live).

Fixed (traps reported by others, confirmed against the 21.1.1 stub where possible)
- `srt_from_transcript.py`: the API import (`AppendToTimeline` of an SRT) lands after the timeline end and crashed Resolve 21.1 with start/end frames → removed; the script reports the playhead timecode for File > Import > Subtitle.
- `render_deliver.py`: `StartRendering([job], False)` (external scripts), Deliver format/codec restored after queuing, back to the Edit page, warning for output folders with spaces, `ColorSpaceTag`/`GammaTag` "Same as Project".
- `fx_apply.py` (effect paste): track states were restored while still on the Fusion page, where `SetTrackEnable` does nothing → restored after returning to the Edit page; tracks are also disabled on the Edit page.
- `duck_music.py`: audio-only appends count source frames at the file's own fps → converted; separate fall (1.0 s, finished before speech) and rise (1.2 s, starting in the tail room).

Added
- `transcript_cut.py` rewritten: pacing profiles, pause shortening (40/60 split), word pads, scene room, waveform confirmation and edge refinement (`SILENCES`), restart cues, fillers cut only in pauses (`FILLER_MODE`), flags for unsure keeps, review text, punchline split, paced/dynamic/hold switching (100/107.5 %, ≥ 4 s), `uncovered_jump_cuts`, `audio_xfade`.
- `build_from_blueprint.py` `audio_xfade` (2-frame audio crossfade on every butt join, fallbacks, report); `qa_audit.py` `av_sync_linked`; `silence_beats.py` adaptive silence floor (`SILENCE_DB = "auto"`, 24 dB under the loudest windows).
- `voice_audit.py` (source audit + ranking; speech-only normalise + Voice Isolation, hiss guard); `audio_presence.py` (audio-only render + correlation per item); `references/voice-audio.md`.
- `motion_fx.py`: `reframe_path` (eased follow with black-edge guard, view centre from the Edit Pan), `invert` (1–2 frame stutter), `resolvefx` (ResolveFX/OFX node in the clip comp); `picture_tools.py` MODE `resolvefx_check`; `references/resolvefx.md`.
- `text_fx.py` `layout_collisions` (events visible together must not overlap on screen); `replace_shot.py` (one shot's picture swapped in the next Draft version, timing/LUT/Pan kept); `references/review-scorecard.md`.
- Docs: transcript-editing §2–3 and §6 (vlog plan), motion-effects §3c (never linear, match cuts, transition pace), storytelling (contrast/movement cuts), broll (2 fps B-roll viewing, Ken Burns, black-to-black), audio-music-sfx, api-cookbook §13f (traps), delivery, visual-qc (scorecard), SKILL router/workflow/failure handling, TEST-PROMPTS 45–54.
- `tests/test_v23.py`.

## 2.2.0 — 2026-10-25
Review of v2.1.0: every documentation mismatch fixed, shared config, and the missing delivery/music/vlog/colour tools added. New scripts are offline-tested only (UNTESTED live).

Fixed
- `ending_plan.py` defaulted to music on A1 (dialogue by layout) → `MUSIC_TRACK = "auto"`: track named MUSIC, else the audio-file track covering most of the runtime. `qa_audit.py` uses the same rule (it picked A1 dialogue when it covered the whole runtime).
- Skill name: `resolve-editor` everywhere (INSTALL, TEST-PROMPTS used "resolve-shortform-editor").
- One timeout rule: plan each call within ~45 s, the MCP's hard limit is 60 s (docs said 30 / 50 / 60 s).
- `fonts.py` said a Resolve restart was needed after installing fonts; measured: not needed.
- `design-directions.md` forbade font installs that the user pre-approved (OFL).
- Legacy `DRAFT_…` names: examples now use `Draft_<Title>_vNN` / `Final_<Title>_NN`; historic case-study names are marked as historic; `calibrate_fonts.py` scratch timeline → `Test_calib_fonts`.
- README module count (said 22), test count in TEST-PROMPTS (said 48).
- One level table (`sfx-library.md` §5 = `config` levels_db); old −20 dB / −18…−22 / −10…−16 examples pointed there.
- Pan wording identical everywhere (+Pan moves the view left = picture right).
- The S-Log3 look LUT named in SKILL.md is now documented (combined LUT, how to make one for other cameras, Sony decode formula).
- "Stored per-project wishes" now have a home: `~/Movies/ClaudeQC/<Title>/project.json` via `loader.py`.
- Endings: the ending question is part of Gate 1 (endings.md said "ask each time" separately).
- Hard-coded paths moved to `config/defaults.json`.
- `resolve-mcp-capabilities.md` / `tool-inventory-template.md` baseline updated (image route and ffmpeg solved).
- `text_fx.py` validation used x 0.05–0.88 / y 0.08–0.94 while the documented TikTok zone is x 0.06–0.87 / y 0.20–0.92 → `SAFE_X`/`SAFE_Y` with the documented zone.

Added
- `config/defaults.json` (paths, tracks, levels, loudness, safe zones per platform, delivery presets, framing, timeouts, per-script CONFIG map) and `scripts/loader.py` (inject config + project.json + OVERRIDES; project_get/set; stage_check md5).
- `scripts/render_deliver.py` + `references/delivery.md`: presets (TikTok/Reels/Shorts/4:5/1:1/YouTube/master), never overwrite, render start/status, ffprobe + EBU R128 check (−14 LUFS ± 1, ≤ −1 dBTP) with the dB fix, cover JPEG, caption/hashtag rules, other aspect ratios.
- `scripts/music_library.py`: music catalogue (duration, BPM, energy, intro, phrase hits/length, ending type, mood) and ranked picks.
- `scripts/duck_music.py`: music ducking under speech with crossfaded segments on A2/A5.
- `scripts/transcript_cut.py`: transcription → fillers/silences/retakes dropped (with reasons) → blueprint with punch-ins, KEPT for SRT, speech ranges; end-to-end vlog plan in `transcript-editing.md`.
- `scripts/color_look.py`: LOG/HDR detection and conversion/look LUT in a `claude_look` version; `color-look.md` table of the conversion LUTs installed on the Mac (list_luts 2026-10-25).
- `scripts/picture_tools.py`: DetectSceneCuts shot list, SmartReframe, Stabilize (stub-verified).
- `motion_fx.py` `ramp_smooth` (TimeStretcher curve); `build_from_blueprint.py` `"resolution"` + `fill_geometry()`; `fonts.py` CJK coverage (`REQUIRE`, `AUDIT_SYSTEM`) + `text-system.md` §8b.
- `broll.md` §3c (vertical sources, 1080p sources, stills, long clips, Smart Reframe, stabilising); platform safe zones and aspect notes in `vertical-frame-checklist.md`; `api-cookbook.md` §13e (stub facts for v2.2).
- `tests/test_v22.py` (config/loader, music track, render parsing/checks, music features/rank, ducking, transcript cut, smooth ramp, fill geometry, scene cuts, gamma/LUT, CJK, docs consistency guards); TEST-PROMPTS 34–44.

## 2.1.0 — 2026-10-25
Completeness test on a fresh project (HongKong night piece, `Draft_HongKong_v01` → `v02`). Lessons from the user's review folded in.

Workflow and rules
- Every clip is analysed and used or explained. Off-theme clips: Claude decides the best use (prologue / B-roll detail / transition material / leave out), builds it and reports why — no question (user rule). `broll.md` §3b–4, `storytelling-montage.md` (night piece with a day prologue), SKILL.md defaults and Gate 1.
- SFX levels +5 dB (user: "sfx hơi nhỏ"; new levels approved). `sfx-library.md` §5, SKILL.md defaults.
- ffmpeg/ffprobe may be installed without admin into `~/.local/bin` (on Resolve's PATH) after a signature check; preflight checks for it; footage analysis starts with `frame_probe.py` contact sheets. `INSTALL.md`, SKILL.md stages 1–2, approval boundaries.
- Inserting a chapter after review = full rebuild with a new text `JOB` name (keeps the previous Draft's text). SKILL.md stage 11.

Fixed (found live)
- `qc_stills.py`: stills right after a seek came back black or showing the previous frame → `SETTLE_S` 0.7 s after every seek + warm-up export. Verified with a jumping 6-frame contact sheet.
- `ending_plan.py`: 0.25 s envelope placed a hit 0.23 s early and called a natural end "cut off" → `refine_hit` on a 20 ms envelope. Verified on Draft_HongKong_v02 (hits 21.44 / 24.92 s; "in a quiet decay: natural").
- `build_from_blueprint.py`: `planned_frames_at_expected_fps` ignored `dur` and ramps (212 reported for 431) → fixed.
- ffmpeg lookup also checks `~/.local/bin` (frame_probe, qc_stills, silence_beats).
- Docs: the loader needs `run_script_unsafe` and UTF-8 override files; shortening an audio item = delete + re-append.
- Tests: 49 (new: fine hit refinement, planned length with dur/ramps).

## 2.0.0 — 2026-10-24
Rebuilt the workflow around "decide once, build in layers" and added storytelling, B-roll and emphasis effects. Verified end-to-end on a fresh project: `Final_HuongCang_01`.

Workflow
- Three gates only: creative plan (story/runtime, effect intensity, look, ending — one question round), text samples, final review. Timing-changing work (cuts, speed, ramps, ending) is built first; look before text; text and sound after picture lock.
- Timeline naming: `Probe_`, `Test_`, `Draft_<Title>_vNN`, `Final_<Title>_NN` (duplicate of the approved Draft, never edited), `TXT_<job>_<id>`. Scripts write only Draft_/Probe_/Test_.

Added
- `references/storytelling-montage.md` (Murch's priorities, Eisenstein's montage methods, story shapes, coverage, transitions with meaning, phrase-chapter montage) — replaces story-patterns.md.
- `references/broll.md` (footage analysis, B-roll techniques: unused ranges, panel reframes, detail inserts, follow moves, virtual camera moves, slow-motion variants, natural wipes).
- `references/motion-effects.md` (inventory, when/why, SFX pairing, measured facts).
- `scripts/motion_fx.py`: push/pull (+drift), punch, shake, blur in/out, whip in/out, flash, freeze, spotlight in clip comps; render-cache refresh.
- `build_from_blueprint.py`: `ramp` (stepped speed ramps) and `dur` (exact lengths by speed convergence).
- brief-template: evidence map, creative-plan gate, cue sheet. api-cookbook §13d. Case study 4. 9 new tests (48).

Fixed (found live)
- Resolve rounding drifted cuts 13 frames off the music → `dur`.
- Pan sign/scale calibrated (+Pan moves the view left, 0.00035/unit).
- Keyed clip-comp effects did not render until a node input changed → pass-through toggle.
- Transform Center vs Pivot (picture shifted, black band) → zoom around Pivot.
- Flash invisible on LOG → Brightness; whip length 0.25 → 0.15.
- qa_audit counted ramps as repeats; ending_plan accepts Final_ timelines.

## 1.7.0 — 2026-10-24
Professional endings ("video dừng đột ngột").
- `references/endings.md`: diagnose → ask the user each time (cinematic close with text, clean fade, TikTok loop, wide bookend, slow tail; closing text; end sound) → build rules → checks; Hong Kong v02 case.
- `scripts/ending_plan.py`: music phrase hits and quiet points mapped to timeline frames; verdict on the current end (cut off / natural / mid-phrase; warning within 0.1 s of a hit); SHORT / HIT_CUT / RING_OUT candidates; last-shot tail. Verified on DRAFT_HK_v01_fill (found the cut-off end 0.08 s after a hit) and DRAFT_HK_v02_end (natural).
- SKILL.md: ending rule in defaults, router row, stage 9b. 3 new tests (39).

## 1.6.0 — 2026-10-24
Use the user's own effects library and SFX folder. Tested live on `DRAFT_fxprobe` (copy of the Hong Kong fit draft).

Added
- `references/effects-library.md`: the 11 installed packs (352 templates), what to use for which moment (travel/mood vs energetic), 40 verified built-in transition names, the 9:16 title-template route, the effect-paste route, Vietnamese font substitutes, placeholder/promo text.
- `references/sfx-library.md`: the 2,436-file SFX folder by source and role, house roles (title whoosh, opening riser, sub drop, shutter, shimmer, ambience), peak/onset placement, levels, never-list.
- Scripts: `sfx_library.py` (resumable scan with envelope shape, word-boundary role tags, ranked picks with dedupe, import), `fx_library.py` (template catalogue with roles, fonts + Vietnamese check, promo text, extract), `fx_apply.py` (transitions with handle fallback + SFX on the cut; pack titles with text mapping, font swap, placeholder blanking, measured auto-fit with centre-gain calibration and safe-zone check, fade-out when shortened; Fusion effect paste with target check and track/clipboard restore).
- Fonts installed for templates (OFL, Vietnamese-verified): Barlow Condensed ×9, Lora ×2, Open Sans ×2.
- api-cookbook §13c; 8 new offline tests (36 total).

Found by live testing
- `AddTransition` needs `alignment`; "center" needs handles on both clips.
- Pack titles designed 16:9 render 2–3× too large in 9:16; a Transform after them concatenates (centre gain x 3.19) → measure, don't assume.
- `comp.Paste()` works only on the comp open in the Fusion page; a paste once landed in a nested title item on V3 (cleaned) → target check.
- Neo Zoom Lite: StartZoom/EndZoom alone gave no visible push.
- mTitle Cinematic 28/43 hold hidden Telegram promo text; VES animations hold "VideoEditorStudio" sample text.

## 1.5.0 — 2026-10-24
Text, subtitles and animation system, built from six reference videos the user picked and tested live on the Hong Kong project (Resolve Studio 21.1.1).

Added
- `references/text-system.md` (rewritten): house style from the references; recipes A–G (editorial title, whisper, emphasis, kinetic, shot label, location pin, text behind object); bilingual Vietnamese–English layout; content-aware placement; timing; copy writing; 2–3 sample approval loop.
- `references/advanced-text-fx.md`: text behind an object (VERIFIED), tracked pin (PARTIAL), text SFX (VERIFIED via the engine), beat snap, title templates (plan).
- Scripts: `text_fx.py` (text engine: nested text timelines on V2+, width-based sizing, stacking, eased blur-in/fade/pop/track-in, halo, glow, one-Transform follow path, SFX, `cues_to_events` bilingual subtitles, `snap_to_beats`), `text_qa.py` (text on/off diff → overflow, safe zone, touching blocks, contrast), `track_point.py` (own point tracker), `fonts.py` (Vietnamese glyph audit + OFL Google Fonts install), `calibrate_fonts.py` (measured Size→width table).
- 14 OFL font files installed on the user's Mac (EB Garamond, Cormorant Garamond, Playfair Display, Be Vietnam Pro, Dancing Script, Great Vibes, Pinyon Script).
- 28 offline tests.

Changed
- Landscape in 9:16 now defaults to **Fill + Pan** (user approved); Fit only on request. `build_from_blueprint.py`: `"landscape": "fill" | "fit"`.
- `AppendToTimeline` endFrame is **exclusive** (measured); build script and tests use it by default.
- SKILL.md stages 7 (text) and 8 (subtitles) rewritten; failure handling: calls < 30 s, save before risky Fusion work, wait after page switches.

Removed
- `add_titles.py` (direct title inserts land on V1 and ripple the footage).

Fixed (found by live testing)
- Text+ Size is not a fraction of frame width → width-based sizing from a measured table.
- CharacterSpacing 1.35 is extremely wide → tracking 1.08–1.12, validated.
- AddModifier keys frame 0 automatically → explicit frame-0 keys (no flash).
- Shadow/halo inputs appear only after `Enabled3 = 1`; halo opacity keyed with the text.
- Fusion Tracker cannot be started by script → own tracker; per-node XYPaths froze Resolve → one Transform.
- `ImportMedia` needs a list of path strings.

## 1.4.0 — 2026-10-24
Added
- Module router in SKILL.md; description broadened so the skill triggers on Vietnamese requests ("dựng video", "làm vlog").
- References: `api-cookbook.md`, `visual-qc-loop.md`, `transcript-editing.md`, `motion-graphics.md`, `audio-music-sfx.md`, `color-look.md`, `viral-shortform-formats.md`, `github-sources.md`.
- Scripts: `inventory.py`, `frame_probe.py`, `qc_stills.py`, `silence_beats.py`, `build_from_blueprint.py`, `add_titles.py`, `srt_from_transcript.py`, `qa_audit.py`; `tests/test_scripts.py`.
- Vertical checklist: landscape-in-portrait fit, band usage, TikTok safe zone numbers.
- Case study 2 (Hong Kong draft): structural PASS but visual FAIL.

Changed
- Workflow: optional colour look stage (user sometimes asks for it); continuous-audio gate; render only on request.
- Defaults updated to the user's real workflow (TikTok, no crop, Text+ titles on Edit page, music/SFX folders).

Fixed (found by live testing)
- `globals()` does not exist in the `run_script` sandbox → scripts use `try: resolve`.
- Resolve localizes the clip `Type` field ("Hình ảnh", "Âm thanh") → kind detection by path/codec/resolution.
- Clip fps ≠ timeline fps (25/50/100 vs 24) → fps-aware lengths and endFrame detection.
- ffmpeg absent on the Mac → audio decoding via `afconvert`, previews via `sips`.
- 25 MB 16-bit stills → JPEG previews for viewing.

## 1.3.0
Evidence-first workflow, blueprint gate, structural vs visual QC separation (DaVinci-AutoEdit-Agent concepts).
