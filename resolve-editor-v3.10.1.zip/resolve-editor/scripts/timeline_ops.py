# timeline_ops.py — the small timeline jobs that were hand-written again and again on the TNCRoast run (v3.0.2).
# Tool: run_script_unsafe (MODE compare exports stills and runs ffmpeg). Every write is read back.
#
# MODE "next_draft":     duplicate SOURCE ("" = current timeline; a Final is only read) to the next free
#                        Draft_<TITLE>_vNN and make it current. The change router's "new Draft version" in one call.
# MODE "place_media":    MEDIA = [{"path", "bin", "kind": "video"|"audio", "track": n | "new:<NAME>",
#                        "record": frame, "start": src frame, "end": src frame (exclusive), "volume": dB, "fades": {...},
#                        "name": item name, "color": clip colour, "track_name": name for track n}]
#                        v3.7.0: a track number above the count adds video tracks up to it; "name" and "color" are
#                        set on the timeline item AND the pool clip (HyperFrames layers: layers_<Title>.json "media").
#                        -> imported once into BIN (an existing pool item with the same path is reused), appended,
#                        read back. Overlays from HyperFrames (ProRes 4444) go on V3 from frame 0; a voice on "new:VOICE".
# MODE "reappend_audio": AUDIO = {"track", "index" (1-based), "start", "end", "record"} -> the item is replaced by the
#                        same media with the new source range; volume and fades are carried over (no trim API).
# MODE "set_levels":     LEVELS = [{"track": n, "index": i | None, "match": "substring" | None, "volume": dB,
#                        "delta": dB, "fades": {...}}] -> volumes/fades set and read back (index None = every item).
# MODE "compare":        A, B = timeline names, FRAMES = [timeline frames] -> stills of both (Edit page, settled),
#                        mean absolute pixel difference and mean luma per frame. 0.0 = identical; a small diff with
#                        equal luma on detailed texture is sub-pixel Fusion re-rendering, not a change.
# Writes only Draft_/Probe_/Test_ timelines (REQUIRE_PREFIX); compare and next_draft write nothing else.

# ---- CONFIG ----------------------------------------------------------------
MODE = "next_draft"
TITLE = ""
SOURCE = ""
MEDIA = []
AUDIO = {}
LEVELS = []
A = ""
B = ""
FRAMES = []
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"
SETTLE_S = 0.8
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
FFMPEG_DIRS = ["~/.local/bin", "/opt/homebrew/bin", "/usr/local/bin"]
# ---------------------------------------------------------------------------

import re


def next_draft_name(names, title):
    """-> 'Draft_<title>_vNN' with NN one above the highest existing version (v01 when none)."""
    nums = [int(m.group(1)) for n in names for m in [re.match(r"^Draft_%s_v(\d+)$" % re.escape(title), n or "")] if m]
    return "Draft_%s_v%02d" % (title, (max(nums) + 1) if nums else 1)


def diff_stats(a, b):
    """a, b: equal-size grey byte strings -> (mean abs difference, mean a, mean b)."""
    n = min(len(a), len(b))
    if not n:
        return None, None, None
    return (round(sum(abs(a[i] - b[i]) for i in range(n)) / float(n), 2),
            round(sum(a[:n]) / float(n), 1), round(sum(b[:n]) / float(n), 1))


def tc_of(frame, fps):
    n = int(round(fps))
    f = int(frame)
    return "%02d:%02d:%02d:%02d" % (f // (n * 3600), (f // (n * 60)) % 60, (f // n) % 60, f % n)


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, time, subprocess
    pm = resolve.GetProjectManager()
    mp = project.GetMediaPool()
    out = {"mode": MODE, "errors": []}
    tls = {project.GetTimelineByIndex(i + 1).GetName(): project.GetTimelineByIndex(i + 1)
           for i in range(project.GetTimelineCount())}
    cur = project.GetCurrentTimeline()

    def writable(tl):
        return tl is not None and tl.GetName().lower().startswith(REQUIRE_PREFIX)

    def items(tl, kind, track):
        return tl.GetItemListInTrack(kind, int(track)) or []

    def readback(tl, kind, track):
        s0 = tl.GetStartFrame()
        rows = []
        for x in items(tl, kind, track):
            r = {"name": x.GetName()[:40], "start": x.GetStart() - s0, "end": x.GetEnd() - s0,
                 "src": [x.GetSourceStartFrame(), x.GetSourceEndFrame()]}
            if kind == "audio":
                r["volume"] = x.GetProperty("AudioVolume")
                r["fades"] = x.GetFades()
            rows.append(r)
        return rows

    if MODE == "next_draft":
        src = tls.get(SOURCE) if SOURCE else cur
        if src is None or not TITLE:
            out["status"] = "REFUSED: SOURCE timeline and TITLE are required"
        else:
            name = next_draft_name(list(tls), TITLE)
            project.SetCurrentTimeline(src)
            resolve.OpenPage("edit")
            new = src.DuplicateTimeline(name)
            if new:
                project.SetCurrentTimeline(new)
            out.update({"status": "CREATED" if new else "FAILED", "draft": name, "from": src.GetName(),
                        "current": project.GetCurrentTimeline().GetName()})

    elif not writable(cur) and MODE in ("place_media", "reappend_audio", "set_levels"):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_ (%s)" % (cur.GetName() if cur else None)

    elif MODE == "place_media":
        root = mp.GetRootFolder()
        s0 = cur.GetStartFrame()
        placed = []
        for m in MEDIA:
            path = os.path.expanduser(m["path"])
            bins = {f.GetName(): f for f in root.GetSubFolderList() or []}
            b = bins.get(m.get("bin") or "") or (mp.AddSubFolder(root, m["bin"]) if m.get("bin") else root)
            item = next((c for f in [root] + list(bins.values()) for c in (f.GetClipList() or [])
                         if c.GetClipProperty("File Path") == path), None)
            if item is None:
                mp.SetCurrentFolder(b)
                got = mp.ImportMedia([path]) or []
                mp.SetCurrentFolder(root)
                item = got[0] if got else None
            if item is None:
                out["errors"].append("import failed: %s" % path)
                continue
            kind = m.get("kind", "video")
            track = m.get("track", 3 if kind == "video" else 1)
            if isinstance(track, str) and track.startswith("new:"):
                if kind == "audio":
                    cur.AddTrack("audio", "mono")
                else:
                    cur.AddTrack("video")
                track_n = cur.GetTrackCount(kind)
                cur.SetTrackName(kind, track_n, track[4:])
                track = track_n
            while kind == "video" and isinstance(track, int) and cur.GetTrackCount("video") < track:
                cur.AddTrack("video")
            if m.get("track_name"):
                cur.SetTrackName(kind, int(track), m["track_name"])
            if m.get("color") and hasattr(item, "SetClipColor"):
                item.SetClipColor(m["color"])
            if m.get("fps"):                     # v3.7.0; unused since v3.9.0 (renders at the Final's exact rate); kept for a manual override
                ok_fps = item.SetClipProperty("FPS", str(m["fps"]))
                if not ok_fps or str(item.GetClipProperty("FPS")) not in (str(m["fps"]), "%.3f" % float(m["fps"])):
                    out["errors"].append("FPS not set to %s on %s: set Clip Attributes by hand" % (m["fps"], os.path.basename(path)))
            info = {"mediaPoolItem": item, "trackIndex": int(track), "recordFrame": s0 + int(m.get("record", 0)),
                    "mediaType": 1 if kind == "video" else 2}
            if m.get("end") is not None:
                info.update({"startFrame": int(m.get("start", 0)), "endFrame": int(m["end"])})
            got = mp.AppendToTimeline([info]) or []
            if not got:
                out["errors"].append("append failed: %s" % path)
                continue
            it = got[0]
            if kind == "audio" and m.get("volume") is not None:
                it.SetProperty("AudioVolume", float(m["volume"]))
            if m.get("fades"):
                it.SetFades(m["fades"])
            if m.get("name") and hasattr(it, "SetName"):
                it.SetName(m["name"])
            if m.get("color") and hasattr(it, "SetClipColor"):
                it.SetClipColor(m["color"])
            placed.append({"path": os.path.basename(path), "kind": kind, "track": int(track), "name": m.get("name"),
                           "color": it.GetClipColor() if hasattr(it, "GetClipColor") else None,
                           "readback": readback(cur, kind, track)})
        out.update({"status": "PLACED_READ_BACK" if placed and not out["errors"] else "PLACED_WITH_ERRORS",
                    "placed": placed})

    elif MODE == "reappend_audio":
        a = AUDIO
        lst = items(cur, "audio", a["track"])
        idx = int(a.get("index", 1)) - 1
        if not 0 <= idx < len(lst):
            out["status"] = "NO_ITEM"
        else:
            old = lst[idx]
            mpi = old.GetMediaPoolItem()
            vol, fades, old_color = old.GetProperty("AudioVolume"), old.GetFades(), old.GetClipColor()
            s0 = cur.GetStartFrame()
            rec = int(a.get("record", old.GetStart() - s0))
            cur.DeleteClips([old], False)
            got = mp.AppendToTimeline([{"mediaPoolItem": mpi, "startFrame": int(a["start"]), "endFrame": int(a["end"]),
                                        "trackIndex": int(a["track"]), "recordFrame": s0 + rec, "mediaType": 2}]) or []
            if got:
                if old_color:                              # v3.3.0: keep the music/SFX colour
                    got[0].SetClipColor(old_color)
                if vol is not None:
                    got[0].SetProperty("AudioVolume", float(vol))
                if fades:
                    got[0].SetFades(fades)
            out.update({"status": "REAPPENDED_READ_BACK" if got else "FAILED",
                        "readback": readback(cur, "audio", a["track"])})

    elif MODE == "set_levels":
        done = []
        for L in LEVELS:
            lst = items(cur, "audio", L["track"])
            sel = [lst[int(L["index"]) - 1]] if L.get("index") else lst
            if L.get("match"):
                sel = [x for x in sel if L["match"] in x.GetName()]
            for x in sel:
                v0 = float(x.GetProperty("AudioVolume") or 0.0)
                v1 = float(L["volume"]) if L.get("volume") is not None else v0 + float(L.get("delta", 0.0))
                x.SetProperty("AudioVolume", round(v1, 2))
                if L.get("fades"):
                    x.SetFades(L["fades"])
                done.append([L["track"], x.GetName()[:30], round(v0, 2), x.GetProperty("AudioVolume")])
        out.update({"status": "SET_READ_BACK", "levels": done})

    elif MODE == "compare":
        ff = next((os.path.join(os.path.expanduser(d), "ffmpeg") for d in FFMPEG_DIRS
                   if os.path.exists(os.path.join(os.path.expanduser(d), "ffmpeg"))), None)
        if not ff or A not in tls or B not in tls:
            out["status"] = "NO_FFMPEG" if not ff else "NO_TIMELINE: %s" % [n for n in (A, B) if n not in tls]
        else:
            d = os.path.join(os.path.expanduser(WORK_DIR), "_compare")
            os.makedirs(d, exist_ok=True)
            resolve.OpenPage("edit")
            grey = {}
            for tag, nm in (("a", A), ("b", B)):
                tl = tls[nm]
                project.SetCurrentTimeline(tl)
                fps = float(tl.GetSetting("timelineFrameRate") or 30)
                s0 = tl.GetStartFrame()
                tl.SetCurrentTimecode(tc_of(s0 + int(FRAMES[0]), fps))
                time.sleep(SETTLE_S)
                project.ExportCurrentFrameAsStill(os.path.join(d, "warm.png"))      # first still of a run can be stale
                for fr in FRAMES:
                    tl.SetCurrentTimecode(tc_of(s0 + int(fr), fps))
                    time.sleep(SETTLE_S)
                    p = os.path.join(d, "%s_%05d.png" % (tag, int(fr)))
                    project.ExportCurrentFrameAsStill(p)
                    grey[(tag, fr)] = subprocess.run([ff, "-v", "error", "-i", p, "-vf", "scale=90:160,format=gray",
                                                      "-f", "rawvideo", "-"], capture_output=True).stdout
            project.SetCurrentTimeline(cur)
            rows = []
            for fr in FRAMES:
                dm, la, lb = diff_stats(grey.get(("a", fr), b""), grey.get(("b", fr), b""))
                rows.append({"frame": fr, "mean_abs_diff": dm, "luma_a": la, "luma_b": lb})
            same = all(r["mean_abs_diff"] == 0.0 for r in rows)
            out.update({"status": "IDENTICAL" if same else "DIFFERENT (look at %s)" % d, "frames": rows, "dir": d})
    else:
        out["status"] = "UNKNOWN_MODE"
    result = out
