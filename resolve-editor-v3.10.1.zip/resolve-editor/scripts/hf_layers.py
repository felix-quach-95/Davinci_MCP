# hf_layers.py — Phase 11 (v3.7.0): trims the per-layer HyperFrames renders to each element's span and checks them.
# Tool: pure Python + ffmpeg/ffprobe (Motion Studio's own: HYPERFRAMES_FFMPEG_PATH / HYPERFRAMES_FFPROBE_PATH, else PATH).
#   python3 -I scripts/hf_layers.py <package_dir>/layers_<Title>.json <hyperframes project dir> [--dry]
# Input: layers_<Title>.json written by hyperframes_handoff.py (names, spans, render fps, the Final's frame count).
# Reads   <project>/renders/layers_full/<layer name>.mov   (full length, solo = that layer, MOV with alpha)
# Writes  <package_dir>/layers/<layer name>.mov            (stream copy: ProRes is all-intra, so the cut is frame-exact)
# Then checks every file with ffprobe: codec prores, a pix_fmt with alpha, the Final's size, the layer's frame count,
# no audio. Prints JSON {status, layers: [{name, ok, problems}]}. Never touches Resolve; placing is timeline_ops.py
# place_media with the "media" list of layers_<Title>.json (names, colours, named tracks).
import json
import os
import shutil
import subprocess
import sys


def tool(env_key, name):
    p = os.environ.get(env_key)
    return p if p and os.path.exists(p) else (shutil.which(name) or name)


def trim_cmd(ffmpeg, src, dst, start, frames, fps):
    return [ffmpeg, "-y", "-v", "error", "-ss", "%.6f" % (start / float(fps)), "-i", src,
            "-frames:v", str(int(frames)), "-c:v", "copy", "-an", dst]


def probe_cmd(ffprobe, path):
    return [ffprobe, "-v", "error", "-count_frames", "-show_entries",
            "stream=codec_type,codec_name,pix_fmt,width,height,nb_read_frames", "-of", "json", path]


def check_probe(info, frames, width, height):
    """info: ffprobe JSON -> list of problems ([] = good)."""
    st = info.get("streams") or []
    v = [s for s in st if s.get("codec_type") == "video"]
    out = []
    if any(s.get("codec_type") == "audio" for s in st):
        out.append("has an audio stream")
    if not v:
        return out + ["no video stream"]
    v = v[0]
    if "prores" not in (v.get("codec_name") or ""):
        out.append("codec %s, not prores" % v.get("codec_name"))
    if not (v.get("pix_fmt") or "").startswith("yuva"):
        out.append("pix_fmt %s has no alpha" % v.get("pix_fmt"))
    if width and height and (int(v.get("width") or 0), int(v.get("height") or 0)) != (int(width), int(height)):
        out.append("size %sx%s, Final is %sx%s" % (v.get("width"), v.get("height"), width, height))
    if str(v.get("nb_read_frames")) != str(int(frames)):
        out.append("%s frames, layer needs %s" % (v.get("nb_read_frames"), frames))
    return out


def run(plan_path, project_dir, dry=False):
    plan = json.load(open(plan_path, encoding="utf-8"))
    pkg = os.path.dirname(os.path.abspath(plan_path))
    fps = plan.get("render_fps") or 30
    ffmpeg, ffprobe = tool("HYPERFRAMES_FFMPEG_PATH", "ffmpeg"), tool("HYPERFRAMES_FFPROBE_PATH", "ffprobe")
    w, h = plan.get("width"), plan.get("height")
    os.makedirs(os.path.join(pkg, "layers"), exist_ok=True)
    res = []
    for L in plan["layers"]:
        src = os.path.join(project_dir, "renders", "layers_full", L["name"] + ".mov")
        dst = os.path.join(pkg, L["file"])
        cmd = trim_cmd(ffmpeg, src, dst, L["start"], L["frames"], fps)
        if dry:
            res.append({"name": L["name"], "cmd": cmd})
            continue
        if not os.path.exists(src):
            res.append({"name": L["name"], "ok": False, "problems": ["missing full render %s" % src]})
            continue
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            res.append({"name": L["name"], "ok": False, "problems": ["ffmpeg: " + r.stderr.strip()[:200]]})
            continue
        info = json.loads(subprocess.run(probe_cmd(ffprobe, dst), capture_output=True, text=True).stdout or "{}")
        pr = check_probe(info, L["frames"], w, h)
        res.append({"name": L["name"], "ok": not pr, "problems": pr, "file": dst})
    ok = dry or all(x.get("ok") for x in res)
    return {"status": "DRY" if dry else ("LAYERS_OK" if ok else "LAYERS_WITH_PROBLEMS"), "layers": res}


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    print(json.dumps(run(a[0], a[1], "--dry" in sys.argv), ensure_ascii=False, indent=1))
