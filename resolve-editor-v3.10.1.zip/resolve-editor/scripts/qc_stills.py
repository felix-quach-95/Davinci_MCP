# qc_stills.py — exports stills from the CURRENT timeline at chosen frames so Claude can
# Read them. Paste into run_script_unsafe (needs filesystem). Writes only into OUT_DIR.
# After it returns, open every listed PNG with the Read tool — that is the visual check.

# ---- CONFIG ----------------------------------------------------------------
JOB = "job"
OUT_DIR = "/Users/felix/Desktop/Final/Cache Edit"     # a sub-folder per JOB is created
FRAMES = "auto"                    # list of timeline-relative frames, or "auto"
AUTO_INCLUDE = {"cuts": True, "cut_offsets": [-1, 1], "first_last": True,
                "titles": False, "max_frames": 24}   # v3.0: no Claude titles; True only to check imported graphics
PAGE = "edit"                      # "edit" (grade + Edit-page fades/opacity: use for QC) or "color" (grade only — v3.0.1:
                                   # the Color page does NOT show Edit-page fades, a faded last frame looked full bright)
CONTACT_SHEET = True               # needs ffmpeg; skipped if missing
SHEET_MAX = 1024                   # v3.1 token rule: the contact sheet is fitted to this long edge (one image to read)
PREVIEW_MAX = 720                  # long edge of the preview copy (macOS `sips`; v2.9 token rule)
SETTLE_S = 0.7                     # wait after each seek before exporting. Without it a still can come
                                   # back black or showing the PREVIOUS frame (measured 2026-10-25)
WARMUP = True                      # one throwaway export first (the first still of a run was black)
# ---------------------------------------------------------------------------


def auto_frames(cut_points, title_spans, end, cfg):
    """cut_points: starts of V1 items (relative); title_spans: [(a, b)]."""
    fr = set()
    if cfg.get("first_last"):
        fr.update([0, max(end - 1, 0)])
    if cfg.get("cuts"):
        for c in cut_points:
            if c <= 0:
                continue
            for off in cfg.get("cut_offsets", [-1, 1]):
                fr.add(c + off)
    if cfg.get("titles"):
        for a, b in title_spans:
            fr.add(a + min(14, max((b - a) // 3, 1)))
    fr = sorted(f for f in fr if 0 <= f < end)
    mx = cfg.get("max_frames", 24)
    if len(fr) > mx:
        step = len(fr) / float(mx)
        fr = [fr[int(i * step)] for i in range(mx)]
    return fr


def frames_to_tc(frame, fps):
    nom = int(round(float(fps)))
    f = int(round(frame))
    s = f // nom
    return "%02d:%02d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60, f % nom)


def tc_to_frames(tc, fps):
    nom = int(round(float(fps)))
    hh, mm, ss, ff = [int(x) for x in tc.replace(";", ":").split(":")]
    return ((hh * 60 + mm) * 60 + ss) * nom + ff


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, shutil, subprocess, time
    tl = project.GetCurrentTimeline()
    fps = (tl.GetSettings() or {}).get("timelineFrameRate") or 30
    s0 = tl.GetStartFrame()
    end = tl.GetEndFrame() - s0
    out_dir = os.path.join(os.path.expanduser(OUT_DIR), JOB)
    os.makedirs(out_dir, exist_ok=True)
    if FRAMES == "auto":
        cuts = [it.GetStart() - s0 for it in (tl.GetItemListInTrack("video", 1) or [])]
        spans = [(it.GetStart() - s0, it.GetEnd() - s0)
                 for i in range(2, (tl.GetTrackCount("video") or 1) + 1)
                 for it in (tl.GetItemListInTrack("video", i) or [])]
        frames = auto_frames(cuts, spans, end, AUTO_INCLUDE)
    else:
        frames = list(FRAMES)
    prev_page = resolve.GetCurrentPage()
    prev_tc = tl.GetCurrentTimecode()
    resolve.OpenPage(PAGE)
    sips = shutil.which("sips") or ("/usr/bin/sips" if os.path.exists("/usr/bin/sips") else None)
    base_tc = tc_to_frames(tl.GetStartTimecode(), fps)
    files, errors = [], []
    if WARMUP and frames:
        # measured 2026-10-25: without this the first still showed the previous run's frame
        warm = os.path.join(out_dir, "_warmup.png")
        if tl.SetCurrentTimecode(frames_to_tc(base_tc + frames[0], fps)):
            time.sleep(SETTLE_S)
            project.ExportCurrentFrameAsStill(warm)
        if os.path.exists(warm):
            os.remove(warm)
    for f in frames:
        tc = frames_to_tc(base_tc + f, fps)
        if not tl.SetCurrentTimecode(tc):
            errors.append("SetCurrentTimecode %s failed" % tc)
            continue
        time.sleep(SETTLE_S)
        path = os.path.join(out_dir, "%s_f%05d.png" % (tl.GetName(), f))
        ok = project.ExportCurrentFrameAsStill(path)
        if ok and os.path.exists(path) and os.path.getsize(path) > 0:
            row = {"frame": f, "tc": tc, "path": path, "preview": path}
            if sips and PREVIEW_MAX:
                pv = path[:-4] + "_preview.jpg"
                r = subprocess.run([sips, "-Z", str(PREVIEW_MAX), "-s", "format", "jpeg", path, "--out", pv],
                                   capture_output=True, text=True, timeout=20)
                if r.returncode == 0 and os.path.exists(pv):
                    row["preview"] = pv
            files.append(row)
        else:
            errors.append("export failed at %s" % tc)
    sheet = None
    ff = shutil.which("ffmpeg") or next((p for p in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg",
                                                     os.path.expanduser("~/.local/bin/ffmpeg")) if os.path.exists(p)), None)
    if CONTACT_SHEET and ff and files:
        cols = 4 if len(files) <= 8 else 6          # v3.1: wider grid, smaller cells for long QC lists
        thumb = 270 if len(files) <= 8 else 180
        rows = (len(files) + cols - 1) // cols
        lst = os.path.join(out_dir, "_list.txt")
        with open(lst, "w") as fh:
            for x in files:
                fh.write("file '%s'\n" % x["preview"].replace("'", "'\\''"))
        sheet = os.path.join(out_dir, "%s_contact.png" % tl.GetName())
        cmd = [ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst,
               "-vf", "scale=%d:-1,tile=%dx%d:padding=6:margin=6" % (thumb, cols, rows), "-frames:v", "1", sheet]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=40)
        if r.returncode != 0:
            errors.append("contact sheet failed: " + r.stderr[-300:])
            sheet = None
        elif SHEET_MAX:
            sp = shutil.which("sips") or "/usr/bin/sips"
            subprocess.run([sp, "-Z", str(int(SHEET_MAX)), sheet], capture_output=True, timeout=20)
    if prev_tc:
        tl.SetCurrentTimecode(prev_tc)
    resolve.OpenPage(prev_page)
    result = {"out_dir": out_dir, "stills": files, "contact_sheet": sheet, "errors": errors,
              "next": "Read the contact sheet (if any) or each preview; open the full PNG only for detail."}
