# frame_probe.py — footage evidence BEFORE editing: N frames per source clip plus a
# contact sheet, straight from the source files with ffmpeg (read-only on sources).
# Paste into run_script_unsafe. Never installs anything; reports if ffmpeg is missing.
# Then Read each contact sheet. Frame file names carry the source frame number so
# usable moments can be written into the blueprint as source frames.
# v2.7.0 (BoConCN, 2026-10-25: 16 frames of one 4K HEVC clip took 25 s; 47 min of footage):
#   - a camera proxy next to the file (DJI .LRF, same fps and frame count, verified frame-accurate with
#     -ss) is decoded instead of the master when its frame count matches (~10x faster);
#   - the source frame number is burned into each thumbnail (sheet order no longer has to be decoded);
#   - frames are extracted in parallel and the call stops at BUDGET_SEC (status PARTIAL + "remaining");
#   - MODE "range": dense frames over one region (pick in/out points) — RANGE = {"clip", "from", "to", "step"}.
#   Never label sheets made with ffmpeg's fps= filter by t: the labels drifted by a whole cell (measured).

# ---- CONFIG ----------------------------------------------------------------
MODE = "sheet"          # "sheet" (N frames per clip) | "range" (dense frames over RANGE)
JOB = "job"
OUT_DIR = "/Users/felix/Desktop/Final/Cache Edit"
CLIPS = "all"           # "all" video clips in the pool, or a list of clip names
FRAMES_PER_CLIP = 12    # evenly spaced, skipping the first/last 3 % (SKILL.md/broll.md: 12–16 per sheet;
                        # long clips: ~1 frame per 30–60 s, then MODE range on the useful parts)
RANGE = {"clip": "", "from": 0, "to": 0, "step": 25}
WIDTH = 360             # thumbnail width
COLS = 4                # contact sheet columns (6 suits range sheets)
LOG_PREVIEW = False     # True adds a rough contrast/saturation lift for LOG footage (preview only)
USE_PROXY = True        # decode a matching sidecar proxy (PROXY_EXT) instead of the master
PROXY_EXT = (".LRF", ".lrf")
LABEL = True            # burn the source frame number into each thumbnail
WORKERS = 6
BUDGET_SEC = 45
OVERVIEW = True         # v3.1: one overview sheet for ALL sources (rows = sources, OVERVIEW_PER_CLIP cells each,
OVERVIEW_PER_CLIP = 8   # cell OVERVIEW_CELL px) — read this one image first; open a per-clip sheet only when needed
OVERVIEW_CELL = 128
# ---------------------------------------------------------------------------


def dup_key(name, props):
    """Same stem (without " (n)") + same frames/duration/resolution/codec = the same source (inventory.py v3.0)."""
    import re as _re
    stem = _re.sub(r"\s*\(\d+\)(?=\.[^.]+$)", "", str(name))
    return (stem, props.get("Frames"), props.get("Duration"), props.get("Resolution"), props.get("Video Codec"))


def clip_kind(props):
    """Language-independent kind: Resolve localizes the 'Type' field (e.g. 'Hình ảnh')."""
    path = str(props.get("File Path") or "")
    res = str(props.get("Resolution") or "")
    codec = str(props.get("Video Codec") or "")
    if not path and not codec and res:
        return "timeline"
    if res and "x" in res.lower() and (codec or path):
        frames = str(props.get("Frames") or "")
        return "video" if frames not in ("", "1") else "still"
    if path:
        return "audio"
    return "other"


def sample_points(total_frames, n, margin=0.03):
    if total_frames <= 0 or n <= 0:
        return []
    a = int(total_frames * margin)
    b = max(int(total_frames * (1 - margin)) - 1, a)
    if n == 1:
        return [(a + b) // 2]
    return sorted({int(round(a + i * (b - a) / float(n - 1))) for i in range(n)})


def range_points(a, b, step):
    """Frames a, a+step, ... <= b (MODE range)."""
    step = max(int(step), 1)
    return list(range(int(a), int(b) + 1, step))


def proxy_candidates(path, exts=(".LRF", ".lrf")):
    """Sidecar proxy paths to try for a master file (same folder, same stem)."""
    stem = path.rsplit(".", 1)[0]
    return [stem + e for e in exts]


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, re, shutil, subprocess, time
    from concurrent.futures import ThreadPoolExecutor

    t0 = time.time()

    def find_bin(name):
        return shutil.which(name) or next((p for p in ("/opt/homebrew/bin/" + name, "/usr/local/bin/" + name,
                                                       os.path.expanduser("~/.local/bin/" + name))
                                           if os.path.exists(p)), None)

    ff, fp_bin = find_bin("ffmpeg"), find_bin("ffprobe")
    out = {"mode": MODE, "ffmpeg": ff, "clips": [], "errors": []}

    def frame_count(path):
        if not fp_bin:
            return None
        r = subprocess.run([fp_bin, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=nb_frames",
                            "-of", "csv=p=0", path], capture_output=True, text=True, timeout=15)
        m = re.search(r"\d+", r.stdout or "")          # ffprobe prints "18291," for DJI files (measured)
        return int(m.group(0)) if m else None

    def grab(src, fps, f, fp_out, label):
        # v3.0: fit the LONG edge to WIDTH — portrait clips at width 360 made 1460x1930 sheets (live run 2026-10-27),
        # twice the image budget of SKILL.md; even sizes for the tile filter
        vf = ("scale=w=%d:h=%d:force_original_aspect_ratio=decrease,scale=trunc(iw/2)*2:trunc(ih/2)*2" % (WIDTH, WIDTH)
              + (",eq=contrast=1.35:saturation=1.4" if LOG_PREVIEW else ""))
        if label:
            vf += (",drawtext=text='%d':x=6:y=6:fontsize=%d:fontcolor=yellow:box=1:boxcolor=black@0.6"
                   % (f, max(WIDTH // 16, 12)))
        cmd = [ff, "-nostdin", "-y", "-loglevel", "error", "-ss", "%.3f" % (f / fps), "-i", src,
               "-frames:v", "1", "-vf", vf, "-q:v", "4", fp_out]
        try:
            subprocess.run(cmd, capture_output=True, timeout=20)
        except subprocess.TimeoutExpired:
            return False
        if not os.path.exists(fp_out) and label:          # no drawtext/font in this ffmpeg build
            return grab(src, fps, f, fp_out, False)
        return os.path.exists(fp_out)

    if not ff:
        out["status"] = "NO_FFMPEG: use the Resolve still route in visual-qc-loop.md (Route A/C); do not install without approval"
    else:
        root = os.path.join(os.path.expanduser(OUT_DIR), JOB, "footage")
        os.makedirs(root, exist_ok=True)
        pool = []

        def walk(folder):
            for c in folder.GetClipList() or []:
                pool.append(c)
            for s in folder.GetSubFolderList() or []:
                walk(s)
        walk(project.GetMediaPool().GetRootFolder())
        pool.sort(key=lambda c: (len(c.GetName()), c.GetName()))   # "x.mp4" represents its "x (1).mp4" copies
        wanted = [RANGE.get("clip")] if MODE == "range" else CLIPS
        todo, seen_files = [], {}
        out["skipped_duplicates"] = []
        for c in pool:
            p = c.GetClipProperty() or {}
            if clip_kind(p) != "video":
                continue
            if wanted != "all" and c.GetName() not in wanted:
                continue
            # v3.0: a duplicate import (same file, or a byte-identical "x (1).mp4" with the same media signature —
            # see inventory.py duplicate_groups) is decoded once; its sheet stands for the whole group
            key = dup_key(c.GetName(), p)
            if key in seen_files:
                out["skipped_duplicates"].append([c.GetName(), seen_files[key]])
                continue
            seen_files[key] = c.GetName()
            todo.append((c, p))
        remaining = [c.GetName() for c, _ in todo]
        for c, p in todo:
            if time.time() - t0 > BUDGET_SEC:
                out["errors"].append("budget reached before %s" % c.GetName())
                break
            path, fps = p.get("File Path"), float(p.get("FPS") or 0)
            try:
                _w, _h = [int(x) for x in str(p.get("Resolution") or "").lower().split("x")[:2]]
                portrait = _h > _w
            except ValueError:
                portrait = False
            total = int(float(p.get("Frames") or 0))
            if not path or not os.path.exists(path) or fps <= 0:
                out["errors"].append("%s: no readable file/fps" % c.GetName())
                remaining.remove(c.GetName())
                continue
            src, proxy = path, None
            if USE_PROXY:
                for cand in proxy_candidates(path, PROXY_EXT):
                    if os.path.exists(cand):
                        n = frame_count(cand)
                        if n and total and abs(n - total) <= 1:
                            src, proxy = cand, cand
                        else:
                            out["errors"].append("%s: proxy frame count %s != %s, master used" % (c.GetName(), n, total))
                        break
            safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in c.GetName())
            if MODE == "range":
                pts = [f for f in range_points(RANGE.get("from", 0), RANGE.get("to", 0), RANGE.get("step", 25))
                       if 0 <= f < (total or 10 ** 9)]
                safe += "_r%d-%d" % (pts[0], pts[-1]) if pts else ""
            else:
                pts = sample_points(total, FRAMES_PER_CLIP)
            d = os.path.join(root, safe)
            os.makedirs(d, exist_ok=True)
            jobs = [(f, os.path.join(d, "src_f%06d.jpg" % f)) for f in pts]
            with ThreadPoolExecutor(max_workers=max(int(WORKERS), 1)) as ex:
                ok = list(ex.map(lambda j: grab(src, fps, j[0], j[1], LABEL), jobs))
            shots = [fp for (f, fp), k in zip(jobs, ok) if k]
            missed = [f for (f, fp), k in zip(jobs, ok) if not k]
            if missed:
                out["errors"].append("%s: no frame at %s" % (c.GetName(), missed[:10]))
            sheet = None
            if shots:
                cols = max(int(COLS), 1)
                if portrait:
                    cols = max(cols, 6)          # narrow thumbnails: more per row keeps the sheet near 4:3
                rows = (len(shots) + cols - 1) // cols
                lst = os.path.join(d, "_list.txt")
                with open(lst, "w") as fh:
                    for s in shots:
                        fh.write("file '%s'\n" % s.replace("'", "'\\''"))
                sheet = os.path.join(root, safe + "_contact.jpg")
                subprocess.run([ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst,
                                "-vf", "tile=%dx%d:padding=4:margin=4" % (cols, rows), "-frames:v", "1", sheet],
                               capture_output=True, timeout=30)
                if not os.path.exists(sheet):
                    sheet = None
            out["clips"].append({"clip": c.GetName(), "fps": fps, "frames": total, "decoded": "proxy" if proxy else "master",
                                 "sampled_source_frames": pts, "frames_dir": d, "contact_sheet": sheet,
                                 "labelled": LABEL})
            remaining.remove(c.GetName())
        out["elapsed_s"] = round(time.time() - t0, 1)
        out["remaining"] = remaining
        out["status"] = ("PARTIAL: run again with CLIPS = remaining" if remaining else
                         "OK" if out["clips"] else "NOTHING_EXTRACTED")
        out["next"] = "Read the overview sheet (one row per source, left→right in time); open a per-clip contact_sheet only for a source that needs detail."
        if OVERVIEW and out["clips"]:
            rows_ = []
            for k, cl in enumerate(out["clips"]):
                fr_files = sorted(os.path.join(cl["frames_dir"], x) for x in os.listdir(cl["frames_dir"]) if x.endswith(".jpg"))
                if not fr_files:
                    continue
                step = max(len(fr_files) / float(OVERVIEW_PER_CLIP), 1.0)
                pick = [fr_files[int(i * step)] for i in range(min(OVERVIEW_PER_CLIP, len(fr_files)))]
                lst = os.path.join(root, "_ov_%02d.txt" % k)
                with open(lst, "w") as fh:
                    for s_ in pick:
                        fh.write("file '%s'\n" % s_.replace("'", "'\\''"))
                row = os.path.join(root, "_ov_%02d.jpg" % k)
                c_ = int(OVERVIEW_CELL)
                subprocess.run([ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-vf",
                                "scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2,"
                                "tile=%dx1:padding=2" % (c_, c_, c_, c_, int(OVERVIEW_PER_CLIP)), "-frames:v", "1", row],
                               capture_output=True, timeout=30)
                if os.path.exists(row):
                    rows_.append(row)
                os.remove(lst)
            if rows_:
                ov = os.path.join(root, "overview.jpg")
                inp = []
                for r_ in rows_:
                    inp += ["-i", r_]
                fl = "".join("[%d]" % i for i in range(len(rows_))) + ("vstack=inputs=%d" % len(rows_) if len(rows_) > 1 else "null")
                subprocess.run([ff, "-y", "-loglevel", "error"] + inp + ["-filter_complex", fl, "-q:v", "4", ov],
                               capture_output=True, timeout=30)
                for r_ in rows_:
                    os.remove(r_)
                out["overview_sheet"] = ov if os.path.exists(ov) else None
                out["overview_rows"] = [c_["clip"] for c_ in out["clips"]]
    result = out
