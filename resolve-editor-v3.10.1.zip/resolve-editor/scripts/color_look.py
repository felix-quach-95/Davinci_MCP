# color_look.py — detect LOG/HDR footage and apply a conversion or look LUT in a new colour version
# (v2.2.0, UNTESTED live as a script; the LUT route itself is verified: SetLUT/GetLUT, HuongCang 2026-10-24).
# Tool: run_script (sandbox is enough). Writes only Draft_/Probe_/Test_ timelines.
# MODE "plan":  per V1 item: source gamma (clip properties, file name, LOG_OVERRIDE), suggested LUT, whether
#               it is installed (LUT list given in INSTALLED_LUTS from the MCP tool `list_luts`).
# MODE "apply": per item: add/load colour version VERSION (the user's grade stays in its own version),
#               SetLUT(1, lut), read GetLUT(1) back. Report how to revert (LoadVersionByName(previous, 0)).
# MODE "measure" (v3.0.1, run_script_unsafe: ffmpeg): per V1 item, 3 source frames -> luma median / 2nd / 98th
#               percentile, clipped and crushed %, average RGB, and the RGB of NEAR-NEUTRAL pixels (steel, walls,
#               paper: saturation < 12 %, luma 60–235) -> `suggest` = technical CDL slope per item.
# MODE "balance": same measurement, then SetCDL(node 1) with the suggested slope in colour version VERSION
#               (Rec.709 footage; LOG items keep their conversion LUT and get the CDL on the same node).
#               Technical only (v3.0 Phase 8): white balance from neutrals (skipped when a frame has too few, so
#               brown coffee beans or a sunset are never "neutralised"), exposure only for shots far from the
#               sequence, capped so highlights stay below clipping. No saturation or contrast style.
# Conversion only for LOG/HDR footage; a look LUT replaces it only when it is a combined LOG->look LUT
# (e.g. MCP/cinematic_teal_orange_slog3_v1.cube). Always look at before/after stills (Color page).

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
LOOK = "convert"                 # convert | teal_orange | <key of LOOKS>
VERSION = "claude_look"
LOG_OVERRIDE = {}                # {"01 street.mov": "slog3"} when detection is wrong/unknown (decide from stills)
SKIP = []                        # item names to leave alone (e.g. a shot whose LUT lives in its Fusion comp)
INSTALLED_LUTS = []              # paste the `files` list of list_luts here for the "installed" check
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
ITEMS = []                       # measure/balance: 1-based V1 indexes; [] = all
OVERRIDE_SLOPE = {}              # {index: [r, g, b]} hand values that win over the suggestion
WB_MIN_NEUTRAL_PCT = 5.0         # fewer near-neutral pixels -> no white-balance change for that item
WB_CAP = 0.06                    # at most ±6 % per channel (technical, not a look)
EXPOSURE_OUTLIER = 0.65          # a shot whose median luma is < 65 % (or > 1/0.65) of the sequence median is corrected
EXPOSURE_TARGET = 0.80           # ... towards 80 % of the sequence median (keeps a darker shot darker)
EXPOSURE_CAP = 1.5               # max gain
HIGHLIGHT_CEIL = 235.0           # the 98th percentile may not be pushed above this (8-bit)
FFMPEG_DIRS = ["~/.local/bin", "/opt/homebrew/bin", "/usr/local/bin"]
# Built-in conversion LUTs found on the user's Mac (list_luts, 2026-10-25)
CONVERT = {
    "slog3":   "Sony/SLog3SGamut3.CineToLC-709.cube",
    "vlog":    "Panasonic/V-Log to V-709.cube",
    "dlog":    "DJI/DJI_X7_DLOG2Rec709.cube",          # Zenmuse X7 D-Log; for D-Log M (Mini/Osmo) use DJI's LUT
    "logc":    "Arri/Arri Alexa LogC to Rec709.dat",
    "bmdfilm": "Blackmagic Design/Blackmagic 4.6K Film to Rec709 v3.cube",
    "llog":    "Leica/Leica L-Log to Rec.709 Gamma 2.4.cube",
    "samsung": "Samsung/Samsung Log to Rec709.cube",
    "omlog":   "Olympus/Olympus OM-Log400_to_BT.709_v1.0.cube",
    "hlg":     "HDR Hybrid Log-Gamma/HLG to Gamma 2.4.cube",   # iPhone HDR / HLG: rough; check highlights
    "applelog": None,                                   # no built-in LUT: Apple's official LUT (download needs approval)
    "clog3":   None,                                    # no built-in LUT: Canon's official LUT (download needs approval)
    "rec709":  None,
}
LOOKS = {
    "teal_orange": {"slog3": "MCP/cinematic_teal_orange_slog3_v1.cube", "rec709": "MCP/cinematic_teal_orange_v1.cube"},
    # v2.7.0: soft warm daylight look (BoConCN, 2026-10-25); regenerate with generate_lut if missing
    # (transform in references/color-look.md §6 "Warm soft"); LOG sources need the conversion first.
    "warm_soft": {"rec709": "MCP/claude_warm_soft_rec709_v1.cube"},
}
# ---------------------------------------------------------------------------

import re

PATTERNS = [
    ("slog3", r"s[-_ ]?log ?3|slog3"), ("vlog", r"v[-_ ]?log"), ("dlog", r"d[-_ ]?log"),
    ("logc", r"log ?c\b|alexa"), ("bmdfilm", r"blackmagic film|bmd ?film|\bfilm gen"),
    ("llog", r"l[-_ ]?log"), ("clog3", r"c[-_ ]?log ?3"), ("applelog", r"apple ?log"),
    ("hlg", r"\bhlg\b|hybrid log|arib std-b67|bt\.?2100"), ("omlog", r"om[-_ ]?log"),
]


def detect_gamma(props, name=""):
    """props: clip properties. -> (key, evidence). Checks Input Gamma / Color Space first, then the
    file name/path. 'unknown' means: decide from a still (flat, grey = LOG)."""
    fields = [("Input Gamma", props.get("Input Gamma")), ("Input Color Space", props.get("Input Color Space")),
              ("Gamma Notes", props.get("Gamma Notes")), ("name", name), ("File Path", props.get("File Path"))]
    for label, val in fields:
        v = str(val or "").lower()
        if not v:
            continue
        for key, pat in PATTERNS:
            if re.search(pat, v):
                return key, "%s = %s" % (label, val)
        if label in ("Input Gamma", "Input Color Space") and re.search(r"709|srgb|gamma 2\.[24]", v):
            return "rec709", "%s = %s" % (label, val)
    return "unknown", "no gamma metadata"


def frame_stats(px):
    """px: [(r, g, b)] 8-bit -> luma percentiles, clip/crush %, mean RGB, near-neutral mean RGB (or None)."""
    if not px:
        return {}
    Y = sorted(0.2126 * r + 0.7152 * g + 0.0722 * b for r, g, b in px)
    n = len(Y)
    neu = [(r, g, b) for r, g, b in px if 60 < 0.2126 * r + 0.7152 * g + 0.0722 * b < 235
           and max(r, g, b) - min(r, g, b) < 0.12 * max(r, g, b, 1)]
    mean = lambda L, i: sum(p[i] for p in L) / float(len(L))
    return {"y_med": Y[n // 2], "y_p02": Y[int(n * 0.02)], "y_p98": Y[int(n * 0.98)],
            "clip_pct": 100.0 * sum(1 for y in Y if y >= 250) / n, "crush_pct": 100.0 * sum(1 for y in Y if y <= 5) / n,
            "rgb": [mean(px, i) for i in range(3)], "neutral_pct": 100.0 * len(neu) / n,
            "neutral_rgb": [mean(neu, i) for i in range(3)] if len(neu) >= max(1, n * WB_MIN_NEUTRAL_PCT / 100.0) else None}


def merge_stats(frames):
    """average of per-frame stats (3 frames per item)."""
    fr = [f for f in frames if f]
    if not fr:
        return {}
    avg = lambda k: sum(f[k] for f in fr) / len(fr)
    neu = [f["neutral_rgb"] for f in fr if f.get("neutral_rgb")]
    return {"y_med": avg("y_med"), "y_p02": avg("y_p02"), "y_p98": avg("y_p98"), "clip_pct": avg("clip_pct"),
            "crush_pct": avg("crush_pct"), "neutral_pct": avg("neutral_pct"),
            "neutral_rgb": [sum(n[i] for n in neu) / len(neu) for i in range(3)] if len(neu) * 2 >= len(fr) else None}


def suggest_slope(st, seq_median):
    """-> ([r, g, b] slope, [reasons]). White balance: scale R and B so the neutrals match G (capped).
    Exposure: only outliers vs the sequence median, towards EXPOSURE_TARGET of it, never past HIGHLIGHT_CEIL."""
    why, wb = [], [1.0, 1.0, 1.0]
    nr = st.get("neutral_rgb")
    if nr and min(nr) > 0:
        g = nr[1]
        for i in (0, 2):
            k = max(1.0 - WB_CAP, min(1.0 + WB_CAP, g / nr[i]))
            wb[i] = round(k, 3) if abs(k - 1.0) >= 0.015 else 1.0
        if wb != [1.0, 1.0, 1.0]:
            why.append("white balance from neutrals (R %+.0f %%, B %+.0f %%)" % ((wb[0] - 1) * 100, (wb[2] - 1) * 100))
    else:
        why.append("no white-balance change: too few neutral pixels (%.0f %%)" % (st.get("neutral_pct") or 0))
    gain = 1.0
    med = st.get("y_med") or 0
    if seq_median and med:
        ratio = med / seq_median
        if ratio < EXPOSURE_OUTLIER or ratio > 1.0 / EXPOSURE_OUTLIER:
            want = EXPOSURE_TARGET * seq_median / med if ratio < 1 else seq_median / (EXPOSURE_TARGET * med)
            ceil = HIGHLIGHT_CEIL / st["y_p98"] if st.get("y_p98") else EXPOSURE_CAP
            gain = round(max(1.0 / EXPOSURE_CAP, min(want, EXPOSURE_CAP, ceil if want > 1 else 99)), 3)
            why.append("exposure %s: median %.0f vs sequence %.0f -> gain %.2f (%.1f stop)" % (
                "lift" if gain > 1 else "pull", med, seq_median, gain, __import__("math").log(gain, 2)))
    return [round(wb[i] * gain, 3) for i in range(3)], why


def choose_lut(gamma, look, convert=CONVERT, looks=LOOKS):
    """-> (lut path or None, note)."""
    if look and look != "convert":
        table = looks.get(look) or {}
        if gamma in table:
            return table[gamma], "combined %s look for %s" % (look, gamma)
        if gamma in ("rec709",) and "rec709" in table:
            return table["rec709"], "%s look (Rec.709 source)" % look
        conv = convert.get(gamma)
        return conv, ("no combined %s LUT for %s: conversion only; make one with generate_lut "
                      "(color-look.md §LOG recipes)" % (look, gamma)) if conv else "no LUT for %s" % gamma
    if gamma == "unknown":
        return None, "unknown gamma: look at a still; set LOG_OVERRIDE"
    conv = convert.get(gamma)
    return conv, "conversion %s -> Rec.709" % gamma if conv else "no conversion needed/available for %s" % gamma


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    out = {"mode": MODE, "look": LOOK}
    if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_"
    else:
        if MODE in ("measure", "balance"):
            import os, subprocess
            ff = next((os.path.join(os.path.expanduser(d), "ffmpeg") for d in FFMPEG_DIRS
                       if os.path.exists(os.path.join(os.path.expanduser(d), "ffmpeg"))), None)
            items = tl.GetItemListInTrack("video", 1) or []
            idx = ITEMS or list(range(1, len(items) + 1))
            meas = {}
            for n in idx:
                it = items[n - 1]
                mpi = it.GetMediaPoolItem()
                path = mpi.GetClipProperty("File Path")
                fps = float(mpi.GetClipProperty("FPS") or 25)
                a, b = it.GetSourceStartFrame(), it.GetSourceEndFrame()
                frames = []
                for fr in (a + (b - a) // 4, (a + b) // 2, a + 3 * (b - a) // 4):
                    raw = subprocess.run([ff, "-v", "error", "-ss", "%.3f" % (fr / fps), "-i", path, "-frames:v", "1",
                                          "-vf", "scale=160:-2", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                                         capture_output=True, timeout=20).stdout
                    frames.append(frame_stats([tuple(raw[i:i + 3]) for i in range(0, len(raw) - 2, 3)]))
                meas[n] = merge_stats(frames)
            meds = sorted(m["y_med"] for m in meas.values() if m)
            seq = meds[len(meds) // 2] if meds else None
            rows = []
            if MODE == "balance":
                resolve.OpenPage("color")
            for n in idx:
                it = items[n - 1]
                slope, why = suggest_slope(meas[n], seq)
                if n in OVERRIDE_SLOPE or str(n) in OVERRIDE_SLOPE:
                    slope, why = list(OVERRIDE_SLOPE.get(n, OVERRIDE_SLOPE.get(str(n)))), ["hand value (OVERRIDE_SLOPE)"]
                st = meas[n]
                row = {"index": n, "name": it.GetName(), "y_med": round(st["y_med"]), "y_p98": round(st["y_p98"]),
                       "clip_pct": round(st["clip_pct"], 1), "crush_pct": round(st["crush_pct"], 1),
                       "neutral_rgb": [round(v) for v in st["neutral_rgb"]] if st.get("neutral_rgb") else None,
                       "slope": slope, "why": why}
                if MODE == "balance" and it.GetName() not in SKIP and slope != [1.0, 1.0, 1.0]:
                    cur = it.GetCurrentVersion() or {}
                    row["previous_version"] = cur.get("versionName")
                    if VERSION not in (it.GetVersionNameList(0) or []):
                        it.AddVersion(VERSION, 0)
                    it.LoadVersionByName(VERSION, 0)
                    row["set"] = bool(it.SetCDL({"NodeIndex": "1", "Slope": "%.3f %.3f %.3f" % tuple(slope),
                                                 "Offset": "0 0 0", "Power": "1 1 1", "Saturation": "1"}))
                rows.append(row)
            out.update({"items": rows, "sequence_median": round(seq) if seq else None,
                        "status": ("BALANCED (check before/after stills on the Color page)" if MODE == "balance"
                                   else "MEASURED"),
                        "revert": "per item: LoadVersionByName(previous_version, 0)"})
            result = out
        if MODE == "apply":
            project.RefreshLUTList()
            resolve.OpenPage("color")
        rows = []
        for n, it in enumerate(tl.GetItemListInTrack("video", 1) or [], 1):
            mpi = it.GetMediaPoolItem()
            props = (mpi.GetClipProperty() or {}) if mpi else {}
            nm = it.GetName()
            gamma, ev = (LOG_OVERRIDE[nm], "LOG_OVERRIDE") if nm in LOG_OVERRIDE else detect_gamma(props, nm)
            lut, note = choose_lut(gamma, LOOK)
            row = {"index": n, "name": nm, "gamma": gamma, "evidence": ev, "lut": lut, "note": note}
            if INSTALLED_LUTS and lut:
                row["installed"] = lut in INSTALLED_LUTS
            if MODE == "apply" and lut and nm not in SKIP:
                cur = it.GetCurrentVersion() or {}
                row["previous_version"] = cur.get("versionName")
                if VERSION not in (it.GetVersionNameList(0) or []):
                    it.AddVersion(VERSION, 0)
                it.LoadVersionByName(VERSION, 0)
                g = it.GetNodeGraph()
                row["set"] = bool(g and g.SetLUT(1, lut))
                row["readback"] = g.GetLUT(1) if g else None
                row["ok"] = bool(row["readback"]) and row["readback"].replace("\\", "/").endswith(lut.split("/")[-1])
            rows.append(row)
        if MODE not in ("measure", "balance"):
            out["items"] = rows
        if MODE in ("measure", "balance"):
            pass
        elif MODE == "apply":
            bad = [r["name"] for r in rows if r.get("lut") and r["name"] not in SKIP and not r.get("ok")]
            out["status"] = "APPLIED_READ_BACK" if not bad else "APPLIED_WITH_ERRORS: %s" % bad
            out["revert"] = "per item: LoadVersionByName(previous_version, 0)"
            out["next"] = "export one still per shot on the Color page and compare with the ungraded version"
        else:
            out["status"] = "PLAN"
    result = out
