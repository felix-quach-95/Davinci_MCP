# music_library.py — catalogue the user's music folder and rank tracks for a brief (v2.2.0, UNTESTED live).
# Tool: run_script_unsafe (decodes with ffmpeg if present, else macOS afconvert). Nothing is modified.
# MODE "scan":   resumable (BUDGET_SEC per call; re-run until "remaining" is 0): duration, tempo (BPM +
#                confidence), energy curve, intro length, phrase hits and typical phrase length, ending type
#                (button / fade / cut), loudness estimate, mood guess, name keywords. Cache = CACHE (JSON).
# MODE "pick":   QUERY -> ranked candidates with the reasons.
# MODE "import": IMPORT = [relative paths] -> Media Pool bin MUSIC_BIN (only these files).
# MODE "analyse" (v3.0.1): FILES = [absolute paths] -> the same measurements for tracks OUTSIDE the library (the
#                user's own music from the Media Pool, the footage folder or a path they named — music_intake.py).
#                Nothing is cached or imported; tempo carries its label (tempo_label).
# v3.3.0: the user supplies the music — the workflow uses MODE "analyse" only; scan/pick/preview stay for manual use.
# Measurement is not listening: report picks as "measured", never as "sounds right".

# ---- CONFIG ----------------------------------------------------------------
MODE = "scan"
ROOT = "/Users/felix/Desktop/Asset/Music"
CACHE = "~/Movies/ClaudeQC/_music/catalog.json"   # persistent (reused by later projects)
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"   # temp decode files (v2.9)
BUDGET_SEC = 45
MAX_SECONDS = 300                # analyse at most this much of each file
QUERY = {"mood": "calm", "min_dur": 15, "max_dur": 240, "bpm": None, "ending": None,
         "keywords": [], "exclude": [], "n": 6}
IMPORT = []
FILES = []                       # MODE "analyse": absolute paths
# MODE "preview" (v3.0.1, user rule 2026-10-27: "no music found -> give me options to listen to and choose"):
# the top PREVIEW_N picks of QUERY (or PREVIEW_FILES) are cut into short MP3 excerpts the user can play —
# the stretch Claude would actually use: after the intro, ending on a measured phrase hit when one fits.
PREVIEW_N = 3
PREVIEW_FILES = []               # optional: absolute paths instead of QUERY picks (free downloads, user files)
TARGET_S = 20.0                  # planned runtime: the excerpt length
PREVIEW_DIR = ""                 # "" = WORK_DIR/<PREVIEW_JOB>/music_preview
PREVIEW_JOB = "job"
SECOND_BPM = {}                  # {path or basename: bpm from silence_beats.py MODE beats} — required for "measured"
MUSIC_BIN = "Music"
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".flac", ".caf")
SR = 8000
HOP = 256
# ---------------------------------------------------------------------------

import math
import re

MOOD_WORDS = {
    "calm": ["calm", "chill", "lofi", "lo-fi", "ambient", "piano", "soft", "relax", "dream", "peace", "night",
             "slow", "acoustic", "silent", "descent", "rain", "sad", "melanchol", "nostalg"],
    "cinematic": ["cinematic", "epic", "trailer", "orchestral", "inspir", "emotional", "film", "story", "rise"],
    "energetic": ["upbeat", "energy", "energetic", "dance", "edm", "pop", "rock", "hip hop", "hiphop", "trap",
                  "funk", "happy", "summer", "party", "drive", "fast", "beat"],
    "funny": ["comic", "comical", "funny", "quirky", "cartoon", "silly", "goofy"],   # v3.1.3: never "calm"
}


def envelope_db(samples, rate, step_s):
    n = max(int(rate * step_s), 1)
    out = []
    for i in range(0, len(samples) - n + 1, n):
        w = samples[i:i + n]
        out.append(round(20 * math.log10(max(math.sqrt(sum(x * x for x in w) / n), 1e-5)), 1))
    return out


def detect_hits(env, rise_db=8.0, lookback=3, floor_db=-60.0):
    """Same rule as ending_plan.py: a step that jumps rise_db above the minimum of the previous steps."""
    hits = []
    for i in range(lookback, len(env)):
        prev = min(env[i - lookback:i])
        if env[i] > floor_db and env[i] - prev >= rise_db and (not hits or i - hits[-1] > lookback):
            hits.append(i)
    return hits


def onset_envelope(samples, hop=HOP):
    env, prev = [], 0.0
    for i in range(len(samples) // hop):
        seg = samples[i * hop:(i + 1) * hop]
        e = sum(x * x for x in seg) / hop
        d = e - prev
        env.append(d if d > 0 else 0.0)
        prev = e
    m = sum(env) / len(env) if env else 0
    return [max(v - m, 0.0) for v in env]


def estimate_tempo(env, sr=SR, hop=HOP, bpm_range=(70, 180)):
    """Autocorrelation tempo (simplified silence_beats.py). Returns (bpm, confidence)."""
    fr = sr / float(hop)
    lo, hi = max(int(fr * 60.0 / bpm_range[1]), 2), int(fr * 60.0 / bpm_range[0]) + 1
    n = len(env)
    if n < hi * 4:
        return None, 0.0
    scores = {}
    for lag in range(lo, hi + 1):
        bpm = 60.0 * fr / lag
        w = 1.0 - 0.15 * min(abs(bpm - 115) / 60.0, 1.0)
        scores[lag] = sum(env[i] * env[i + lag] for i in range(0, n - lag)) * w
    best = max(scores, key=scores.get)
    mean = sum(scores.values()) / len(scores)
    conf = (scores[best] - mean) / scores[best] if scores[best] > 0 else 0.0
    return round(60.0 * fr / best, 1), round(conf, 3)


def percentile(vals, p):
    if not vals:
        return None
    s = sorted(vals)
    k = min(max(int(round((len(s) - 1) * p)), 0), len(s) - 1)
    return s[k]


def features(samples, sr=SR):
    """Pure analysis of mono float samples in [-1, 1]."""
    dur = len(samples) / float(sr)
    env = envelope_db(samples, sr, 0.25)
    loud = [v for v in env if v > -60]
    p90 = percentile(loud, 0.9) or -60.0
    intro = next((i * 0.25 for i, v in enumerate(env) if v >= p90 - 6.0), 0.0)
    hits = [h * 0.25 for h in detect_hits(env)]
    gaps = [b - a for a, b in zip(hits, hits[1:]) if b - a >= 1.0]
    phrase = percentile(gaps, 0.5)
    tail = env[-int(6 / 0.25):] if len(env) > 24 else env
    last_hit = [h for h in hits if h > dur - 3.0]
    if len(tail) >= 8 and tail[-1] < max(tail) - 18 and all(b <= a + 1.5 for a, b in zip(tail[len(tail) // 2:], tail[len(tail) // 2 + 1:])):
        ending = "fade"
    elif last_hit and tail and tail[-1] < max(tail[-8:]) - 10:
        ending = "button"          # a final hit that decays: a natural end
    else:
        ending = "cut"
    bpm, conf = estimate_tempo(onset_envelope(samples), sr)
    curve = []
    if env:
        k = max(len(env) // 16, 1)
        curve = [round(sum(env[i:i + k]) / len(env[i:i + k]), 1) for i in range(0, len(env), k)][:16]
    spread = (max(loud) - min(loud)) if loud else 0.0
    return {"duration_s": round(dur, 2), "bpm": bpm, "bpm_conf": conf, "intro_s": round(intro, 2),
            "hits_s": [round(h, 2) for h in hits[:200]], "phrase_s": round(phrase, 2) if phrase else None,
            "ending": ending, "level_p90_db": p90, "dynamics_db": round(spread, 1), "energy_curve": curve}


def mood_of(entry):
    name = entry.get("rel", "").lower()
    words = {m: sum(1 for w in ws if w in name) for m, ws in MOOD_WORDS.items()}
    named = max(words, key=words.get) if max(words.values()) else None
    bpm, conf = entry.get("bpm"), entry.get("bpm_conf") or 0
    measured = None
    if bpm and conf >= 0.2:
        measured = "energetic" if bpm >= 118 and (entry.get("level_p90_db") or -60) > -14 else \
                   "calm" if bpm < 96 else "cinematic"
    return named or measured or "cinematic", named, measured


BPM_MEASURED_CONF = 0.6          # v3.0: below this the tempo is reported as an estimate, not a measurement


def tempos_agree(a, b, tol=0.02):
    """Two tempo estimates agree when equal within tol, also at half/double time."""
    if not a or not b:
        return False
    return any(abs(a * k - b) <= tol * b for k in (0.5, 1.0, 2.0))


def tempo_label(entry, second_bpm=None):
    """v3.0 (live run 2026-10-27): picks showed '144.2 BPM' with confidence 0.43 and a 69.4 that is likely half-time.
    Phase 2 must not present a guess as a measurement: label it and give the octave alternatives."""
    bpm, conf = entry.get("bpm"), entry.get("bpm_conf") or 0.0
    if not bpm:
        return {"bpm": None, "bpm_label": "not measured"}
    lab = "measured" if conf >= BPM_MEASURED_CONF else "estimated (low confidence %.2f — not usable for frame sync)" % conf
    # v3.0.1 (live run): a confident 117.2 here vs 80.6 from silence_beats on the same file — one tool is not a
    # measurement; music-analysis.md requires two estimates that agree
    if second_bpm is not None and lab == "measured" and not tempos_agree(bpm, second_bpm):
        lab = "estimated (two estimates disagree: %.1f vs %.1f BPM)" % (bpm, second_bpm)
    return {"bpm": bpm, "bpm_conf": conf, "bpm_label": lab,
            "bpm_octaves": [round(bpm / 2, 1), round(bpm * 2, 1)],
            "hit_spacing_s": entry.get("phrase_s"),
            "hit_spacing_note": "median gap between envelope hits (measured); musical phrase length in bars is interpretation"}


def choose_excerpt(duration, intro_s, hits, target_s, tol_s=1.5):
    """-> (start_s, end_s, reason). Prefer a window that starts after the intro and ENDS on a measured hit
    (a phrase boundary), so the user hears the same arc the edit would use; else start after the intro."""
    duration = float(duration or 0)
    if duration <= 0:
        return 0.0, 0.0, "unknown length"
    if duration <= target_s:
        return 0.0, round(duration, 2), "whole track (shorter than the target)"
    lo = max(float(intro_s or 0) * 0.5, 0.0)
    best = None
    for h in sorted(hits or []):
        st = h - target_s
        if st < lo - tol_s or h > duration:
            continue
        st = max(st, 0.0)
        score = abs((h - st) - target_s)
        if best is None or score < best[0]:
            best = (score, st, h)
    if best is not None and best[0] <= tol_s:
        return round(best[1], 2), round(best[2], 2), "ends on the measured hit at %.2f s (phrase boundary)" % best[2]
    st = min(lo, max(duration - target_s, 0.0))
    return round(st, 2), round(min(st + target_s, duration), 2), "from %.1f s (after the intro); no hit fits the end" % st


def rank(entries, q):
    """-> [(score, entry, reasons)] best first."""
    out = []
    excl = [x.lower() for x in q.get("exclude") or []]
    for e in entries:
        rel = e.get("rel", "").lower()
        if any(x in rel for x in excl) or e.get("error"):
            continue
        d = e.get("duration_s") or 0
        if d < (q.get("min_dur") or 0) or d > (q.get("max_dur") or 1e9):
            continue
        score, why = 0.0, []
        mood, named, measured = mood_of(e)
        if q.get("mood"):
            if named == q["mood"]:
                score += 3; why.append("name says %s" % named)
            if measured == q["mood"]:
                score += 2; why.append("tempo/level say %s" % measured)
            if mood != q["mood"]:
                score -= 2
            if named and named != q["mood"]:
                score -= 2; why.append("name says %s, not %s" % (named, q["mood"]))   # v3.1.3: "comical" ranked calm
        if q.get("bpm") and e.get("bpm"):
            lo, hi = q["bpm"]
            if lo <= e["bpm"] <= hi or lo <= e["bpm"] * 2 <= hi or lo <= e["bpm"] / 2 <= hi:
                score += 2; why.append("bpm %.0f in range" % e["bpm"])
        if q.get("ending") and e.get("ending") == q["ending"]:
            score += 1.5; why.append("ends with a %s" % e["ending"])
        if e.get("ending") in ("button", "fade"):
            score += 0.5
        if e.get("phrase_s") and 2.0 <= e["phrase_s"] <= 8.0:
            score += 1; why.append("clear phrases ~%.1f s" % e["phrase_s"])
        if (e.get("intro_s") or 0) > 12:
            score -= 1; why.append("long intro %.0f s (start later)" % e["intro_s"])
        hits = [k for k in q.get("keywords") or [] if k.lower() in rel]
        if hits:
            # v3.1.3: a brief keyword ("coffee") outweighs a tempo-only mood guess ("Cold Coffee" lost to "comical")
            score += 2 + 2 * len(hits) + (2 if mood != q.get("mood") and not named else 0)
            why.append("keyword %s" % ", ".join(hits))
        out.append((round(score, 2), e, why))
    out.sort(key=lambda x: -x[0])
    return out[:q.get("n", 6)]


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, json, shutil, subprocess, struct, wave, time
    t_start = time.time()
    root = os.path.expanduser(ROOT)
    cache_p = os.path.expanduser(CACHE)
    cat = {}
    if os.path.exists(cache_p):
        with open(cache_p, encoding="utf-8") as fh:
            cat = json.load(fh)
    res = {"mode": MODE}

    def find_bin(name):
        return shutil.which(name) or next((p for p in (os.path.expanduser("~/.local/bin/" + name),
                                                       "/opt/homebrew/bin/" + name, "/usr/local/bin/" + name)
                                           if os.path.exists(p)), None)

    def decode(path):
        ff, afc = find_bin("ffmpeg"), find_bin("afconvert")
        tmpd = os.path.join(os.path.expanduser(WORK_DIR), "_tmp")
        os.makedirs(tmpd, exist_ok=True)
        wav = os.path.join(tmpd, "music_%d.wav" % os.getpid())
        try:
            cmd = ([ff, "-y", "-v", "error", "-t", str(MAX_SECONDS), "-i", path, "-ac", "1", "-ar", str(SR), wav]
                   if ff else [afc, "-f", "WAVE", "-d", "LEI16@%d" % SR, "-c", "1", path, wav])
            subprocess.run(cmd, capture_output=True, timeout=40)
            with wave.open(wav, "rb") as w:
                raw = w.readframes(min(w.getnframes(), SR * MAX_SECONDS))
            return [v / 32768.0 for v in struct.unpack("<%dh" % (len(raw) // 2), raw[:len(raw) // 2 * 2])]
        finally:
            if os.path.exists(wav):
                os.remove(wav)

    # v3.0.1: catalogue entries whose file is gone (the user reorganised the library) are never offered;
    # filtered BEFORE ranking so "top 3" still means three playable tracks
    live_entries = [e for e in cat.values() if isinstance(e, dict) and e.get("rel")
                    and os.path.exists(os.path.join(root, e["rel"]))]
    stale_music = len(cat) - len(live_entries)
    if stale_music:
        res["stale_entries"] = stale_music

    if MODE == "scan":
        files = []
        for d, _, fs in os.walk(root):
            for f in fs:
                if f.lower().endswith(AUDIO_EXT):
                    files.append(os.path.relpath(os.path.join(d, f), root))
        todo = [f for f in sorted(files) if f not in cat]
        done = 0
        for rel in todo:
            if time.time() - t_start > BUDGET_SEC:
                break
            try:
                e = features(decode(os.path.join(root, rel)))
            except Exception as ex:
                e = {"error": str(ex)[:120]}
            e["rel"] = rel
            cat[rel] = e
            done += 1
        os.makedirs(os.path.dirname(cache_p), exist_ok=True)
        with open(cache_p, "w", encoding="utf-8") as fh:
            json.dump(cat, fh, ensure_ascii=False)
        res.update({"status": "OK", "files": len(files), "scanned_now": done, "remaining": len(todo) - done,
                    "cache": cache_p})
    elif MODE == "analyse":
        rows = []
        for p in FILES:
            ap = os.path.expanduser(p)
            if not os.path.exists(ap):
                rows.append({"file": p, "error": "not found"})
                continue
            if time.time() - t_start > BUDGET_SEC:
                rows.append({"file": p, "error": "budget reached: run again with the remaining FILES"})
                continue
            try:
                e = features(decode(ap))
                e.pop("energy_curve", None)
                e["hits_s"] = e.get("hits_s", [])[:40]
                row = dict(e, file=ap, mood=mood_of(dict(e, rel=os.path.basename(ap)))[0])
                # v3.1.3 (live run): analyse ignored SECOND_BPM and called a one-tool tempo "measured"
                sb = SECOND_BPM.get(ap, SECOND_BPM.get(os.path.basename(ap)))
                row.update(tempo_label(e, sb))
                if sb is None and row.get("bpm_label") == "measured":
                    row["bpm_label"] = "measured (one tool; pass SECOND_BPM from silence_beats to confirm)"
                rows.append(row)
            except Exception as ex:
                rows.append({"file": p, "error": str(ex)[:120]})
        res.update({"status": "OK" if rows and not any("error" in r for r in rows) else "PARTIAL", "tracks": rows,
                    "note": "measured from the file, not listened to; frame-accurate beats: silence_beats.py MODE beats"})
    elif MODE == "preview":
        ff = find_bin("ffmpeg")
        if not ff:
            res.update({"status": "NO_FFMPEG"})
        else:
            if PREVIEW_FILES:
                todo = []
                for p in PREVIEW_FILES:
                    ap = os.path.expanduser(p)
                    rel = os.path.relpath(ap, root) if ap.startswith(root.rstrip("/") + "/") else None
                    e = cat.get(rel) if rel else None
                    if e is None and os.path.exists(ap):
                        e = features(decode(ap))
                    todo.append((ap, e or {}, ["file you named"]))
            else:
                todo = [(os.path.join(root, e["rel"]), e, w)
                        for s_, e, w in rank(live_entries, dict(QUERY, n=max(PREVIEW_N, int(QUERY.get("n") or 0))))][:PREVIEW_N]
            odir = os.path.expanduser(PREVIEW_DIR or os.path.join(WORK_DIR, PREVIEW_JOB, "music_preview"))
            os.makedirs(odir, exist_ok=True)
            rows = []
            for i, (path, e, why) in enumerate(todo):
                letter = "ABCDEFGH"[i]
                st, en, reason = choose_excerpt(e.get("duration_s"), e.get("intro_s"), e.get("hits_s"), TARGET_S)
                sb = SECOND_BPM.get(path, SECOND_BPM.get(os.path.basename(path)))
                tl_ = tempo_label(e, sb)
                if sb is None and tl_.get("bpm_label") == "measured":
                    tl_["bpm_label"] = "measured (one tool; pass SECOND_BPM from silence_beats to confirm)"
                stem = re.sub(r"[^A-Za-z0-9]+", "_", os.path.splitext(os.path.basename(path))[0])[:40]
                out_p = os.path.join(odir, "%s_%s_%sbpm.mp3" % (letter, stem, int(round(tl_["bpm"])) if tl_.get("bpm") else "x"))
                fade = 0.8 if en - st > 3 else 0.2
                r_ = subprocess.run([ff, "-y", "-v", "error", "-ss", "%.3f" % st, "-t", "%.3f" % (en - st), "-i", path,
                                     "-af", "afade=t=in:d=0.3,afade=t=out:st=%.3f:d=%.2f" % (max(en - st - fade, 0), fade),
                                     "-ac", "2", "-b:a", "160k", out_p], capture_output=True, text=True, timeout=40)
                side = {}
                if os.path.exists(path + ".licence.json"):
                    with open(path + ".licence.json", encoding="utf-8") as fh:
                        side = json.load(fh)
                rows.append({"option": letter, "file": path, "preview": out_p if os.path.exists(out_p) else None,
                             "title": side.get("title"), "artist": side.get("artist"), "source": side.get("source"),
                             "licence": side.get("licence"), "page_url": side.get("page_url"),
                             "excerpt_s": [st, en], "excerpt_reason": reason, "why": why,
                             "duration_s": e.get("duration_s"), "ending": e.get("ending"), "intro_s": e.get("intro_s"),
                             "mood": mood_of(dict(e, rel=os.path.basename(path)))[0] if e else None,
                             "error": (r_.stderr or "")[:120] or None, **tl_})
            res.update({"status": "OK" if rows and all(r["preview"] for r in rows) else "PARTIAL", "previews": rows,
                        "dir": odir, "next": "send the previews (SendUserFile) + one line per option (tempo with its "
                                             "label, mood, ending, why it fits the footage); ask with AskUserQuestion; "
                                             "project_set music {file, chosen_by: 'user' after their pick}"})
    elif MODE == "pick":
        picks = rank(live_entries, QUERY)
        res.update({"status": "OK" if picks else "NO_MATCH (scan first?)", "query": QUERY,
                    "picks": [dict({"rel": e["rel"], "score": s, "why": w, "duration_s": e.get("duration_s"),
                               "bpm": e.get("bpm"), "phrase_s": e.get("phrase_s"), "intro_s": e.get("intro_s"),
                               "ending": e.get("ending"), "mood": mood_of(e)[0]}, **tempo_label(e)) for s, e, w in picks]})
    elif MODE == "import":
        mp = project.GetMediaPool()
        rootf = mp.GetRootFolder()
        binf = next((f for f in rootf.GetSubFolderList() or [] if f.GetName() == MUSIC_BIN), None) \
            or mp.AddSubFolder(rootf, MUSIC_BIN)
        mp.SetCurrentFolder(binf)
        items = mp.ImportMedia([os.path.join(root, r) for r in IMPORT]) or []
        res.update({"status": "IMPORTED" if items else "FAILED", "items": [i.GetName() for i in items]})
    result = res
