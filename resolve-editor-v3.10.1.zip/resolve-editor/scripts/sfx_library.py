# sfx_library.py — catalogue and pick sound effects from the user's SFX folder.
# Tool: run_script_unsafe (needs the filesystem + macOS afinfo/afconvert).
# MODE "scan":  resumable. Each call works for at most BUDGET_SEC, stores progress in CACHE,
#               returns {"done": n, "total": N}. Call again until done == total.
#               Per file: duration, sample rate, channels, role tags (from folder/file names),
#               envelope (peak time, onset, tail, shape: hit / rise / swell / flat, peak and rms dB).
# MODE "pick":  query the cache -> ranked candidates for a role (see QUERY).
# MODE "import": import chosen files into the Media Pool folder SFX_BIN (only those files).
# MODE "place" (v2.6.2): CUES -> imported if needed, appended to the current Draft on the first free track of
#               SFX_TRACKS so the peak (rise/swell) or onset (hit) lands on the event frame; level = role level
#               adjusted by the file's own peak vs the role's typical peak (auto_level); read back to the frame.
# MODE "bed" (v2.8.0): FRAMES -> loudness of the program bed (footage sound, dialogue, music, ambience: every
#               audio track except SFX_TRACKS) around each frame, after each item's AudioVolume. Writes nothing.
# v2.8.0 levels follow the footage (user rule 2026-10-25): with LEVEL_MODE "context" MODE place measures the
#               bed around every cue and moves the role level by (bed − BED_REF_DBFS), so an accent sits at the
#               same distance above a quiet night street as above a loud market. Under speech it never rises.
# Nothing in the SFX folder is changed. Temp WAVs go to the system temp dir and are deleted.

MODE = "scan"                       # "scan" | "pick" | "import" | "stats" | "place" | "bed"
ROOT = "/Users/felix/Desktop/Asset/Sound Effect"
CACHE = "~/Movies/ClaudeQC/_sfx/catalog.json"
BUDGET_SEC = 45                     # keep each call under the MCP timeout
ENVELOPE = True                     # decode audio for envelope features (slower, ~0.1 s/file)
QUERY = {"role": "whoosh", "mood": "soft", "max_dur": 2.5, "min_dur": 0.3, "shape": None, "n": 8,
         "exclude": [], "prefer": []}
IMPORT = []                         # relative paths (from pick results) for MODE "import"
SFX_BIN = "SFX"
# v2.6.2 MODE "place": put a cue sheet on the CURRENT Draft_/Probe_/Test_ timeline, aligned and levelled.
CUES = [
    # {"file": "<rel path from pick>", "event": 211, "role": "whoosh"},          # peak lands on frame 211
    # {"file": "...", "event": 700, "role": "shimmer", "align": "onset", "length": 50, "volume": -18},
]
#   align: "auto" (hit -> onset, rise/swell -> peak) | "peak" | "onset" | "start"; length: timeline frames
#   (shortens the file); volume: dB, overrides the automatic level.
SFX_TRACKS = [3, 4]                 # first track free over the cue's range is used (config tracks.sfx_track…)
SFX_COLOR = "Yellow"                # v3.3.0: clip colour of placed SFX (music is Green); "" = leave the colour
TRANSITION_ONLY = True              # v3.4.0 (user rule 2026-10-27): SFX only on transitions — a cue whose event is
CUT_TOL = 3                         # not within CUT_TOL frames of a V1/V2 cut is refused (no SFX for content)
# v3.5.0 (TestSkill live run): whooshes were "buried" at context level (-4 dB) and clipped the mix at +4 dB; 0..+1 dB
# worked. Whoosh/transition sit 4 dB higher in LEVELS, and no automatic level may push a file peak above PEAK_CEIL_DBFS.
PEAK_CEIL_DBFS = 0.0
TRANSITIONS_PER_30S = 7             # v3.5.0: fewer placed transition SFX than this (scaled to the runtime) is reported
LEVELS = {"whoosh": -4, "riser": -10, "subdrop": -7, "slowmo": -9, "hit": -7, "camera": -12,
          "shimmer": -17, "transition": -6, "ambience_open_air": -19, "ambience_busy": -23}   # = levels_db (2026-10-25 BoConCN)
LEVEL_CLAMP = (-30.0, 10.0)         # automatic levels stay inside this range (dB); +10: the quiet riser on
                                    # BoConCN needed +7 by ear
# v2.8.0 context levels: the levels_db table is the level of a typical file over a bed of BED_REF_DBFS (RMS dBFS
# after item volume: a typical music file at -9 dB). Each cue moves by (measured bed - BED_REF_DBFS).
LEVEL_MODE = "context"              # "context" (follow the footage/music around each cue) | "table" (v2.7 behaviour)
BED_REF_DBFS = -24.0                # recalibrate: run MODE "bed" on a Draft whose SFX the user approved by ear
BED_WINDOW_S = 1.0                  # bed measured over [event - w/2, event + w/2]
BED_SHIFT_CLAMP = (-12.0, 9.0)      # how far the bed may move a level (dB)
BED_SILENT_DBFS = -55.0             # a bed quieter than this counts as silence (no footage sound, no music)
DIALOGUE_TRACKS = [1]               # speech in the window: the shift is capped at 0 (accents never fight words)
FRAMES = []                         # MODE "bed": timeline-relative frames to measure
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
REPLACE_SAME = True                 # re-running a cue replaces an item of the same file overlapping its range
                                    # (v2.6.2: ±2 frames missed a hand-placed bell 3 frames early -> duplicate on A4)

AUDIO_EXT = (".wav", ".mp3", ".aif", ".aiff", ".m4a", ".caf", ".flac", ".aac")

# role -> keywords (lower-case). A keyword must start at a word boundary ("hit" does not match
# "white", "rise" does not match "surprise"); suffixes are allowed ("risers", "whooshes").
# Tags are recomputed from these rules at pick time, so improving a rule needs no re-scan.
ROLE_RULES = [
    ("weapon",   ["gun sfx", "pistol", "rifle", "shotgun", "sniper", "machinegun", "smg/", "rocket launcher", "bullets and guns", "gun", "bullet", "gunshot"]),
    ("meme",     ["memes/", "230 mixed sound effcts/", "faaaa", "famous sound", "meme", "maga", "bruh", "comedic",
                  "y2mate", "(hd)", "ringtone", "one-piece", "onepiece", "one_piece", "spongebob", "minecraft",
                  "discord", "fart", "rizz", "sigma"]),
    ("bed",      ["fc_sfx_bed", "fullmix"]),
    ("subdrop",  ["sub drop", "subdrop", "sub_drop", "sub-drop", "downer"]),
    ("riser",    ["riser", "rise", "rising", "uplift", "build up", "buildup", "reverse", "suckback", "suck back"]),
    ("whoosh",   ["whoosh", "swoosh", "woosh", "swish", "swipe", "pass by", "passby", "fly by", "flyby", "swing",
                  "stem_whoosh"]),
    ("hit",      ["hit", "impact", "boom", "slam", "punch", "thud", "braam", "trailer", "drum"]),
    ("transition", ["transition", "fast cut/"]),
    ("camera",   ["camera", "shutter", "photo", "flash", "film roll", "projector"]),
    ("glitch",   ["glitch", "static", "distort", "digital"]),
    ("click",    ["click", "button", "select", "tap", "keyboard", "typing", "typewriter", "mouse", "enter key"]),
    ("ui",       ["user_interface", "notification", "refresh", "interface", "ui", "hud", "beep", "blip", "pop", "bubble"]),
    ("shimmer",  ["bell", "chime", "ding", "shimmer", "sparkle", "magic", "fantasy", "melodic", "harp", "twinkle",
                  "angels"]),
    ("slowmo",   ["slow motion", "slowmo", "slow-mo", "time stop", "rewind"]),
    ("tension",  ["horror", "tension", "drone", "suspense", "dark"]),
    ("ambience", ["fire/", "water/", "subway/", "train/", "rain", "city", "crowd", "ambien", "ocean", "bird",
                  "forest", "street", "cricket", "water-droplet", "page flip"]),
    ("vehicle",  ["renault", "car/", "engine", "horn/", "doors/", "mechanisms/"]),
    ("scifi",    ["sci-fi", "sci_fi", "scifi", "arcade", "laser", "steampunk", "drones", "cyber", "futuristic"]),
]
# moods a role can serve (used by "pick" when QUERY["mood"] is set)
MOOD_OK = {
    "soft":      {"whoosh", "riser", "shimmer", "ambience", "subdrop", "slowmo", "camera", "transition"},
    "cinematic": {"whoosh", "riser", "hit", "subdrop", "tension", "slowmo", "transition", "shimmer", "bed"},
    "energetic": {"whoosh", "hit", "transition", "glitch", "click", "riser", "camera", "ui"},
    "tech":      {"glitch", "click", "ui", "scifi", "transition"},
    "funny":     {"meme", "ui", "click"},
}
# preferred envelope shape and duration window (seconds) per role, used in ranking
ROLE_SHAPE = {"whoosh": "swell", "riser": "rise", "subdrop": "hit", "hit": "hit", "transition": "swell", "slowmo": "swell"}
IDEAL_DUR = {"whoosh": (0.6, 1.6), "riser": (1.5, 4.0), "subdrop": (2.0, 5.0), "hit": (0.5, 2.5), "shimmer": (0.8, 3.0),
             "camera": (0.3, 1.0), "transition": (0.4, 1.5), "ambience": (4.0, 30.0), "slowmo": (2.0, 8.0),
             "click": (0.05, 0.6), "ui": (0.1, 1.2), "glitch": (0.2, 1.5)}
NEVER_FOR_MOOD = {"soft": {"weapon", "meme", "scifi", "vehicle"}, "cinematic": {"meme", "weapon"},
                  "energetic": {"weapon"}, "tech": {"weapon", "meme"}}


def _kw_re(k):
    import re
    return re.compile(r"(?<![a-z0-9])" + re.escape(k))


_RULES_RE = None


def tags_for(rel):
    global _RULES_RE
    if _RULES_RE is None:
        _RULES_RE = [(role, [_kw_re(k) for k in kws]) for role, kws in ROLE_RULES]
    s = "/" + rel.lower().replace("\\", "/")
    tags = [role for role, res in _RULES_RE if any(r.search(s) for r in res)]
    return tags or ["misc"]


def envelope_features(samples, rate, win_ms=10):
    """samples: list of ints (mono). Returns peak/onset/tail times, dB levels and a shape label."""
    import math
    n = max(int(rate * win_ms / 1000), 1)
    env = []
    for i in range(0, len(samples), n):
        w = samples[i:i + n]
        if not w:
            break
        env.append(math.sqrt(sum(x * x for x in w) / len(w)))
    if not env or max(env) <= 0:
        return {"shape": "silent"}
    pk = max(env)
    ip = env.index(pk)
    db = lambda v: round(20 * math.log10(max(v, 1e-9) / 32768.0), 1)
    thr_on, thr_tail = pk * 0.1, pk * 0.0316          # -20 dB, -30 dB under the peak
    onset = next(i for i, v in enumerate(env) if v >= thr_on)
    tail = max(i for i, v in enumerate(env) if v >= thr_tail)
    dur = len(env) * win_ms / 1000.0
    rel = ip / max(len(env) - 1, 1)
    active = env[onset:tail + 1] or env
    flat = (sum(active) / len(active)) / pk > 0.55
    if flat and dur > 3:
        shape = "flat"           # beds, ambiences, drones
    elif rel <= 0.18:
        shape = "hit"            # attack first, decays (impacts, clicks, shutters, drops)
    elif rel >= 0.65:
        shape = "rise"           # builds to the end (risers, reverse swells)
    else:
        shape = "swell"          # peak in the middle (whooshes, pass-bys)
    allsq = sum(v * v for v in env) / len(env)
    return {"peak_t": round(ip * win_ms / 1000.0, 3), "onset_t": round(onset * win_ms / 1000.0, 3),
            "tail_t": round((tail + 1) * win_ms / 1000.0, 3), "peak_db": db(pk), "rms_db": db(math.sqrt(allsq)),
            "shape": shape}


def mood_of(entry):
    """Rough feel from level and shape: soft / punchy."""
    pk = entry.get("peak_db")
    if pk is None:
        return None
    return "punchy" if (entry.get("shape") == "hit" and pk > -6) or pk > -3 else "soft"


def rank(entries, q):
    role = q.get("role")
    mood = q.get("mood")
    out = []
    for rel, e in entries.items():
        tags = tags_for(rel)
        if role and role not in tags:
            continue
        if mood and set(tags) & NEVER_FOR_MOOD.get(mood, set()):
            continue
        d = e.get("dur") or 0
        if q.get("min_dur") and d < q["min_dur"]:
            continue
        if q.get("max_dur") and d > q["max_dur"]:
            continue
        if q.get("shape") and e.get("shape") != q["shape"]:
            continue
        low = rel.lower()
        if any(x.lower() in low for x in q.get("exclude", [])):
            continue
        score = 0.0
        score += 2.0 if tags and tags[0] == role else 0.0                 # primary role
        score += sum(1.5 for x in q.get("prefer", []) if x.lower() in low)
        if mood == "soft":
            score += 1.0 if e.get("feel") == "soft" else -0.5
        if mood in ("energetic", "cinematic"):
            score += 0.5 if e.get("feel") == "punchy" else 0.0
        if "misc" in tags:
            score -= 1.0
        if role and ROLE_SHAPE.get(role) and e.get("shape") == ROLE_SHAPE[role]:
            score += 1.0
        lo, hi = IDEAL_DUR.get(role, (0, 1e9))
        score -= 0.5 * (max(lo - d, 0) + max(d - hi, 0))
        out.append((round(score, 2), rel, e))
    seen, uniq = set(), []
    for t in out:                                  # the library holds copies in several folders
        k = (t[1].rsplit("/", 1)[-1].lower(), round(t[2].get("dur") or 0, 2))
        if k not in seen:
            seen.add(k)
            uniq.append(t)
    out = uniq
    mid = sum(IDEAL_DUR.get(role, (0, 0))) / 2.0
    out.sort(key=lambda t: (-t[0], abs((t[2].get("dur") or 0) - mid)))
    return out[: int(q.get("n", 8))]


def placement(e, event_frame, fps, kind="auto"):
    """Timeline frame to start a SFX so its feature lands on event_frame.
    rise/swell -> peak on the event; hit -> onset on the event."""
    shape = e.get("shape")
    t = e.get("onset_t", 0.0) if shape == "hit" or kind == "hit" else e.get("peak_t", 0.0)
    return int(round(event_frame - t * fps))


def role_ref_peaks(files):
    """Median peak_db per role over the catalogue: what a 'typical' file of that role peaks at. The level
    table (levels_db) was approved by ear with typical files, so a file is moved by its distance from it."""
    by = {}
    for rel, e in files.items():
        if e.get("peak_db") is None:
            continue
        for t in tags_for(rel):
            by.setdefault(t, []).append(e["peak_db"])
    out = {}
    for t, v in by.items():
        v = sorted(v)
        out[t] = v[len(v) // 2]
    return out


def level_key(role, levels):
    if role in levels:
        return role
    if role == "ambience":
        return "ambience_open_air" if "ambience_open_air" in levels else None
    return None


def auto_level(role, peak_db, levels, refs, clamp=(-30.0, 10.0), ref_role=None):
    """v2.6.2: item AudioVolume for a file = table level of its role + (typical peak of the role − this
    file's peak). BoConCN: 'The wind.wav' peaks at −28.6 dBFS; −14 dB from the table put it near −43 dBFS,
    buried under the music. -> (dB, note)."""
    k = level_key(role, levels)
    base = float(levels[k]) if k else -18.0
    note = "table %s %+.0f" % (k, base) if k else "no table level for %r: -18" % role
    ref = refs.get(ref_role or role)
    if ref is not None and peak_db is not None:
        adj = ref - peak_db
        note += ", file peak %.1f vs typical %s %.1f dBFS -> %+.1f" % (peak_db, ref_role or role, ref, adj)
        base += adj
    v = round(min(max(base, clamp[0]), clamp[1]), 1)
    if v != round(base, 1):
        note += " (clamped)"
    return v, note


def power_sum_db(levels):
    """dB levels of simultaneous sounds -> their combined level (power sum). None/empty -> None."""
    import math
    v = [l for l in (levels or []) if l is not None]
    if not v:
        return None
    return round(10 * math.log10(sum(10 ** (l / 10.0) for l in v)), 1)


def rms_dbfs(samples):
    """samples in [-1, 1] -> RMS dBFS (None when empty)."""
    import math
    if not samples:
        return None
    return round(20 * math.log10(max(math.sqrt(sum(x * x for x in samples) / len(samples)), 1e-6)), 1)


def context_shift(bed_db, ref_db=-24.0, clamp=(-12.0, 9.0), speech=False, silent_db=-55.0):
    """v2.8.0: how far the program bed around a cue moves the role level. A bed louder than the reference
    pushes the SFX up by the same amount (it would be masked), a quieter bed pulls it down (it would jump
    out). Speech in the window: never up. Silence: the full downward clamp is not used — a lone accent over
    silence keeps half of it so it is still heard. -> (dB, note)."""
    if bed_db is None:
        return 0.0, "no bed measured: table level"
    if bed_db <= silent_db:
        sh = clamp[0] / 2.0
        return sh, "bed silent (%.1f dBFS): %+.1f" % (bed_db, sh)
    sh = bed_db - ref_db
    note = "bed %.1f vs ref %.1f dBFS" % (bed_db, ref_db)
    sh = min(max(sh, clamp[0]), clamp[1])
    if speech and sh > 0:
        sh = 0.0
        note += ", speech in window: not raised"
    return round(sh, 1), note + " -> %+.1f" % sh


def tc_frames(tc, fps):
    """'00:00:02;09' at the clip's own fps -> frames (audio clips report Duration, not Frames)."""
    import re
    h, m, s, f = [int(x) for x in re.split(r"[:;]", str(tc))]
    return ((h * 60 + m) * 60 + s) * int(round(fps)) + f


def plan_cue(e, cue, tl_fps, clip_fps, src_frames, levels, refs, clamp=(-30.0, 10.0), tags=None, shift=(0.0, "")):
    """One cue -> where and how to append it. Times inside the file come from the catalogue envelope.
    tags: the file's role tags; its loudness is compared with the typical file of the cue's role when the
    file carries that tag, else with its own first tag (a whoosh used as a slow-mo swell is still a whoosh)."""
    align = cue.get("align", "auto")
    if align == "start":
        t = 0.0
    elif align == "onset" or (align == "auto" and e.get("shape") == "hit"):
        t = e.get("onset_t") or 0.0
    else:
        t = e.get("peak_t") or 0.0
    record = int(round(cue["event"] - t * tl_fps))
    start_src = 0
    if record < 0:                                   # the cue would start before the timeline: trim its head
        start_src = int(round(-record * clip_fps / tl_fps))
        record = 0
    end_src = src_frames
    if cue.get("length"):
        end_src = min(src_frames, start_src + int(round(cue["length"] * clip_fps / tl_fps)))
    if cue.get("volume") is not None:
        vol, note = float(cue["volume"]), "set in the cue"
    else:
        role = cue.get("role")
        ref_role = role if not tags or role in tags else tags[0]
        vol, note = auto_level(role, e.get("peak_db"), levels, refs, clamp, ref_role)
        if shift and shift[0]:
            vol = round(min(max(vol + shift[0], clamp[0]), clamp[1]), 1)
            note += "; context %s" % shift[1]
        if e.get("peak_db") is not None and vol > PEAK_CEIL_DBFS - e["peak_db"]:
            vol = round(PEAK_CEIL_DBFS - e["peak_db"], 1)        # v3.5.0: the file's own peak may not pass the ceiling
            note += "; capped by the file peak"
    length_tl = int(round((end_src - start_src) * tl_fps / clip_fps))
    return {"record": record, "start_src": start_src, "end_src": end_src, "length": length_tl,
            "feature_t": t, "feature_frame": int(round(record + (t - start_src / clip_fps) * tl_fps)),
            "volume": vol, "level_note": note}


def transition_target(frames, fps, per_30s=None):
    """v3.5.0: how many transitions should carry an SFX for a runtime of `frames`."""
    per_30s = TRANSITIONS_PER_30S if per_30s is None else per_30s
    return int(round(per_30s * frames / float(fps) / 30.0))


def on_a_cut(event, cuts, tol=None):
    """v3.4.0: True when the cue's event frame is within tol frames of a picture cut."""
    tol = CUT_TOL if tol is None else tol
    return any(abs(int(event) - c) <= tol for c in cuts)


def timeline_cuts(tl, s0):
    """Timeline-relative frames where a picture cut happens on video tracks 1–2 (item starts and ends; the first
    and last frame of the video are not cuts)."""
    edges, end = set(), 0
    for t in (1, 2):
        for it in tl.GetItemListInTrack("video", t) or []:
            a, b = it.GetStart() - s0, it.GetEnd() - s0
            edges.update((a, b))
            end = max(end, b)
    return sorted(e for e in edges if 0 < e < end)


def free_track(occupied, a, b, tracks):
    """occupied: {track: [(start, end)]}, end exclusive. First track in `tracks` with no overlap of [a, b)."""
    for t in tracks:
        if all(b <= s or a >= e for s, e in occupied.get(t, [])):
            return t
    return None


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, json, time, re, subprocess, tempfile, wave, struct, shutil
    cache_p = os.path.expanduser(CACHE)
    _whole = {}

    def _ff():
        return shutil.which("ffmpeg") or next((x for x in (os.path.expanduser("~/.local/bin/ffmpeg"),
                                                           "/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg")
                                               if os.path.exists(x)), None)

    def decode_seg(path, start_s, length_s, sr=8000):
        """Mono samples in [-1, 1] of [start_s, start_s + length_s). ffmpeg seeks; without it afconvert
        decodes the whole file once per call (cached)."""
        w = os.path.join(tempfile.gettempdir(), "sfxbed_%d.wav" % os.getpid())
        try:
            ff = _ff()
            if ff:
                subprocess.run([ff, "-y", "-v", "error", "-ss", "%.3f" % max(start_s, 0), "-t", "%.3f" % length_s,
                                "-i", path, "-vn", "-ac", "1", "-ar", str(sr), w], capture_output=True, timeout=30)
                with wave.open(w) as wf:
                    raw = wf.readframes(wf.getnframes())
                return [v / 32768.0 for v in struct.unpack("<%dh" % (len(raw) // 2), raw[:len(raw) // 2 * 2])]
            if path not in _whole:
                subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@%d" % sr, "-c", "1", path, w],
                               capture_output=True, timeout=40)
                with wave.open(w) as wf:
                    raw = wf.readframes(wf.getnframes())
                _whole[path] = struct.unpack("<%dh" % (len(raw) // 2), raw[:len(raw) // 2 * 2])
            a = int(max(start_s, 0) * sr)
            return [v / 32768.0 for v in _whole[path][a:a + int(length_s * sr)]]
        except Exception:
            return []
        finally:
            if os.path.exists(w):
                os.remove(w)

    def measure_bed(tl, frame, tl_fps, s0):
        """Program bed around a timeline-relative frame: every audio item outside SFX_TRACKS, its source
        decoded over the window, moved by its AudioVolume, power-summed. Track faders are not readable."""
        half = BED_WINDOW_S / 2.0
        a, b = s0 + frame - half * tl_fps, s0 + frame + half * tl_fps
        parts, speech, items = [], False, []
        for t in range(1, (tl.GetTrackCount("audio") or 0) + 1):
            if t in SFX_TRACKS:
                continue
            for it in tl.GetItemListInTrack("audio", t) or []:
                if it.GetEnd() <= a or it.GetStart() >= b:
                    continue
                mpi = it.GetMediaPoolItem()
                path = mpi.GetClipProperty("File Path") if mpi else None
                if not path or not os.path.exists(path):
                    continue
                lo, hi = max(a, it.GetStart()), min(b, it.GetEnd())
                src_s = (it.GetLeftOffset() + (lo - it.GetStart())) / tl_fps
                lv = rms_dbfs(decode_seg(path, src_s, (hi - lo) / tl_fps))
                if lv is None:
                    continue
                vol = float((it.GetProperties() or {}).get("AudioVolume") or 0.0)
                parts.append(lv + vol)
                items.append({"track": t, "name": it.GetName(), "rms_dbfs": lv, "volume": vol})
                if t in DIALOGUE_TRACKS and lv > BED_SILENT_DBFS:
                    speech = True
        return power_sum_db(parts), speech, items
    os.makedirs(os.path.dirname(cache_p), exist_ok=True)
    cat = {"root": ROOT, "files": {}}
    if os.path.exists(cache_p):
        try:
            cat = json.load(open(cache_p))
        except Exception:
            pass
    files = cat.setdefault("files", {})
    out = {"mode": MODE}
    if MODE == "scan":
        t0 = time.time()
        allf = []
        for dp, dn, fn in os.walk(ROOT):
            for f in fn:
                if f.lower().endswith(AUDIO_EXT) and not f.startswith("._"):
                    allf.append(os.path.relpath(os.path.join(dp, f), ROOT))
        allf.sort()
        todo = [r for r in allf if r not in files or (ENVELOPE and "shape" not in files[r] and not files[r].get("err"))]
        tmpd = tempfile.mkdtemp(prefix="sfxscan_")
        done_now = 0
        for rel in todo:
            if time.time() - t0 > BUDGET_SEC:
                break
            p = os.path.join(ROOT, rel)
            e = files.get(rel) or {}
            try:
                if "dur" not in e:
                    o = subprocess.run(["afinfo", p], capture_output=True, text=True, timeout=10).stdout
                    m = re.search(r"estimated duration:\s*([\d.]+)", o)
                    sr = re.search(r"(\d+) Hz", o)
                    ch = re.search(r"(\d+) ch", o)
                    e.update({"dur": round(float(m.group(1)), 3) if m else None,
                              "sr": int(sr.group(1)) if sr else None, "ch": int(ch.group(1)) if ch else None,
                              "tags": tags_for(rel), "bytes": os.path.getsize(p)})
                if ENVELOPE and (e.get("dur") or 0) <= 60:
                    w = os.path.join(tmpd, "x.wav")
                    subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@8000", "-c", "1", p, w],
                                   capture_output=True, timeout=20)
                    with wave.open(w) as wf:
                        nfr = wf.getnframes()
                        data = wf.readframes(nfr)
                    smp = struct.unpack("<%dh" % (len(data) // 2), data)
                    e.update(envelope_features(list(smp), 8000))
                    e["feel"] = mood_of(e)
                    os.remove(w)
                elif ENVELOPE:
                    e["shape"] = "long"
            except Exception as ex:
                e["err"] = str(ex)[:80]
            files[rel] = e
            done_now += 1
        try:
            os.rmdir(tmpd)
        except OSError:
            pass
        gone = [r for r in files if r not in set(allf)]
        for r in gone:
            files.pop(r, None)
        json.dump(cat, open(cache_p, "w"), ensure_ascii=False)
        out.update({"done": sum(1 for r in allf if r in files and ("shape" in files[r] or files[r].get("err") or not ENVELOPE)),
                    "total": len(allf), "this_call": done_now, "removed": len(gone), "cache": cache_p})
    elif MODE == "stats":
        from collections import Counter
        out["roles"] = Counter(t for r in files for t in tags_for(r)).most_common()
        out["shapes"] = Counter(e.get("shape") for e in files.values()).most_common()
        out["errors"] = [r for r, e in files.items() if e.get("err")][:20]
    elif MODE == "pick":
        refs = role_ref_peaks(files)
        # v3.0.1 (live run): the catalogue offered a riser deleted from disk after the scan; place then said only
        # "import failed". Candidates are checked on disk; stale entries are counted (re-run MODE scan to drop them).
        _root = os.path.expanduser(ROOT)
        _stale = [r for r in files if not os.path.exists(os.path.join(_root, r))]
        out["stale_entries"] = len(_stale)
        files = {r: e for r, e in files.items() if r not in set(_stale)}
        out["candidates"] = [{"score": s, "rel": r, "dur": e.get("dur"), "shape": e.get("shape"),
                              "peak_t": e.get("peak_t"), "onset_t": e.get("onset_t"), "peak_db": e.get("peak_db"),
                              "feel": e.get("feel"), "tags": tags_for(r),
                              "auto_level_db": auto_level(QUERY.get("role"), e.get("peak_db"), LEVELS, refs,
                                                          LEVEL_CLAMP)[0]}
                             for s, r, e in rank(files, QUERY)]
    elif MODE == "place":
        import unicodedata
        nfc = lambda s: unicodedata.normalize("NFC", str(s or ""))
        tl = project.GetCurrentTimeline()
        if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
            out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_"
        else:
            refs = role_ref_peaks(files)
            by_base = {}
            for r in files:
                by_base.setdefault(nfc(r.rsplit("/", 1)[-1]).lower(), r)
            nfc_files = {nfc(r): r for r in files}
            mp = project.GetMediaPool()
            root = mp.GetRootFolder()
            sub = [f for f in root.GetSubFolderList() if f.GetName() == SFX_BIN]
            fold = sub[0] if sub else mp.AddSubFolder(root, SFX_BIN)
            s0 = tl.GetStartFrame()
            tl_fps = float(tl.GetSetting("timelineFrameRate"))
            n_audio = tl.GetTrackCount("audio") or 0
            while n_audio < max(SFX_TRACKS):
                tl.AddTrack("audio", "stereo")
                n_audio += 1
            rows, errors = [], []
            cuts = timeline_cuts(tl, s0) if TRANSITION_ONLY else []
            for n, cue in enumerate(CUES):
                if TRANSITION_ONLY and not on_a_cut(int(cue["event"]), cuts, CUT_TOL):
                    errors.append("#%d %s: event %s is not on a cut (±%d frames) — v3.4.0 SFX are for transitions only"
                                  % (n, cue.get("file"), cue["event"], CUT_TOL))
                    continue
                key = nfc(cue.get("file"))
                rel = nfc_files.get(key) or by_base.get(key.rsplit("/", 1)[-1].lower())
                if not rel:
                    errors.append("#%d %s: not in the catalogue (run MODE scan / pick)" % (n, cue.get("file")))
                    continue
                e = files[rel]
                path = os.path.join(ROOT, rel)
                clip = next((c for c in (fold.GetClipList() or [])
                             if nfc(c.GetClipProperty("File Path")) == nfc(path)), None)
                if clip is None:
                    prev = mp.GetCurrentFolder()
                    mp.SetCurrentFolder(fold)
                    got = mp.ImportMedia([path]) or []
                    mp.SetCurrentFolder(prev)
                    clip = got[0] if got else None
                if clip is None:
                    errors.append("#%d %s: %s" % (n, rel, "import failed" if os.path.exists(path) else
                                                  "file missing on disk (catalogue stale: re-run MODE scan, pick again)"))
                    continue
                pr = clip.GetClipProperty() or {}
                cfps = float(pr.get("FPS") or tl_fps)
                total = int(pr.get("Frames") or 0) or tc_frames(pr.get("Duration") or "00:00:00:00", cfps)
                shift, bed_info = (0.0, ""), None
                if LEVEL_MODE == "context" and cue.get("volume") is None:
                    bed, speech, parts = measure_bed(tl, int(cue["event"]), tl_fps, s0)
                    shift = context_shift(bed, BED_REF_DBFS, BED_SHIFT_CLAMP, speech, BED_SILENT_DBFS)
                    bed_info = {"bed_dbfs": bed, "speech": speech, "items": parts}
                plan = plan_cue(e, cue, tl_fps, cfps, total, LEVELS, refs, LEVEL_CLAMP, tags_for(rel), shift)
                plan["bed"] = bed_info
                a, b = plan["record"], plan["record"] + plan["length"]
                occ = {}
                for t in SFX_TRACKS:
                    for it in tl.GetItemListInTrack("audio", t) or []:
                        st, en = it.GetStart() - s0, it.GetEnd() - s0
                        if REPLACE_SAME and nfc(it.GetName()) == nfc(clip.GetName()) and st < b and en > a:
                            tl.DeleteClips([it], False)
                            continue
                        occ.setdefault(t, []).append((st, en))
                track = free_track(occ, a, b, SFX_TRACKS)
                if track is None:
                    errors.append("#%d %s: tracks %s busy over %d-%d" % (n, rel, SFX_TRACKS, a, b))
                    continue
                got = mp.AppendToTimeline([{"mediaPoolItem": clip, "startFrame": plan["start_src"],
                                            "endFrame": plan["end_src"], "trackIndex": track,
                                            "recordFrame": s0 + a, "mediaType": 2}])
                if not got:
                    errors.append("#%d %s: AppendToTimeline failed" % (n, rel))
                    continue
                it = got[0]
                it.SetProperties({"AudioVolume": plan["volume"]})
                if SFX_COLOR:                              # v3.3.0: SFX stand apart from the music bed
                    it.SetClipColor(SFX_COLOR)
                st = it.GetStart() - s0
                rb = {"track": track, "start": st, "end": it.GetEnd() - s0,
                      "volume": (it.GetProperties() or {}).get("AudioVolume")}
                rb["feature_frame"] = round(st + (plan["feature_t"] - plan["start_src"] / cfps) * tl_fps, 1)
                rb["off_by"] = round(rb["feature_frame"] - cue["event"], 1)
                rows.append({"cue": n, "file": clip.GetName(), "role": cue.get("role"), "event": cue["event"],
                             "plan": plan, "readback": rb})
            bad = [r["cue"] for r in rows if abs(r["readback"]["off_by"]) > 1 or r["readback"]["start"] != r["plan"]["record"]]
            need = transition_target(tl.GetEndFrame() - s0, tl_fps)
            got_n = len({r["event"] for r in rows})                # a riser + hit on one cut is one transition
            if got_n < need:
                errors.append("only %d transition(s) with SFX in this cue sheet; the plan needs about %d "
                              "(sfx-library.md §3: every ramp/zoom-through/whip join, chapter turn and B-roll entry with motion)"
                              % (got_n, need))
            out["transitions"] = {"placed": got_n, "target": need}
            out.update({"placed": rows, "errors": errors,
                        "status": "PLACED_READ_BACK" if not errors and not bad else
                        "PLACED_WITH_ISSUES: cues %s off by > 1 frame; errors %d" % (bad, len(errors)),
                        "next": "audio_presence.py on a busy range; listen — levels are measured, not auditioned"})
    elif MODE == "bed":
        tl = project.GetCurrentTimeline()
        if tl is None:
            out["status"] = "NO_TIMELINE"
        else:
            s0, tl_fps = tl.GetStartFrame(), float(tl.GetSetting("timelineFrameRate"))
            rows = []
            for f in FRAMES:
                bed, speech, parts = measure_bed(tl, int(f), tl_fps, s0)
                rows.append({"frame": f, "bed_dbfs": bed, "speech": speech, "items": parts,
                             "shift_db": context_shift(bed, BED_REF_DBFS, BED_SHIFT_CLAMP, speech,
                                                       BED_SILENT_DBFS)[0]})
            out.update({"status": "MEASURED", "beds": rows, "ref_dbfs": BED_REF_DBFS,
                        "note": "on a Draft whose SFX the user approved by ear, the median bed is the new BED_REF_DBFS"})
    elif MODE == "import":
        mp = project.GetMediaPool()
        root = mp.GetRootFolder()
        prev = mp.GetCurrentFolder()
        sub = [f for f in root.GetSubFolderList() if f.GetName() == SFX_BIN]
        fold = sub[0] if sub else mp.AddSubFolder(root, SFX_BIN)
        mp.SetCurrentFolder(fold)
        have = {c.GetClipProperty("File Path"): c for c in (fold.GetClipList() or [])}
        paths = [os.path.join(ROOT, r) for r in IMPORT]
        new = [p for p in paths if p not in have and os.path.exists(p)]
        got = mp.ImportMedia(new) if new else []
        mp.SetCurrentFolder(prev)
        out["imported"] = [c.GetName() for c in (got or [])]
        out["already"] = [os.path.basename(p) for p in paths if p in have]
        out["missing"] = [p for p in paths if not os.path.exists(p)]
    result = out
