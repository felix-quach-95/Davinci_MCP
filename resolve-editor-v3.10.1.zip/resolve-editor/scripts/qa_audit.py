# qa_audit.py — READ-ONLY structural audit of the current (draft) timeline.
# Paste into run_script. Edit CONFIG. Pass the same BLUEPRINT used for the build
# (optional) to compare plan vs reality.
# Checks: runtime vs target, video gaps/black frames, overlaps on a track, audio
# continuity across all audio tracks, source bounds, adjacent repeats, subtitle timing sanity,
# fades present on music, and (v3.0) that the graphics tracks reserved for HyperFrames are still empty.
# It does NOT check how anything looks or sounds — see visual-qc-loop.md.

# ---- CONFIG ----------------------------------------------------------------
TARGET_FRAMES = None        # e.g. 450; falls back to BLUEPRINT["target_frames"]
BLUEPRINT = None            # paste the blueprint dict here to compare
FOOTAGE_TRACKS = [1]        # tracks that must cover the whole runtime
GRAPHICS_TRACKS = [3, 4, 5]  # v3.0: reserved for HyperFrames output, empty in every Claude Draft (V2 = B-roll)
GRAPHICS_PLACED = False      # v3.0.1: True once the approved HyperFrames renders were placed on purpose (user request)
MUSIC_TRACKS = "auto"       # "auto" = track named MUSIC, else the audio-file track covering most of the runtime
                            # (dialogue from the footage on A1 is skipped), or a list of indexes
MIN_SUB_FRAMES = 20         # ~0.7 s at 30 fps
ENDING_HOLD_MAX = 48        # an end-of-video black hold up to this long is accepted as intentional when the last
                            # footage item fades out and the audio continues (see references/endings.md)
# ---------------------------------------------------------------------------


def union(intervals):
    out = []
    for a, b in sorted(intervals):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def holes(intervals, start, end, min_len=1):
    """Frame ranges in [start, end) not covered by intervals."""
    res, cur = [], start
    for a, b in union(intervals):
        if a - cur >= min_len:
            res.append((cur, a))
        cur = max(cur, b)
    if end - cur >= min_len:
        res.append((cur, end))
    return res


def overlaps(intervals):
    s = sorted(intervals)
    return [(s[i][1], s[i + 1][0]) for i in range(len(s) - 1) if s[i + 1][0] < s[i][1]]


def adjacent_repeats(items):
    """items: list of dicts with clip, src_in, src_out ordered on the track."""
    rep = []
    for a, b in zip(items, items[1:]):
        if a["clip"] and a["clip"] == b["clip"]:
            # speed ramps are consecutive items of one clip with continuous source; Resolve reports the
            # boundary frame on both sides of a retimed cut, so up to 2 shared frames is a ramp, not a repeat
            if min(a["src_out"], b["src_out"]) - max(a["src_in"], b["src_in"]) > 2:
                rep.append((a["name"], b["name"]))
    return rep


def music_check(A, music_tracks, end, tail=2):
    """Music must reach the end of the timeline and end on a fade (or finish naturally earlier,
    covered by other audio). Fades are in frames."""
    mus = [r for i in music_tracks for r in A.get(i, [])]
    if not mus:
        return {"music": {"ok": None, "note": "no music track found"}}
    last = max(mus, key=lambda r: r["b"])
    first = min(mus, key=lambda r: r["a"])
    fo = (last["fades"] or {}).get("FadeOut") or 0
    fi = (first["fades"] or {}).get("FadeIn") or 0
    reaches_end = last["b"] >= end - tail
    return {"music": {"ok": bool(fo) if reaches_end else None, "tracks": music_tracks,
                      "starts_at": first["a"], "ends_at": last["b"], "timeline_end": end,
                      "fade_in": fi, "fade_out": fo,
                      "note": "music reaches the end with no fade-out" if reaches_end and not fo else
                              ("music stops before the end; check it is intentional" if not reaches_end else "")}}


def split_ending_hold(gaps, end, last_fade_out, audio_holes, max_len=48):
    """Separate an intentional ending hold (final gap after a faded-out last shot, audio still running)
    from real gaps. Returns (real_gaps, ending_hold or None)."""
    if not gaps:
        return gaps, None
    a, b = gaps[-1]
    tail_audio_ok = not any(x < b and y > a for x, y in audio_holes)
    if b == end and (b - a) <= max_len and last_fade_out and last_fade_out >= 8 and tail_audio_ok:
        return gaps[:-1], [a, b]
    return gaps, None


def av_mismatches(pairs, tol=1):
    """pairs [(name, v_src_in, v_src_out, a_src_in, a_src_out, same_rate)] of linked items -> names whose
    audio does not cover the same source frames as the picture (out of sync). Different-rate pairs are
    skipped (their source frames are not comparable)."""
    return [p[0] for p in pairs if p[5] and (abs(p[1] - p[3]) > tol or abs(p[2] - p[4]) > tol)]


def verdict(checks):
    fails = [k for k, v in checks.items() if v.get("ok") is False]
    return "FAIL: " + ", ".join(fails) if fails else "STRUCTURAL PASS"


def pick_music_track(info):
    """info: {track_index: {"name": track name, "cover": frames covered, "video_src": items come from
    video files}}. Prefer a track named MUSIC/NHAC; else the audio-file track covering most of the
    runtime (A1 dialogue from the footage is skipped); else the most covered track."""
    if not info:
        return None
    for i in sorted(info):
        nm = (info[i].get("name") or "").lower()
        if "music" in nm or "nhạc" in nm or "nhac" in nm:
            return i
    files = {i: v for i, v in info.items() if not v.get("video_src") and v.get("cover")}
    pool = files or {i: v for i, v in info.items() if v.get("cover")}
    if not pool:
        return None
    return max(sorted(pool), key=lambda i: pool[i]["cover"])


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    s0 = tl.GetStartFrame()
    end = tl.GetEndFrame() - s0
    fps = (tl.GetSettings() or {}).get("timelineFrameRate")
    target = TARGET_FRAMES or (BLUEPRINT or {}).get("target_frames")

    def track(tt, i):
        rows = []
        for it in tl.GetItemListInTrack(tt, i) or []:
            mpi = it.GetMediaPoolItem()
            rows.append({"name": it.GetName(), "a": it.GetStart() - s0, "b": it.GetEnd() - s0,
                         "clip": mpi.GetMediaId() if mpi else None,
                         "src_in": it.GetSourceStartFrame() if mpi else 0,
                         "src_out": it.GetSourceEndFrame() if mpi else 0,
                         "frames": int(float(mpi.GetClipProperty("Frames") or 0)) if mpi else None,
                         "fades": it.GetFades()})
        return rows

    V = {i: track("video", i) for i in range(1, (tl.GetTrackCount("video") or 0) + 1)}
    A = {i: track("audio", i) for i in range(1, (tl.GetTrackCount("audio") or 0) + 1)}
    S = {i: track("subtitle", i) for i in range(1, (tl.GetTrackCount("subtitle") or 0) + 1)}
    checks = {}

    if target:
        ratio = end / float(target)
        checks["runtime"] = {"ok": 0.97 <= ratio <= 1.03, "timeline": end, "target": target,
                             "ratio": round(ratio, 3), "below_70pct": ratio < 0.7}
    foot = [(r["a"], r["b"]) for i in FOOTAGE_TRACKS for r in V.get(i, [])]
    allv = [(r["a"], r["b"]) for rows in V.values() for r in rows]
    alla0 = [(r["a"], r["b"]) for rows in A.values() for r in rows]
    a_holes = holes(alla0, 0, end, 2)
    lastv = max(V.get(FOOTAGE_TRACKS[0], []) or [{"b": 0, "fades": {}}], key=lambda r: r["b"])
    lfo = float((lastv.get("fades") or {}).get("FadeOut") or 0)
    g1, hold1 = split_ending_hold(holes(foot, 0, end), end, lfo, a_holes, ENDING_HOLD_MAX)
    g2, hold2 = split_ending_hold(holes(allv, 0, end), end, lfo, a_holes, ENDING_HOLD_MAX)
    checks["video_gaps_footage"] = {"ok": not g1, "holes": g1, "ending_hold": hold1}
    checks["black_frames_any_track"] = {"ok": not g2, "holes": g2, "ending_hold": hold2}
    checks["overlaps_same_track"] = {"ok": True, "found": {}}
    for tt, D in (("V", V), ("A", A)):
        for i, rows in D.items():
            o = overlaps([(r["a"], r["b"]) for r in rows])
            if o:
                checks["overlaps_same_track"]["ok"] = False
                checks["overlaps_same_track"]["found"]["%s%d" % (tt, i)] = o
    alla = [(r["a"], r["b"]) for rows in A.values() for r in rows]
    checks["audio_continuity"] = {"ok": not holes(alla, 0, end, 2), "silent_ranges": holes(alla, 0, end, 2)}
    bounds = [r["name"] for rows in list(V.values()) + list(A.values()) for r in rows
              if r["frames"] and (r["src_in"] < 0 or r["src_out"] > r["frames"] + 1)]
    checks["source_bounds"] = {"ok": not bounds, "out_of_bounds": bounds}
    reps = []
    for i in FOOTAGE_TRACKS:
        reps += adjacent_repeats(sorted(V.get(i, []), key=lambda r: r["a"]))
    checks["adjacent_repeats"] = {"ok": not reps, "pairs": reps}
    graphics = [r for i in GRAPHICS_TRACKS for r in V.get(i, [])]
    subs = [r for rows in S.values() for r in rows]
    short_s = [r["name"] for r in subs if r["b"] - r["a"] < MIN_SUB_FRAMES]
    # v3.0: Claude builds no graphics; anything here before Phase 10 is a mistake (or the user's own import)
    checks["graphics_tracks_empty"] = {"ok": (True if GRAPHICS_PLACED else not graphics),
                                       "items": [r["name"] for r in graphics][:10], "tracks": GRAPHICS_TRACKS,
                                       "note": "HyperFrames renders placed on purpose" if GRAPHICS_PLACED else ""}
    checks["subtitle_timing"] = {"ok": not short_s, "too_short": short_s, "count": len(subs),
                                 "overlaps": overlaps([(r["a"], r["b"]) for r in subs])}
    # linked picture/sound must use the same source frames (rebuilt cuts, transcript cuts) — v2.3
    pairs = []
    for i in FOOTAGE_TRACKS:
        for it in tl.GetItemListInTrack("video", i) or []:
            try:
                linked = [x for x in (it.GetLinkedItems() or []) if x.GetTrackTypeAndIndex()[0] == "audio"]
            except Exception:
                linked = []
            for au in linked[:1]:
                same = au.GetMediaPoolItem() is not None and it.GetMediaPoolItem() is not None and \
                    au.GetMediaPoolItem().GetMediaId() == it.GetMediaPoolItem().GetMediaId()
                pairs.append((it.GetName(), it.GetSourceStartFrame(), it.GetSourceEndFrame(),
                              au.GetSourceStartFrame(), au.GetSourceEndFrame(), same))
    bad_sync = av_mismatches(pairs)
    checks["av_sync_linked"] = {"ok": None if not pairs else not bad_sync, "pairs": len(pairs), "out_of_sync": bad_sync}
    music_tracks = MUSIC_TRACKS
    if music_tracks == "auto":

        def _track_info(tl):
            info = {}
            for i in range(1, (tl.GetTrackCount("audio") or 0) + 1):
                items = tl.GetItemListInTrack("audio", i) or []
                vid = False
                for it in items:
                    mpi = it.GetMediaPoolItem()
                    res = str((mpi.GetClipProperty("Resolution") if mpi else "") or "")
                    if "x" in res.lower():
                        vid = True
                info[i] = {"name": tl.GetTrackName("audio", i) if hasattr(tl, "GetTrackName") else "",
                           "cover": sum(int(it.GetDuration()) for it in items), "video_src": vid}
            return info
        mt = pick_music_track(_track_info(tl))
        music_tracks = [mt] if mt else []
    checks.update(music_check(A, music_tracks, end))
    if BLUEPRINT:
        planned = len(BLUEPRINT.get("segments", [])) + len(BLUEPRINT.get("audio", []))
        actual = sum(len(r) for r in V.values()) - len(graphics) + sum(len(r) for r in A.values())
        checks["item_count_vs_blueprint"] = {"ok": None, "planned_rows": planned, "actual_items": actual,
                                             "note": "linked audio/video can make counts differ; inspect if far off"}
    result = {"timeline": tl.GetName(), "fps": fps, "frames": end, "verdict": verdict(checks),
              "checks": checks, "visual_audio": "UNVERIFIED by this script"}
