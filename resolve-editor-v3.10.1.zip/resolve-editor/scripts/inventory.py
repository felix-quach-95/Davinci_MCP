# inventory.py — READ-ONLY preflight. Paste into run_script (sandbox is enough).
# Returns: resolve version, page, project, timeline settings, `warnings` (v2.7.0: empty pool, fps mismatch,
# landscape project — raise them before the Story approval), timelines with track
# counts and item counts, and every Media Pool clip with key properties.
# Writes nothing.

# ---- CONFIG ----------------------------------------------------------------
MAX_CLIPS = 400          # stop listing after this many clips (huge pools)
INCLUDE_TIMELINE_ITEMS = False   # True = also list items of the current timeline
COMPACT = True           # v3.0.2: clip rows carry only what the decisions need (name, kind, fps, frames, size,
                         # gamma, orientation); False = every property (paths, codecs, timecodes)
# ---------------------------------------------------------------------------

KEYS = ["File Path", "FPS", "Frames", "Duration", "Resolution", "Video Codec",
        "Type", "Audio Ch", "Input Color Space", "Input Gamma", "Online Status",
        "Start TC", "Format"]


def clip_kind(props):
    """Language-independent kind: Resolve localizes the 'Type' field (e.g. 'Hình ảnh')."""
    path = str(props.get("File Path") or "")
    res = str(props.get("Resolution") or "")
    codec = str(props.get("Video Codec") or "")
    if not path and not codec and res:
        return "timeline"
    if res and "x" in res.lower() and (codec or path):
        frames = str(props.get("Frames") or "")
        return "video" if frames not in ("", "1") else "still"
    if path:
        return "audio"
    return "other"


def _walk(folder, path, out, limit):
    for clip in folder.GetClipList() or []:
        if len(out) >= limit:
            return
        try:
            props = clip.GetClipProperty() or {}
        except Exception:
            props = {}
        row = {"name": clip.GetName(), "folder": path, "media_id": clip.GetMediaId()}
        for k in KEYS:
            if k in props:
                row[k] = props[k]
        row["kind"] = clip_kind(props)
        res = str(props.get("Resolution", ""))
        if "x" in res:
            try:
                w, h = [int(v) for v in res.lower().split("x")[:2]]
                row["orientation"] = "landscape" if w > h else ("portrait" if h > w else "square")
            except ValueError:
                pass
        out.append(row)
    for sub in folder.GetSubFolderList() or []:
        _walk(sub, path + "/" + sub.GetName(), out, limit)


def _timeline_summary(tl, with_items):
    s = tl.GetSettings() or {}
    info = {
        "name": tl.GetName(),
        "start_frame": tl.GetStartFrame(),
        "end_frame": tl.GetEndFrame(),
        "start_tc": tl.GetStartTimecode(),
        "fps": s.get("timelineFrameRate"),
        "width": s.get("timelineResolutionWidth"),
        "height": s.get("timelineResolutionHeight"),
        "tracks": {},
    }
    for tt in ("video", "audio", "subtitle"):
        n = tl.GetTrackCount(tt) or 0
        info["tracks"][tt] = []
        for i in range(1, n + 1):
            items = tl.GetItemListInTrack(tt, i) or []
            t = {"index": i, "name": tl.GetTrackName(tt, i), "items": len(items),
                 "enabled": tl.GetIsTrackEnabled(tt, i), "locked": tl.GetIsTrackLocked(tt, i)}
            if with_items:
                t["list"] = [{"name": it.GetName(), "start": it.GetStart(), "end": it.GetEnd(),
                              "src_in": _safe(it.GetSourceStartFrame),
                              "src_out": _safe(it.GetSourceEndFrame)} for it in items]
            info["tracks"][tt].append(t)
    return info


def duplicate_groups(clips):
    """v3.0 (Test_ / Coffee live run: 13 pool items, 8 files — browser downloads "x (1).mp4", "x (2).mp4" were
    byte-identical). Same name stem (without " (n)") and same media signature (frames, duration, resolution,
    codec, audio) = one source: analyse it once and never use it as a second, "different" shot."""
    import re as _re
    groups = {}
    for c in clips:
        if c.get("kind") not in ("video", "audio", "still"):
            continue
        if not c.get("name"):
            continue
        stem = _re.sub(r"\s*\(\d+\)(?=\.[^.]+$)", "", str(c["name"]))
        sig = (c.get("Frames"), c.get("Duration"), c.get("Resolution"), c.get("Video Codec"), c.get("Audio Ch"))
        key = (stem,) + (sig if all(sig[:3]) else ())   # same stem AND same media (two different takes can share a length)
        groups.setdefault(key, []).append(c.get("name"))
    return [sorted(v) for v in groups.values() if len(v) > 1]


def preflight_warnings(ps, clips, timelines):
    """v2.7.0: what the preflight must raise before the Story approval (BoConCN: an empty pool, then 25 fps footage
    in a 24 fps project — both found by hand). ps: project settings; clips: rows of _walk."""
    out = []
    vids = [c for c in clips if c.get("kind") == "video"]
    if not clips:
        out.append("EMPTY_MEDIA_POOL: the project has no clips — stop and ask where the footage is (gate 2)")
        return out
    try:
        tl_fps = float(ps.get("timelineFrameRate") or 0)
    except (TypeError, ValueError):
        tl_fps = 0.0
    rates = {}
    for c in vids:
        try:
            f = round(float(c.get("FPS") or 0), 3)
        except (TypeError, ValueError):
            continue
        if f:
            rates[f] = rates.get(f, 0) + 1
    if rates and tl_fps:
        main = max(rates, key=lambda f: rates[f])
        if abs(main - tl_fps) > 0.01 and abs(main - 2 * tl_fps) > 0.02 and abs(main - 4 * tl_fps) > 0.04:
            how = ("no timeline yet: project fps can be changed (ask at the kickoff questions — the first Probe_/Draft_ timeline locks it)" if not timelines else
                   "timelines exist: the project fps is locked; new timelines can set their own rate")
            out.append("FPS_MISMATCH: most footage is %g fps (%d clips), project timeline %g fps — %s"
                       % (main, rates[main], tl_fps, how))
    try:
        w, h = int(ps.get("timelineResolutionWidth") or 0), int(ps.get("timelineResolutionHeight") or 0)
    except (TypeError, ValueError):
        w = h = 0
    if w and h and w > h:
        out.append("LANDSCAPE_PROJECT: timeline %dx%d; vertical delivery needs a 9:16 timeline (blueprint "
                   "'resolution' or project setting)" % (w, h))
    dups = duplicate_groups(clips)
    if dups:
        out.append("DUPLICATE_MEDIA: %d pool items are copies of %d sources (%s) — analyse one per group, "
                   "never cut the same source as two different shots" % (sum(len(g) for g in dups), len(dups),
                                                                         "; ".join(" = ".join(g) for g in dups[:4])))
    if w and h:
        low = []
        for c in vids:
            try:
                cw, ch = [int(x) for x in str(c.get("Resolution") or "").lower().split("x")[:2]]
            except ValueError:
                continue
            # fill = scale until the frame is covered; the shorter source side must cover the matching timeline side
            scale = max(float(w) / cw, float(h) / ch)
            if scale > 2.0:
                low.append((c.get("name"), round(scale, 1)))
        if low:
            out.append("LOW_RES_SOURCE: %d clips need > 2x upscale to fill %dx%d (max %.1fx) — a 1080-wide timeline halves "
                       "the upscale on a 2160-wide one; landscape sources filling 9:16 stay soft (consider fit for those); "
                       "punch-ins make it worse" % (len(low), w, h, max(x[1] for x in low)))
    return out


def compact_rows(clips):
    """v3.0.2 token rule: the full rows (paths, codecs, TCs) cost tokens on every call; scripts read the pool
    themselves, so the decision needs only these fields. Folders are listed once."""
    keep = ("name", "kind", "FPS", "Frames", "Resolution", "Input Gamma", "orientation")
    rows = [{k: c[k] for k in keep if c.get(k) not in (None, "")} for c in clips]
    dirs = sorted({str(c.get("File Path") or "").rsplit("/", 1)[0] for c in clips if c.get("File Path")})
    return rows, dirs


def _safe(fn):
    try:
        return fn()
    except Exception:
        return None


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    pm = resolve.GetProjectManager()
    cur = project.GetCurrentTimeline()
    timelines = []
    for i in range(1, (project.GetTimelineCount() or 0) + 1):
        tl = project.GetTimelineByIndex(i)
        if tl is None:
            continue
        is_cur = cur is not None and tl.GetUniqueId() == cur.GetUniqueId()
        summary = _timeline_summary(tl, INCLUDE_TIMELINE_ITEMS and is_cur)
        summary["current"] = is_cur
        timelines.append(summary)
    clips = []
    _walk(project.GetMediaPool().GetRootFolder(), "Master", clips, MAX_CLIPS)
    ps = project.GetSettings() or {}
    result = {
        "resolve_version": resolve.GetVersionString(),
        "page": resolve.GetCurrentPage(),
        "project": project.GetName(),
        "project_settings": {k: ps.get(k) for k in (
            "timelineFrameRate", "timelineResolutionWidth", "timelineResolutionHeight",
            "colorScienceMode", "colorSpaceTimeline", "colorSpaceOutput")},
        "timelines": timelines,
        "clip_count": len(clips),
        "clips_truncated": len(clips) >= MAX_CLIPS,
        "clips": clips,
        "render_jobs": len(project.GetRenderJobList() or []),
    }
    result["warnings"] = preflight_warnings(ps, clips, timelines)
    if COMPACT:
        result["clips"], result["source_dirs"] = compact_rows(clips)
    result["duplicates"] = duplicate_groups(clips)
