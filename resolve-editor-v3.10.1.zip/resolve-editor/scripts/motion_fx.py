# motion_fx.py — emphasis effects inside a clip's own Fusion comp (no Fusion page, no paste).
# Tool: run_script (sandbox is enough). Writes only to Draft_/Probe_/Test_ timelines.
#
# Effects (times are frames RELATIVE TO THE ITEM START on the timeline; the script maps them to the
# clip comp's source frames — measured: the comp render range maps linearly onto the item):
#   push      : slow zoom a -> b over [t0, t1] around `center` (x, y of the SOURCE frame, y up). Draw the eye.
#               "drift": [dx, dy] also slides the picture (follow a subject that walks out / virtual pan;
#               a = b = 1.0 with drift = pure virtual camera move). +dx moves the picture right.
#               Source x of a subject seen at crop x c under Edit-page Pan P (16:9 in 9:16 fill):
#               x = 0.5 - P * 0.00035 + (c - 0.5) * 0.316   (measured: +Pan moves the VIEW LEFT).
#   pull      : zoom-out reveal b -> a (show context after a detail).
#   punch     : instant zoom step to b at t (cut-like emphasis on a beat), optional `release` frames back.
#   zoom_keys (v3.4.0, UNTESTED live): any zoom curve "keys": [[t, size(, ease)], ...] (negative t = from the end)
#               — zoom-through exit/entry, snap zoom, push-then-pull, reverse zoom cut (references/motion-effects.md §0).
#   shake     : impact shake for n frames from t, amplitude amp (fraction of frame), decaying.
#   blur_in   : defocus -> sharp over [t0, t1] (soft entrance, dream, time jump).
#   blur_out  : sharp -> defocus over [t0, t1] (soft exit; pair with blur_in on the next clip = focus transition).
#   whip_in / whip_out : directional blur + horizontal slide (whip-pan transition halves; put a whoosh on the cut).
#   flash     : exposure spike at t for n frames (beat hit, photo moment, impact).
#   freeze    : hold the frame at t for the rest of the item (photo/"this moment"); pair with shutter SFX.
#   spotlight : darken around `center` (radius r) between t0..t1 with soft in/out (make the subject clear).
#   ramp_smooth (v2.2, UNTESTED live): a smooth speed ramp INSIDE one item. "profile": [[t, speed], ...]
#               relative speeds at item frames (linear between points), e.g. [[0, 300], [20, 300], [30, 40],
#               [50, 40], [60, 200]]. The clip comp's TimeStretcher replays the item's source range with that
#               shape: the source used stays the item's own range, so the profile is normalised to the item's
#               average speed. Set the item speed (blueprint "speed"/"dur") to the average you want and give the
#               item extra source = its length x average speed. Replaces the stepped blueprint "ramp" when the
#               steps stutter; check with stills two frames apart around the slow point.
#   reframe_path (v2.3, UNTESTED): the picture follows a subject — "points": [[t, x, y], ...] (+ optional 4th
#               value = zoom) give the subject's SOURCE position at item frames; the subject is kept at the view
#               centre (the Edit-page Pan window) with eased in-out moves between points, keys every 2 frames.
#               Black edges are refused before writing. Sources: contact sheet positions or stills.
#   invert    (v2.3, UNTESTED): 1–2 frame negative flash at t (subliminal "stutter" that makes a hard cut feel
#               intentional; rugpull/energetic pieces only), BrightnessContrast Gain −1 / Brightness +1.
#   resolvefx (v2.3, UNTESTED): a built-in ResolveFX/OFX node in the clip comp, e.g. {"fx": "resolvefx",
#               "regid": "filmgrain", "params": {...}} — chained before MediaOut1 (ids: references/resolvefx.md;
#               check availability and input names first with picture_tools.py MODE "resolvefx_check").
# Each effect builds/reuses one node per kind named MFX_<kind>, appended after the clip's current chain
# (keeps any LUT / behind-object nodes). REPLACE=True removes this script's MFX_* nodes first — only on the items listed in EFFECTS, so give every
# effect of one item in the same run.
# Pair effects with SFX (references/motion-effects.md): push->riser, punch->hit, shake->sub drop,
# whip->whoosh (peak on the cut), flash/freeze->shutter, blur_in->swell.

REQUIRE_PREFIX = ("draft_", "probe_", "test_")
REPLACE = True
PAN_PER_UNIT = 0.00035            # 16:9 source in a 9:16 fill on a 2160-wide timeline (DJI); v3.0.1: depends on timeline
                                  # and source size (1080-wide + 1280x720 = 0.000923) — measure with picture_tools pan_calibrate
EFFECTS = [
    # {"track": 1, "index": 1, "fx": "push", "t0": 0, "t1": 60, "a": 1.0, "b": 1.12, "center": [0.55, 0.5], "ease": "inout"},
]

import math
import re


# ---------------- pure helpers ----------------
def comp_mapper(render_start, render_end, item_dur):
    """timeline-relative frame -> comp frame (linear over the item)."""
    span = max(item_dur - 1, 1)
    k = (render_end - render_start) / float(span)
    return lambda t: render_start + k * float(t)


def ease_handles(t0, v0, t1, v1, kind):
    dt, dv = float(t1 - t0), float(v1 - v0)
    if kind == "out":
        return {1: dt * 0.16, 2: dv * 0.9}, {1: -dt * 0.65, 2: 0.0}
    if kind == "in":
        return {1: dt * 0.65, 2: 0.0}, {1: -dt * 0.16, 2: -dv * 0.9}
    if kind == "inout":
        return {1: dt * 0.4, 2: 0.0}, {1: -dt * 0.4, 2: 0.0}
    return {1: dt / 3.0, 2: dv / 3.0}, {1: -dt / 3.0, 2: -dv / 3.0}


def build_keyframes(points):
    """points [(frame, value, ease_into_point)] -> Fusion keyframe dict (relative handles)."""
    pts = sorted(points, key=lambda p: p[0])
    kf = {}
    for t, v, _ in pts:
        kf[float(t)] = {1: float(v)}
    for i in range(len(pts) - 1):
        t0, v0, _ = pts[i]
        t1, v1, kind = pts[i + 1]
        rh, lh = ease_handles(t0, v0, t1, v1, kind or "linear")
        kf[float(t0)]["RH"] = rh
        kf[float(t1)]["LH"] = lh
    return kf


def ramp_curve(profile, dur, every=2):
    """profile [[t, speed%], ...] over item frames -> [(t, fraction 0..1 of the source range)].
    Source position is the running integral of speed, normalised so the last frame reaches 1.0."""
    pts = sorted((max(0, min(int(t), dur - 1)), float(v)) for t, v in profile)
    if not pts or any(v <= 0 for _, v in pts):
        raise ValueError("ramp_smooth needs a profile of positive speeds")
    if pts[0][0] > 0:
        pts.insert(0, (0, pts[0][1]))
    if pts[-1][0] < dur - 1:
        pts.append((dur - 1, pts[-1][1]))

    def speed_at(t):
        for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
            if t0 <= t <= t1:
                return v0 if t1 == t0 else v0 + (v1 - v0) * (t - t0) / float(t1 - t0)
        return pts[-1][1]
    cum, acc = [0.0], 0.0
    for t in range(1, dur):
        acc += (speed_at(t - 1) + speed_at(t)) / 2.0
        cum.append(acc)
    total = cum[-1] or 1.0
    frames = sorted(set(list(range(0, dur, max(int(every), 1))) + [dur - 1] + [t for t, _ in pts]))
    return [(t, cum[t] / total) for t in frames]


def smooth(u):
    """ease in-out (smoothstep) for u in [0, 1]"""
    u = min(max(u, 0.0), 1.0)
    return u * u * (3 - 2 * u)


def reframe_curve(points, dur, window_x=0.5, every=2, visible=0.316):
    """points [[t, x, y(, zoom)]] -> [(t, (cx, cy), (px, py), zoom)] Transform keys that bring the subject to the
    view centre: Pivot = subject (zoom happens around it), Center = translation (window_x - x, 0.5 - y).
    Eased between points. Raises ValueError when the shifted picture would show an edge inside the
    visible window (width `visible` of the source, centred on window_x)."""
    pts = sorted((int(p[0]), float(p[1]), float(p[2]), float(p[3]) if len(p) > 3 else 1.0) for p in points)
    if not pts:
        raise ValueError("reframe_path needs points")
    if pts[0][0] > 0:
        pts.insert(0, (0,) + pts[0][1:])
    if pts[-1][0] < dur - 1:
        pts.append((dur - 1,) + pts[-1][1:])

    def at(t):
        for (t0, x0, y0, z0), (t1, x1, y1, z1) in zip(pts, pts[1:]):
            if t0 <= t <= t1:
                u = smooth((t - t0) / float(t1 - t0)) if t1 > t0 else 1.0
                return x0 + (x1 - x0) * u, y0 + (y1 - y0) * u, z0 + (z1 - z0) * u
        return pts[-1][1:]
    frames = sorted(set(list(range(0, dur, max(int(every), 1))) + [dur - 1] + [p[0] for p in pts]))
    out = []
    for t in frames:
        x, y, z = at(t)
        dx, dy = window_x - x, 0.5 - y
        # picture spans [(0 - x) * z + x + dx, (1 - x) * z + x + dx] horizontally; the view must stay inside
        left, right = (0 - x) * z + x + dx, (1 - x) * z + x + dx
        if left > window_x - visible / 2 + 1e-6 or right < window_x + visible / 2 - 1e-6:
            raise ValueError("reframe_path: frame %d would show a black edge (subject x=%.3f, zoom %.2f)" % (t, x, z))
        bottom, top = (0 - y) * z + y + dy, (1 - y) * z + y + dy
        if bottom > 1e-6 or top < 1 - 1e-6:
            raise ValueError("reframe_path: frame %d would show a black edge vertically (y=%.3f, zoom %.2f)" % (t, y, z))
        out.append((t, (0.5 + dx, 0.5 + dy), (x, y), z))
    return out


def fx_points(e, dur):
    """-> {(node_kind, input): [(tl_frame, value, ease)]} plus static inputs {(node_kind, input): value}."""
    fx = e["fx"]
    keys, static = {}, {}
    last = dur - 1
    if fx in ("push", "pull"):
        a, b = float(e.get("a", 1.0)), float(e.get("b", 1.12))
        if fx == "pull":
            a, b = b, a
        t0, t1 = int(e.get("t0", 0)), int(e.get("t1", last))
        keys[("Xf", "Size")] = [(0, a, None), (t0, a, "linear"), (t1, b, e.get("ease", "inout"))]
        c = e.get("center") or [0.5, 0.5]
        # Fusion Transform: Pivot = point the zoom happens around (subject, source coords);
        # Center = translation of the whole picture (0.5, 0.5 = none). Measured 2026-10-24:
        # Center = Pivot = subject shifted the picture by (subject - 0.5) and left a black band.
        static[("Xf", "Pivot")] = c
        if e.get("drift"):
            # follow a moving subject / virtual camera move: the picture slides by drift (source
            # fractions; +x moves the picture right = the view travels left)
            dx, dy = e["drift"]
            keys[("Xf", "Center@path")] = [(0, (0.5, 0.5), None), (t0, (0.5, 0.5), None),
                                           (t1, (0.5 + dx, 0.5 + dy), None)]
    elif fx == "punch":
        t = int(e["t"])
        b = float(e.get("b", 1.15))
        pts = [(0, 1.0, None), (max(t - 1, 0), 1.0, "linear"), (t, b, "linear")]
        if e.get("release"):
            pts.append((min(t + int(e["release"]), last), 1.0, "inout"))
        keys[("Xf", "Size")] = pts
        if e.get("center"):
            static[("Xf", "Pivot")] = e["center"]
    elif fx == "zoom_keys":
        # v3.4.0 (UNTESTED live): one zoom curve per item — slow push that accelerates into a zoom-through exit,
        # a zoom-through entry that settles, push-then-pull. "keys": [[t, size(, ease)], ...] at item frames;
        # a negative t counts from the end (-1 = last frame). Same Transform as push/punch: use one per item.
        pts = []
        for k in sorted(e["keys"], key=lambda k: int(k[0]) if int(k[0]) >= 0 else last + 1 + int(k[0])):
            t = int(k[0]) if int(k[0]) >= 0 else last + 1 + int(k[0])
            pts.append((t, float(k[1]), k[2] if len(k) > 2 else e.get("ease", "inout")))
        if pts and pts[0][0] > 0:
            pts.insert(0, (0, pts[0][1], None))
        keys[("Xf", "Size")] = pts
        static[("Xf", "Pivot")] = e.get("center") or [0.5, 0.5]
    elif fx == "shake":
        t, n, amp = int(e["t"]), int(e.get("n", 8)), float(e.get("amp", 0.012))
        cx, cy = 0.5, 0.5                      # Center is a translation: shake around "no offset"
        pts = [(0, (cx, cy))] + ([(t - 1, (cx, cy))] if t > 0 else [])
        for i in range(n):
            dec = (1.0 - i / float(n)) ** 1.5
            ang = i * 2.39996       # golden angle: non-repeating directions
            pts.append((t + i, (cx + amp * dec * math.cos(ang), cy + amp * dec * math.sin(ang))))
        pts.append((t + n, (cx, cy)))
        keys[("Xf", "Center@path")] = [(f, v, None) for f, v in pts if f <= last]
    elif fx in ("blur_in", "blur_out"):
        t0, t1, amt = int(e.get("t0", 0)), int(e.get("t1", 8)), float(e.get("amount", 12.0))
        if fx == "blur_in":
            keys[("Blur", "XBlurSize")] = [(0, amt, None), (t0, amt, "linear"), (t1, 0.0, "out")]
        else:
            keys[("Blur", "XBlurSize")] = [(0, 0.0, None), (t0, 0.0, "linear"), (t1, amt, "in")]
    elif fx in ("whip_in", "whip_out"):
        n = int(e.get("n", 6))
        length = float(e.get("length", 0.15))
        shift = float(e.get("shift", 0.18)) * (1 if e.get("direction", "left") == "left" else -1)
        if fx == "whip_out":
            t0 = max(last - n, 0)
            keys[("DBlur", "Length")] = [(0, 0.0, None), (t0, 0.0, "linear"), (last, length, "in")]
            keys[("Xf", "Center@x")] = [(0, 0.5, None), (t0, 0.5, "linear"), (last, 0.5 - shift, "in")]
        else:
            keys[("DBlur", "Length")] = [(0, length, None), (n, 0.0, "out")]
            keys[("Xf", "Center@x")] = [(0, 0.5 + shift, None), (n, 0.5, "out")]
    elif fx == "flash":
        # Gain alone barely shows on LOG footage (measured): add Brightness (additive) as the main flash.
        t, n = int(e["t"]), int(e.get("n", 4))
        g, br = float(e.get("gain", 1.6)), float(e.get("brightness", 0.35))
        keys[("Flash", "Gain")] = [(0, 1.0, None)] + ([(t - 1, 1.0, "linear")] if t > 0 else []) + \
                                  [(t, g, "linear"), (min(t + n, last), 1.0, "out")]
        keys[("Flash", "Brightness")] = [(0, 0.0, None)] + ([(t - 1, 0.0, "linear")] if t > 0 else []) + \
                                        [(t, br, "linear"), (min(t + n, last), 0.0, "out")]
    elif fx == "freeze":
        keys[("Time", "SourceTime@hold")] = [(int(e["t"]), None, None)]
    elif fx == "reframe_path":
        curve = reframe_curve(e["points"], dur, float(e.get("window_x", 0.5)), e.get("every", 2),
                              float(e.get("visible", 0.316)))
        keys[("Xf", "Center@path")] = [(t, c, None) for t, c, _, _ in curve]
        keys[("Xf", "Pivot@path")] = [(t, p, None) for t, _, p, _ in curve]
        if any(abs(z - 1.0) > 1e-6 for _, _, _, z in curve):
            keys[("Xf", "Size")] = [(t, z, None) for t, _, _, z in curve]
    elif fx == "invert":
        t, n = int(e["t"]), int(e.get("n", 2))
        g = [(0, 1.0, None)] + ([(t - 1, 1.0, "linear")] if t > 0 else []) + [(t, -1.0, "linear"),
                                                                              (min(t + n - 1, last), -1.0, "linear")]
        br = [(0, 0.0, None)] + ([(t - 1, 0.0, "linear")] if t > 0 else []) + [(t, 1.0, "linear"),
                                                                               (min(t + n - 1, last), 1.0, "linear")]
        if t + n <= last:
            g.append((t + n, 1.0, "linear"))
            br.append((t + n, 0.0, "linear"))
        keys[("Inv", "Gain")] = g
        keys[("Inv", "Brightness")] = br
    elif fx == "resolvefx":
        rid = e["regid"]
        rid = rid if rid.startswith("ofx.") else "ofx." + (rid if "." in rid else "com.blackmagicdesign.resolvefx." + rid)
        static[("OFX:" + rid, "_params")] = dict(e.get("params") or {})
    elif fx == "ramp_smooth":
        keys[("Time", "SourceTime@curve")] = [(t, f, None) for t, f in ramp_curve(e["profile"], dur, e.get("every", 2))]
    elif fx == "spotlight":
        t0, t1 = int(e.get("t0", 0)), int(e.get("t1", last))
        ramp = int(e.get("ramp", 8))
        dark = float(e.get("dark", 0.55))
        keys[("Spot", "Gain")] = [(0, 1.0, None), (t0, 1.0, "linear"), (min(t0 + ramp, t1), dark, "inout"),
                                  (max(t1 - ramp, t0), dark, "linear"), (t1, 1.0, "inout")]
        static[("SpotMask", "Center")] = e.get("center", [0.5, 0.5])
        static[("SpotMask", "Width")] = float(e.get("r", 0.35)) * 2
        static[("SpotMask", "Height")] = float(e.get("r", 0.35)) * 2 * 16 / 9.0
        static[("SpotMask", "SoftEdge")] = float(e.get("soft", 0.25))
    else:
        raise ValueError("unknown fx %s" % fx)
    return keys, static


NODE = {"Xf": ("Transform", "MFX_Xf"), "Blur": ("Blur", "MFX_Blur"), "DBlur": ("DirectionalBlur", "MFX_DBlur"),
        "Flash": ("BrightnessContrast", "MFX_Flash"), "Time": ("TimeStretcher", "MFX_Time"),
        "Spot": ("BrightnessContrast", "MFX_Spot"), "SpotMask": ("EllipseMask", "MFX_SpotMask"),
        "Inv": ("BrightnessContrast", "MFX_Inv")}
ORDER = ["Time", "Xf", "DBlur", "Blur", "Flash", "Inv", "Spot"]   # chain order after the existing nodes;
                                                                  # ResolveFX nodes (OFX:<regid>) go last


def validate(effects, items_len):
    probs = []
    for i, e in enumerate(effects):
        n = items_len.get((e.get("track", 1), e.get("index")))
        if n is None:
            probs.append("#%d: no item V%s#%s" % (i, e.get("track", 1), e.get("index")))
            continue
        try:
            keys, _ = fx_points(e, n)
        except Exception as ex:
            probs.append("#%d: %s" % (i, ex))
            continue
        for k, pts in keys.items():
            for f, _, _ in pts:
                if f < 0 or f > n - 1:
                    probs.append("#%d %s: frame %s outside item 0..%d" % (i, e["fx"], f, n - 1))
                    break
        same = [x["fx"] for x in effects if (x.get("track", 1), x.get("index")) == (e.get("track", 1), e.get("index"))]
        if e["fx"] == "reframe_path" and any(f in same for f in ("push", "pull", "punch", "shake", "whip_in", "whip_out", "zoom_keys")):
            probs.append("#%d: reframe_path drives the same Transform as push/punch/shake/whip: use one" % i)
        if e["fx"] == "zoom_keys":
            if any(f in same for f in ("push", "pull", "punch")):
                probs.append("#%d: zoom_keys and push/pull/punch drive the same Size: put the whole curve in zoom_keys" % i)
            if max(float(k[1]) for k in e["keys"]) > 1.35:
                probs.append("#%d: zoom_keys above 1.35 looks soft on 16:9 fill footage" % i)
        if e["fx"] == "ramp_smooth" and "freeze" in same:
            probs.append("#%d: ramp_smooth and freeze share the TimeStretcher of one item: use one" % i)
        if e["fx"] in ("push", "punch") and float(e.get("b", 1.12)) > 1.35:
            probs.append("#%d: zoom %.2f > 1.35 looks soft on 16:9 fill footage" % (i, float(e["b"])))
    return probs


# ---------------- Resolve side ----------------
try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    out = {"applied": [], "errors": []}
    if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_ (%s)" % (tl.GetName() if tl else None)
    else:
        lens = {}
        for e in EFFECTS:
            items = tl.GetItemListInTrack("video", int(e.get("track", 1))) or []
            k = int(e["index"]) - 1
            if 0 <= k < len(items):
                lens[(e.get("track", 1), e["index"])] = int(items[k].GetDuration())
                if e.get("fx") == "reframe_path" and "window_x" not in e:
                    # the Edit-page Pan decides which part of the source is in view (9:16 fill: measured
                    # 0.00035 of the source width per unit, +Pan moves the view left)
                    pan = float((items[k].GetProperties() or {}).get("Pan") or 0.0)
                    e["window_x"] = 0.5 - pan * PAN_PER_UNIT
        probs = validate(EFFECTS, lens)
        if probs:
            out["status"] = "STOPPED_BEFORE_WRITE"
            out["problems"] = probs
        else:
            by_item = {}
            for e in EFFECTS:
                by_item.setdefault((int(e.get("track", 1)), int(e["index"])), []).append(e)
            for (tr, ix), effs in by_item.items():
                it = tl.GetItemListInTrack("video", tr)[ix - 1]
                if not it.GetFusionCompCount():
                    it.AddFusionComp()
                comp = it.GetFusionCompByIndex(1)
                a = comp.GetAttrs()
                dur = int(it.GetDuration())
                to_comp = comp_mapper(float(a["COMPN_RenderStart"]), float(a["COMPN_RenderEnd"]), dur)
                comp.Lock()
                comp.StartUndo("claude motion fx")
                # v2.9: nodes renamed to Vietnamese by finalize_project.py keep their original name in
                # Comments ("[claude:MFX_Xf]") — map them back so a revision Draft finds/replaces them.
                for t in list(comp.GetToolList(False).values()):
                    _m = re.search(r"\[claude:(MFX_\w+)\]", t.GetInput("Comments") or "")
                    if _m and t.GetAttrs("TOOLS_Name") != _m.group(1):
                        t.SetAttrs({"TOOLS_Name": _m.group(1)})
                if REPLACE:
                    for t in list(comp.GetToolList(False).values()):
                        if t.GetAttrs("TOOLS_Name").startswith("MFX_"):
                            t.Delete()
                mo = comp.FindTool("MediaOut1")
                src = mo.Input.GetConnectedOutput().GetTool()
                needed = {}
                plans = []
                for e in effs:
                    keys, static = fx_points(e, dur)
                    plans.append((e, keys, static))
                    for (kind, _inp) in list(keys) + list(static):
                        needed[kind] = True
                tools = {}
                for kind in needed:
                    if kind.startswith("OFX:"):
                        rid = kind[4:]
                        name = "MFX_OFX_" + rid.rsplit(".", 1)[-1]
                        t = comp.FindTool(name) or comp.AddTool(rid, -32768, -32768)
                        if t is None:
                            out["errors"].append("ResolveFX %s not available (AddTool returned None)" % rid)
                            continue
                    else:
                        reg, name = NODE[kind]
                        t = comp.FindTool(name) or comp.AddTool(reg, -32768, -32768)
                    t.SetAttrs({"TOOLS_Name": name})
                    tools[kind] = t
                prev = src
                for kind in ORDER + sorted(k for k in tools if k.startswith("OFX:")):
                    if kind in tools:
                        # ResolveFX nodes take their image on "Source"; Fusion tools on "Input"
                        tools[kind].ConnectInput("Source" if kind.startswith("OFX:") else "Input", prev)
                        prev = tools[kind]
                mo.ConnectInput("Input", prev)
                if "Spot" in tools:
                    if "SpotMask" not in tools:
                        reg, name = NODE["SpotMask"]
                        tools["SpotMask"] = comp.AddTool(reg, -32768, -32768)
                        tools["SpotMask"].SetAttrs({"TOOLS_Name": name})
                    tools["SpotMask"].SetInput("Invert", 1)
                    tools["Spot"].ConnectInput("EffectMask", tools["SpotMask"])
                if "DBlur" in tools:
                    tools["DBlur"].SetInput("Type", 0)          # linear
                    tools["DBlur"].SetInput("Angle", 0.0)
                for e, keys, static in plans:
                    rec = {"item": [tr, ix, it.GetName()], "fx": e["fx"]}
                    for (kind, inp), val in static.items():
                        t = tools.get(kind)
                        if t is None:
                            continue
                        if inp == "_params":
                            rec["params_set"] = {k: bool(t.SetInput(k, v)) for k, v in val.items()}
                            continue
                        if isinstance(val, (list, tuple)):
                            t.SetInput(inp, {1: float(val[0]), 2: float(val[1])})
                        else:
                            t.SetInput(inp, val)
                    for (kind, inp), pts in keys.items():
                        t = tools[kind]
                        if inp in ("Center@path", "Pivot@path"):
                            pin = inp.split("@")[0]
                            t.AddModifier(pin, "XYPath")
                            for f, (x, y), _ in pts:
                                t.SetInput(pin, {1: x, 2: y}, to_comp(f))
                        elif inp == "Center@x":
                            t.AddModifier("Center", "XYPath")
                            cy = 0.5
                            for f, x, _ in pts:
                                t.SetInput("Center", {1: x, 2: cy}, to_comp(f))
                        elif inp == "SourceTime@hold":
                            hold = to_comp(pts[0][0])
                            t.AddModifier("SourceTime", "BezierSpline")
                            spl = t.SourceTime.GetConnectedOutput().GetTool()
                            c0, c1 = float(a["COMPN_RenderStart"]), float(a["COMPN_RenderEnd"])
                            spl.SetKeyFrames({c0: {1: c0}, hold: {1: hold}, c1: {1: hold}}, True)
                        elif inp == "SourceTime@curve":
                            c0, c1 = float(a["COMPN_RenderStart"]), float(a["COMPN_RenderEnd"])
                            t.AddModifier("SourceTime", "BezierSpline")
                            spl = t.SourceTime.GetConnectedOutput().GetTool()
                            # dense linear keys (every 2 frames) make the curve smooth without handles
                            spl.SetKeyFrames({to_comp(f): {1: c0 + fr * (c1 - c0)} for f, fr, _ in pts}, True)
                        else:
                            cpts = [(to_comp(f), v, k) for f, v, k in pts]
                            t.AddModifier(inp, "BezierSpline")
                            for f, v, _ in cpts:
                                t.SetInput(inp, v, f)
                            getattr(t, inp).GetConnectedOutput().GetTool().SetKeyFrames(build_keyframes(cpts), True)
                    rec["keys"] = {"%s.%s" % k: len(v) for k, v in keys.items()}
                    out["applied"].append(rec)
                comp.EndUndo(True)
                comp.Unlock()
                # Resolve does not re-render a clip comp when only splines change (measured 21.1.1):
                # toggle pass-through on every MFX node so the cached frames are invalidated.
                for t in tools.values():
                    t.SetAttrs({"TOOLB_PassThrough": True})
                    t.SetAttrs({"TOOLB_PassThrough": False})
                out.setdefault("chains", {})["%d:%d" % (tr, ix)] = [x.GetAttrs("TOOLS_Name") for x in [src] + [tools[k] for k in ORDER if k in tools]] + ["MediaOut1"]
            out["status"] = "BUILT_WITH_ERRORS" if out["errors"] else "BUILT_READ_BACK"
            out["note"] = "Structure only: export stills at the effect frames and look."
    result = out
