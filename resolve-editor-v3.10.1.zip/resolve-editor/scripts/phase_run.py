# phase_run.py — one call per phase: runs the phase's staged tools in order, keeps the full results in a file and
# returns only a short summary (v3.1.0, token plan T2/T3). Tool: run_script_unsafe through boot.py:
#   run("phase_run.py", {"MODE": "p1", "TITLE": "TNCRoast", "ARGS": {...}}, "TNCRoast")["result"]
# Each mode stops before the MCP time limit (BUDGET_S) and resumes on the next identical call (state in
# WORK_DIR/<TITLE>/phase_run/<MODE>.state.json; RESET=True starts over). After every call STATUS.md in
# WORK_DIR/<TITLE>/ is rewritten: the file a new session reads to continue (one session per project).
#
# Modes (ARGS keys in brackets; everything else comes from project.json):
#   p1  intake: stage_check, prefs (lessons), inventory, music_intake [named_paths], frame_probe overview sheet
#   p6  build: edit_analysis [beats_s], DRY_RUN, build when the dry run is clean [build: true], stills at segment
#       middles -> one sheet. Blueprint = project.json "blueprint".
#   p7  sound/accents: motion_fx [effects], sfx place [cues], ending_plan, audio check render (peak, LUFS)
#   p8  colour: color_look plan, measure, balance [apply: true]
#   p9  QC: qa_audit [graphics_placed], QC sheet (cuts ±1, first/last), audio check render
#   p10 Final: duplicate the approved Draft [draft] to Final_<TITLE>_NN, compare a few frames, finalize plan
#       (apply stays a separate, approved call)
# A step's summary keeps only what the next decision needs; "look" lists the images worth opening (if any).

# ---- CONFIG ----------------------------------------------------------------
MODE = "p1"
TITLE = ""
ARGS = {}
TOOLS = "/Users/felix/Desktop/Final/Cache Edit/_tools"
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"
BUDGET_S = 8.0     # v3.1.3 (live run): the MCP reply times out after 10 s. A step that alone takes longer (build,
                   # audio, qc_sheet) still finishes inside Resolve, but its reply is lost: on "timed out" read
                   # STATUS.md (or repeat the same call — the state file shows the step done) instead of re-running it.
RESET = False
# ---------------------------------------------------------------------------

import json
import time

EST = {"stage": 2, "prefs": 1, "inventory": 4, "music_intake": 4, "overview": 15, "edit_analysis": 3, "dry_run": 3,
       "build": 12, "mid_stills": 10, "motion_fx": 6, "sfx": 8, "ending": 3, "audio": 20, "colour_plan": 2,
       "measure": 8, "balance": 8, "qa": 4, "qc_sheet": 14, "final_dup": 4, "compare": 10, "finalize_plan": 4}


def short(s, n=160):
    s = str(s)
    return s if len(s) <= n else s[:n - 1] + "…"


def input_sig(mode, args, project_data):
    """What the phase's results depend on. A changed signature (new blueprint, new cues…) restarts the phase;
    the flags that only extend a run (build, apply) are left out so 'p6 build:true' continues 'p6'."""
    a = {k: v for k, v in (args or {}).items() if k not in ("build", "apply")}
    dep = project_data.get("blueprint") if mode == "p6" else None
    return json.dumps([mode, a, dep], sort_keys=True, ensure_ascii=False, default=str)


def fresh_state(prev, sig, n_steps, reset=False):
    """v3.1.2: start over when asked, when the inputs changed, or when the previous run completed — a re-run after
    fixes (e.g. p9 on the next Draft) must measure again, not return the old summary."""
    if reset or not prev or prev.get("sig") != sig or prev.get("complete"):
        return {"sig": sig, "done": {}}
    return prev


def run_steps(steps, state, clock, budget):
    """steps: [(name, fn)] ; fn(state) -> summary dict. Runs the steps not yet in state["done"], in order, until the
    next step's estimate would cross the budget. -> (summaries, remaining names)."""
    t0 = clock()
    done = state.setdefault("done", {})
    for name, fn in steps:
        if name in done:
            continue
        if clock() - t0 + EST.get(name, 5) > budget and done:
            break
        try:
            done[name] = fn(state)
        except Exception as e:                       # a failing step is reported, not retried silently
            done[name] = {"error": short(e, 300)}
            break
    remaining = [n for n, _ in steps if n not in done]
    return done, remaining


# ---------- summarisers (pure: raw tool results -> what the next decision needs) ----------
def sum_inventory(r):
    kinds = {}
    for c in r.get("clips", []):
        kinds[c.get("kind")] = kinds.get(c.get("kind"), 0) + 1
    ps = r.get("project_settings") or {}
    return {"project": r.get("project"), "fps": ps.get("timelineFrameRate"),
            "size": [ps.get("timelineResolutionWidth"), ps.get("timelineResolutionHeight")], "kinds": kinds,
            "timelines": len(r.get("timelines") or []), "duplicate_groups": len(r.get("duplicates") or []),
            "warnings": [short(w) for w in r.get("warnings") or []], "dirs": r.get("source_dirs")}


def sum_build(r):
    rb = r.get("readback") or {}
    return {"status": r.get("status"), "timeline": r.get("timeline"), "frames": r.get("timeline_frames"),
            "target": r.get("target_frames"), "items": {k: len(v) for k, v in rb.items() if v},
            "problems": r.get("problems"), "errors": r.get("errors")}


def sum_presence(r):
    bad = [[short(i.get("item"), 30), i.get("verdict")] for i in r.get("items", []) if i.get("verdict") != "present"]
    return {"status": r.get("status"), "peak_dbfs": r.get("mix_peak_dbfs"), "lufs": r.get("integrated_lufs"),
            "clipping": r.get("clipping"), "not_clearly_present": bad, "cleaned": r.get("cleaned")}


def sum_sfx(r):
    return {"status": r.get("status"), "errors": r.get("errors"),
            "cues": [[short(c.get("file"), 28), c["plan"].get("volume"), (c.get("readback") or {}).get("off_by")]
                     for c in r.get("placed", [])]}


def sum_qa(r):
    return {"verdict": r.get("verdict"), "frames": r.get("frames"),
            "failed": {k: short(v.get("items") or v.get("note") or v, 120)
                       for k, v in (r.get("checks") or {}).items() if v.get("ok") is False}}


def status_md(title, mode, summary, remaining, project):
    """STATUS.md: what a new session needs to continue this project (decisions, last result, next step)."""
    keep = ("stops", "gates", "style", "story", "footage", "gate1", "music", "framing", "mix", "phase7", "phase8", "gate3", "phase10", "todo", "notes")
    lines = ["# STATUS — %s" % title, "",
             "Read this file and project.json to continue; do not reload earlier sessions.", "",
             "## Last phase run", "- mode: %s · remaining steps: %s" % (mode, remaining or "none")]
    for k, v in summary.items():
        lines.append("- %s: %s" % (k, short(json.dumps(v, ensure_ascii=False), 240)))
    lines += ["", "## Decisions in project.json"]
    for k in keep:
        if k in project:
            lines.append("- %s: %s" % (k, short(json.dumps(project[k], ensure_ascii=False), 240)))
    nxt = {"p1": "footage scan (subagent pass 1) -> Style choice -> Music request (wait for the user's file) -> Phase 2 music map -> Phase 3 deepen (references/phases/footage-subagent.md)",
           "p6": "rough-cut approval (Standard mode) or Phase 7", "p7": "Phase 8 (p8)", "p8": "Phase 9 (p9)",
           "p9": "Draft review",
           "p10": "Final approval (name + cleanup, no graphic question) -> finalize apply -> report -> switch question -> "
                  "SAME CHAT: Phase 11 with motion-studio (references/phases/phase-11.md): style gallery with pictures -> "
                  "graphic questions -> brief + package -> build agent, preview link sent at once"}.get(mode, "")
    lines += ["", "## Next", "- " + (("resume %s (same call)" % mode) if remaining else nxt)]
    return "\n".join(lines) + "\n"


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os
    g = {"resolve": resolve, "TOOLS": TOOLS, "__name__": "boot"}
    exec(open(os.path.join(os.path.expanduser(TOOLS), "boot.py"), encoding="utf-8").read(), g)
    RUN = g["run"]
    pdir = os.path.join(os.path.expanduser(WORK_DIR), TITLE, "phase_run")
    os.makedirs(pdir, exist_ok=True)
    sp = os.path.join(pdir, "%s.state.json" % MODE)
    prev = None if not os.path.exists(sp) else json.load(open(sp, encoding="utf-8"))
    full = {}

    def tool(name, ov=None, mode="run", data=None):
        r = RUN(name, ov or {}, TITLE, mode=mode, data=data)
        full[name + (":" + str((ov or {}).get("MODE")) if ov and ov.get("MODE") else "")] = r
        return r.get("result", r) if mode == "run" else r

    proj = tool("", None, mode="project_get").get("project") or {}
    A = ARGS or {}
    state = fresh_state(prev, input_sig(MODE, A, proj), 0, RESET)

    def wait_render(job, limit=25):
        t = time.time()
        while time.time() - t < limit:
            st = project.GetRenderJobStatus(job) or {}
            if st.get("JobStatus") in ("Complete", "Failed", "Cancelled"):
                return st.get("JobStatus")
            time.sleep(1.0)
        return "Timeout"

    def audio_step(s):
        tl = project.GetCurrentTimeline()
        fps = float(tl.GetSetting("timelineFrameRate") or 30)
        length = (tl.GetEndFrame() - tl.GetStartFrame()) / fps
        st = tool("audio_presence.py", {"MODE": "start", "START_S": 0.0, "LENGTH_S": round(length - 0.02, 3)})
        job = st.get("job_id")
        if not job:                                   # refused (not a Draft) or not queued: report, do not wait
            return {"status": short(st.get("status"), 120)}
        wait_render(job)
        return sum_presence(tool("audio_presence.py", {"MODE": "check", "JOB_ID": job, "START_S": 0.0,
                                                       "LENGTH_S": round(length - 0.02, 3)}))

    def mid_frames(bp):
        out, rec = [], 0
        for sg in bp.get("segments", []):
            out.append(rec + int(sg["dur"]) // 2)
            rec += int(sg["dur"])
        return out

    steps = []
    if MODE == "p1":
        steps = [
            ("stage", lambda s: {k: tool("", None, mode="stage_check").get(k) for k in ("status", "config_version", "obsolete")}),
            ("prefs", lambda s: (lambda p: {"lessons": len(p.get("lessons", [])), "recent": [short(x, 110) for x in p.get("lessons", [])[-4:]],
                                             "mode": (p.get("choices") or {}).get("workflow_mode")})(tool("", None, mode="prefs_get").get("prefs") or {})),
            ("inventory", lambda s: sum_inventory(tool("inventory.py"))),
            ("music_intake", lambda s: (lambda r: {"status": r.get("status"), "user_music": [x.get("path") for x in r.get("user_music", [])],
                                                   "has_question": bool(r.get("question"))})(
                tool("music_intake.py", {"TITLE": TITLE, "NAMED_PATHS": A.get("named_paths", [])}))),
            # JOB = TITLE -> sheets land in Cache Edit/<Title>/footage/ (the path footage-subagent.md uses); the summary
            # carries what the subagent prompt needs (per-source sheet, fps, frames) so full.json is never opened
            ("overview", lambda s: (lambda r: {"status": r.get("status"), "sheet": r.get("overview_sheet"),
                                               "sources": [{"clip": c.get("clip"), "fps": c.get("fps"), "frames": c.get("frames"),
                                                            "sheet": c.get("contact_sheet")} for c in r.get("clips", [])],
                                               "skipped_duplicates": len(r.get("skipped_duplicates") or []),
                                               "remaining": r.get("remaining")})(tool("frame_probe.py", {"JOB": TITLE}))),
        ]
    elif MODE == "p6":
        bp = proj.get("blueprint") or {}
        steps = [
            ("edit_analysis", lambda s: (lambda r: {"notes": r.get("notes"), "music": r.get("music")})(
                tool("edit_analysis.py", {"BLUEPRINT": bp, "BEATS_S": A.get("beats_s", [])}))),
            ("dry_run", lambda s: sum_build(tool("build_from_blueprint.py", {"BLUEPRINT": bp, "DRY_RUN": True}))),
        ]
        if A.get("build"):
            steps += [("build", lambda s: sum_build(tool("build_from_blueprint.py", {"BLUEPRINT": bp}))
                       if not (s["done"]["dry_run"].get("problems")) else {"skipped": "dry run has problems"}),
                      ("mid_stills", lambda s: {"sheet": tool("qc_stills.py", {"JOB": TITLE + "/rough", "FRAMES": mid_frames(bp)}).get("contact_sheet")})]
    elif MODE == "p7":
        steps = []
        if A.get("effects"):
            steps.append(("motion_fx", lambda s: (lambda r: {"status": r.get("status"), "errors": r.get("errors")})(
                tool("motion_fx.py", {"EFFECTS": A["effects"], "REPLACE": True}))))
        if A.get("cues"):
            steps.append(("sfx", lambda s: sum_sfx(tool("sfx_library.py", {"MODE": "place", "CUES": A["cues"]}))))
        steps += [("ending", lambda s: {"current_end": (tool("ending_plan.py").get("plan") or {}).get("current_end")}),
                  ("audio", audio_step)]
    elif MODE == "p8":
        steps = [("colour_plan", lambda s: {"gammas": sorted({r_["gamma"] for r_ in tool("color_look.py", {"MODE": "plan"}).get("items", [])})}),
                 ("measure", lambda s: (lambda r: {"sequence_median": r.get("sequence_median"),
                                                   "slopes": [[i["index"], i["slope"]] for i in r.get("items", [])]})(
                     tool("color_look.py", {"MODE": "measure"})))]
        if A.get("apply"):
            steps.append(("balance", lambda s: {"status": tool("color_look.py", {"MODE": "balance"}).get("status")}))
    elif MODE == "p9":
        steps = [("qa", lambda s: sum_qa(tool("qa_audit.py", {"GRAPHICS_PLACED": bool(A.get("graphics_placed"))}))),
                 ("qc_sheet", lambda s: {"sheet": tool("qc_stills.py", {"JOB": TITLE + "/qc", "FRAMES": "auto"}).get("contact_sheet")}),
                 ("audio", audio_step)]
    elif MODE == "p10":
        def dup(s):
            tls = {project.GetTimelineByIndex(i + 1).GetName(): project.GetTimelineByIndex(i + 1)
                   for i in range(project.GetTimelineCount())}
            src = tls.get(A.get("draft") or "")
            nums = [int(n.rsplit("_", 1)[1]) for n in tls if n.startswith("Final_%s_" % TITLE) and n.rsplit("_", 1)[1].isdigit()]
            name = "Final_%s_%02d" % (TITLE, (max(nums) + 1) if nums else 1)
            if src is None:
                return {"error": "ARGS.draft not found"}
            project.SetCurrentTimeline(src)
            resolve.OpenPage("edit")
            fin = src.DuplicateTimeline(name)
            s["final"] = name if fin else None
            s["draft"] = src.GetName()
            return {"final": s["final"]}
        steps = [("final_dup", dup),
                 ("compare", lambda s: {"skipped": "no Final"} if not s.get("final") else (lambda r: {"status": short(r.get("status"), 40), "frames": r.get("frames")})(
                     tool("timeline_ops.py", {"MODE": "compare", "A": s["draft"], "B": s["final"],
                                              "FRAMES": A.get("frames", [30, 150, 300])}))),
                 ("finalize_plan", lambda s: (lambda r: {"status": r.get("status"), "keep": r["timelines"]["keep"],
                                                         "delete": r["timelines"]["delete"], "untouched": r["timelines"]["untouched"],
                                                         "backup": r.get("backup"), "plan_token": r.get("plan_token")})(
                     tool("finalize_project.py", {"MODE": "plan", "TITLE": TITLE, "FINAL": s["final"]})))]
    else:
        result = {"status": "UNKNOWN_MODE %s" % MODE}

    if steps:
        done, remaining = run_steps(steps, state, time.time, BUDGET_S)
        state["complete"] = not remaining
        json.dump(state, open(sp, "w", encoding="utf-8"), ensure_ascii=False)
        with open(os.path.join(pdir, "%s.full.json" % MODE), "w", encoding="utf-8") as fh:
            json.dump(full, fh, ensure_ascii=False, default=str)
        summary = {k: v for k, v in done.items()}
        look = [v.get("sheet") for v in done.values() if isinstance(v, dict) and v.get("sheet")]
        proj = tool("", None, mode="project_get").get("project") or proj
        with open(os.path.join(os.path.expanduser(WORK_DIR), TITLE, "STATUS.md"), "w", encoding="utf-8") as fh:
            fh.write(status_md(TITLE, MODE, summary, remaining, proj))
        result = {"mode": MODE, "status": "PARTIAL: call again" if remaining else "DONE", "remaining": remaining,
                  "summary": summary, "look": look, "full_results": os.path.join(pdir, "%s.full.json" % MODE)}
