# loader.py — run a staged helper script with the shared config, and keep per-project wishes.
# Tool: run_script_unsafe (reads files; the run_script sandbox refuses `import os`).
#
# Setup once per session: copy scripts/*.py and config/defaults.json (flat or as config/defaults.json) to TOOLS_DIR
# (v2.9: /Users/felix/Desktop/Final/Cache Edit/_tools/) under fresh names if they changed, check md5 (a re-staged file with the
# same name was served stale once).
#
# MODE "run":         exec TOOL with CONFIG values injected just before its Resolve block, in this order
#                     (later wins): script defaults < defaults.json "scripts"[TOOL] < project.json
#                     "scripts"[TOOL] < OVERRIDES. Returns the tool's `result` plus what was injected.
# MODE "project_get": read WORK_ROOT/<PROJECT>/project.json (creates nothing). v2.9: WORK_ROOT = Cache Edit
#                     (temp, deleted by the user after the Final); QC_ROOT keeps only data for later videos.
# MODE "project_set": merge PROJECT_DATA into project.json (deep merge; lists replaced) and save.
# MODE "config":      return the resolved defaults.json (+ project overrides) for inspection.
# MODE "stage_check": md5 of every file in TOOLS_DIR (compare with the skill copy before running).
# v2.8.0 user preferences across videos (~/Movies/ClaudeQC/_prefs.json), so the next video starts from what the
#   user chose and corrected last time (fewer revisions):
# MODE "prefs_get":   read the preferences (creates nothing).
# MODE "prefs_set":   PROJECT_DATA = {"choices": {...}, "config": {...}, "lessons": ["..."]}: choices/config are
#                     deep-merged, lessons appended without duplicates (newest last, at most 60 kept).
# Config order (later wins): defaults.json < _prefs.json "config" < project.json < OVERRIDES.

# ---- CONFIG ----------------------------------------------------------------
MODE = "run"
TOOL = "inventory.py"             # file name inside TOOLS_DIR
PROJECT = ""                      # <Title> (e.g. "HongKong"); "" = no project overrides
OVERRIDES = {}                    # {"MODE": "pick", "QUERY": {...}} — UPPERCASE names only
PROJECT_DATA = {}                 # for MODE "project_set"
TOOLS_DIR = "/Users/felix/Desktop/Final/Cache Edit/_tools"
CONFIG_FILE = "defaults.json"     # inside TOOLS_DIR
QC_ROOT = "~/Movies/ClaudeQC"     # persistent: _prefs.json, _styles, catalogues
WORK_ROOT = "/Users/felix/Desktop/Final/Cache Edit"   # v2.9: per-video temp (project.json, stills, probes)
PREFS_FILE = "_prefs.json"        # inside QC_ROOT (v2.8.0)
# ---------------------------------------------------------------------------

import json
import re

MARKER = "\ntry:\n    resolve"
_REF = re.compile(r"\$\{([A-Za-z0-9_.]+)\}")


def lookup(cfg, dotted):
    cur = cfg
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            raise KeyError(dotted)
        cur = cur[part]
    return cur


def resolve_refs(value, cfg, depth=0):
    """Replace ${a.b} references. A string that is exactly one reference keeps the referenced type."""
    if depth > 8:
        raise ValueError("reference loop")
    if isinstance(value, dict):
        # keys starting with "_" are comments: left as written
        return {k: (v if k.startswith("_") else resolve_refs(v, cfg, depth)) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_refs(v, cfg, depth) for v in value]
    if isinstance(value, str):
        m = _REF.fullmatch(value)
        if m:
            return resolve_refs(lookup(cfg, m.group(1)), cfg, depth + 1)
        return _REF.sub(lambda mm: str(resolve_refs(lookup(cfg, mm.group(1)), cfg, depth + 1)), value)
    return value


def deep_merge(base, extra):
    """Dicts merge recursively; anything else (lists included) is replaced."""
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def merge_prefs(prefs, data, keep=60):
    """v2.8.0: choices/config deep-merged; lessons appended (no duplicates, newest last, last `keep`)."""
    out = dict(prefs or {})
    data = data or {}
    for k in ("choices", "config"):
        if k in data:
            out[k] = deep_merge(out.get(k) or {}, data[k] or {})
    lessons = list(out.get("lessons") or [])
    for l in data.get("lessons") or []:
        if l in lessons:
            lessons.remove(l)
        lessons.append(l)
    if lessons:
        out["lessons"] = lessons[-keep:]
    for k, v in data.items():
        if k not in ("choices", "config", "lessons"):
            out[k] = v
    return out


def effective_config(defaults, project_cfg=None):
    return resolve_refs(deep_merge(defaults, project_cfg or {}), deep_merge(defaults, project_cfg or {}))


def overrides_for(tool, cfg, extra=None):
    """UPPERCASE assignments for one tool: config 'scripts'[tool] then extra (later wins)."""
    vals = dict((cfg.get("scripts") or {}).get(tool) or {})
    vals.update(extra or {})
    bad = [k for k in vals if not re.fullmatch(r"[A-Z][A-Z0-9_]*", k)]
    if bad:
        raise ValueError("override names must be UPPERCASE identifiers: %s" % bad)
    return vals


def to_source(vals):
    # repr() of JSON-like values is valid Python and keeps Vietnamese text intact
    return "".join("%s = %r\n" % (k, v) for k, v in sorted(vals.items()))


def inject(src, assignments):
    """Insert the assignments before the script's first top-level def/class (v2.6.1), so default
    arguments such as `def choose_lut(..., looks=LOOKS)` see the overrides too. Injecting just before
    the Resolve block (v2.2–v2.6.0) left those defaults bound to the in-file values (found live 2026-10-25,
    color_look.py ignored an overridden LOOKS)."""
    if MARKER not in src:
        raise ValueError("script has no Resolve block marker (try: resolve)")
    m = re.search(r"(?m)^(def |class )", src)
    at = m.start() if m and m.start() < src.index(MARKER) else src.index(MARKER) + 1
    return src[:at] + assignments + "\n" + src[at:]


def project_path(root, title):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", title or ""):
        raise ValueError("project title must be short, no spaces or diacritics: %r" % title)
    return "%s/%s/project.json" % (root.rstrip("/"), title)


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, hashlib
    tools = os.path.expanduser(TOOLS_DIR)
    root = os.path.expanduser(QC_ROOT)
    work = os.path.expanduser(WORK_ROOT)
    out = {"mode": MODE}

    def _read_json(p, default):
        if not os.path.exists(p):
            return default
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)

    # v3.0: the skill keeps the file in config/; staging may copy it flat or with its folder — accept both.
    cfg_path = next((p for p in (os.path.join(tools, CONFIG_FILE), os.path.join(tools, "config", CONFIG_FILE))
                     if os.path.exists(p)), None)
    defaults = _read_json(cfg_path, {}) if cfg_path else {}
    out["config_file"] = cfg_path
    if not defaults:
        out["warning"] = "NO_CONFIG: no %s in %s or %s/config: scripts run with their in-file defaults" % (CONFIG_FILE, tools, tools)
    ppath = project_path(work, PROJECT) if PROJECT else None
    pcfg = _read_json(ppath, {}) if ppath else {}
    prefs_path = os.path.join(root, PREFS_FILE)
    prefs = _read_json(prefs_path, {})
    if prefs.get("config"):
        defaults = deep_merge(defaults, prefs["config"])

    if MODE == "project_get":
        out.update({"status": "OK" if pcfg else "NO_PROJECT_FILE", "path": ppath, "project": pcfg})
    elif MODE == "project_set":
        merged = deep_merge(pcfg, PROJECT_DATA)
        os.makedirs(os.path.dirname(ppath), exist_ok=True)
        tmp = ppath + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(merged, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, ppath)
        out.update({"status": "SAVED", "path": ppath, "project": merged})
    elif MODE == "prefs_get":
        out.update({"status": "OK" if prefs else "NO_PREFS_FILE", "path": prefs_path, "prefs": prefs})
    elif MODE == "prefs_set":
        merged = merge_prefs(prefs, PROJECT_DATA)
        os.makedirs(root, exist_ok=True)
        tmp = prefs_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(merged, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, prefs_path)
        out.update({"status": "SAVED", "path": prefs_path, "prefs": merged})
    elif MODE == "config":
        out.update({"status": "OK", "config": effective_config(defaults, pcfg)})
    elif MODE == "stage_check":
        out["md5"] = {}
        for n in sorted(os.listdir(tools)):
            p = os.path.join(tools, n)
            if os.path.isfile(p):
                with open(p, "rb") as fh:
                    out["md5"][n] = hashlib.md5(fh.read()).hexdigest()
        out["config_version"] = defaults.get("version")
        # v3.0: tools removed from the skill but still staged would run stale code if called by an old note
        out["obsolete"] = [n for n in defaults.get("removed_tools", []) if n in out["md5"]]
        out["status"] = "OK" if defaults and not out["obsolete"] else ("NO_CONFIG" if not defaults else "OBSOLETE_FILES_STAGED")
    else:
        cfg = effective_config(defaults, pcfg)
        vals = overrides_for(TOOL, cfg, OVERRIDES)
        p = os.path.join(tools, TOOL)
        with open(p, encoding="utf-8") as fh:
            src = inject(fh.read(), to_source(vals))
        g = {"resolve": resolve, "project": project, "__name__": "tool"}
        exec(compile(src, p, "exec"), g)
        out.update({"status": "RAN", "tool": TOOL, "injected": sorted(vals), "project_file": ppath,
                    "result": g.get("result")})
    result = out
