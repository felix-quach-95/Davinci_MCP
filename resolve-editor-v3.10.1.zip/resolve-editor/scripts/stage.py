# stage.py — copy this skill's scripts and config into the Resolve tools folder in one command (v3.0.2).
# Run locally, once per session:   python3 -I <skill>/scripts/stage.py        (optional: a tools dir as argument)
# Copies scripts/*.py and config/ (defaults.json, styles) to paths.tools, moves tools listed in
# defaults.json "removed_tools" into _tools/_obsolete/, verifies every copy by md5 and prints one JSON line.
# Replaces the hand-made copy + loader MODE stage_check round trip (2–3 calls per session).
import hashlib, json, os, shutil, sys

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def md5(p):
    with open(p, "rb") as fh:
        return hashlib.md5(fh.read()).hexdigest()


def stage(tools=None):
    cfg = json.load(open(os.path.join(SKILL, "config", "defaults.json"), encoding="utf-8"))
    tools = os.path.expanduser(tools or cfg["paths"]["tools"])
    os.makedirs(os.path.join(tools, "config", "styles"), exist_ok=True)
    copied, bad, moved = 0, [], []
    for name in sorted(os.listdir(os.path.join(SKILL, "scripts"))):
        if name.endswith(".py"):
            src, dst = os.path.join(SKILL, "scripts", name), os.path.join(tools, name)
            shutil.copyfile(src, dst)
            copied += 1
            if md5(src) != md5(dst):
                bad.append(name)
    shutil.copyfile(os.path.join(SKILL, "config", "defaults.json"), os.path.join(tools, "config", "defaults.json"))
    for name in os.listdir(os.path.join(SKILL, "config", "styles")):
        shutil.copyfile(os.path.join(SKILL, "config", "styles", name), os.path.join(tools, "config", "styles", name))
    for name in cfg.get("removed_tools", []):
        p = os.path.join(tools, name)
        if os.path.exists(p):
            os.makedirs(os.path.join(tools, "_obsolete"), exist_ok=True)
            shutil.move(p, os.path.join(tools, "_obsolete", name))
            moved.append(name)
    return {"status": "OK" if not bad else "MD5_MISMATCH", "tools": tools, "version": cfg.get("version"),
            "scripts": copied, "md5_mismatch": bad, "moved_obsolete": moved}


if __name__ == "__main__":
    print(json.dumps(stage(sys.argv[1] if len(sys.argv) > 1 else None), ensure_ascii=False))
