# ending_plan.py — find where a video can end musically and visually (read-only).
# Tool: run_script_unsafe (decodes the music with macOS afconvert).
# Reads the current DRAFT_ timeline: the music item (longest item on MUSIC_TRACK), its source offset,
# the last video shot and its unused source tail. Decodes the music file, finds phrase hits (sudden
# rises) and quiet points (the decay just before the next hit), maps them to timeline frames and reports:
#   - what the current end lands on ("new phrase just hit" = sounds cut off; "quiet" = natural),
#   - candidate ends: SHORT (last quiet point at/before the current end), HIT_CUT (a hit near the end, good
#     as the cut into a closing shot or closing text), RING_OUT (the quiet point after that hit),
#   - how many source frames the last shot has left (for extending it).
# Then present the ending options in references/endings.md to the user (they want to choose each time).
# v2.6.2: phrase hits = this script's own detection MERGED with music_library.py's catalogue hits (the
# coarse detector missed the 28.0 s hit of summer-fun on BoConCN); candidates only inside LOOK_AROUND_S
# (it once offered "SHORT at frame 3"); a hit followed by the music item's fade-out counts as a natural end.

MUSIC_TRACK = "auto"     # audio track with the music bed: "auto" (track named MUSIC, else the audio-file
                         # track covering most of the runtime — A1 dialogue is skipped) or an index (A2 by layout)
LOOK_AROUND_S = 6.0      # search window around the current end (seconds)
ENV_STEP_S = 0.25        # envelope resolution (finding phrase hits)
FINE_STEP_S = 0.02       # resolution used to place each hit exactly
MUSIC_CATALOG = "~/Movies/ClaudeQC/_music/catalog.json"   # music_library.py cache ("hits_s" per file); "" = off
MIN_FADE_S = 0.5         # a music fade-out at least this long, after a hit, ends the piece naturally

import math


def envelope_db(samples, rate, step_s=0.25):
    n = max(int(rate * step_s), 1)
    out = []
    for i in range(0, len(samples) - n + 1, n):
        w = samples[i:i + n]
        out.append(round(20 * math.log10(max(math.sqrt(sum(x * x for x in w) / n), 1.0) / 32768.0), 1))
    return out


def detect_hits(env, rise_db=8.0, lookback=3, floor_db=-60.0):
    """Indexes where the level jumps by rise_db over the minimum of the previous `lookback` steps."""
    hits = []
    for i in range(lookback, len(env)):
        prev = min(env[i - lookback:i])
        if env[i] > floor_db and env[i] - prev >= rise_db and (not hits or i - hits[-1] > lookback):
            hits.append(i)
    return hits


def quiet_before(env, hit, max_back=8):
    """Index of the quietest step in the `max_back` steps before a hit (the natural end of a phrase)."""
    lo = max(hit - max_back, 0)
    seg = env[lo:hit]
    if not seg:
        return hit
    return lo + seg.index(min(seg))


def refine_hit(fine_env, fine_step, t, window=0.35, rise_db=8.0, look=5):
    """Exact onset of a coarse hit at t (s) from a fine envelope (20 ms steps): the first step in
    [t - window, t + window] that rises rise_db over the minimum of the previous `look` steps.
    The coarse grid only says the hit is somewhere in its 0.25 s step (measured 2026-10-25: coarse
    21.25 s, real onset 21.48 s). Returns t unchanged when no such rise is found."""
    i0 = max(int((t - window) / fine_step), look)
    i1 = min(int((t + window) / fine_step), len(fine_env) - 1)
    for i in range(i0, i1 + 1):
        if fine_env[i] - min(fine_env[i - look:i]) >= rise_db:
            return round(i * fine_step, 3)
    return t


def merge_hits(own_t, extra_t, tol=0.3):
    """Union of two hit lists (seconds); an extra hit within tol of an own hit is the same hit.
    -> sorted [(t, source)] with source "detected" / "catalog"."""
    out = [(t, "detected") for t in own_t]
    for t in extra_t or []:
        if all(abs(t - o) > tol for o in own_t):
            out.append((float(t), "catalog"))
    return sorted(out)


def plan_end(env, step_s, music_t_at_end, src_t_to_frame, look=6.0, fine=None, fine_step=0.02,
             extra_hits=None, fade_out_s=0.0):
    """env over the music file; music_t_at_end = music time (s) at the current timeline end;
    src_t_to_frame(t) -> timeline frame. fine: optional 20 ms envelope to place hits exactly.
    extra_hits: hit times (s) measured elsewhere (music_library catalogue). fade_out_s: length of the
    music item's fade-out at the timeline end. Returns a dict of findings and candidates; every
    candidate lies within `look` seconds of the current end."""
    own = [h * step_s for h in detect_hits(env)]
    if fine:
        own = [refine_hit(fine, fine_step, t) for t in own]
    merged = merge_hits(own, extra_hits)
    hit_t = [t for t, _ in merged]
    idx = lambda t: min(max(int(t / step_s), 0), max(len(env) - 1, 0))
    quiet_t = [quiet_before(env, idx(t)) * step_s + step_s / 2.0 for t in hit_t]   # middle of the quietest step
    near_end = lambda t: abs(t - music_t_at_end) <= look
    res = {"hits_s": [round(t, 2) for t in hit_t if near_end(t)],
           "hit_sources": {"%.2f" % t: s for t, s in merged if near_end(t)},
           "end_music_s": round(music_t_at_end, 2)}
    since = [music_t_at_end - t for t in hit_t if t <= music_t_at_end]
    upcoming = [t - music_t_at_end for t in hit_t if t > music_t_at_end]
    if upcoming and upcoming[0] < 0.1:
        res["warning"] = "the music ends within 0.1 s of the next phrase hit: end in the middle of the quiet step instead"
    last_since = min(since) if since else None
    faded = fade_out_s >= MIN_FADE_S
    if not res["hits_s"]:
        res["current_end"] = ("NO_HITS_NEAR_END: no phrase hit within %.0f s; %s" %
                              (look, "the fade-out carries the end" if faded else "listen to decide"))
    elif faded and last_since is not None and last_since <= fade_out_s + 2.0:
        res["current_end"] = ("hit %.2fs before the end, then a %.1fs fade-out: natural (hit + fade)"
                              % (last_since, fade_out_s))
    elif last_since is not None and last_since < 0.9:
        res["current_end"] = "cut %.2fs after a new phrase hit: sounds cut off" % last_since
    else:
        q = [t for t in quiet_t if abs(t - music_t_at_end) < 0.4]
        res["current_end"] = "in a quiet decay: natural" if q else "mid-phrase: may sound unfinished"
    short = [t for t in quiet_t if t <= music_t_at_end + 0.05 and near_end(t)]
    if short:
        res["SHORT"] = {"music_s": round(short[-1], 2), "frame": src_t_to_frame(short[-1])}
    near = [t for t in hit_t if abs(t - music_t_at_end) <= 1.5]
    if near:
        h = min(near, key=lambda t: abs(t - music_t_at_end))
        res["HIT_CUT"] = {"music_s": round(h, 2), "frame": src_t_to_frame(h)}
        after = [q for q in quiet_t if q > h + 0.5 and near_end(q)]
        if after:
            res["RING_OUT"] = {"music_s": round(after[0], 2), "frame": src_t_to_frame(after[0]),
                               "extra_s": round(after[0] - music_t_at_end, 2)}
    return res


def pick_music_track(info):
    """info: {track_index: {"name": track name, "cover": frames covered, "video_src": items come from
    video files}}. Prefer a track named MUSIC/NHAC; else the audio-file track covering most of the
    runtime (A1 dialogue from the footage is skipped); else the most covered track."""
    if not info:
        return None
    for i in sorted(info):
        nm = (info[i].get("name") or "").lower()
        if "music" in nm or "nhạc" in nm or "nhac" in nm:
            return i
    files = {i: v for i, v in info.items() if not v.get("video_src") and v.get("cover")}
    pool = files or {i: v for i, v in info.items() if v.get("cover")}
    if not pool:
        return None
    return max(sorted(pool), key=lambda i: pool[i]["cover"])


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, subprocess, tempfile, wave, struct
    tl = project.GetCurrentTimeline()
    out = {}
    if tl is None or not tl.GetName().lower().startswith(("draft_", "final_", "probe_", "test_")):
        out["status"] = "REFUSED: open a Draft_/Final_ timeline"
    else:
        s0 = tl.GetStartFrame()
        fps = float(tl.GetSetting("timelineFrameRate") or 24)
        end = tl.GetEndFrame() - s0

        def _track_info(tl):
            info = {}
            for i in range(1, (tl.GetTrackCount("audio") or 0) + 1):
                items = tl.GetItemListInTrack("audio", i) or []
                vid = False
                for it in items:
                    mpi = it.GetMediaPoolItem()
                    res = str((mpi.GetClipProperty("Resolution") if mpi else "") or "")
                    if "x" in res.lower():
                        vid = True
                info[i] = {"name": tl.GetTrackName("audio", i) if hasattr(tl, "GetTrackName") else "",
                           "cover": sum(int(it.GetDuration()) for it in items), "video_src": vid}
            return info
        mtrack = pick_music_track(_track_info(tl)) if MUSIC_TRACK == "auto" else int(MUSIC_TRACK)
        out["music_track"] = mtrack
        items = (tl.GetItemListInTrack("audio", mtrack) or []) if mtrack else []
        mus = max(items, key=lambda i: i.GetDuration()) if items else None
        v1 = tl.GetItemListInTrack("video", 1) or []
        last = v1[-1] if v1 else None
        if last is not None:
            mpi = last.GetMediaPoolItem()
            total = int(mpi.GetClipProperty("Frames") or 0) if mpi else 0
            out["last_shot"] = {"name": last.GetName(), "start": last.GetStart() - s0, "end": last.GetEnd() - s0,
                                "src_end": last.GetSourceEndFrame(), "src_total": total,
                                "src_frames_left": max(total - int(last.GetSourceEndFrame() or 0), 0),
                                "speed": (last.GetSpeed() or {}).get("Percentage")}
        if mus is None:
            out["status"] = "NO_MUSIC_ON_TRACK"
        else:
            path = mus.GetMediaPoolItem().GetClipProperty("File Path")
            tmp = os.path.join(tempfile.mkdtemp(), "m.wav")
            subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@4000", "-c", "1", path, tmp], capture_output=True)
            with wave.open(tmp) as wf:
                data = wf.readframes(wf.getnframes())
            os.remove(tmp)
            smp = struct.unpack("<%dh" % (len(data) // 2), data)
            env = envelope_db(smp, 4000, ENV_STEP_S)
            fine = envelope_db(smp, 4000, FINE_STEP_S)
            off = mus.GetLeftOffset()                     # source frames (timeline rate) before the item start
            mstart = mus.GetStart() - s0
            mend = mus.GetEnd() - s0
            t_end = (off + (min(end, mend) - mstart)) / fps
            to_frame = lambda t: int(round(t * fps - off + mstart))
            extra = []
            cat_p = os.path.expanduser(MUSIC_CATALOG) if MUSIC_CATALOG else ""
            if cat_p and os.path.exists(cat_p):
                import json
                base = path.rsplit("/", 1)[-1]
                try:
                    cat = json.load(open(cat_p, encoding="utf-8"))
                    row = next((v for k, v in cat.items() if isinstance(v, dict) and k.rsplit("/", 1)[-1] == base), None)
                    extra = list((row or {}).get("hits_s") or [])
                except Exception as ex:
                    out["catalog_error"] = str(ex)[:80]
            fade_s = 0.0
            if mend >= end - 1:                           # the fade only matters when the music runs to the end
                fade_s = float(((mus.GetFades() if hasattr(mus, "GetFades") else None) or {}).get("FadeOut") or 0) / fps   # GetProperties has no FadeOut
            out.update({"timeline_end": end, "music_item": [mstart, mend, off, path.rsplit("/", 1)[-1]],
                        "catalog_hits": len(extra), "music_fade_out_s": round(fade_s, 2),
                        "plan": plan_end(env, ENV_STEP_S, t_end, to_frame, LOOK_AROUND_S, fine, FINE_STEP_S,
                                         extra, fade_s),
                        "status": "OK"})
    result = out
