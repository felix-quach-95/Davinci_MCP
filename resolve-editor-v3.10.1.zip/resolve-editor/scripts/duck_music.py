# duck_music.py — lower the music bed under speech, with crossfades (v2.2.0, UNTESTED live).
# Tool: run_script (sandbox is enough). Writes only Draft_/Probe_/Test_ timelines.
# The API has no volume keyframes or sidechain, so the music item is rebuilt as consecutive segments
# of the same file (source continuous) that alternate between MUSIC_TRACK and DUCK_TRACK. Neighbours
# overlap by FADE frames with a fade-out/fade-in pair, so every level change is a short crossfade of
# the same audio (no dip, no jump). Segments under speech get DUCK_DB, the rest NORMAL_DB.
# MODE "plan": compute and return the segments (writes nothing). MODE "apply": rebuild + read back.
# Speech comes from (first available): RANGES (timeline-relative [a, b] frames, e.g. transcript_cut.py
# "speech_ranges"), the Resolve subtitle track 1, or the items on SPEECH_TRACK.
# v2.3 envelope (appariciojunior/video-editor-skills, measured on real vlogs): the music falls over ~1.0 s
# into speech and rises over ~1.2 s after it, the rise starting in the speaker's tail room so the music
# flows into the B-roll. Audio-only appends count source frames at the FILE's own fps (a WAV can report
# 23.976 in a 24/25 fps timeline), so source frames are converted with the clip FPS.
# Afterwards: listen. Report "levels set, not auditioned" unless the user listened.

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
MUSIC_TRACK = 2
DUCK_TRACK = 5
SPEECH_TRACK = 1
RANGES = []                 # [[a, b], ...] timeline-relative frames; [] = subtitles or SPEECH_TRACK
NORMAL_DB = -9.0
DUCK_DB = -20.0
PAD_BEFORE = 6              # frames the duck starts before speech
PAD_AFTER = 4               # frames it holds after speech before the rise starts
MERGE_GAP = 24              # speech gaps shorter than this stay ducked (no pumping)
FADE = 8                    # minimum segment length unit (frames)
FADE_DOWN_S = 1.0           # seconds: music falls into speech (crossfade length at normal -> duck)
FADE_UP_S = 1.2             # seconds: music rises after speech (duck -> normal)
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
# ---------------------------------------------------------------------------


def speech_intervals(ranges, pad_before=PAD_BEFORE, pad_after=PAD_AFTER, merge_gap=MERGE_GAP, lo=0, hi=None):
    """Pad, clip to [lo, hi] and merge speech ranges that are closer than merge_gap."""
    out = []
    for a, b in sorted((int(a), int(b)) for a, b in ranges if b > a):
        a, b = a - pad_before, b + pad_after
        a = max(a, lo)
        if hi is not None:
            b = min(b, hi)
        if b <= a:
            continue
        if out and a - out[-1][1] < merge_gap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def duck_plan(music_a, music_b, speech, min_len=FADE * 2):
    """Split [music_a, music_b) into ("duck"|"normal") segments. Segments shorter than min_len are
    absorbed into their neighbour so every crossfade fits."""
    segs, cur = [], music_a
    for a, b in speech:
        a, b = max(a, music_a), min(b, music_b)
        if b <= a:
            continue
        if a > cur:
            segs.append([cur, a, "normal"])
        segs.append([max(a, cur), b, "duck"])
        cur = max(cur, b)
    if cur < music_b:
        segs.append([cur, music_b, "normal"])
    def coalesce(lst):
        res = []
        for s in lst:
            if res and res[-1][2] == s[2]:
                res[-1][1] = s[1]
            else:
                res.append(list(s))
        return res
    merged = coalesce(segs)
    while len(merged) > 1:
        short = [i for i, s in enumerate(merged) if s[1] - s[0] < min_len]
        if not short:
            break
        i = short[0]
        if i > 0:
            merged[i - 1][1] = merged[i][1]      # absorb into the previous segment
        else:
            merged[1][0] = merged[0][0]          # first one: absorb into the next
        del merged[i]
        merged = coalesce(merged)
    return [tuple(s) for s in merged]


def layout(segments, src0, rec0, fade, main_track, alt_track, normal_db, duck_db, fade_in=0, fade_out=0,
           fade_up=None, src_ratio=1.0):
    """Timeline items for the segments: alternating tracks, each (but the last) extended into the next one
    and crossfaded. `fade` = frames of a fall into a duck, `fade_up` = frames of a rise out of it (default
    = fade). src0/rec0 = source and timeline frame of the music start; src_ratio = file fps / timeline fps
    (source frames of an audio-only append count at the file's own rate)."""
    fade_up = fade if fade_up is None else fade_up
    items = []
    n = len(segments)

    def join(i):                     # crossfade length between segment i and i + 1
        return fade if segments[i + 1][2] == "duck" else fade_up
    for i, (a, b, kind) in enumerate(segments):
        end = b + (join(i) if i < n - 1 else 0)
        fi = fade_in if i == 0 else join(i - 1)
        fo = fade_out if i == n - 1 else join(i)
        items.append({"track": main_track if i % 2 == 0 else alt_track, "rec": a, "end": end,
                      "src_in": int(round((src0 + (a - rec0)) * src_ratio)),
                      "src_out": int(round((src0 + (end - rec0)) * src_ratio)),
                      "volume": duck_db if kind == "duck" else normal_db, "kind": kind,
                      "fades": {"FadeIn": fi, "FadeOut": fo}})
    return items


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    out = {"mode": MODE}
    if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_"
    else:
        s0 = tl.GetStartFrame()
        end = tl.GetEndFrame() - s0
        mitems = tl.GetItemListInTrack("audio", MUSIC_TRACK) or []
        if not mitems:
            out["status"] = "NO_MUSIC_ON_A%d" % MUSIC_TRACK
        elif len(mitems) > 1 or (tl.GetItemListInTrack("audio", DUCK_TRACK) or []):
            out["status"] = "REFUSED: music already split (A%d has %d items, A%d not empty) — duck a fresh Draft" % (
                MUSIC_TRACK, len(mitems), DUCK_TRACK)
        else:
            mus = mitems[0]
            ma, mb = mus.GetStart() - s0, mus.GetEnd() - s0
            if RANGES:
                ranges, source = RANGES, "RANGES"
            else:
                subs = tl.GetItemListInTrack("subtitle", 1) or [] if (tl.GetTrackCount("subtitle") or 0) else []
                if subs:
                    ranges, source = [[i.GetStart() - s0, i.GetEnd() - s0] for i in subs], "subtitle track 1"
                else:
                    ranges = [[i.GetStart() - s0, i.GetEnd() - s0] for i in tl.GetItemListInTrack("audio", SPEECH_TRACK) or []]
                    source = "A%d items" % SPEECH_TRACK
            fps = float(tl.GetSetting("timelineFrameRate") or 24)
            fdown, fup = int(round(FADE_DOWN_S * fps)), int(round(FADE_UP_S * fps))
            # the fall must be finished when speech starts: the duck segment begins fdown frames earlier
            sp = speech_intervals(ranges, PAD_BEFORE + fdown, PAD_AFTER, MERGE_GAP, lo=ma, hi=mb)
            segs = duck_plan(ma, mb, sp, max(2 * max(fdown, fup), FADE * 2))
            fades = mus.GetFades() or {}
            src0 = int(mus.GetLeftOffset())          # music source frames (timeline rate) before the item start
            try:
                cfps = float(mus.GetMediaPoolItem().GetClipProperty("FPS") or fps)
            except Exception:
                cfps = fps
            plan = layout(segs, src0, ma, fdown, MUSIC_TRACK, DUCK_TRACK, NORMAL_DB, DUCK_DB,
                          int(fades.get("FadeIn") or 0), int(fades.get("FadeOut") or 0), fup, cfps / fps)
            out["file_fps"] = cfps
            out.update({"speech_source": source, "speech": sp, "segments": segs, "items": plan,
                        "music_item": [ma, mb, src0, mus.GetName()]})
            if MODE != "apply" or len(segs) < 2:
                out["status"] = "PLAN" if len(segs) >= 2 else "NOTHING_TO_DUCK"
            else:
                mpi = mus.GetMediaPoolItem()
                while (tl.GetTrackCount("audio") or 0) < DUCK_TRACK:
                    tl.AddTrack("audio", "stereo")
                tl.SetTrackName("audio", DUCK_TRACK, "MUSIC DUCK")
                tl.DeleteClips([mus], False)
                errors, made = [], []
                for p in plan:
                    got = project.GetMediaPool().AppendToTimeline([{
                        "mediaPoolItem": mpi, "startFrame": float(p["src_in"]), "endFrame": float(p["src_out"]),
                        "trackIndex": p["track"], "recordFrame": float(s0 + p["rec"]), "mediaType": 2}]) or []
                    if not got:
                        errors.append("append failed at %d" % p["rec"])
                        continue
                    it = got[0]
                    it.SetProperties({"AudioVolume": float(p["volume"])})
                    it.SetFades(p["fades"])
                    made.append({"track": p["track"], "start": it.GetStart() - s0, "end": it.GetEnd() - s0,
                                 "src": it.GetLeftOffset(), "volume": (it.GetProperties() or {}).get("AudioVolume"),
                                 "fades": it.GetFades(), "planned": [p["rec"], p["end"], p["src_in"]]})
                drift = [m for m in made if abs(m["start"] - m["planned"][0]) > 1 or abs(m["end"] - m["planned"][1]) > 1]
                if drift:
                    errors.append("%d segment(s) differ from the plan (source mapping of audio files is UNTESTED): inspect"
                                  % len(drift))
                out.update({"readback": made, "errors": errors,
                            "status": "BUILT_WITH_ERRORS" if errors else "BUILT_READ_BACK",
                            "note": "Levels set, not auditioned. Listen to every duck before calling it done."})
    result = out
