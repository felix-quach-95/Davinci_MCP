# replace_shot.py — swap the picture of ONE shot in a Draft without rebuilding the video (v2.3.0, UNTESTED live).
# Tool: run_script (sandbox is enough).
# For review notes like "đổi cảnh này bằng đoạn khác" when timing must not move: the current Draft is duplicated
# to the next version (Draft_<Title>_vNN+1, markers and everything else kept), then in the COPY the V1 item
# is deleted (video only — sound on other tracks stays) and the new source range is appended at the same
# record frame with the same length: speed is fitted so the length is exact (dur convergence, like
# build_from_blueprint.py), and Scaling/Pan/Tilt/Zoom, fades and the node-1 LUT are carried over (or replaced
# by NEW_PROPS). The old item's Fusion effects (MFX_*) are NOT carried: the report lists them to re-run
# motion_fx.py. Idea from guycochran/resolve-mcp-server (video-only replacement, recovery copies).
# v3.3.0 (UNTESTED live): the new item takes the old item's timeline name (shot_NN) and clip colour.

# ---- CONFIG ----------------------------------------------------------------
TRACK = 1
INDEX = 3                        # 1-based V1 item to replace
NEW_CLIP = ""                    # media pool clip name (or the same clip for another range)
NEW_SRC_IN = 0                   # source frames (the clip's own fps)
NEW_SPEED = None                 # None = keep the old item's speed; e.g. 48 for 50 fps slow motion
NEW_PROPS = {}                   # e.g. {"Pan": -300.0}; merged over the carried properties
SHOTS = []                       # v2.7.0: several swaps in ONE new version (BoConCN: two fixes made v02 and v03):
                                 # [{"index": 1, "clip": "...", "src_in": 2650, "speed": None, "props": {}}, ...]
                                 # empty = the single swap above (INDEX / NEW_CLIP / NEW_SRC_IN / NEW_SPEED / NEW_PROPS)
DUPLICATE = True                 # False only on a Test_ timeline
RETIME = "optical_flow"
CARRY = ["Scaling", "Pan", "Tilt", "ZoomX", "ZoomY", "ZoomGang", "RotationAngle", "FlipX", "FlipY",
         "CropLeft", "CropRight", "CropTop", "CropBottom", "Opacity", "RetimeProcess"]
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
# ---------------------------------------------------------------------------

import re


def next_version(name, existing):
    """Draft_X_v03 -> Draft_X_v04 (skipping names that exist); other names get _v02."""
    m = re.match(r"^(.*_v)(\d+)$", name)
    base, n = (m.group(1), int(m.group(2)) + 1) if m else (name + "_v", 2)
    while "%s%02d" % (base, n) in existing:
        n += 1
    return "%s%02d" % (base, n)


def source_needed(length_tl, clip_fps, tl_fps, speed):
    """Source frames (clip fps) that fill length_tl timeline frames at speed %."""
    return int(round(length_tl * float(clip_fps) / float(tl_fps) * float(speed) / 100.0))


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    out = {"errors": []}
    src_tl = project.GetCurrentTimeline()
    mp = project.GetMediaPool()
    names = {project.GetTimelineByIndex(i).GetName() for i in range(1, (project.GetTimelineCount() or 0) + 1)}
    if src_tl is None or not src_tl.GetName().lower().startswith(REQUIRE_PREFIX):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_ (Final_ timelines are never edited)"
    elif not DUPLICATE and not src_tl.GetName().lower().startswith("test_"):
        out["status"] = "REFUSED: in-place replacement only on Test_ timelines"
    else:
        shots = SHOTS or [{"index": INDEX, "clip": NEW_CLIP, "src_in": NEW_SRC_IN, "speed": NEW_SPEED,
                           "props": NEW_PROPS}]
        pool = {}

        def walk(f):
            for c in f.GetClipList() or []:
                pool.setdefault(c.GetName(), c)
            for s in f.GetSubFolderList() or []:
                walk(s)
        walk(mp.GetRootFolder())
        missing = sorted({sh["clip"] for sh in shots if sh["clip"] not in pool})
        n_items = len(src_tl.GetItemListInTrack("video", TRACK) or [])
        bad = [sh["index"] for sh in shots if not 1 <= int(sh["index"]) <= n_items]
        if missing:
            out["status"] = "CLIP_NOT_FOUND: %s" % missing
        elif bad:
            out["status"] = "NO_ITEM V%d#%s" % (TRACK, bad)
        else:
            tl = src_tl
            if DUPLICATE:
                newname = next_version(src_tl.GetName(), names)
                tl = src_tl.DuplicateTimeline(newname)
                if tl is None:
                    out["status"] = "FAILED: DuplicateTimeline"
                else:
                    project.SetCurrentTimeline(tl)
                out["timeline"] = newname
            if tl:
                s0 = tl.GetStartFrame()
                fps = float(tl.GetSetting("timelineFrameRate"))
                items = tl.GetItemListInTrack("video", TRACK) or []
                targets = [(sh, items[int(sh["index"]) - 1]) for sh in shots]   # resolved before any change
                rows = []
                for sh, old in targets:
                    row = {"index": sh["index"], "errors": []}
                    rows.append(row)
                    rec, length = old.GetStart(), int(old.GetDuration())
                    props = {k: v for k, v in (old.GetProperties() or {}).items() if k in CARRY}
                    props.update(sh.get("props") or {})
                    fades = old.GetFades() or {}
                    speed = float(sh["speed"] if sh.get("speed") is not None else
                                  (old.GetSpeed() or {}).get("Percentage") or 100)
                    lut = None
                    try:
                        lut = old.GetNodeGraph().GetLUT(1)
                    except Exception:
                        pass
                    mfx = []
                    if old.GetFusionCompCount():
                        comp = old.GetFusionCompByIndex(1)
                        mfx = [t.GetAttrs("TOOLS_Name") for t in comp.GetToolList(False).values()
                               if t.GetAttrs("TOOLS_Name").startswith("MFX_")]
                    clip = pool[sh["clip"]]
                    cfps = float(clip.GetClipProperty("FPS") or fps)
                    total = int(float(clip.GetClipProperty("Frames") or 0))
                    src_in = int(sh["src_in"])
                    need = source_needed(length, cfps, fps, speed)
                    if total and src_in + need > total:
                        row["status"] = "STOPPED: new range %d+%d exceeds the clip (%d frames)" % (src_in, need, total)
                        continue
                    old_name, old_color = old.GetName(), old.GetClipColor()
                    row["old"] = {"name": old_name, "src": [old.GetSourceStartFrame(), old.GetSourceEndFrame()],
                                  "record": rec - s0, "length": length, "mfx_not_carried": mfx}
                    tl.DeleteClips([old], False)
                    got = mp.AppendToTimeline([{"mediaPoolItem": clip, "startFrame": float(src_in),
                                                "endFrame": float(src_in + need), "trackIndex": TRACK,
                                                "recordFrame": float(rec), "mediaType": 1}]) or []
                    if not got:
                        row["status"] = "FAILED: AppendToTimeline (the gap is now empty — fix by hand or delete this version)"
                        continue
                    it = got[0]
                    if speed != 100 and RETIME:
                        props.setdefault("RetimeProcess", getattr(resolve, "RETIME_" + RETIME.upper(), None))
                    props = {k: v for k, v in props.items() if v is not None}
                    if props and not it.SetProperties(props):
                        row["errors"].append("SetProperties returned False for %s" % sorted(props))
                    sp = speed
                    if sp != 100:
                        it.SetSpeed({"Percentage": sp, "RippleTimeline": False})
                    for _ in range(4):                       # converge on the exact length
                        d = int(round(it.GetDuration()))
                        if d == length:
                            break
                        sp = sp * d / float(length)
                        it.SetSpeed({"Percentage": sp, "RippleTimeline": False})
                    if fades:
                        it.SetFades(fades)
                    # v3.3.0: the new picture keeps the slot's timeline name (shot_NN) and clip colour
                    if old_name and not it.SetName(old_name):
                        row["errors"].append("SetName(%s) returned False" % old_name)
                    if old_color:
                        it.SetClipColor(old_color)
                    if lut:
                        try:
                            it.GetNodeGraph().SetLUT(1, lut)
                        except Exception:
                            row["errors"].append("LUT %s not re-applied" % lut)
                    nxt = [x for x in tl.GetItemListInTrack("video", TRACK) if x.GetStart() >= rec + length]
                    row["readback"] = {"name": it.GetName(), "record": it.GetStart() - s0, "length": it.GetDuration(),
                                       "src": [it.GetSourceStartFrame(), it.GetSourceEndFrame()],
                                       "speed": (it.GetSpeed() or {}).get("Percentage"),
                                       "lut": (it.GetNodeGraph().GetLUT(1) if it.GetNodeGraph() else None),
                                       "next_item_start": (nxt[0].GetStart() - s0) if nxt else None}
                    if it.GetStart() != rec or int(round(it.GetDuration())) != length:
                        row["errors"].append("timing differs from the old shot: check the cut before/after")
                    row["status"] = "REPLACED_WITH_ERRORS" if row["errors"] else "REPLACED_READ_BACK"
                    row["next"] = ("re-run motion_fx.py for %s on this item" % mfx) if mfx else "stills at first/middle/last frame"
                ok = all(r.get("status") == "REPLACED_READ_BACK" for r in rows)
                out["shots"] = rows
                if len(rows) == 1:                            # v2.3 result shape for a single swap
                    out.update({k: v for k, v in rows[0].items() if k in ("old", "readback", "next")})
                    out["errors"] = rows[0]["errors"]
                out["status"] = "REPLACED_READ_BACK" if ok else "REPLACED_WITH_ISSUES: %s" % [
                    (r["index"], r.get("status")) for r in rows if r.get("status") != "REPLACED_READ_BACK"]
    result = out
