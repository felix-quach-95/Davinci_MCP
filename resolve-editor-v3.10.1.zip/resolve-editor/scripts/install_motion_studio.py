# install_motion_studio.py — Phase 11 step 0 (v3.7.1): installs the Motion Studio copy that ships INSIDE this skill.
# Tool: pure Python, run on the Mac (or in the container with --pack, then move the archive to the Mac).
#   python3 -I scripts/install_motion_studio.py                 -> copies <skill>/motion-studio to ~/.claude/skills/motion-studio
#   python3 -I scripts/install_motion_studio.py --dest <dir>    -> another skills folder (CLAUDE_CONFIG_DIR/skills, a project)
#   python3 -I scripts/install_motion_studio.py [--hf-version latest|x.y.z|shipped]   (default latest: newest on npm)
#   python3 -I scripts/install_motion_studio.py --check-hf      -> HyperFrames skills installed vs Motion Studio's pin
#   python3 -I scripts/install_motion_studio.py --move-hf-aside -> mismatching HyperFrames skills to a backup folder (ask first)
#   python3 -I scripts/install_motion_studio.py --pack <out.tar.gz>   -> an archive of the same folder, for a skill that
#                                                                    runs in the cloud while Motion Studio must live on the Mac
# The embedded copy keeps its guide as GUIDE.md (a skill upload must hold one SKILL.md); the installed copy gets it back
# as SKILL.md. An update keeps the user's styles/, .tools/ and node_modules/. A destination that is a link is left
# alone (a developer's own copy). Afterwards run its own installer, exactly as its INSTALL.md says:
#   bash ~/.claude/skills/motion-studio/scripts/install.sh --update   (fetches the pinned release's skills, replacing
#   any HyperFrames skills already there). v3.10.0: the job continues in the SAME chat through the "files" route of
#   phase-11.md §2 (skills and settings installed now load as skills only in a later session); never ask for /clear.
import json
import os
import re
import shutil
import sys
import tarfile
import time

SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(SKILL, "motion-studio")
KEEP = ("styles", ".tools", "node_modules")


def default_dest():
    base = os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join(os.path.expanduser("~"), ".claude")
    return os.path.join(base, "skills", "motion-studio")


def version(src=SRC):
    return json.load(open(os.path.join(src, "package.json"), encoding="utf-8")).get("version")


def latest_hf(timeout=20):
    """v3.9.0: the newest HyperFrames release on npm, or None (offline: keep the shipped pin)."""
    import subprocess
    try:
        r = subprocess.run(["npm", "view", "hyperframes", "version"], capture_output=True, text=True, timeout=timeout)
        v = r.stdout.strip()
        return v if re.fullmatch(r"\d+\.\d+\.\d+", v) else None
    except (OSError, subprocess.SubprocessError):
        return None


def set_pin(dest, version):
    p = os.path.join(dest, "package.json")
    d = json.load(open(p, encoding="utf-8"))
    d["hyperframesVersion"] = version
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(d, fh, indent=2)
        fh.write("\n")


def install(dest=None, src=SRC, hf_version="latest"):
    """hf_version: "latest" (default, user rule 2026-10-28: the newest HyperFrames) | "x.y.z" | "shipped"."""
    dest = os.path.abspath(os.path.expanduser(dest or default_dest()))
    if os.path.islink(dest):
        return {"status": "REFUSED", "why": "%s is a link to another folder: ask the user first" % dest}
    os.makedirs(dest, exist_ok=True)
    for name in os.listdir(src):
        s, d = os.path.join(src, name), os.path.join(dest, "SKILL.md" if name == "GUIDE.md" else name)
        if name in KEEP:
            continue
        if os.path.isdir(s):
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            shutil.copy2(s, d)
    for sh in ("install.sh", "session-env.sh"):
        p = os.path.join(dest, "scripts", sh)
        if os.path.exists(p):
            os.chmod(p, 0o755)
    shipped = pinned(src)
    want = latest_hf() if hf_version == "latest" else (shipped if hf_version == "shipped" else hf_version)
    pin = want or shipped
    set_pin(dest, pin)
    return {"status": "COPIED", "dest": dest, "version": version(src), "hyperframes": pin,
            "hyperframes_source": "npm latest" if (hf_version == "latest" and want) else ("shipped (npm unreachable)" if hf_version == "latest" else hf_version),
            "next": 'bash "%s/scripts/install.sh" --update' % dest,
            "then": "continue in the same chat (phase-11.md §2 files route); no /clear, no new chat"}


HF_SKILLS = ("hyperframes", "hyperframes-cli", "hyperframes-registry", "media-use")   # what HyperFrames' installer adds


def pinned(src=SRC):
    return json.load(open(os.path.join(src, "package.json"), encoding="utf-8")).get("hyperframesVersion")


def hf_check(skills_dir=None, src=SRC):
    """Which HyperFrames release the installed HyperFrames skills call, against Motion Studio's pin. Motion Studio's
    setup SKIPS fetching when hyperframes/SKILL.md exists, so skills installed another way stay as they are until
    `install.sh --update` (it replaces them). Seen on the user's Mac 2026-10-28: skills from 27 Oct calling an
    UNPINNED `npx hyperframes` (= whatever is newest); "1.2.3" there is only a test fixture (v3.9.0 ignores tests)."""
    skills_dir = os.path.expanduser(skills_dir or os.path.dirname(default_dest()))
    found = {}
    for name in HF_SKILLS:
        d = os.path.join(skills_dir, name)
        if not os.path.isdir(d):
            continue
        vers = set()
        unpinned = False
        for root, _, files in os.walk(d):
            for f in files:
                if ".test." in f or not f.endswith((".md", ".json", ".sh", ".txt", ".yml", ".yaml")):
                    continue          # v3.9.0: test fixtures ("hyperframes@1.2.3") are not the release in use
                try:
                    t = open(os.path.join(root, f), encoding="utf-8", errors="ignore").read()
                except OSError:
                    continue
                vers.update(re.findall(r"hyperframes@(\d+\.\d+\.\d+)", t))
                if re.search(r"\bnpx (?:-y |--yes )?hyperframes(?:@latest)?(?=[\s`'\")\],;]|$)", t, re.M):
                    unpinned = True
        found[name] = sorted(vers) + (["unpinned"] if unpinned else [])
    pin = pinned(os.path.join(skills_dir, "motion-studio")) if os.path.isfile(os.path.join(skills_dir, "motion-studio", "package.json")) else pinned(src)
    other = {k: v for k, v in found.items() if v != [pin]}
    return {"pin": pin, "installed": found, "status": "NONE" if not found else ("NEEDS_UPDATE" if other else "OK"),
            "differs": other, "fix": "bash ~/.claude/skills/motion-studio/scripts/install.sh --update" if other else None}


def hf_move_aside(skills_dir=None, names=None):
    """Moves the mismatching HyperFrames skills to <skills>/.backup-hyperframes-<time>/ (nothing deleted), so
    `install.sh --update` fetches the pinned release. Ask the user first: other work may use the newer skills."""
    skills_dir = os.path.expanduser(skills_dir or os.path.dirname(default_dest()))
    dest = os.path.join(skills_dir, ".backup-hyperframes-%s" % time.strftime("%Y%m%d-%H%M%S"))
    moved = []
    for name in names or HF_SKILLS:
        d = os.path.join(skills_dir, name)
        if os.path.isdir(d) and not os.path.islink(d):
            os.makedirs(dest, exist_ok=True)
            shutil.move(d, os.path.join(dest, name))
            moved.append(name)
    return {"status": "MOVED" if moved else "NOTHING", "moved": moved, "backup": dest if moved else None,
            "next": 'bash "%s/scripts/install.sh" --update' % default_dest()}


def pack(out, src=SRC):
    out = os.path.abspath(out)
    with tarfile.open(out, "w:gz") as t:
        for root, dirs, files in os.walk(src):
            for f in files:
                p = os.path.join(root, f)
                rel = os.path.relpath(p, src)
                t.add(p, arcname=os.path.join("motion-studio", "SKILL.md" if rel == "GUIDE.md" else rel))
    return {"status": "PACKED", "archive": out, "version": version(src),
            "next": "on the Mac: tar -xzf <archive> -C ~/.claude/skills, then bash ~/.claude/skills/motion-studio/scripts/install.sh"}


if __name__ == "__main__":
    a = sys.argv[1:]
    opt = lambda k: a[a.index(k) + 1] if k in a and a.index(k) + 1 < len(a) else None
    if "--check-hf" in a:
        r = hf_check(opt("--skills"))
    elif "--move-hf-aside" in a:
        r = hf_move_aside(opt("--skills"))
    elif "--pack" in a:
        r = pack(opt("--pack"))
    else:
        r = install(opt("--dest"), hf_version=opt("--hf-version") or "latest")
    print(json.dumps(r, ensure_ascii=False, indent=1))
