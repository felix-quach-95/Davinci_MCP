# srt_from_transcript.py — subtitles from Resolve's own transcription, remapped onto the
# re-cut draft timeline (only words inside kept segments survive, times shifted).
# Paste into run_script_unsafe (it writes the .srt). The user (or computer use) imports it in the UI.
# Never changes the words; it can only drop words outside kept ranges and re-break lines.

# ---- CONFIG ----------------------------------------------------------------
CLIP = "C0001.MP4"          # media pool clip name with a finished transcription
KEPT = [
    # {"src_in": 120, "src_out": 210, "record": 0},   # frames; record = timeline-relative
]
FPS_TIMELINE = None          # None = read from current timeline
MAX_CHARS = 32               # per line (Vietnamese, vertical 1080)
MAX_LINES = 1
MIN_DUR = 0.8                # seconds on screen
GAP_FRAMES = 1
OUT_PATH = "/Users/felix/Desktop/Final/Cache Edit/job/subs.srt"
# v2.3: no API import. AppendToTimeline puts an SRT AFTER the timeline end and passing start/end frames
# crashed Resolve 21.1 (reported by appariciojunior/video-editor-skills). Import with File > Import > Subtitle
# with the playhead on the timeline start; cue times here are relative to record frame 0.
# ---------------------------------------------------------------------------


def tc_to_frames(tc, fps):
    nom = int(round(float(fps)))
    hh, mm, ss, ff = [int(x) for x in tc.replace(";", ":").split(":")]
    return ((hh * 60 + mm) * 60 + ss) * nom + ff


def words_from_transcription(tr, clip_start_tc, fps):
    """Flatten to [(src_frame_start, src_frame_end, word)], frames relative to clip start."""
    base = tc_to_frames(clip_start_tc, fps)
    out = []
    for seg in tr.get("segments", []):
        ws = seg.get("words") or []
        if ws:
            for w in ws:
                txt = (w.get("text") or w.get("word") or "").strip()
                if not txt or txt == "(...)":
                    continue
                a = tc_to_frames(w["start"], fps) - base
                b = tc_to_frames(w["end"], fps) - base
                out.append((a, max(b, a + 1), txt))
        else:
            txt = (seg.get("text") or "").replace("(...)", "").strip()
            if not txt:
                continue
            a = tc_to_frames(seg["start"], fps) - base
            b = tc_to_frames(seg["end"], fps) - base
            parts = txt.split()
            step = (b - a) / float(len(parts))
            for i, p in enumerate(parts):
                out.append((int(a + i * step), int(a + (i + 1) * step), p))
    return out


def remap(words, kept):
    """Keep words whose midpoint lies in a kept source range; shift to timeline frames."""
    res = []
    for a, b, w in words:
        mid = (a + b) / 2.0
        for k in kept:
            if k["src_in"] <= mid < k["src_out"]:
                off = k["record"] - k["src_in"]
                na, nb = max(a, k["src_in"]) + off, min(b, k["src_out"]) + off
                res.append((na, max(nb, na + 1), w, k["record"], k["record"] + k["src_out"] - k["src_in"]))
                break
    return sorted(res)


def group_lines(rw, fps, max_chars=MAX_CHARS, max_lines=MAX_LINES, min_dur=MIN_DUR, gap=GAP_FRAMES):
    """Group remapped words into cues; never let a cue cross a kept-segment boundary."""
    cues, cur = [], []
    limit = max_chars * max_lines

    def flush():
        if cur:
            cues.append([cur[0][0], cur[-1][1], " ".join(x[2] for x in cur), cur[0][4]])
    for w in rw:
        text = " ".join([x[2] for x in cur] + [w[2]])
        same_seg = not cur or cur[-1][3] == w[3]
        pause = cur and w[0] - cur[-1][1] > fps * 0.6
        if cur and (len(text) > limit or not same_seg or pause):
            flush()
            cur = []
        cur.append(w)
        if w[2].endswith((".", "?", "!", "…")):
            flush()
            cur = []
    flush()
    md = int(round(min_dur * fps))
    for i, c in enumerate(cues):
        nxt = cues[i + 1][0] - gap if i + 1 < len(cues) else c[3]
        if c[1] - c[0] < md:
            c[1] = min(c[0] + md, max(nxt, c[1]), c[3])
        if i + 1 < len(cues) and c[1] > cues[i + 1][0] - gap:
            c[1] = max(cues[i + 1][0] - gap, c[0] + 1)
    return [(c[0], c[1], c[2]) for c in cues]


def to_srt(cues, fps):
    def ts(fr):
        ms = int(round(fr * 1000.0 / float(fps)))
        h, ms = divmod(ms, 3600000)
        m, ms = divmod(ms, 60000)
        s, ms = divmod(ms, 1000)
        return "%02d:%02d:%02d,%03d" % (h, m, s, ms)
    return "\n".join("%d\n%s --> %s\n%s\n" % (i + 1, ts(a), ts(b), t) for i, (a, b, t) in enumerate(cues))


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os
    mp = project.GetMediaPool()
    found = []

    def walk(f):
        for c in f.GetClipList() or []:
            if c.GetName() == CLIP:
                found.append(c)
        for s in f.GetSubFolderList() or []:
            walk(s)
    walk(mp.GetRootFolder())
    clip = found[0] if found else None
    res = {}
    if clip is None:
        res["status"] = "CLIP_NOT_FOUND"
    else:
        tr = clip.GetTranscription() or {}
        if not tr.get("segments"):
            res["status"] = "NO_TRANSCRIPTION: run clip.TranscribeAudio() and poll project.GetTranscribeAudioStatus() first"
        else:
            p = clip.GetClipProperty() or {}
            cfps = float(p.get("FPS") or 30)
            tl = project.GetCurrentTimeline()
            tfps = float(FPS_TIMELINE or (tl.GetSettings() or {}).get("timelineFrameRate") or cfps)
            words = words_from_transcription(tr, p.get("Start TC", "00:00:00:00"), cfps)
            if abs(cfps - tfps) > 0.01:
                words = [(a * tfps / cfps, b * tfps / cfps, w) for a, b, w in words]
            cues = group_lines(remap(words, KEPT), tfps)
            srt = to_srt(cues, tfps)
            path = os.path.expanduser(OUT_PATH)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(srt)
            res.update({"status": "WRITTEN", "path": path, "cues": len(cues), "language": tr.get("language"),
                        "preview": srt[:600]})
            # Resolve's UI import places the FIRST cue at the playhead and keeps the others relative to it
            first = cues[0][0] if cues else 0
            nom = int(round(tfps))
            f = int(first) + int(tl.GetStartFrame())
            tc = "%02d:%02d:%02d:%02d" % (f // (3600 * nom), (f // (60 * nom)) % 60, (f // nom) % 60, f % nom)
            res["import"] = {"how": "File > Import > Subtitle with the playhead at the first cue",
                             "playhead": tc, "file": path,
                             "why": "the API route is disabled: it lands after the timeline end or crashes Resolve 21.1"}
    result = res
