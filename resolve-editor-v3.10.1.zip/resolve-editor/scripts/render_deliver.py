# render_deliver.py — render the deliverable, then check the file (v2.2.0, UNTESTED live).
# Tool: run_script_unsafe (checks the output folder, runs ffprobe/ffmpeg).
# Render only when the user asked for it (SKILL.md stage 12). Never overwrites: a taken name gets _2, _3…
#
# MODE "plan":   validate preset vs timeline (size, fps), list render formats/codecs, report the output path.
#                Writes nothing.
# MODE "start":  load settings, add ONE render job for TIMELINE, start it and return the job id
#                (rendering continues after the call returns — poll with MODE "status").
# MODE "status": GetRenderJobStatus(JOB_ID) (+ when Complete: the file path).
# MODE "verify": ffprobe + ffmpeg ebur128 on FILE (or the job's file): size, fps, duration vs timeline,
#                audio codec/rate, integrated loudness, true peak, LRA vs the preset target.
# MODE "cover":  export one frame of TIMELINE (COVER_FRAME, timeline-relative) as a JPEG cover image
#                (ExportCurrentFrameAsStill + sips), for the TikTok/Reels cover picker.
# The user's render queue is left alone except for the job this script adds (it is not deleted after
# rendering, so the user can see it in the Deliver page).
# v2.3 (traps reported in appariciojunior/video-editor-skills, Resolve 21): an external script starts a job
# only with StartRendering([job], False); wait on GetRenderJobStatus, not IsRenderingInProgress (it can be
# False before rendering begins); a target folder with spaces left a job unstarted once (warned); the
# Deliver page's format/codec is restored right after the job is queued (the job keeps its own copy);
# colour tags "Same as Project" so a Rec.709 file is not shown faded on Apple devices.

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
TIMELINE = ""                    # "" = current timeline; normally the latest Final_<Title>_NN
PRESET = "tiktok"                # key of PRESETS (tiktok | reels | shorts | feed45 | square | youtube | youtube4k | master)
TARGET_DIR = "~/Movies/Exports"
CUSTOM_NAME = ""                 # "" = timeline name
JOB_ID = ""                      # for MODE "status"/"verify"
FILE = ""                        # for MODE "verify" (absolute path)
COVER_FRAME = 0                  # for MODE "cover"
LOUDNESS_TARGET = {"integrated_lufs": -14.0, "true_peak_dbtp": -1.0, "tolerance_lu": 1.0}
PRESETS = {
    "tiktok":    {"width": 1080, "height": 1920, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "reels":     {"width": 1080, "height": 1920, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "shorts":    {"width": 1080, "height": 1920, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "feed45":    {"width": 1080, "height": 1350, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "square":    {"width": 1080, "height": 1080, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "youtube":   {"width": 1920, "height": 1080, "format": "mp4", "codec": "H264", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "youtube4k": {"width": 3840, "height": 2160, "format": "mp4", "codec": "H265", "audio_codec": "aac", "audio_rate": 48000, "quality": "Best"},
    "master":    {"width": 2160, "height": 3840, "format": "mov", "codec": "ProRes422HQ", "audio_codec": "lpcm", "audio_rate": 48000, "quality": "Best"},
}
# ---------------------------------------------------------------------------

import json
import re


def unique_path(folder, name, ext, exists):
    """folder/name.ext, or name_2.ext, name_3.ext… when taken. exists(path) -> bool."""
    base = "%s/%s" % (folder.rstrip("/"), name)
    if not exists("%s.%s" % (base, ext)):
        return "%s.%s" % (base, ext), name
    n = 2
    while exists("%s_%d.%s" % (base, n, ext)):
        n += 1
    return "%s_%d.%s" % (base, n, ext), "%s_%d" % (name, n)


def path_warnings(path):
    w = []
    if " " in path:
        w.append("output folder contains spaces: a job once stayed 'Ready' — prefer a path without spaces")
    return w


def aspect_mismatch(tl_w, tl_h, out_w, out_h, tol=0.01):
    """True when the render would change the aspect ratio (letterbox/crop)."""
    return abs(float(tl_w) / tl_h - float(out_w) / out_h) > tol


def pick_codec(codecs, wanted):
    """codecs: {description: codec name} from GetRenderCodecs. Exact name first, then a case-insensitive
    match on name or description (e.g. "H264" vs "H.264")."""
    if not codecs:
        return None
    names = list(codecs.values())
    if wanted in names:
        return wanted
    w = re.sub(r"[^a-z0-9]", "", wanted.lower())
    for desc, name in codecs.items():
        if w in (re.sub(r"[^a-z0-9]", "", str(name).lower()), re.sub(r"[^a-z0-9]", "", str(desc).lower())):
            return name
    for desc, name in codecs.items():
        if w in re.sub(r"[^a-z0-9]", "", (str(name) + str(desc)).lower()):
            return name
    return None


def parse_ffprobe(js):
    """ffprobe -show_streams -show_format -of json -> summary dict."""
    d = json.loads(js) if isinstance(js, str) else js
    out = {"duration_s": None, "video": None, "audio": None}
    try:
        out["duration_s"] = float(d.get("format", {}).get("duration"))
    except (TypeError, ValueError):
        pass
    for st in d.get("streams", []):
        if st.get("codec_type") == "video" and out["video"] is None:
            num, den = (st.get("avg_frame_rate") or st.get("r_frame_rate") or "0/1").split("/")
            out["video"] = {"codec": st.get("codec_name"), "width": st.get("width"), "height": st.get("height"),
                            "fps": round(float(num) / float(den), 3) if float(den) else None,
                            "pix_fmt": st.get("pix_fmt"), "frames": int(st["nb_frames"]) if str(st.get("nb_frames", "")).isdigit() else None}
        elif st.get("codec_type") == "audio" and out["audio"] is None:
            out["audio"] = {"codec": st.get("codec_name"), "rate": int(st.get("sample_rate") or 0),
                            "channels": st.get("channels")}
    return out


def parse_ebur128(stderr_text):
    """Summary block of ffmpeg -af ebur128=peak=true -> integrated LUFS, LRA, true peak dBTP."""
    txt = stderr_text[stderr_text.rfind("Summary:"):] if "Summary:" in stderr_text else stderr_text

    def grab(pattern):
        m = re.search(pattern, txt)
        return float(m.group(1)) if m else None
    return {"integrated_lufs": grab(r"I:\s*(-?[0-9.]+)\s*LUFS"),
            "lra_lu": grab(r"LRA:\s*(-?[0-9.]+)\s*LU\b"),
            "true_peak_dbtp": grab(r"Peak:\s*(-?[0-9.]+)\s*dBFS")}


def check_delivery(probe, loud, preset, tl_fps, tl_frames, target):
    """Compare the rendered file with the preset and the timeline. Returns {check: {ok, ...}}."""
    c = {}
    v = probe.get("video") or {}
    c["size"] = {"ok": (v.get("width"), v.get("height")) == (preset["width"], preset["height"]),
                 "file": [v.get("width"), v.get("height")], "preset": [preset["width"], preset["height"]]}
    c["fps"] = {"ok": v.get("fps") is not None and abs(v["fps"] - float(tl_fps)) < 0.02,
                "file": v.get("fps"), "timeline": tl_fps}
    want_s = tl_frames / float(tl_fps) if tl_fps else None
    dur = probe.get("duration_s")
    c["duration"] = {"ok": None if want_s is None or dur is None else abs(dur - want_s) <= 1.5 / float(tl_fps) + 0.05,
                     "file_s": dur, "timeline_s": round(want_s, 3) if want_s else None}
    a = probe.get("audio") or {}
    c["audio"] = {"ok": bool(a) and (a.get("rate") == preset.get("audio_rate")), "file": a}
    if loud and loud.get("integrated_lufs") is not None:
        li, tp = loud["integrated_lufs"], loud.get("true_peak_dbtp")
        c["loudness"] = {"ok": abs(li - target["integrated_lufs"]) <= target["tolerance_lu"],
                         "integrated_lufs": li, "target": target["integrated_lufs"],
                         "fix_db": round(target["integrated_lufs"] - li, 1)}
        c["true_peak"] = {"ok": tp is not None and tp <= target["true_peak_dbtp"], "dbtp": tp,
                          "max": target["true_peak_dbtp"]}
    else:
        c["loudness"] = {"ok": None, "note": "not measured (no ffmpeg)"}
    return c


def verdict(checks):
    bad = [k for k, v in checks.items() if v.get("ok") is False]
    unk = [k for k, v in checks.items() if v.get("ok") is None]
    return "FILE CHECK PASS" if not bad and not unk else ("FILE CHECK FAIL: " + ", ".join(bad) if bad
                                                           else "FILE CHECK PARTIAL (unmeasured: %s)" % ", ".join(unk))


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, shutil, subprocess, time
    out = {"mode": MODE, "preset": PRESET}

    def find_bin(name):
        return shutil.which(name) or next((p for p in (os.path.expanduser("~/.local/bin/" + name),
                                                       "/opt/homebrew/bin/" + name, "/usr/local/bin/" + name)
                                           if os.path.exists(p)), None)

    def get_timeline(name):
        if not name:
            return project.GetCurrentTimeline()
        for i in range(1, (project.GetTimelineCount() or 0) + 1):
            t = project.GetTimelineByIndex(i)
            if t and t.GetName() == name:
                return t
        return None

    pre = PRESETS.get(PRESET)
    tl = get_timeline(TIMELINE)
    tdir = os.path.expanduser(TARGET_DIR)
    if MODE in ("plan", "start", "cover") and (pre is None or tl is None):
        out["status"] = "REFUSED: unknown preset %r or timeline %r not found" % (PRESET, TIMELINE)
    elif MODE in ("plan", "start"):
        project.SetCurrentTimeline(tl)
        tw, th = int(tl.GetSetting("timelineResolutionWidth")), int(tl.GetSetting("timelineResolutionHeight"))
        fps = float(tl.GetSetting("timelineFrameRate"))
        name = CUSTOM_NAME or tl.GetName()
        path, name = unique_path(tdir, name, pre["format"], os.path.exists)
        codecs = project.GetRenderCodecs(pre["format"]) or {}
        codec = pick_codec(codecs, pre["codec"])
        out.update({"timeline": tl.GetName(), "timeline_size": [tw, th], "fps": fps, "output": path,
                    "codec": codec, "available_codecs": codecs if not codec else None,
                    "aspect_change": aspect_mismatch(tw, th, pre["width"], pre["height"])})
        problems = []
        if codec is None:
            problems.append("codec %s not offered for %s" % (pre["codec"], pre["format"]))
        if out["aspect_change"]:
            problems.append("timeline %dx%d and preset %dx%d differ in aspect: build a timeline for this format"
                            % (tw, th, pre["width"], pre["height"]))
        out["problems"] = problems
        out["warnings"] = path_warnings(tdir)
        if problems or MODE == "plan":
            out["status"] = "STOPPED" if problems else "PLAN_OK"
        else:
            os.makedirs(tdir, exist_ok=True)
            prev_fc = project.GetCurrentRenderFormatAndCodec() or {}
            ok_fmt = project.SetCurrentRenderFormatAndCodec(pre["format"], codec)
            settings = {"SelectAllFrames": True, "TargetDir": tdir, "CustomName": name,
                        "FormatWidth": pre["width"], "FormatHeight": pre["height"], "FrameRate": fps,
                        "ExportVideo": True, "ExportAudio": True, "AudioCodec": pre["audio_codec"],
                        "AudioSampleRate": pre["audio_rate"], "VideoQuality": pre["quality"],
                        "UseUniqueFilenames": False,
                        "ColorSpaceTag": "Same as Project", "GammaTag": "Same as Project"}
            ok_set = project.SetRenderSettings(settings)
            job = project.AddRenderJob() if ok_fmt and ok_set else None
            started = bool(job) and project.StartRendering([job], False)
            restored = None
            if prev_fc.get("format") and prev_fc.get("codec"):
                restored = project.SetCurrentRenderFormatAndCodec(prev_fc["format"], prev_fc["codec"])
            resolve.OpenPage("edit")          # AddRenderJob jumps to the Deliver page
            out.update({"format_ok": ok_fmt, "settings_ok": ok_set, "job_id": job, "started": started,
                        "deliver_format_restored": restored,
                        "status": "RENDERING" if started else "FAILED",
                        "next": "poll MODE status with this JOB_ID, then MODE verify"})
    elif MODE == "status":
        st = project.GetRenderJobStatus(JOB_ID) or {}
        info = next((j for j in (project.GetRenderJobList() or []) if j.get("JobId") == JOB_ID), {})
        out.update({"status": st.get("JobStatus"), "percent": st.get("CompletionPercentage"),
                    "error": st.get("Error"), "job": {k: info.get(k) for k in ("TargetDir", "OutputFilename", "TimelineName")}})
    elif MODE == "verify":
        path = FILE
        tl_name = TIMELINE
        if not path and JOB_ID:
            info = next((j for j in (project.GetRenderJobList() or []) if j.get("JobId") == JOB_ID), {})
            path = os.path.join(info.get("TargetDir", ""), info.get("OutputFilename", ""))
            tl_name = tl_name or info.get("TimelineName", "")
        tl = get_timeline(tl_name)
        fp, ff = find_bin("ffprobe"), find_bin("ffmpeg")
        if not path or not os.path.exists(path):
            out["status"] = "NO_FILE: %s" % path
        elif not fp or tl is None or pre is None:
            out["status"] = "CANNOT_VERIFY (ffprobe %s, timeline %s)" % (bool(fp), tl is not None)
        else:
            r = subprocess.run([fp, "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
                               capture_output=True, text=True, timeout=20)
            probe = parse_ffprobe(r.stdout)
            loud = None
            if ff:
                r2 = subprocess.run([ff, "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "ebur128=peak=true",
                                     "-f", "null", "-"], capture_output=True, text=True, timeout=40)
                loud = parse_ebur128(r2.stderr)
            fps = float(tl.GetSetting("timelineFrameRate"))
            frames = tl.GetEndFrame() - tl.GetStartFrame()
            checks = check_delivery(probe, loud, pre, fps, frames, LOUDNESS_TARGET)
            out.update({"file": path, "bytes": os.path.getsize(path), "probe": probe, "loudness": loud,
                        "checks": checks, "status": verdict(checks),
                        "note": "File facts only: playback and the mix are not verified by this check."})
    elif MODE == "cover":
        project.SetCurrentTimeline(tl)
        fps = float(tl.GetSetting("timelineFrameRate"))
        nom = int(round(fps))
        f = int(tl.GetStartFrame()) + int(COVER_FRAME)
        tc = "%02d:%02d:%02d:%02d" % (f // (3600 * nom), (f // (60 * nom)) % 60, (f // nom) % 60, f % nom)
        os.makedirs(tdir, exist_ok=True)
        png, _ = unique_path(tdir, (CUSTOM_NAME or tl.GetName()) + "_cover", "png", os.path.exists)
        tl.SetCurrentTimecode(tc)
        time.sleep(0.7)                       # stale-still guard (visual-qc-loop.md)
        ok = project.ExportCurrentFrameAsStill(png)
        jpg = png[:-4] + ".jpg"
        if ok and os.path.exists(png):
            subprocess.run(["sips", "-s", "format", "jpeg", "-Z", str(max(pre["width"], pre["height"])),
                            png, "--out", jpg], capture_output=True, timeout=30)
            os.remove(png)
        out.update({"status": "WRITTEN" if os.path.exists(jpg) else "FAILED", "cover": jpg, "timecode": tc,
                    "next": "Read the JPEG and look at it before offering it as the cover"})
    else:
        out["status"] = "UNKNOWN_MODE"
    result = out
