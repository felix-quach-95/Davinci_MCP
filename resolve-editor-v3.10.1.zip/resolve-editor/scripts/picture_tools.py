# picture_tools.py — Resolve's own picture analysis on Draft_/Probe_/Test_ items (v2.2.0, UNTESTED live).
# Tool: run_script (sandbox is enough). Each call is stub-verified (21.1.1) but its behaviour is not
# measured yet: read the result, then LOOK at stills before relying on it (visual-qc-loop.md).
# MODE "scene_cuts":    Timeline.DetectSceneCuts() on a Probe_/Test_ timeline holding long clips whole, then
#                       read the resulting items back as source ranges (shot list for the evidence map).
#                       It cuts the items of that timeline, so never run it on a Draft_.
# MODE "smart_reframe": TimelineItem.SmartReframe() on ITEMS (V1 indexes) — Resolve picks the subject and
#                       reframes for the timeline aspect. Compare with the measured Pan route (broll.md);
#                       keep whichever frames the subject better on the stills.
# MODE "stabilize":     TimelineItem.Stabilize() on ITEMS (handheld walking shots). Stabilising crops: check
#                       the edges on stills; skip drone/gimbal shots that are already smooth.
# MODE "resolvefx_check" (v2.3): on item ITEMS[0] (default 1) of TRACK of a Test_/Probe_ timeline, add each
#                       ResolveFX in RESOLVEFX to the clip comp, record whether it exists and its input names
#                       (for motion_fx "resolvefx" params), then delete it again. ≤ 15 per call.
# MODE "pan_calibrate" (v3.0.1, run_script_unsafe: stills + ffmpeg): measures what one Edit-page Pan unit moves
#                       for item ITEMS[0] on this timeline (stills at FRAME with Pan 0 and Pan PAN_TEST, column-profile
#                       correlation) -> "pan_per_unit" as a fraction of SOURCE width. The constant depends on the
#                       timeline and source sizes (2160-wide timeline/DJI footage: 0.00035; 1080-wide timeline with
#                       1280x720 sources: ~0.00088, live 2026-10-27). Write it to project.json
#                       {"framing": {"pan_per_unit_9x16_fill": v}} so motion_fx / composition_check use it. Pan restored.
# Every mode reports item properties before/after so a change can be undone by hand (Inspector reset).

# ---- CONFIG ----------------------------------------------------------------
MODE = "scene_cuts"
TRACK = 1
ITEMS = []                    # 1-based item indexes on TRACK; [] = all items (smart_reframe/stabilize)
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
SCENE_CUT_PREFIX = ("probe_", "test_")
FRAME = None                  # pan_calibrate: timeline-relative frame (None = middle of the item)
PAN_TEST = 80                 # pan_calibrate: test offset (small: the shifted picture must still overlap)
FFMPEG_DIRS = ["~/.local/bin", "/opt/homebrew/bin", "/usr/local/bin"]
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"
RESOLVEFX = ["filmgrain", "glow", "lightray", "lensflare", "vignette", "halationplugin", "filmlook",
             "motionblur", "invertcolor", "camerashake", "chromaticaberration", "lensreflections",
             "aperturediffraction", "defocusbackground", "contrastpop"]
WATCH = ["Pan", "Tilt", "ZoomX", "ZoomY", "RotationAngle", "Scaling", "CropLeft", "CropRight",
         "CropTop", "CropBottom"]
# ---------------------------------------------------------------------------


def diff_props(before, after, keys=WATCH):
    return {k: [before.get(k), after.get(k)] for k in keys if before.get(k) != after.get(k)}


def profile_shift(a, b, max_shift):
    """Column-mean brightness profiles a, b (same length) -> (shift, score): b looks like a moved by `shift`
    columns (+ = picture moved right). Mean-normalised correlation over the overlap; overlaps under half the
    width are not considered (the v3.0.1 live run: a raw SAD search slid to its edge on textured beans)."""
    n = len(a)
    best = (0, -2.0)
    for sh in range(-max_shift, max_shift + 1):
        xs = range(max(0, sh), min(n, n + sh))
        if len(xs) < n // 2:
            continue
        pa = [a[x - sh] for x in xs]
        pb = [b[x] for x in xs]
        ma, mb = sum(pa) / len(pa), sum(pb) / len(pb)
        num = sum((u - ma) * (v - mb) for u, v in zip(pa, pb))
        da = sum((u - ma) ** 2 for u in pa) ** 0.5
        db = sum((v - mb) ** 2 for v in pb) ** 0.5
        sc = num / (da * db) if da and db else -1.0
        if sc > best[1]:
            best = (sh, round(sc, 4))
    return best


def shots_from_items(rows, min_len=6):
    """rows [{name, src_in, src_out}] after scene detection -> shot list per clip (src_out exclusive),
    tiny slivers (< min_len frames) folded into the previous shot."""
    out = {}
    for r in rows:
        lst = out.setdefault(r["name"], [])
        a, b = int(r["src_in"]), int(r["src_out"]) + 1
        if lst and b - a < min_len:
            lst[-1][1] = b
        else:
            lst.append([a, b])
    return out


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    out = {"mode": MODE}
    name = tl.GetName().lower() if tl else ""
    prefix = SCENE_CUT_PREFIX if MODE in ("scene_cuts", "resolvefx_check") else REQUIRE_PREFIX
    if MODE == "pan_calibrate":
        prefix = REQUIRE_PREFIX
    if not name.startswith(prefix):
        out["status"] = "REFUSED: %s needs a %s timeline (current: %s)" % (MODE, "/".join(prefix), tl.GetName() if tl else None)
    elif MODE == "scene_cuts":
        before = len(tl.GetItemListInTrack("video", TRACK) or [])
        ok = tl.DetectSceneCuts()
        items = tl.GetItemListInTrack("video", TRACK) or []
        rows = [{"name": it.GetName(), "src_in": it.GetSourceStartFrame(), "src_out": it.GetSourceEndFrame(),
                 "start": it.GetStart() - tl.GetStartFrame(), "dur": it.GetDuration()} for it in items]
        out.update({"status": "OK" if ok else "RETURNED_FALSE", "items_before": before, "items_after": len(items),
                    "shots": shots_from_items(rows), "rows": rows,
                    "next": "qc_stills at each shot's middle; write the shots into the evidence map"})
    elif MODE == "resolvefx_check":
        items = tl.GetItemListInTrack("video", TRACK) or []
        idx = (ITEMS or [1])[0]
        if not 1 <= idx <= len(items):
            out["status"] = "NO_ITEM"
        else:
            it = items[idx - 1]
            if not it.GetFusionCompCount():
                it.AddFusionComp()
            comp = it.GetFusionCompByIndex(1)
            found = {}
            comp.Lock()
            try:
                for short in RESOLVEFX[:15]:
                    rid = short if short.startswith("ofx.") else "ofx.com.blackmagicdesign.resolvefx." + short
                    t = comp.AddTool(rid, -32768, -32768)
                    if t is None:
                        found[short] = None
                        continue
                    names = []
                    try:
                        for inp in (t.GetInputList() or {}).values():
                            names.append(inp.GetAttrs("INPS_ID"))
                    except Exception:
                        pass
                    found[short] = [n for n in names if n][:40]
                    t.Delete()
            finally:
                comp.Unlock()
            out.update({"status": "CHECKED", "item": it.GetName(),
                        "available": sorted(k for k, v in found.items() if v is not None),
                        "missing": sorted(k for k, v in found.items() if v is None), "inputs": found,
                        "note": "Nodes were added and deleted again in this Test_/Probe_ item's comp."})
    elif MODE in ("smart_reframe", "stabilize"):
        items = tl.GetItemListInTrack("video", TRACK) or []
        idx = ITEMS or list(range(1, len(items) + 1))
        done = []
        for i in idx:
            if not 1 <= i <= len(items):
                done.append({"index": i, "status": "NO_ITEM"})
                continue
            it = items[i - 1]
            b = dict(it.GetProperties() or {})
            ok = it.SmartReframe() if MODE == "smart_reframe" else it.Stabilize()
            a = dict(it.GetProperties() or {})
            done.append({"index": i, "name": it.GetName(), "returned": ok, "changed": diff_props(b, a),
                         "before": {k: b.get(k) for k in WATCH}})
        out.update({"status": "DONE_READ_BACK", "items": done,
                    "note": "UNTESTED behaviour: export stills of these items and look before keeping the result. "
                            "An empty 'changed' does not mean nothing happened (the analysis may live outside "
                            "these properties)."})
    elif MODE == "pan_calibrate":
        import os, subprocess, time
        ff = next((os.path.join(os.path.expanduser(d), "ffmpeg") for d in FFMPEG_DIRS
                   if os.path.exists(os.path.join(os.path.expanduser(d), "ffmpeg"))), None)
        items = tl.GetItemListInTrack("video", TRACK) or []
        idx = (ITEMS or [1])[0]
        if not ff or not 1 <= idx <= len(items):
            out["status"] = "NO_FFMPEG" if not ff else "NO_ITEM"
        else:
            it = items[idx - 1]
            s0 = tl.GetStartFrame()
            fr = int(FRAME) if FRAME is not None else (it.GetStart() - s0) + it.GetDuration() // 2
            fps = float(project.GetSetting("timelineFrameRate") or 24)
            n = int(round(fps))
            f = s0 + fr
            tc = "%02d:%02d:%02d:%02d" % (f // (n * 3600), (f // (n * 60)) % 60, (f // n) % 60, f % n)
            d = os.path.join(os.path.expanduser(WORK_DIR), "_pan_calibrate")
            os.makedirs(d, exist_ok=True)
            tw = int(project.GetSetting("timelineResolutionWidth") or 1080)
            resolve.OpenPage("edit")

            def grab(tag):
                tl.SetCurrentTimecode(tc)
                time.sleep(0.8)
                p = os.path.join(d, tag + ".png")
                project.ExportCurrentFrameAsStill(p)
                time.sleep(0.3)
                raw = subprocess.run([ff, "-loglevel", "error", "-i", p, "-vf", "scale=360:-2,format=gray",
                                      "-f", "rawvideo", "-"], capture_output=True).stdout
                h = len(raw) // 360
                cols = [sum(raw[y * 360 + x] for y in range(h // 6, h - h // 6, 2)) for x in range(360)]
                os.remove(p)
                return cols
            orig = it.GetProperty("Pan") or 0.0
            grab("warm")
            it.SetProperty("Pan", 0.0)
            a = grab("pan0")
            it.SetProperty("Pan", float(PAN_TEST))
            b = grab("pan_test")
            it.SetProperty("Pan", float(orig))
            sh, sc = profile_shift(a, b, 170)
            mpi = it.GetMediaPoolItem()
            try:
                sw, sh_ = [int(x) for x in str(mpi.GetClipProperty("Resolution")).lower().split("x")[:2]]
                th = int(project.GetSetting("timelineResolutionHeight") or 1920)
                scale = max(float(tw) / sw, float(th) / sh_)         # fill
                vis = tw / (sw * scale)                              # visible fraction of source width
            except Exception:
                sw, vis = None, None
            frame_frac = sh / 360.0
            out.update({"status": "MEASURED" if sc >= 0.8 else "LOW_CONFIDENCE (look at the stills)",
                        "item": it.GetName(), "frame": fr, "pan_test": PAN_TEST, "shift_frame_frac": round(frame_frac, 4),
                        "score": sc, "timeline_px_per_unit": round(frame_frac * tw / PAN_TEST, 3),
                        "pan_per_unit": round(frame_frac * vis / PAN_TEST, 6) if vis else None,
                        "pan_restored": it.GetProperty("Pan"),
                        "next": 'project_set {"framing": {"pan_per_unit_9x16_fill": pan_per_unit}} for this title'})
    else:
        out["status"] = "UNKNOWN_MODE"
    result = out
