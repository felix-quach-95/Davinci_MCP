# composition_check.py — measure how a shot is framed in the 9:16 frame and propose a Pan (v2.4.0, offline-tested).
# Tool: run_script (sandbox is enough). Writes nothing.
# Input per shot, from a still Claude LOOKED at (references/composition.md): the subject box in SOURCE
# coordinates (x0, y0, x1, y1; 0–1, y from the TOP), optional eyes y, gaze/motion direction ("left", "right",
# "camera"/None), and the item's Edit-page Pan (read live when "index" is given).
# Output: the box in frame coordinates, nearest power point (thirds) and distance, eye line vs the upper third,
# headroom, look/lead room, overlap with the platform UI, and a suggested Pan that puts the subject on the right
# third for its gaze (clamped to |Pan| <= PAN_EDGE). Numbers support the judgement; the still decides.

# ---- CONFIG ----------------------------------------------------------------
SHOTS = [
    # {"index": 3, "box": [0.58, 0.22, 0.70, 0.95], "eyes_y": 0.30, "gaze": "left"},
    # {"name": "s05", "box": [...], "pan": 120.0, "gaze": "right"}   # pan given instead of index
]
TRACK = 1
MODE_916 = "fill"                 # fill = 16:9 source in a 9:16 fill (measured) | native = source has the frame's aspect
VISIBLE = 0.316                   # visible share of the source width in a 9:16 fill of 16:9
PAN_PER_UNIT = 0.00035            # measured: +Pan moves the view left by 0.00035 of the source width
PAN_EDGE = 900                    # black edges near ±950
UI = {"right": 0.87, "bottom": 0.80, "top": 0.08}   # TikTok, frame fractions (y from the top)
# ---------------------------------------------------------------------------

import math

THIRDS = [(x, y) for x in (1 / 3.0, 2 / 3.0) for y in (1 / 3.0, 2 / 3.0)]


def window_x(pan):
    return 0.5 - float(pan or 0) * PAN_PER_UNIT


def to_frame_x(x_src, pan, mode=MODE_916):
    if mode == "native":
        return x_src
    return (x_src - window_x(pan)) / VISIBLE + 0.5


def frame_box(box, pan, mode=MODE_916):
    x0, y0, x1, y1 = box
    return [to_frame_x(x0, pan, mode), y0, to_frame_x(x1, pan, mode), y1]


def suggest_pan(cx_src, target_fx, mode=MODE_916):
    """Pan that places source x at frame x target_fx (clamped). Returns (pan, achieved frame x)."""
    if mode == "native":
        return 0.0, cx_src
    wx = cx_src - (target_fx - 0.5) * VISIBLE
    pan = max(-PAN_EDGE, min(PAN_EDGE, (0.5 - wx) / PAN_PER_UNIT))
    return round(pan, 1), round(to_frame_x(cx_src, pan, mode), 3)


def target_x(gaze):
    """Look/lead room: a subject looking/moving left sits right of centre, and vice versa."""
    return {"left": 0.64, "right": 0.36}.get(gaze, 0.5)


def ui_overlap(fb, ui=UI):
    x0, y0, x1, y1 = fb
    area = max(x1 - x0, 1e-6) * max(y1 - y0, 1e-6)
    zones = [(ui["right"], 0.0, 1.0, 1.0), (0.0, ui["bottom"], 1.0, 1.0), (0.0, 0.0, 1.0, ui["top"])]
    cov = 0.0
    for zx0, zy0, zx1, zy1 in zones:
        w = max(0.0, min(x1, zx1) - max(x0, zx0))
        h = max(0.0, min(y1, zy1) - max(y0, zy0))
        cov += w * h
    return round(min(cov / area, 1.0), 3)


def analyse_shot(shot, pan=None, mode=MODE_916):
    pan = shot.get("pan", pan) or 0.0
    fb = frame_box(shot["box"], pan, mode)
    cx, cy = (fb[0] + fb[2]) / 2.0, (fb[1] + fb[3]) / 2.0
    eyes = shot.get("eyes_y")
    anchor = (cx, eyes if eyes is not None else cy)
    pp = min(THIRDS, key=lambda p: math.hypot(p[0] - anchor[0], p[1] - anchor[1]))
    notes = []
    inside = max(0.0, min(fb[2], 1.0) - max(fb[0], 0.0)) / max(fb[2] - fb[0], 1e-6)
    if inside < 0.98:
        notes.append("subject cut by the frame edge (%.0f %% visible)" % (100 * inside))
    headroom = fb[1]
    if eyes is not None:
        d = eyes - 1 / 3.0
        if abs(d) > 0.08:
            notes.append("eyes at y %.2f: %s the upper third line (0.33)" % (eyes, "below" if d > 0 else "above"))
    if eyes is None and headroom > 0.12 and (fb[3] - fb[1]) > 0.5:      # with eyes known, the eye line rules
        notes.append("headroom %.0f %% — subject sinks; tilt/zoom so the eyes sit on the upper third" % (100 * headroom))
    gaze = shot.get("gaze")
    room = None
    if gaze in ("left", "right"):
        front = cx if gaze == "left" else 1 - cx
        back = 1 - cx if gaze == "left" else cx
        room = round(front / max(back, 1e-6), 2)
        if room < 1.0 and not shot.get("short_side"):
            notes.append("looks/moves %s with less space in front than behind (ratio %.2f): give it look room" % (gaze, room))
    # the head/upper body is what must stay clear of the UI; a body continuing into the caption band is normal
    key = [fb[0], fb[1], fb[2], fb[1] + 0.4 * (fb[3] - fb[1])]
    ui = ui_overlap(key)
    if ui > 0.15:
        notes.append("%.0f %% of the head/upper body under platform UI (right column/captions/top)" % (100 * ui))
    sp, sx = suggest_pan((shot["box"][0] + shot["box"][2]) / 2.0, target_x(gaze), mode)
    return {"name": shot.get("name") or shot.get("index"), "pan": pan, "frame_box": [round(v, 3) for v in fb],
            "anchor": [round(anchor[0], 3), round(anchor[1], 3)],
            "nearest_power_point": [round(pp[0], 3), round(pp[1], 3)],
            "power_point_distance": round(math.hypot(pp[0] - anchor[0], pp[1] - anchor[1]), 3),
            "headroom": round(headroom, 3), "look_room_ratio": room, "ui_overlap": ui,
            "suggested_pan": sp, "subject_x_with_suggestion": sx,
            "subject_in_out_for_blueprint": [round(anchor[0], 3), round(anchor[1], 3)],
            "notes": notes}


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    tl = project.GetCurrentTimeline()
    items = tl.GetItemListInTrack("video", TRACK) if tl else []
    rows = []
    for sh in SHOTS:
        pan = sh.get("pan")
        if pan is None and sh.get("index") and 1 <= sh["index"] <= len(items or []):
            pan = float((items[sh["index"] - 1].GetProperties() or {}).get("Pan") or 0.0)
        rows.append(analyse_shot(sh, pan))
    result = {"status": "MEASURED", "shots": rows,
              "note": "From boxes read off stills; check the suggestion on a new still before keeping it."}
