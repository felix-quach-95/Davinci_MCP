# research_card.py — turn vidIQ (or hand-collected) research into a Research Card for the edit (v2.6.0, offline-tested).
# Tool: run_script (pure Python, sandbox is enough) or locally: python3 scripts/research_card.py research.json
# Writes nothing. references/trend-research.md explains the research pass and how the card feeds the Story approval and the
# blueprint (`bp["research"]`, checked by edit_analysis.py).
# Input RESEARCH: what the vidIQ tools actually returned (null for missing fields), never guessed numbers:
#   {"topic": "...", "platform": "tiktok", "languages": ["vi", "en"], "source": "vidIQ + Creative Center 2026-10-25",
#    "credits_spent": 25, "credits_left": 125,
#    "trending_music": [{"title": "...", "artist": "...", "rank": 1, "rank_change": 12, "commercial": false, "url": "..."}],
#    "trending_hashtags": [{"tag": "#hongkong", "posts": 120000, "rank": 4}],
#    "keywords": [{"term": "...", "volume": 0-100 or absolute, "competition": 0-100 or 0-1, "score": optional}],
#    "videos": [{"title": "...", "platform": "tiktok|instagram|youtube", "url": "...", "views": n,
#               "channel_median": n or "outlier_score": vidIQ breakout/outlier score, "duration_s": s,
#               "source": "vidiq|creative_center|tiktok_search|youtube_search",
#               "hook_text": "first 3 s (hook search / caption / walkthrough)", "cuts_first_3s": n, "opening_asl_s": s}]}
# Output: keyword ranking + primary keyword, outlier tiers, hook patterns among the strongest outliers with the
# recommended pattern, runtime recommendation, hashtag candidates, warnings, `blueprint_research`.

# ---- CONFIG ----------------------------------------------------------------
RESEARCH = {}
STRONG_RATIO = 3.0            # views / channel median for a strong outlier
GOOD_RATIO = 1.5
MIN_VIDEOS = 5                # fewer -> "thin data" warning
MIN_PATTERN = 2               # a hook pattern needs at least this many videos (vidIQ: >= 2 outliers per platform)
RUNTIME_LIMITS = {"tiktok": (12, 90), "reels": (10, 90), "shorts": (10, 60), "youtube": (10, 60)}
MAX_HASHTAGS = 5
# ---------------------------------------------------------------------------

import re

HOOK_PATTERNS = [   # (pattern, regex over lower-cased text); first match wins, order = specificity
    ("pov", r"\bpov\b|góc nhìn"),
    ("number_list", r"\b(top\s*)?\d+\s+(things|places|tips|ways|reasons|foods|spots|mistakes|điều|nơi|món|cách|địa điểm|lý do|mẹo)"),
    ("warning", r"\b(don'?t|never|stop|avoid|mistakes?|warning)\b|đừng|sai lầm|tránh|cảnh báo|đừng bao giờ"),
    ("constraint", r"\bonly\s*\$|\bunder\s*\$?\d|\b24\s*h|\b(one|1)\s*day\b|\$\d+|chỉ với|chỉ có|dưới\s*\d|\d+\s*k\b|\d+\s*(nghìn|triệu)|1 ngày|24h"),
    ("secret", r"\b(secret|hidden|nobody|no one tells|no one knows)\b|bí mật|ít ai biết|không ai (nói|biết)"),
    ("contrast", r"\bvs\.?\b|\bbefore\b.*\bafter\b|\binstead of\b|trước và sau|thay vì|so với"),
    ("result_first", r"^(here'?s|this is (what|how)|after\b)|kết quả|thành quả|^đây là"),
    ("question", r"\?|^(how|why|what|which|where|is|are|can|should)\b|tại sao|làm sao|bao nhiêu|có nên|ở đâu|thế nào|là gì"),
    ("story_open", r"^(i\b|i'm|my\b|the day|today)|^(tôi|mình|hôm nay|lần đầu)"),
]
STOP = set("the a an and or of to in on for with at by is are this that my your you i we it from".split()) | \
    set("và của là có cho với ở trong một những các này đó tôi mình bạn đi".split())


def classify_hook(text):
    t = (text or "").strip().lower()
    if not t:
        return None
    for name, rx in HOOK_PATTERNS:
        if re.search(rx, t):
            return name
    return "statement"


def is_vietnamese(text):
    return bool(re.search(u"[ăâđêôơưàáạảãằắặẳẵầấậẩẫèéẹẻẽềếệểễìíịỉĩòóọỏõồốộổỗờớợởỡùúụủũừứựửữỳýỵỷỹ]", (text or "").lower()))


def _unit(v):
    """0–1 from 0–1 or 0–100 scales; None stays None."""
    if v is None:
        return None
    v = float(v)
    return v / 100.0 if v > 1.0 else v


def rank_keywords(keywords):
    vols = [float(k["volume"]) for k in keywords if k.get("volume") is not None]
    vmax = max(vols) if vols else 0.0
    rows = []
    for k in keywords:
        if k.get("score") is not None:
            opp = _unit(k["score"])
        else:
            vol = float(k["volume"]) / vmax if (k.get("volume") is not None and vmax > 0) else None
            comp = _unit(k.get("competition"))
            if vol is None:
                opp = None
            else:
                opp = vol * (1.0 - comp) if comp is not None else vol * 0.5
        rows.append({"term": k["term"], "volume": k.get("volume"), "competition": k.get("competition"),
                     "opportunity": None if opp is None else round(opp, 3), "vi": is_vietnamese(k["term"])})
    rows.sort(key=lambda r: -1 if r["opportunity"] is None else r["opportunity"], reverse=True)
    return rows


def outlier_rows(videos):
    rows = []
    for v in videos:
        ratio = None
        if v.get("views") and v.get("channel_median"):
            ratio = round(float(v["views"]) / float(v["channel_median"]), 2)
        elif v.get("outlier_score") is not None:
            ratio = round(float(v["outlier_score"]), 2)
        tier = None if ratio is None else ("strong" if ratio >= STRONG_RATIO else "good" if ratio >= GOOD_RATIO else "normal")
        rows.append({"title": v.get("title"), "url": v.get("url"), "ratio": ratio, "tier": tier,
                     "duration_s": v.get("duration_s"), "platform": (v.get("platform") or "").lower() or None,
                     "cuts_first_3s": v.get("cuts_first_3s"), "opening_asl_s": v.get("opening_asl_s"),
                     "source": v.get("source"),
                     "title_hook": classify_hook(v.get("title")), "spoken_hook": classify_hook(v.get("hook_text")),
                     "hook_text": v.get("hook_text")})
    rows.sort(key=lambda r: -1 if r["ratio"] is None else r["ratio"], reverse=True)
    return rows


def best_set(rows):
    best = [r for r in rows if r["tier"] == "strong"] or [r for r in rows if r["tier"] == "good"]
    return best or rows[:5]


def hook_stats(rows):
    counts = {}
    for r in best_set(rows):
        hs = {r["title_hook"], r["spoken_hook"]} - {None}           # one vote per video per pattern
        if hs - {"statement"}:                                       # "statement" is only the fallback
            hs -= {"statement"}
        for h in hs:
            counts[h] = counts.get(h, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0] == "statement", kv[0]))
    return ranked


def median(xs):
    xs = sorted(xs)
    if not xs:
        return None
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2.0


def runtime_target(rows, platform):
    durs = [float(r["duration_s"]) for r in best_set(rows) if r.get("duration_s")]
    med = median(durs)
    if med is None:
        return None, None
    lo, hi = RUNTIME_LIMITS.get((platform or "tiktok").lower(), (10, 90))
    spread = (max(durs) - min(durs)) / med if len(durs) > 1 and med else 0.0
    return int(round(min(max(med, lo), hi))), round(spread, 2)


def opening_pace(rows):
    best = best_set(rows)
    cuts = [float(r["cuts_first_3s"]) for r in best if r.get("cuts_first_3s") is not None]
    asl = [float(r["opening_asl_s"]) for r in best if r.get("opening_asl_s")]
    if not cuts and not asl:
        return None
    return {"cuts_first_3s": median(cuts), "opening_asl_s": None if not asl else round(median(asl), 2),
            "videos": max(len(cuts), len(asl))}


def _tag(text):
    return "#" + re.sub(r"[^\w]", "", (text or "").lower().lstrip("#").replace(" ", ""), flags=re.UNICODE)


def _fold(text):
    """Lower-case, Vietnamese diacritics removed (đ -> d), for loose topic matching."""
    import unicodedata
    t = unicodedata.normalize("NFD", (text or "").lower().replace(u"đ", "d"))
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def topic_words(research, kw_rows):
    words = set()
    for t in [research.get("topic")] + [r["term"] for r in kw_rows]:
        words |= {w for w in re.split(r"\W+", _fold(t), flags=re.UNICODE) if len(w) > 2} - STOP
    return words


def hashtags(kw_rows, n=MAX_HASHTAGS, trending=(), words=()):
    """Trending tags that match the topic first (rank order), then tags made from the best keywords."""
    tags, seen = [], set()
    on_topic = [t for t in sorted(trending, key=lambda t: t.get("rank") or 999)
                if any(w in _fold(t.get("tag")) for w in words)]
    for src in [t["tag"] for t in on_topic] + [r["term"] for r in kw_rows]:
        tag = _tag(src)
        if len(tag) > 2 and tag not in seen:
            seen.add(tag)
            tags.append(tag)
        if len(tags) >= n:
            break
    return tags


def music_rows(music):
    rows = sorted(music, key=lambda m: m.get("rank") or 999)
    return [{"title": m.get("title"), "artist": m.get("artist"), "rank": m.get("rank"),
             "rising": (m.get("rank_change") or 0) > 0, "commercial": m.get("commercial"), "url": m.get("url")}
            for m in rows]


def build_card(research):
    platform = (research.get("platform") or "tiktok").lower()
    kw = rank_keywords(research.get("keywords") or [])
    vids = outlier_rows(research.get("videos") or [])
    hooks = hook_stats(vids)
    target, spread = runtime_target(vids, platform)
    warnings = []
    if len(vids) < MIN_VIDEOS:
        warnings.append("thin data: %d video(s) — treat the card as a hint, not evidence" % len(vids))
    if not [r for r in vids if r["tier"] in ("strong", "good")] and vids:
        warnings.append("no video beats its channel median by %.1fx: the topic may be saturated or the seed too broad"
                        % GOOD_RATIO)
    plats = {(r.get("platform") or "").lower() for r in vids} - {""}
    if platform in ("tiktok", "reels") and plats and plats <= {"youtube", "shorts"}:
        warnings.append("only YouTube data for a %s brief: Shorts used as a proxy (TikTok opens faster, more on-screen text)"
                        % platform)
    if spread is not None and spread > 1.0:
        warnings.append("outlier lengths vary widely (spread %.1f): choose the runtime by the story" % spread)
    if not kw:
        warnings.append("no keyword data: caption/hashtags from the topic words only")
    pattern = hooks[0][0] if hooks else None
    if hooks and hooks[0][1] < MIN_PATTERN:
        warnings.append("hook '%s' seen in only %d video: a hint, not a pattern" % (pattern, hooks[0][1]))
    pace = opening_pace(vids)
    music = music_rows(research.get("trending_music") or [])
    sources = sorted({r["source"] for r in vids if r.get("source")} |
                     ({"creative_center"} if research.get("trending_music") or research.get("trending_hashtags") else set()))
    examples = [r["hook_text"] or r["title"] for r in best_set(vids)
                if pattern in (r["title_hook"], r["spoken_hook"])][:3]
    primary = next((r["term"] for r in kw if r["opportunity"] is not None), kw[0]["term"] if kw else research.get("topic"))
    evidence = "%d/%d strongest outliers use '%s'" % (hooks[0][1], len(best_set(vids)), pattern) if hooks else None
    return {"topic": research.get("topic"), "platform": platform, "source": research.get("source") or "unspecified",
            "keywords": kw, "primary_keyword": primary, "outliers": vids, "hook_patterns": hooks,
            "recommended_hook": pattern, "hook_examples_do_not_copy": examples, "target_dur": target,
            "opening_pace": pace, "credits_spent": research.get("credits_spent"),
            "credits_left": research.get("credits_left"), "sources": sources,
            "trending_music": music,
            "music_note": ("Trending songs show mood/tempo, not a licence: match a library track by mood/BPM, or cut to "
                           "the song and add the sound in the TikTok app when posting.") if music else None,
            "hashtags": hashtags(kw, trending=research.get("trending_hashtags") or [],
                                 words=topic_words(research, kw)), "warnings": warnings,
            "blueprint_research": {"primary_keyword": primary, "hook_pattern": pattern, "hook_text": None,
                                   "target_dur": target, "evidence": evidence,
                                   "opening_asl_s": pace["opening_asl_s"] if pace else None,
                                   "source": research.get("source") or "unspecified"}}


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    result = build_card(RESEARCH)
    result["status"] = "CARD"
    result["note"] = "Write hook_text in the user's own words (<= 7 words) before putting blueprint_research in bp."
elif __name__ == "__main__":
    import json, sys
    data = json.load(open(sys.argv[1], encoding="utf-8")) if len(sys.argv) > 1 else RESEARCH
    print(json.dumps(build_card(data), ensure_ascii=False, indent=1))
