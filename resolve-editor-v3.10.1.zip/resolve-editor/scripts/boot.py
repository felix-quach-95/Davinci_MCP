# boot.py — 3-line way to run any staged tool through loader.py (v2.7.0; used live on BoConCN 2026-10-25).
# Tool: run_script_unsafe. Instead of pasting the 150-line loader every call:
#
#   import os
#   TOOLS = "/Users/felix/Desktop/Final/Cache Edit/_tools"          # optional: the staged folder (default below)
#   exec(open(os.path.expanduser(TOOLS + "/boot.py")).read())
#   result = run("build_from_blueprint.py", {"BLUEPRINT": bp, "DRY_RUN": True}, "BoConCN")["result"]
#
# run(tool, overrides, project, mode="run", data=None) returns the loader's dict:
#   {"status": "RAN", "tool", "injected", "project_file", "result": <the tool's result>}.
# Other loader modes: run("", None, "BoConCN", mode="project_get" | "config" | "stage_check")
#                     run("", None, "BoConCN", mode="project_set", data={...}).
#                     run("", None, "", mode="prefs_get") / mode="prefs_set", data={"choices": {...},
#                     "lessons": ["..."]} (v2.8: preferences kept across videos).
# The loader's CONFIG lines are replaced by plain assignments placed after them, so the staged loader
# is never edited. A staged copy under a new name (stale-cache rule) is run by its new name.

try:
    TOOLS
except NameError:
    TOOLS = "/Users/felix/Desktop/Final/Cache Edit/_tools"


def run(tool, overrides=None, project="", mode="run", data=None, tools=None):
    import os
    tdir = tools or TOOLS
    path = os.path.join(os.path.expanduser(tdir), "loader.py")
    src = open(path, encoding="utf-8").read()
    cfg = ("MODE=%r\nTOOL=%r\nPROJECT=%r\nOVERRIDES=%r\nPROJECT_DATA=%r\nTOOLS_DIR=%r\n"
           % (mode, tool, project, overrides or {}, data or {}, tdir))
    marker = "\nimport json\nimport re\n"
    if marker not in src:
        raise ValueError("loader.py changed: no import marker to place the settings after its CONFIG block")
    src = src.replace(marker, "\n" + cfg + marker.lstrip("\n"), 1)
    g = {"resolve": resolve, "project": resolve.GetProjectManager().GetCurrentProject(), "__name__": "boot"}
    exec(compile(src, path, "exec"), g)
    return g["result"]
