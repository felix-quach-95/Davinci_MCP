# hyperframes_handoff.py — Phase 11 start (Phase 10 before v3.10.0): structured hand-over of every graphic element to HyperFrames (v3.6.0, offline-tested).
# Tool: pure Python. Locally: python3 scripts/hyperframes_handoff.py spec.json [out_dir]   (or run_script, sandbox is enough)
# Writes (local run only): <out_dir>/handoff_<Title>.json and handoff_<Title>.md. Never touches Resolve or the timeline.
# v3.6.0: out_dir is the Phase 11 package (<Cache Edit>/<Title>/hyperframes/). When the status is APPROVED it also
# writes HF_REQUEST_<Title>.md (the request Motion Studio passes to HyperFrames, overlay mode, timing in seconds that
# keep the Final's frame count) and START_PHASE11.md (v3.10.0: the line that resumes the build later in the SAME
# chat — no /clear, no new chat). Phase 11 runs in the same chat with the user's `motion-studio` skill; the build
# runs in a fresh-context agent inside it (references/phases/phase-11.md).
# v3.7.0 (user rule 2026-10-28): every element becomes its OWN named layer — one MOV per element, trimmed to its
# span, named DHnn_<Kind>_<Words>, coloured by kind, on a named Vietnamese track — so the user keeps refining each
# one in DaVinci. plan_layers() computes names, colours, tracks and the place_media list; write_files() writes
# layers_<Title>.json; HF_REQUEST asks HyperFrames for one named layer per element and a `solo` variable.
#
# Claude does NOT design titles, subtitles, captions, motion graphics or decorative overlays. This script only
# records what the user approved (or what Claude proposed and the user has not answered yet), checks that the
# record is complete and consistent with the locked cut, and writes it in two forms: a Markdown brief the user
# reads and approves, and a JSON file with frame-accurate data HyperFrames can consume.
#
# Input SPEC:
#   {"title": "HuongCang", "final_timeline": "Final_HuongCang_01", "fps": 24, "width": 1080, "height": 1920,
#    "duration_frames": 480, "format": "tiktok",
#    "safe_zone": {"x0": .06, "y_top": .08, "x1": .87, "y_bottom": .80},       # fractions, top-origin (config safe_zones)
#    "style": {"direction": "…" | null, "references": ["…"], "status": "approved|proposed|open", "notes": "…"},
#    "cuts": [0, 96, 168], "beats": [0, 48, 96], "markers": [{"frame": 96, "name": "DROP"}],
#    "audio_events": [{"frame": 96, "role": "hit", "file": "Hit 03.wav"}],       # informational: what already sounds there
#    "elements": [{"id": "e01", "category": "title_main", "text": {"vi": "HƯƠNG CẢNG", "en": "Fragrant Harbour"},
#                  "start": 24, "end": 120, "position": {"anchor": "upper_third", "x": 0.5, "y": 0.28},
#                  "hierarchy": 1, "animation": {"in": "…", "out": "…", "feel": "…"},
#                  "anchored_to": {"kind": "cut|beat|word|marker|none", "ref": "…"},
#                  "status": "approved|proposed|open", "source": "user|claude_proposal", "notes": "…"}],
#    "subtitle_cues": [{"start": 10, "end": 50, "vi": "…", "en": "…"}],            # expanded to category "subtitle"
#    "open_questions": ["…"],
#    "stills": {"e01": "stills/e01.jpg"},     # v3.6.0: Final stills behind each element (qc_stills.py), package-relative
#    "package_dir": "/Users/felix/Desktop/Final/Cache Edit/HuongCang/hyperframes"}   # where Phase 11 works
# style may carry "look": "<name>" = a look in Motion Studio's library (styles.mjs path <name>).
# Frames are timeline-relative (0 = first frame of the Final). Positions are fractions of the frame, y from the TOP.

CATEGORIES = {
    "title_main": "Tiêu đề chính",
    "opening_text": "Văn bản mở đầu",
    "section_title": "Tiêu đề phần",
    "onscreen_text": "Văn bản trên màn hình",
    "subtitle": "Phụ đề",
    "caption": "Chú thích",
    "motion_graphic": "Đồ họa chuyển động",
    "supporting_visual": "Yếu tố hình ảnh hỗ trợ",
}
TEXT_CATEGORIES = ("title_main", "opening_text", "section_title", "onscreen_text", "subtitle", "caption")
STATUSES = ("approved", "proposed", "open")
ANCHOR_KINDS = ("cut", "beat", "word", "marker", "none")
SNAP_TOLERANCE = 2                 # frames: how far a start may sit from its declared cut/beat/marker
SUBTITLE_MAX_CHARS = 32            # Vietnamese line on 1080-wide vertical (transcript-editing.md)
SUBTITLE_MIN_FRAMES_S = 0.8        # seconds
HF_PIN = "0.8.209"                 # v3.9.0: newest HyperFrames on 2026-10-28; the real pin is the installed Motion Studio's
                                   # package.json (set to npm's newest at install) — pass SPEC "hf_version" to use it
MOTION_STUDIO = "motion-studio"    # the user's skill that runs Phase 11
OVERLAY_RULES = [                  # constraints every overlay job carries (lessons from live runs, hyperframes-handoff.md §8)
    "Transparent canvas: no full-frame background colour, image or video; only the elements listed. It is laid over footage in DaVinci Resolve.",
    "No sound at all: the edit already has music and SFX (listed below). Skip Motion Studio's music step.",
    "Keep every element inside the safe zone and off faces, key action and the platform's UI.",
    "Readability on real footage: a text-sized dark scrim about 0.5 opacity behind text on bright areas; a second (English) line at least 28 px, weight 400.",
    "Vietnamese text: HyperFrames' bundled fonts carry Latin only at a few weights; use a family that sets Vietnamese (Be Vietnam Pro, Inter, Montserrat …) through @font-face in assets/fonts (or let the compiler fetch it) and check the first snapshots for missing marks.",
    "Timing is fixed by the locked cut: keep every start and end time below; a change of timing is a change of the cut, not of the graphics.",
]


def tc(frame, fps):
    n = int(round(fps))
    f = int(frame)
    return "%02d:%02d:%02d:%02d" % (f // (n * 3600), (f // (n * 60)) % 60, (f // n) % 60, f % n)


def expand_subtitles(spec):
    out = []
    for i, c in enumerate(spec.get("subtitle_cues") or [], 1):
        out.append({"id": "sub%03d" % i, "category": "subtitle",
                    "text": {"vi": c.get("vi", ""), "en": c.get("en", "")},
                    "start": int(c["start"]), "end": int(c["end"]),
                    "position": c.get("position") or {"anchor": "lower_third", "x": 0.5, "y": 0.72},
                    "hierarchy": 3, "animation": c.get("animation") or {},
                    "anchored_to": {"kind": "word", "ref": c.get("vi", "")[:24]},
                    "status": c.get("status", "proposed"), "source": c.get("source", "claude_proposal"), "notes": ""})
    return out


def _near(frame, points, tol=SNAP_TOLERANCE):
    return any(abs(int(frame) - int(p)) <= tol for p in points)


def validate(spec, elements):
    """-> list of {severity: BLOCKER|WARN, id, issue}. A BLOCKER keeps the hand-over from being marked APPROVED."""
    issues = []
    fps = float(spec.get("fps") or 0)
    dur = int(spec.get("duration_frames") or 0)
    safe = spec.get("safe_zone")
    markers = [m["frame"] for m in spec.get("markers") or []]
    pts = {"cut": spec.get("cuts") or [], "beat": spec.get("beats") or [], "marker": markers}

    def add(sev, eid, msg):
        issues.append({"severity": sev, "id": eid, "issue": msg})

    for k in ("title", "final_timeline", "fps", "width", "height", "duration_frames"):
        if not spec.get(k):
            add("BLOCKER", "spec", "missing %s (read it from the Final timeline, do not guess)" % k)
    st = spec.get("style") or {}
    if st.get("status") != "approved":
        add("WARN", "style", "graphic style is %s — HyperFrames needs an approved direction" % (st.get("status") or "not set"))
    seen = set()
    for e in elements:
        eid = e.get("id", "?")
        if eid in seen:
            add("BLOCKER", eid, "duplicate id")
        seen.add(eid)
        cat = e.get("category")
        if cat not in CATEGORIES:
            add("BLOCKER", eid, "unknown category %r (allowed: %s)" % (cat, ", ".join(CATEGORIES)))
            continue
        if e.get("status") not in STATUSES:
            add("BLOCKER", eid, "status must be one of %s" % ", ".join(STATUSES))
        s, en = e.get("start"), e.get("end")
        if s is None or en is None or int(en) <= int(s):
            add("BLOCKER", eid, "needs start < end (timeline frames)")
        elif dur and (int(s) < 0 or int(en) > dur):
            add("BLOCKER", eid, "outside the cut: %s–%s of %s frames" % (s, en, dur))
        if cat in TEXT_CATEGORIES:
            t = e.get("text") or {}
            if not (t.get("vi") or t.get("en")):
                add("BLOCKER" if e.get("status") == "approved" else "WARN", eid, "no text content")
        pos = e.get("position") or {}
        if pos.get("x") is None or pos.get("y") is None:
            add("WARN", eid, "no position (x, y as fractions of the frame, y from the top)")
        elif safe and cat != "motion_graphic":
            x, y = float(pos["x"]), float(pos["y"])
            if not (safe["x0"] <= x <= safe["x1"] and safe["y_top"] <= y <= safe["y_bottom"]):
                add("WARN", eid, "anchor point (%.2f, %.2f) is outside the platform safe zone" % (x, y))
        if not e.get("hierarchy"):
            add("WARN", eid, "no visual hierarchy (1 = dominant … 3 = quiet)")
        if cat != "subtitle" and not (e.get("animation") or {}).get("in"):
            add("WARN", eid, "no animation intent (how it enters, how it leaves, what it should feel like)")
        a = e.get("anchored_to") or {}
        if a.get("kind") not in ANCHOR_KINDS:
            add("WARN", eid, "anchored_to.kind should be one of %s" % ", ".join(ANCHOR_KINDS))
        elif a.get("kind") in pts and s is not None and pts[a["kind"]] and not _near(s, pts[a["kind"]]):
            add("WARN", eid, "start %s is not within %d frames of any %s in the cut — re-check the anchor" % (s, SNAP_TOLERANCE, a["kind"]))
        if cat == "subtitle":
            for lang in ("vi", "en"):
                for line in ((e.get("text") or {}).get(lang) or "").split("\n"):
                    if lang == "vi" and len(line) > SUBTITLE_MAX_CHARS:
                        add("WARN", eid, "Vietnamese line has %d characters (max %d for 1080-wide vertical)" % (len(line), SUBTITLE_MAX_CHARS))
            if fps and s is not None and en is not None and (int(en) - int(s)) / fps < SUBTITLE_MIN_FRAMES_S:
                add("WARN", eid, "on screen %.2f s (< %.1f s)" % ((int(en) - int(s)) / fps, SUBTITLE_MIN_FRAMES_S))
        if e.get("source") == "claude_proposal" and e.get("status") == "approved":
            add("BLOCKER", eid, "a Claude proposal cannot be 'approved' — the user's answer must set status and source 'user'")
    # overlaps at the same anchor
    by_cat = [e for e in elements if e.get("start") is not None and e.get("end") is not None and int(e["end"]) > int(e["start"])]
    for i, a in enumerate(by_cat):
        for b in by_cat[i + 1:]:
            if a.get("category") == b.get("category") == "subtitle" and int(a["start"]) < int(b["end"]) and int(b["start"]) < int(a["end"]):
                add("WARN", "%s/%s" % (a["id"], b["id"]), "two subtitles overlap in time")
            elif a.get("category") != "subtitle" and b.get("category") != "subtitle" and a.get("category") in TEXT_CATEGORIES \
                    and b.get("category") in TEXT_CATEGORIES and int(a["start"]) < int(b["end"]) and int(b["start"]) < int(a["end"]):
                pa, pb = a.get("position") or {}, b.get("position") or {}
                if pa.get("y") is not None and pb.get("y") is not None and abs(float(pa["y"]) - float(pb["y"])) < 0.06 \
                        and abs(float(pa.get("x", .5)) - float(pb.get("x", .5))) < 0.25:
                    add("WARN", "%s/%s" % (a["id"], b["id"]), "text blocks overlap in time and nearly in place")
    for q in spec.get("open_questions") or []:
        add("WARN", "open", q)
    return issues


def overall_status(issues, elements, style):
    if any(i["severity"] == "BLOCKER" for i in issues):
        return "INCOMPLETE"
    if not elements or any(e.get("status") != "approved" for e in elements) or (style or {}).get("status") != "approved":
        return "AWAITING_USER_APPROVAL"
    return "APPROVED"


def build_handoff(spec):
    spec = dict(spec)
    elements = [dict(e) for e in spec.get("elements") or []] + expand_subtitles(spec)
    elements.sort(key=lambda e: (int(e.get("start") or 0), e.get("id", "")))
    issues = validate(spec, elements)
    fps = float(spec.get("fps") or 24)
    for e in elements:
        if e.get("start") is not None:
            e["start_tc"] = tc(e["start"], fps)
        if e.get("end") is not None:
            e["end_tc"] = tc(e["end"], fps)
            if e.get("start") is not None:
                e["duration_s"] = round((int(e["end"]) - int(e["start"])) / fps, 2)
    status = overall_status(issues, elements, spec.get("style"))
    data = {
        "schema": "resolve-editor/hyperframes-handoff@1",
        "hf_version": spec.get("hf_version"),
        "status": status,
        "project": {"title": spec.get("title"), "final_timeline": spec.get("final_timeline"), "format": spec.get("format"),
                    "fps": spec.get("fps"), "width": spec.get("width"), "height": spec.get("height"),
                    "duration_frames": spec.get("duration_frames"),
                    "duration_s": round(int(spec.get("duration_frames") or 0) / fps, 2)},
        "reference_video": {"path": spec.get("reference_video"),
                            "note": "Rendered by the user from the Final; Claude never renders. Null = ask the user for a proxy export."},
        "safe_zone": spec.get("safe_zone"),
        "style": spec.get("style") or {"status": "open"},
        "cuts": spec.get("cuts") or [], "beats": spec.get("beats") or [], "markers": spec.get("markers") or [],
        "audio_events": spec.get("audio_events") or [],
        "elements": elements,
        "counts": {c: sum(1 for e in elements if e.get("category") == c) for c in CATEGORIES},
        "issues": issues,
    }
    return data


def to_markdown(data):
    p = data["project"]
    L = ["# Bàn giao HyperFrames — %s" % p["title"], "",
         "**Trạng thái:** `%s` · Timeline: `%s` · %sx%s @ %s fps · %s khung hình (%.2f s)" % (
             data["status"], p["final_timeline"], p["width"], p["height"], p["fps"], p["duration_frames"], p["duration_s"]), "",
         "Claude không thiết kế các yếu tố này. HyperFrames sản xuất; mọi mục có trạng thái `proposed`/`open` cần bạn chốt trước.", ""]
    st = data["style"]
    L += ["## Định hướng đồ họa", "- Trạng thái: **%s**" % st.get("status", "open"),
          "- Hướng: %s" % (st.get("direction") or "_chưa chọn_")]
    for r in st.get("references") or []:
        L.append("- Tham chiếu: %s" % r)
    if st.get("notes"):
        L.append("- Ghi chú: %s" % st["notes"])
    sz = data.get("safe_zone")
    if sz:
        L += ["", "Vùng an toàn (tỉ lệ khung, gốc ở trên): x %.2f–%.2f, y %.2f–%.2f" % (sz["x0"], sz["x1"], sz["y_top"], sz["y_bottom"])]
    L += ["", "## Danh sách yếu tố (%d)" % len(data["elements"]), ""]
    # v3.0.1: groups in order of first appearance (a logo at 484 was listed after a tagline at 501)
    order = []
    for e in data["elements"]:
        if e.get("category") in CATEGORIES and e["category"] not in order:
            order.append(e["category"])
    for cat in order:
        label = CATEGORIES[cat]
        els = [e for e in data["elements"] if e.get("category") == cat]
        if not els:
            continue
        L += ["### %s (%d)" % (label, len(els)), "",
              "| ID | Thời điểm | Nội dung | Vị trí | Bậc | Hoạt ảnh (vào → ra · cảm giác) | Neo | Trạng thái |", "|---|---|---|---|---|---|---|---|"]
        notes = [(e.get("id"), e.get("notes")) for e in els if e.get("notes")]
        for e in els:
            t = e.get("text") or {}
            txt = " / ".join(x for x in (t.get("vi"), t.get("en")) if x).replace("\n", " ⏎ ") or "—"
            pos = e.get("position") or {}
            ps = "%s (%.2f, %.2f)" % (pos.get("anchor", ""), pos.get("x", 0), pos.get("y", 0)) if pos.get("x") is not None else "—"
            an = e.get("animation") or {}
            ans = "%s → %s · %s" % (an.get("in", "—"), an.get("out", "—"), an.get("feel", "—"))
            a = e.get("anchored_to") or {}
            L.append("| %s | %s → %s (%.2fs) | %s | %s | %s | %s | %s %s | %s%s |" % (
                e.get("id"), e.get("start_tc", ""), e.get("end_tc", ""), e.get("duration_s", 0), txt, ps,
                e.get("hierarchy", "—"), ans, (a.get("kind") or "—") + ":", a.get("ref", ""), e.get("status"),
                " (Claude đề xuất)" if e.get("source") == "claude_proposal" else ""))
        for i_, n_ in notes:
            L.append("- `%s`: %s" % (i_, n_))
        L.append("")
    if data["audio_events"]:
        L += ["## Âm thanh đã có trong bản dựng (để đồng bộ, không phải để thay)", ""]
        for a in data["audio_events"]:
            L.append("- khung %s (%s): %s %s" % (a.get("frame"), tc(a.get("frame", 0), data["project"]["fps"] or 24), a.get("role", ""), a.get("file", "")))
        L.append("")
    if data["issues"]:
        L += ["## Cần xử lý trước khi chốt", ""]
        for i in data["issues"]:
            L.append("- **%s** `%s` — %s" % (i["severity"], i["id"], i["issue"]))
        L.append("")
    L += ["## Thông số kỹ thuật", "- Khung hình 0 = khung đầu tiên của Final; mọi mốc là khung hình của timeline.",
          "- Cắt: %s" % (", ".join(str(c) for c in data["cuts"]) or "—"),
          "- Nhịp: %s" % (", ".join(str(c) for c in data["beats"]) or "—"),
          "- Video tham chiếu: %s" % (data["reference_video"]["path"] or "_chưa có — người dùng xuất bản proxy_"), ""]
    return "\n".join(L)


# v3.7.0 layers: kind -> (name part, Vietnamese label, Resolve clip colour, track group). Green = music and
# Yellow = SFX in this pack, so graphics use other colours.
LAYER_KINDS = {
    "title_main": ("TieuDeChinh", "Tiêu đề chính", "Orange", "title"),
    "opening_text": ("MoDau", "Văn bản mở đầu", "Apricot", "title"),
    "section_title": ("TieuDePhan", "Tiêu đề phần", "Purple", "title"),
    "onscreen_text": ("ChuTrenHinh", "Chữ trên hình", "Blue", "text"),
    "caption": ("ChuThich", "Chú thích", "Navy", "text"),
    "subtitle": ("PhuDe", "Phụ đề", "Teal", "sub"),
    "motion_graphic": ("DoHoaDong", "Đồ họa chuyển động", "Pink", "motion"),
    "supporting_visual": ("HoTro", "Hình hỗ trợ", "Tan", "motion"),
}
# bottom -> top: motion graphics under text, subtitles on top
TRACK_GROUPS = [("motion", "ĐH Chuyển động"), ("text", "ĐH Chữ"), ("title", "ĐH Tiêu đề"), ("sub", "ĐH Phụ đề")]
FIRST_GRAPHICS_TRACK = 3           # V1 footage, V2 B-roll
LAYER_DIR = "layers"               # inside the package: <package_dir>/layers/<name>.mov


def ascii_words(text, n=3, max_len=24):
    """'Hương Cảng về đêm' -> 'HuongCangVe' (no marks, CamelCase, first n words)."""
    import unicodedata
    t = unicodedata.normalize("NFD", (text or "").replace("đ", "d").replace("Đ", "D"))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    words = ["".join(ch for ch in w if ch.isalnum()) for w in t.split()][:n]
    return "".join(w[:1].upper() + w[1:].lower() for w in words if w)[:max_len] if words else ""


def plan_layers(data, package_dir=None, first_track=FIRST_GRAPHICS_TRACK):
    """-> {"layers": [...], "tracks": [{"index", "name"}], "solo_rows": [...], "media": [...]} for an APPROVED hand-over.
    One layer per element, named in start order; overlapping layers of one group go to the next lane of that group."""
    els = sorted([e for e in data.get("elements") or [] if e.get("start") is not None and e.get("end") is not None],
                 key=lambda e: (int(e["start"]), e.get("id", "")))
    layers, lanes = [], {}
    for i, e in enumerate(els, 1):
        part, label, colour, group = LAYER_KINDS.get(e.get("category"), ("DoHoa", "Đồ họa", "Brown", "motion"))
        t = e.get("text") or {}
        words = ascii_words(t.get("vi") or t.get("en") or "")
        name = "DH%02d_%s%s" % (i, part, ("_" + words) if words else "")
        ends = lanes.setdefault(group, [])
        lane = next((k for k, last in enumerate(ends) if int(e["start"]) >= last), None)
        if lane is None:
            ends.append(0)
            lane = len(ends) - 1
        ends[lane] = int(e["end"])
        layers.append({"id": e.get("id"), "name": name, "category": e.get("category"), "label": label, "colour": colour,
                       "group": group, "lane": lane, "start": int(e["start"]), "end": int(e["end"]),
                       "frames": int(e["end"]) - int(e["start"]), "file": "%s/%s.mov" % (LAYER_DIR, name)})
    tracks, idx, n = [], {}, first_track
    for g, gname in TRACK_GROUPS:
        for lane in range(len(lanes.get(g, []))):
            idx[(g, lane)] = n
            tracks.append({"index": n, "name": gname + ("" if lane == 0 else " %d" % (lane + 1))})
            n += 1
    base = (package_dir.rstrip("/") + "/") if package_dir else ""
    for L in layers:
        L["track"] = idx[(L["group"], L["lane"])]
        L["track_name"] = next(t["name"] for t in tracks if t["index"] == L["track"])
    media = [{"path": base + L["file"], "bin": "Đồ họa (HyperFrames)", "kind": "video", "track": L["track"],
              "track_name": L["track_name"], "record": L["start"], "name": L["name"], "color": L["colour"]} for L in layers]
    return {"layers": layers, "tracks": tracks, "solo_rows": [{"name": L["name"], "solo": L["name"]} for L in layers],
            "media": media}


NTSC = {23.976: "24000/1001", 29.97: "30000/1001", 59.94: "60000/1001", 47.952: "48000/1001", 119.88: "120000/1001"}


def render_fps(fps):
    """v3.9.0: HyperFrames' `--fps` takes a rational (`30000/1001`), so the overlay renders at the Final's exact rate.
    -> (fps value for --fps as a string, frames per second as a float, conform needed: always False now)."""
    f = float(fps or 0) or 30.0
    for k, v in NTSC.items():
        if abs(f - k) < 0.01:
            num, den = v.split("/")
            return v, int(num) / float(int(den)), False
    return str(int(round(f))) if abs(f - round(f)) < 1e-3 else ("%g" % f), f, False


def hf_request(data, stills=None, pin=HF_PIN):
    """-> Markdown: the one request Motion Studio hands to HyperFrames (references/handoff.md shape, overlay mode).
    None when the hand-over is not APPROVED: Phase 11 never starts on proposed or open items."""
    if data.get("status") != "APPROVED":
        return None
    p, st, stills = data["project"], data.get("style") or {}, stills or {}
    r_arg, r, conformed = render_fps(p.get("fps"))
    pin = (data.get("hf_version") or pin)
    n = int(p.get("duration_frames") or 0)
    sec = lambda f: "%.3f" % (int(f) / float(r))
    title = p.get("title") or "Project"
    texts = [e for e in data["elements"] if e.get("category") in TEXT_CATEGORIES]
    main = next((e for e in texts if e.get("category") == "title_main"), texts[0] if texts else None)
    msg = " / ".join(x for x in ((main or {}).get("text") or {}).values() if x) or "see the element list"
    langs = sorted({k for e in texts for k, v in (e.get("text") or {}).items() if v}, key=lambda k: (k != "vi", k))
    L = ["# HyperFrames request — %s (Phase 11, overlay)" % title, "",
         "Motion Studio: this request comes from resolve-editor Phase 10 and is APPROVED by the user. Skip step 2 (Describe):",
         "every answer is here. Pass the block below to the `hyperframes` skill as step 3 says, then build, review and export.",
         "HyperFrames %s or newer flow: no storylines (the story is the locked edit), SPEC.md, check, snapshot review." % pin, "",
         "```",
         "Make a new video (fresh creation) with HyperFrames.", "",
         "What it is: a transparent graphics overlay for the edited film \"%s\" (DaVinci Resolve timeline %s). It is laid over"
         % (title, p.get("final_timeline")),
         "the footage on video track 3 and above; it contains only the graphic elements listed below.",
         "The one message: \"%s\"" % msg,
         "Offer / numbers: none",
         "Who watches and where: viewers of %s; aspect %sx%s" % (p.get("format") or "short-form video", p.get("width"), p.get("height")),
         "Length: %ss exactly = %d frames at %s fps (root data-duration; data-fps %s). Every time below is in seconds from 0" % (sec(n), n, r_arg, r_arg),
         "(frame / %s), rounded to the millisecond; the frame numbers in brackets are the truth." % r_arg,
         "Words on screen in: %s, exactly as quoted below" % (", ".join(langs) or "vi"),
         "Talk to me in: Vietnamese (every question, the SPEC summary, progress and the Studio tips)",
         "Preview: as soon as the Studio preview runs, give me its link exactly as the preview command prints it (http://localhost:...)",
         "  before anything else, without my asking; repeat it after every change, and send the new one after a restart",
         "Material: stills of the Final behind the elements (judge placement and readability on them; never put them in the render):"]
    if stills:
        for k in sorted(stills):
            L.append("  %s: %s" % (k, stills[k]))
    else:
        L.append("  none (ask the user for 3-5 stills of the Final, or work from the safe zone only)")
    L += ["Website: don't capture", ""]
    if st.get("look"):
        L.append("Design spec: they have one: the look \"%s\" in Motion Studio's library (styles.mjs path \"%s\"). Adopt it as"
                 " frame.md at the project root after init, and treat it as brand truth." % (st["look"], st["look"]))
    elif st.get("direction"):
        L.append("Design spec: none saved yet. Direction approved in words: %s.%s Motion Studio step 1 turns it into a look first."
                 % (st["direction"], (" References: " + ", ".join(st.get("references") or [])) if st.get("references") else ""))
    else:
        L.append("Design spec: none; Motion Studio step 1 picks one with the user (gallery or a reference).")
    L += ["", "Overlay rules:"] + ["- " + x for x in OVERLAY_RULES]
    sz = data.get("safe_zone")
    if sz:
        L.append("- Safe zone (fractions of the frame, y from the top): x %.2f-%.2f, y %.2f-%.2f" % (sz["x0"], sz["x1"], sz["y_top"], sz["y_bottom"]))
    L += ["", "Elements (all approved by the user):"]
    for e in data["elements"]:
        t = e.get("text") or {}
        txt = " / ".join('\"%s\"' % v.replace("\n", " | ") for v in (t.get("vi"), t.get("en")) if v) or "(no text)"
        pos = e.get("position") or {}
        an = e.get("animation") or {}
        a = e.get("anchored_to") or {}
        L.append("- %s · %s · %s-%s s (frames %s-%s) · %s · %s (x %.2f, y %.2f) · hierarchy %s · in: %s · out: %s · feel: %s · anchor: %s %s%s%s" % (
            e.get("id"), e.get("category"), sec(e["start"]), sec(e["end"]), e["start"], e["end"], txt,
            pos.get("anchor", "-"), float(pos.get("x", .5)), float(pos.get("y", .5)), e.get("hierarchy", "-"),
            an.get("in", "-"), an.get("out", "-"), an.get("feel", "-"), a.get("kind", "-"), a.get("ref", ""),
            (" · still: " + stills[e["id"]]) if e.get("id") in stills else "",
            (" · note: " + e["notes"]) if e.get("notes") else ""))
    if data.get("audio_events"):
        L += ["", "Sound already in the edit (time graphic hits to these; add no sound):"]
        for ev in data["audio_events"]:
            L.append("- %s s (frame %s): %s %s" % (sec(ev.get("frame", 0)), ev.get("frame"), ev.get("role", ""), ev.get("file", "")))
    lp = plan_layers(data)
    L += ["", "Separate named layers (user rule: every object is refined later in DaVinci, one clip each):",
          "- Build every element as its own top-level layer element with id and data-layer = its layer name below; no",
          "  element shares a layer with another, and nothing outside these layers is drawn.",
          "- Add a composition variable `solo` (string, default empty, label \"Chỉ hiện lớp\"): read it once at init with",
          "  getVariables(); when it holds a layer name, set opacity 0 on the inner wrapper of every OTHER layer (never",
          "  display/visibility on a .clip, never remove one, so no timing shifts); empty shows every layer.",
          "- One kind per track: data-track-kind=\"graphics\" on the title/text/motion hosts, \"captions\" on the one host holding",
          "  every subtitle; more than 3 timed layers on one track → give that group its own sub-composition.",
          "- Layer names (keep them exactly):"]
    for x in lp["layers"]:
        L.append("  %s = %s (%s, %s-%s s)" % (x["name"], x["id"], x["label"], sec(x["start"]), sec(x["end"])))
    L += ["", "Editable copy: make every word of every element a composition variable, so each is one field in Studio's",
          "Variables panel. Ids = element id + language (e01_vi, e01_en); Vietnamese labels (\"Tiêu đề chính\", \"Phụ đề 03\").", "",
          "Export (only when I say so, after check --json is clean and snapshot --review is done): MOV with transparency,",
          "%s fps, %dx%s, exactly %d frames. The whole overlay for review:" % (r_arg, int(p.get("width") or 0), p.get("height"), n),
          "  npx hyperframes@%s render --format mov --fps %s --quality delivery --output renders/%s_DoHoa.mov" % (pin, r_arg, title),
          "Then one MOV per layer, full length (rows = layers_<title>.json \"solo_rows\"):",
          "  npx hyperframes@%s render --batch layers_rows.json --format mov --fps %s --quality delivery --output \"renders/layers_full/{name}.mov\" --strict-variables" % (pin, r_arg),
          "(resolve-editor's Phase 11 card trims each to its span and checks it).",
          "",
          "Run shape: storylines no (the story and the timing are fixed above), storyboard no.",
          "Write SPEC.md from this request, ask only what it leaves open, then show me the SPEC summary to confirm before building.",
          "```", ""]
    return "\n".join(L)


def start_phase11(data, package_dir):
    """-> Markdown for START_PHASE11.md: the line that resumes the Phase 11 build later, in the same chat."""
    t = data["project"].get("title") or "Project"
    line = 'Làm đồ họa HyperFrames (Phase 11) cho video "%s" theo gói: %s/HF_REQUEST_%s.md' % (t, package_dir, t)
    return "\n".join([
        "# Phase 11 — làm tiếp phần đồ họa (cùng cuộc trò chuyện)", "",
        "Final đã xong, phong cách đã chọn trong thư viện mẫu, và bản bàn giao đã APPROVED. Đồ họa được làm bằng skill `%s`" % MOTION_STUDIO,
        "(HyperFrames mới nhất lúc cài, %s trở lên), ngay trong cuộc trò chuyện dựng video này: không cần mở cửa sổ mới hay gõ /clear." % HF_PIN, "",
        "Khi muốn làm tiếp, gửi đúng dòng này trong cuộc trò chuyện dựng video:", "", "    " + line, "",
        "Claude chạy phần dựng HyperFrames bằng một agent bộ nhớ sạch ngay trong cuộc trò chuyện (tiết kiệm usage), và gửi",
        "link xem trước (preview) của HyperFrames Studio cho bạn ngay khi nó chạy.", "",
        "Gói gồm: `HF_REQUEST_%s.md` (yêu cầu cho HyperFrames), `handoff_%s.md/.json` (bản bàn giao), `stills/` (ảnh Final)." % (t, t), ""])


def write_files(data, out_dir, stills=None):
    import json, os
    os.makedirs(out_dir, exist_ok=True)
    t = data["project"]["title"] or "Project"
    jp = os.path.join(out_dir, "handoff_%s.json" % t)
    mp = os.path.join(out_dir, "handoff_%s.md" % t)
    json.dump(data, open(jp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(mp, "w", encoding="utf-8").write(to_markdown(data))
    out = [jp, mp]
    req = hf_request(data, stills)
    if req:
        rp = os.path.join(out_dir, "HF_REQUEST_%s.md" % t)
        sp = os.path.join(out_dir, "START_PHASE11.md")
        open(rp, "w", encoding="utf-8").write(req)
        open(sp, "w", encoding="utf-8").write(start_phase11(data, out_dir))
        lp_path = os.path.join(out_dir, "layers_%s.json" % t)
        lp = plan_layers(data, out_dir)
        pj = data["project"]
        open(os.path.join(out_dir, "layers_rows.json"), "w", encoding="utf-8").write(json.dumps(lp["solo_rows"], ensure_ascii=False, indent=1))
        lp.update({"title": t, "fps": pj.get("fps"), "render_fps": render_fps(pj.get("fps"))[1], "render_fps_arg": render_fps(pj.get("fps"))[0],
                   "duration_frames": pj.get("duration_frames"), "width": pj.get("width"), "height": pj.get("height")})
        json.dump(lp, open(lp_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        out += [rp, sp, lp_path]
    return out


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

SPEC = {}
if _IN_RESOLVE:
    result = build_handoff(SPEC)
    result["markdown"] = to_markdown(result)
    result["hf_request"] = hf_request(result, SPEC.get("stills"))          # None until APPROVED
    if result["hf_request"] and SPEC.get("package_dir"):
        result["start_phase11"] = start_phase11(result, SPEC["package_dir"])
        result["layers"] = plan_layers(result, SPEC["package_dir"])
elif __name__ == "__main__":
    import json, sys
    spec = json.load(open(sys.argv[1], encoding="utf-8")) if len(sys.argv) > 1 else SPEC
    d = build_handoff(spec)
    if len(sys.argv) > 2:
        print(json.dumps({"status": d["status"], "files": write_files(d, sys.argv[2], spec.get("stills")), "issues": len(d["issues"])}, ensure_ascii=False))
    else:
        print(json.dumps(d, ensure_ascii=False, indent=1))
