# build_from_blueprint.py — builds a NEW draft timeline from a blueprint, then reads it back.
# Paste into run_script (sandbox is enough). Edit only the CONFIG block.
# Never touches existing timelines, source media or project settings.
#
# Frame conventions in the blueprint:
#   src_in / src_out : source frames, src_out EXCLUSIVE (duration = src_out - src_in)
#   record           : timeline frame offset from timeline start, or "auto"
#                      ("auto" = right after the previous item on the same track)
#   speed            : percent (100 = normal). Source needed for a slot of N frames
#                      at S % is N * S / 100 frames; plan src ranges accordingly.
#   Source frames are in the CLIP's own fps. A 50 fps clip in a 24 fps timeline plays
#   in real time, so 50 source frames = 24 timeline frames. For frame-for-frame slow
#   motion of high-fps footage use speed = timeline_fps / clip_fps * 100 (24/50 -> 48).
# endFrame convention: measured live on Resolve 21.1.1 (2026-10-24) as EXCLUSIVE
# (startFrame 0, endFrame 142 -> 142 source frames; GetSourceEndFrame() then returns 141,
# the last frame used). The script sends src_out as endFrame and re-checks the first
# same-rate append; if a future build behaves inclusively it re-appends with src_out - 1.

# ---- CONFIG ----------------------------------------------------------------
BLUEPRINT = {
    "timeline_name": "Draft_Example_v01",
    "expected_fps": 30,            # stop if the new timeline's fps differs
    "target_frames": 450,
    "landscape": "fill",           # fill (user default since 2026-10-24) | fit | none ; reframe fill with props Pan
                                   # (Pan is NOT pixels: ~300 shifts a 16:9 fill by ~1/3 frame width,
                                   #  black edges appear beyond about +-950 — check a still)
    "retime": "optical_flow",      # for speed segments: optical_flow | frame_blend | nearest
    # "audio_xfade": {"track": 1, "frames": 2},   # v2.3 optional: short audio crossfade on every butt join of
    #                              # that track (kills clicks at jump cuts; transcript_cut.py sets it)
    # "resolution": [2160, 3840],  # v2.2 optional: custom timeline size (9:16 2160x3840 / 1080x1920,
    #                              # 4:5 1080x1350, 1:1 1080x1080, 16:9 1920x1080); omitted = project setting
    "video_tracks": 3,
    "audio_tracks": 3,
    "track_names": {"video": {"1": "FOOTAGE", "2": "B-ROLL", "3": "GRAPHICS A"},
                    "audio": {"1": "DIALOGUE", "2": "MUSIC", "3": "SFX"}},
    "segments": [
        # {"id": "s01", "clip": "C0001.MP4", "src_in": 120, "src_out": 210,
        #  "track": 1, "record": "auto", "media": "video",   # video | audio | both
        #  "section": "hook", "purpose": "open on motion",
        #  "props": {"ZoomX": 1.12, "ZoomY": 1.12}, "speed": 100,
        #  "ramp": [{"frames": 40, "speed": 200}, {"frames": 10, "speed": 100}, {"frames": 30, "speed": 30}],
        #  "fades": {"FadeIn": 0, "FadeOut": 0},
        #  "marker": {"color": "Blue", "name": "HOOK", "note": "open on motion"}},
    ],
    "audio": [
        # {"id": "m01", "clip": "mixkit-silent-descent.mp3", "src_in": 0, "src_out": 450,
        #  "track": 2, "record": 0, "volume": -12.0, "fades": {"FadeIn": 6, "FadeOut": 36}},
    ],
}
DRY_RUN = False   # True = resolve clips and validate only, no timeline is created
RETIME_FOR_DUR = True   # when a "dur" target forces a speed change on a 100 % clip, use the blueprint retime
# v3.3.0 (user request 2026-10-27, UNTESTED live): after the build, video items are renamed left to right
# (V1 shot_01, shot_02 …; V2 broll_01 …) and audio items get a colour per role so sound and music differ.
ITEM_NAMES = {1: "shot", 2: "broll"}            # video track -> name prefix; {} = keep the clip names
CLIP_COLORS = {"music": "Green", "sfx": "Yellow"}
MUSIC_TRACKS = [2, 5]
SFX_TRACKS = [3, 4]
# ---------------------------------------------------------------------------


def expand_ramps(bp):
    """Speed ramps: a segment with "ramp": [{"frames": source frames, "speed": %}, ...] becomes
    consecutive sub-segments of the same clip (source continuous, speeds stepped). Each step is a
    separate item; with optical flow the motion stays continuous and the change of pace reads as a
    ramp (Resolve's retime curves cannot be scripted). Frames of all steps must add up to
    src_out - src_in. FadeIn goes to the first step, FadeOut and the marker to the first/last."""
    out = dict(bp)
    segs = []
    for s in bp.get("segments", []):
        steps = s.get("ramp")
        if not steps:
            segs.append(s)
            continue
        a = s["src_in"]
        total = sum(int(x["frames"]) for x in steps)
        if total != s["src_out"] - s["src_in"]:
            segs.append(dict(s, ramp=None, _ramp_error="ramp frames %d != src range %d" % (total, s["src_out"] - s["src_in"])))
            continue
        for i, st in enumerate(steps):
            sub = {k: v for k, v in s.items() if k not in ("ramp", "fades", "marker")}
            sub.update({"id": "%s_r%d" % (s["id"], i + 1), "src_in": a, "src_out": a + int(st["frames"]),
                        "speed": float(st["speed"]), "ramp_of": s["id"]})
            if i > 0:
                sub["record"] = "auto"
            fades = dict(s.get("fades") or {})
            f = {}
            if i == 0 and fades.get("FadeIn"):
                f["FadeIn"] = fades["FadeIn"]
            if i == len(steps) - 1 and fades.get("FadeOut"):
                f["FadeOut"] = fades["FadeOut"]
            if f:
                sub["fades"] = f
            if i == 0 and s.get("marker"):
                sub["marker"] = s["marker"]
            if i == len(steps) - 1 and s.get("dur"):
                sub["dur_total_of_ramp"] = int(s["dur"])
            segs.append(sub)
            a += int(st["frames"])
    out["segments"] = segs
    return out


def fill_geometry(src_w, src_h, tl_w, tl_h):
    """How a source sits in the timeline with SCALE_FILL. Returns the reframing axis ("pan" when the
    source is wider than the frame, "tilt" when taller), the visible fraction of the source along that
    axis, and the fill magnification relative to fit. 16:9 in 9:16 -> pan, 0.316 visible (measured)."""
    sa, ta = float(src_w) / src_h, float(tl_w) / tl_h
    if abs(sa - ta) < 1e-3:
        return {"axis": None, "visible": 1.0, "fill_over_fit": 1.0}
    if sa > ta:
        return {"axis": "pan", "visible": round(ta / sa, 4), "fill_over_fit": round(sa / ta, 4)}
    return {"axis": "tilt", "visible": round(sa / ta, 4), "fill_over_fit": round(ta / sa, 4)}


def butt_joins(rows, tol=0):
    """rows [(start, end)] of one track in timeline order -> indexes i where item i ends exactly where item
    i + 1 starts (a cut that can take a crossfade)."""
    return [i for i in range(len(rows) - 1) if abs(rows[i][1] - rows[i + 1][0]) <= tol]


XFADE_TYPES = ["Cross Fade 0 dB", "Cross Fade +3 dB", "Cross Fade -3 dB"]


def sequence_names(n, prefix):
    """n items left to right -> ["shot_01", "shot_02", ...]; three digits from 100 items on."""
    width = max(2, len(str(n)))
    return ["%s_%0*d" % (prefix, width, i + 1) for i in range(n)]


def grouped_names(keys, prefix):
    """v3.5.0: items left to right with the blueprint segment each came from -> names; the steps of one speed ramp
    share a number with letters (shot_01a, shot_01b, shot_01c), other items get plain numbers."""
    groups = []
    for k in keys:
        if groups and groups[-1][0] == k:
            groups[-1][1] += 1
        else:
            groups.append([k, 1])
    width = max(2, len(str(len(groups))))
    out = []
    for n, (_, count) in enumerate(groups, 1):
        base = "%s_%0*d" % (prefix, width, n)
        out += [base] if count == 1 else [base + chr(97 + i) for i in range(count)]
    return out


def segment_keys(bp, track):
    """Blueprint segment of each item on `track`, in record order (ramp steps carry their ramp's id)."""
    segs = [s for s in bp.get("segments", []) if int(s.get("track", 1)) == track and s.get("media", "video") != "audio"]
    if all(isinstance(s.get("record"), (int, float)) for s in segs):
        segs = sorted(segs, key=lambda s: s["record"])
    return [s.get("ramp_of") or s.get("id") for s in segs]


def audio_role_color(track, colors=None, music_tracks=None, sfx_tracks=None):
    """Clip colour for an audio item on `track` (music vs sound effects), or None."""
    colors = CLIP_COLORS if colors is None else colors
    if track in (MUSIC_TRACKS if music_tracks is None else music_tracks):
        return colors.get("music")
    if track in (SFX_TRACKS if sfx_tracks is None else sfx_tracks):
        return colors.get("sfx")
    return None


def label_timeline(tl, bp=None):
    """Rename video items left to right (ITEM_NAMES) and colour audio items by role. -> report dict."""
    rep = {"renamed": 0, "coloured": 0, "failed": []}
    for track, prefix in sorted(ITEM_NAMES.items()):
        items = sorted(tl.GetItemListInTrack("video", int(track)) or [], key=lambda i: i.GetStart())
        keys = segment_keys(bp, int(track)) if bp else []
        names = grouped_names(keys, prefix) if len(keys) == len(items) else sequence_names(len(items), prefix)
        for it, name in zip(items, names):
            if hasattr(it, "SetName") and it.SetName(name):
                rep["renamed"] += 1
            else:
                rep["failed"].append("V%s %s" % (track, name))
    for track in range(1, (tl.GetTrackCount("audio") or 0) + 1):
        col = audio_role_color(track)
        for it in (tl.GetItemListInTrack("audio", track) or []) if col else []:
            if hasattr(it, "SetClipColor") and it.SetClipColor(col):
                rep["coloured"] += 1
            else:
                rep["failed"].append("A%d colour" % track)
    return rep


def timeline_len(src_frames, clip_fps, tl_fps, speed=100):
    """Timeline frames produced by src_frames of a clip at clip_fps played at speed %."""
    ratio = (float(tl_fps) / float(clip_fps)) if clip_fps and tl_fps else 1.0
    return src_frames * ratio * 100.0 / (speed or 100)


def validate_blueprint(bp, clip_frames):
    """Pure check. clip_frames: {clip_key: total_frames or None}. Returns list of problems."""
    problems = []
    seen = set()
    for kind in ("segments", "audio"):
        for s in bp.get(kind, []):
            sid = s.get("id", "?")
            if sid in seen:
                problems.append("%s: duplicate id" % sid)
            seen.add(sid)
            a, b = s.get("src_in"), s.get("src_out")
            if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
                problems.append("%s: src_in/src_out missing" % sid)
                continue
            if b <= a:
                problems.append("%s: src_out <= src_in" % sid)
            total = clip_frames.get(s.get("clip"))
            if total is not None and (a < 0 or b > total):
                problems.append("%s: range %s-%s outside source 0-%s" % (sid, a, b, total))
            if s.get("_ramp_error"):
                problems.append("%s: %s" % (sid, s["_ramp_error"]))
            sp = s.get("speed", 100)
            if not (0 <= sp <= 1000):
                problems.append("%s: speed %s out of range" % (sid, sp))
    return problems


def planned_length(bp, clip_fps=None, tl_fps=None):
    """Timeline length implied by V1 segments placed 'auto' or by record offsets.
    clip_fps: {clip_key: fps}; tl_fps: timeline fps (both optional = same rate)."""
    end = 0
    cursor = {}
    ramp_done = {}          # ramp id -> timeline frames of its earlier steps
    clip_fps = clip_fps or {}
    for s in bp.get("segments", []):
        tr = s.get("track", 1)
        dur = timeline_len(s["src_out"] - s["src_in"], clip_fps.get(s.get("clip")), tl_fps, s.get("speed", 100))
        rid = s.get("ramp_of")
        if rid:             # "dur" of a ramp applies to the whole ramp (set on its last step)
            if s.get("dur_total_of_ramp"):
                dur = s["dur_total_of_ramp"] - ramp_done.get(rid, 0)
            ramp_done[rid] = ramp_done.get(rid, 0) + dur
        elif s.get("dur"):
            dur = s["dur"]
        rec = s.get("record", "auto")
        start = cursor.get(tr, 0) if rec == "auto" else rec
        cursor[tr] = start + dur
        if tr == 1:
            end = max(end, start + dur)
    return int(round(end))


def _find_clips(folder, out):
    for c in folder.GetClipList() or []:
        out.append(c)
    for sub in folder.GetSubFolderList() or []:
        _find_clips(sub, out)
    return out


def _clip_index(mp):
    idx = {}
    for c in _find_clips(mp.GetRootFolder(), []):
        props = c.GetClipProperty() or {}
        for key in (c.GetName(), props.get("File Name"), props.get("File Path"), c.GetMediaId()):
            if key and key not in idx:
                idx[key] = c
    return idx


def _fps_of(c):
    try:
        return float(c.GetClipProperty("FPS"))
    except Exception:
        return None


def _frames_of(c):
    try:
        return int(float(c.GetClipProperty("Frames")))
    except Exception:
        return None


def _is_landscape(c):
    res = str(c.GetClipProperty("Resolution") or "")
    try:
        w, h = [int(v) for v in res.lower().split("x")[:2]]
        return w > h
    except ValueError:
        return False


def _unique_name(project, name):
    names = set()
    for i in range(1, (project.GetTimelineCount() or 0) + 1):
        t = project.GetTimelineByIndex(i)
        if t:
            names.add(t.GetName())
    if name not in names:
        return name
    base, n = name, 2
    if "_v" in name and name.rsplit("_v", 1)[1].isdigit():
        base, n = name.rsplit("_v", 1)[0], int(name.rsplit("_v", 1)[1]) + 1
        while "%s_v%02d" % (base, n) in names:
            n += 1
        return "%s_v%02d" % (base, n)
    while "%s_%d" % (base, n) in names:
        n += 1
    return "%s_%d" % (base, n)


def _track_end(tl, ttype, idx):
    items = tl.GetItemListInTrack(ttype, idx) or []
    return max([it.GetEnd() for it in items], default=tl.GetStartFrame())


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    log, errors = [], []
    mp = project.GetMediaPool()
    idx = _clip_index(mp)
    bp = expand_ramps(BLUEPRINT)
    rows = bp.get("segments", []) + bp.get("audio", [])
    missing = sorted({r["clip"] for r in rows if r.get("clip") not in idx})
    frames = {r["clip"]: _frames_of(idx[r["clip"]]) for r in rows if r.get("clip") in idx}
    problems = validate_blueprint(bp, frames)
    if missing:
        problems.append("clips not found in Media Pool: %s" % ", ".join(missing))
    cfps = {r["clip"]: _fps_of(idx[r["clip"]]) for r in rows if r.get("clip") in idx}
    result = {"planned_frames_at_expected_fps": planned_length(bp, cfps, bp.get("expected_fps")),
              "target_frames": bp.get("target_frames"), "problems": problems}
    if problems or DRY_RUN:
        result["status"] = "STOPPED_BEFORE_WRITE" if problems else "DRY_RUN_OK"
    else:
        name = _unique_name(project, bp["timeline_name"])
        tl = mp.CreateEmptyTimeline(name)
        if tl is None:
            result["status"] = "FAILED"
            result["problems"] = ["CreateEmptyTimeline returned None"]
        else:
            project.SetCurrentTimeline(tl)
            if bp.get("resolution"):
                w, h = [int(v) for v in bp["resolution"]]
                tl.SetSetting("useCustomSettings", "1")
                for key, val in (("timelineResolutionWidth", w), ("timelineResolutionHeight", h),
                                 ("timelineOutputResolutionWidth", w), ("timelineOutputResolutionHeight", h)):
                    tl.SetSetting(key, str(val))
                got_wh = (tl.GetSetting("timelineResolutionWidth"), tl.GetSetting("timelineResolutionHeight"))
                result["resolution"] = got_wh
                if [str(w), str(h)] != [str(x) for x in got_wh]:
                    errors.append("timeline resolution %s, wanted %dx%d (UNTESTED route: set it in the UI)" % (got_wh, w, h))
            fps = (tl.GetSettings() or {}).get("timelineFrameRate")
            result["timeline"] = name
            result["fps"] = fps
            if bp.get("expected_fps") and fps and abs(float(fps) - float(bp["expected_fps"])) > 0.01:
                errors.append("timeline fps %s != expected %s (timeline created, nothing appended)" % (fps, bp["expected_fps"]))
            else:
                for tt, key in (("video", "video_tracks"), ("audio", "audio_tracks")):
                    while (tl.GetTrackCount(tt) or 0) < bp.get(key, 1):
                        ok = tl.AddTrack(tt, "stereo") if tt == "audio" else tl.AddTrack(tt)
                        if not ok:
                            errors.append("AddTrack %s failed" % tt)
                            break
                for tt, names in (bp.get("track_names") or {}).items():
                    for i, nm in names.items():
                        tl.SetTrackName(tt, int(i), nm)

                start0 = tl.GetStartFrame()
                inclusive = None   # API convention for endFrame, detected on first append
                retime = {"optical_flow": "RETIME_OPTICAL_FLOW", "frame_blend": "RETIME_FRAME_BLEND",
                          "nearest": "RETIME_NEAREST"}.get(bp.get("retime"), None)
                placed = []
                ramp_start = {}
                for kind in ("segments", "audio"):
                    for s in bp.get(kind, []):
                        clip = idx[s["clip"]]
                        tr = int(s.get("track", 1))
                        media = s.get("media", "video" if kind == "segments" else "audio")
                        ttype = "audio" if media == "audio" else "video"
                        rec = s.get("record", "auto")
                        rec_frame = _track_end(tl, ttype, tr) if rec == "auto" else start0 + int(rec)
                        want = int(round(timeline_len(s["src_out"] - s["src_in"], _fps_of(clip), fps)))
                        info = {"mediaPoolItem": clip, "startFrame": float(s["src_in"]),
                                "trackIndex": tr, "recordFrame": float(rec_frame)}
                        if media == "video":
                            info["mediaType"] = 1
                        elif media == "audio":
                            info["mediaType"] = 2

                        def _append(incl):
                            d = dict(info)
                            d["endFrame"] = float(s["src_out"] - 1 if incl else s["src_out"])
                            return mp.AppendToTimeline([d]) or []

                        got = _append(False if inclusive is None else inclusive)
                        if not got:
                            errors.append("%s: AppendToTimeline returned nothing" % s["id"])
                            continue
                        same_rate = abs((_fps_of(clip) or fps) - float(fps)) < 0.01
                        dur = int(round(got[0].GetDuration()))
                        if inclusive is None and not same_rate:
                            # source and timeline rates differ: one source frame is not one
                            # timeline frame, so the convention cannot be measured here
                            if abs(dur - want) > 1:
                                errors.append("%s: length %s, expected ~%s (clip %s fps in %s fps timeline)"
                                              % (s["id"], dur, want, _fps_of(clip), fps))
                        elif inclusive is None:
                            if dur == want:
                                inclusive = False
                            elif dur == want + 1:
                                tl.DeleteClips(got, False)
                                inclusive = True
                                got = _append(True)
                                if not got:
                                    errors.append("%s: re-append failed" % s["id"])
                                    continue
                            else:
                                inclusive = False
                                errors.append("%s: first append length %s, expected %s" % (s["id"], dur, want))
                            log.append("endFrame convention: %s" % ("inclusive" if inclusive else "exclusive"))
                        main = [g for g in got if g.GetTrackTypeAndIndex()[0] == ttype] or got
                        for it in main:
                            props = dict(s.get("props") or {})
                            mode = bp.get("landscape") or ("fit" if bp.get("fit_landscape") else "fill")
                            if ttype == "video" and _is_landscape(clip) and "Scaling" not in props and mode in ("fill", "fit"):
                                props["Scaling"] = resolve.SCALE_FILL if mode == "fill" else resolve.SCALE_FIT
                            if "volume" in s:
                                props["AudioVolume"] = float(s["volume"])
                            sp = s.get("speed", 100)
                            if sp != 100 and retime and ttype == "video":
                                props["RetimeProcess"] = getattr(resolve, retime)
                            if props and not it.SetProperties(props):
                                errors.append("%s: SetProperties returned False for %s" % (s["id"], sorted(props)))
                            if sp != 100:
                                if not it.SetSpeed({"Percentage": float(sp), "RippleTimeline": True}):
                                    errors.append("%s: SetSpeed(%s) returned False" % (s["id"], sp))
                            want_dur = s.get("dur")
                            if s.get("ramp_of"):
                                ramp_start.setdefault(s["ramp_of"], rec_frame)
                                want_dur = None
                                if s.get("dur_total_of_ramp"):
                                    want_dur = int(s["dur_total_of_ramp"]) - int(rec_frame - ramp_start[s["ramp_of"]])
                            if want_dur and ttype == "video":
                                # Resolve rounds speed-changed lengths (measured: up to 3 frames per item,
                                # 13 frames over a 10-shot montage). Converge on the exact length so cuts
                                # stay on the music hits.
                                for _ in range(4):
                                    d_now = int(round(it.GetDuration()))
                                    if d_now == int(want_dur):
                                        break
                                    sp = float(sp) * d_now / float(want_dur)
                                    if RETIME_FOR_DUR and "RetimeProcess" not in props and retime:
                                        it.SetProperties({"RetimeProcess": getattr(resolve, retime)})
                                    it.SetSpeed({"Percentage": sp, "RippleTimeline": True})
                                if int(round(it.GetDuration())) != int(want_dur):
                                    errors.append("%s: length %s, wanted %s after speed fitting" % (s["id"], it.GetDuration(), want_dur))
                            if s.get("fades"):
                                if not it.SetFades(s["fades"]):
                                    errors.append("%s: SetFades returned False" % s["id"])
                        m = s.get("marker")
                        if m:
                            ok = tl.AddMarker(int(rec_frame - start0), m.get("color", "Blue"), m.get("name", s["id"]),
                                              m.get("note", s.get("purpose", "")), 1, "bp:" + s["id"])
                            if not ok:
                                errors.append("%s: AddMarker returned False" % s["id"])
                        placed.append(s["id"])

                # ---- short audio crossfades on butt joins (v2.3, UNTESTED live) ----
                xf = bp.get("audio_xfade")
                if xf:
                    items = sorted(tl.GetItemListInTrack("audio", int(xf.get("track", 1))) or [], key=lambda i: i.GetStart())
                    joins = butt_joins([(i.GetStart(), i.GetEnd()) for i in items])
                    made, failed, used_type = 0, [], None
                    for j in joins:
                        ok = None
                        for typ in ([used_type] if used_type else XFADE_TYPES):
                            for al in ("center", "left", "right"):
                                ok = items[j].AddTransition({"type": typ, "category": "audio", "position": "end",
                                                             "alignment": al, "duration": int(xf.get("frames", 2))})
                                if ok:
                                    used_type = typ
                                    break
                            if ok:
                                break
                        if ok:
                            made += 1
                        else:
                            failed.append(items[j].GetEnd() - start0)
                    result["audio_xfades"] = {"joins": len(joins), "made": made, "type": used_type,
                                              "failed_at": failed[:20]}
                    if failed:
                        log.append("audio crossfade not added at %d joins (no handles?): listen for clicks there" % len(failed))

                # ---- v3.3.0: shot_01 … names and music/SFX colours ----
                lab = label_timeline(tl, bp)
                result["labels"] = lab
                if lab["failed"]:
                    log.append("names/colours not set: %s" % lab["failed"][:10])

                # ---- read-back ----
                rb = {}
                for tt in ("video", "audio"):
                    for i in range(1, (tl.GetTrackCount(tt) or 0) + 1):
                        rb["%s%d" % (tt[0].upper(), i)] = [{
                            "name": it.GetName(), "start": it.GetStart() - start0, "end": it.GetEnd() - start0,
                            "dur": it.GetDuration(), "src_in": it.GetSourceStartFrame(),
                            "src_out": it.GetSourceEndFrame(), "speed": (it.GetSpeed() or {}).get("Percentage"),
                            "scaling": (it.GetProperties() or {}).get("Scaling"),
                            "zoom": (it.GetProperties() or {}).get("ZoomX"),
                            "volume": (it.GetProperties() or {}).get("AudioVolume") if tt == "audio" else None,
                            "fades": it.GetFades()} for it in (tl.GetItemListInTrack(tt, i) or [])]
                result["placed"] = placed
                result["readback"] = rb
                result["timeline_frames"] = tl.GetEndFrame() - start0
                result["markers"] = len(tl.GetMarkers() or {})
            result["log"] = log
            result["errors"] = errors
            result["status"] = "BUILT_WITH_ERRORS" if errors else "BUILT_READ_BACK"
