# edit_analysis.py — the lead editor's check of a blueprint before it is built (v2.4.0, offline-tested).
# Tool: run_script (sandbox is enough; reads clip fps from the Media Pool). Writes nothing.
# MODE "plan": for BLUEPRINT (same dict as build_from_blueprint.py, with the v2.4 fields of
#   references/montage-advanced.md §8) report:
#   - rationale: segments without a `cut` reason / with unknown vocabulary;
#   - pacing: ASL per section vs the tension arc (`bp["arc"]`), mechanical constant lengths, release after
#     the peak, metric acceleration in "metric" sections;
#   - equal runs (v2.8.0 addendum): EQUAL_RUN or more consecutive shots whose lengths differ by less than
#     EQUAL_TOL — "never the same shot length three times in a row"; metric sections are exempt (on purpose);
#   - music: cuts that claim `on: "beat"` but miss the beat grid (BEATS_S), the peak vs `bp["drop_frame"]`;
#   - continuity: jump cuts (same clip, same size), very large size jumps, screen-direction breaks inside a
#     section, eye-trace jumps across cuts (`subject_out` -> `subject_in`), parallel-editing intervals;
#   - split edits: segments with `audio_lead` (J) / `audio_tail` (L) expanded into picture + sound rows with
#     their own record frames -> `blueprint_split` ready for build_from_blueprint.py;
#   - repeats (v3.2.0): source ranges of one clip that overlap by > OVERLAP_FRAMES, the same `shot` or `grp` twice
#     (unless `callback`), the same `info` twice, runs of REPEAT_RUN with the same size/move/direction, segments
#     without `why` once the blueprint uses `shot`; and a runtime above MAX_RUNTIME_S (videos are at most 30 s);
#   - research (v2.5): runtime vs `bp["research"]["target_dur"]`, hook text length, opening ASL vs
#     `opening_asl_s` (v2.5.1), and whether the opening
#     delivers the researched hook pattern (segment `role` "payoff" / "answer"; references/trend-research.md).
# Findings are advice with reasons; the creative call stays with Claude and the user.

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
BLUEPRINT = {}
BEATS_S = []                 # music beat times in seconds, timeline-relative (music offset applied)
SPLIT_AUDIO_TRACK = 1        # dialogue/production sound track for split edits
EYE_TRACE_MAX = 0.45         # frame fraction; larger jumps must be marked intentional
ELLIPSIS_GAP_S = 10.0        # v2.7.0: same clip but this far apart in the source = a time cut, not a jump cut
EQUAL_RUN = 3                # v2.8.0 addendum: this many consecutive shots of (nearly) equal length are flagged
MAX_RUNTIME_S = 30.0         # v3.2.0: videos are at most 30 s (config workflow.max_runtime_s)
OVERLAP_FRAMES = 2           # v3.2.0: source overlap above this many frames of one clip is a repeat
REPEAT_RUN = 3               # v3.2.0: this many consecutive shots with the same size / move / direction are flagged
EQUAL_TOL = 0.12             # relative spread (max/min - 1) that still counts as "equal length"
# v3.4.0 (user request 2026-10-27, starting values): a real B-roll layer on V2 and more speed ramps / zoom moves
BROLL_MIN = 3                # at least this many V2 cutaways …
BROLL_EVERY_S = 4.0          # … or one every this many seconds of runtime, whichever is more (v3.5.0: was 6, too few)
BROLL_COVER = (0.25, 0.5)    # share of the runtime covered by V2 (v3.5.0: was 0.15–0.45)
BROLL_LEN_S = (0.4, 2.0)     # one cutaway's length
BROLL_TYPES = {"establish", "detail", "cutaway", "reaction", "texture", "process", "transition"}
RAMPS_PER_30S = 5            # hero ramp + ramp transitions (v3.5.1: was 3)
# v3.5.1 (TestSkill: ramps of 2–7 fast frames went by unnoticed): a ramp must last long enough to be felt
RAMP_STEP_MIN_S = 0.33       # every speed step on screen at least this long (≈ 10 frames at 30 fps)
RAMP_MIN_S = 1.5             # the whole ramped shot
RAMP_HOLD_MIN_S = 0.6        # the slow part (speed < 100 %) together
RAMP_CONTRAST = 2.5          # fastest / slowest step
ZOOM_SHARE = 0.6             # share of shots with a zoom move in `fx_plan`
ZOOM_FX = {"push", "pull", "punch", "snap", "zoomthrough", "zoomkeys", "reverse"}
# ---------------------------------------------------------------------------

import math

REASONS = {"emotion", "story", "rhythm", "eye_trace", "plane", "space", "idea", "reveal"}
CUT_ON = {"beat", "movement", "gaze", "breath", "sound", "contrast", "ellipsis", "structure"}
CUT_TYPES = {"hard", "action_match", "graphic_match", "eyeline_match", "smash", "jump", "cross", "insert",
             "ellipsis", "j_cut", "l_cut", "invisible", "dissolve"}
SIZES = ["EWS", "WS", "MWS", "MS", "MCU", "CU", "ECU", "INSERT"]
OPPOSITE = {"L": "R", "R": "L", "up": "down", "down": "up", "in": "out", "out": "in"}
INTENDED_JOLT = {"smash", "jump", "graphic_match", "dissolve", "invisible"}


def seg_len(s, clip_fps=None, tl_fps=None):
    """Timeline length of one unexpanded segment (dur wins; ramps sum their steps)."""
    if s.get("dur"):
        return int(s["dur"])
    ratio = (float(tl_fps) / float(clip_fps)) if clip_fps and tl_fps else 1.0
    if s.get("ramp"):
        return int(round(sum(st["frames"] * ratio * 100.0 / st["speed"] for st in s["ramp"])))
    return int(round((s["src_out"] - s["src_in"]) * ratio * 100.0 / (s.get("speed") or 100)))


def positions(bp, clip_fps=None, tl_fps=None, track=1):
    """[(segment, start, end)] for one track in blueprint order ("auto" = after the previous)."""
    clip_fps = clip_fps or {}
    out, cursor = [], 0
    for s in bp.get("segments", []):
        if int(s.get("track", 1)) != track:
            continue
        n = seg_len(s, clip_fps.get(s.get("clip")), tl_fps)
        start = cursor if s.get("record", "auto") == "auto" else int(s["record"])
        out.append((s, start, start + n))
        cursor = start + n
    return out


def rationale_report(segs):
    missing, bad = [], []
    for s in segs[1:]:                       # the first shot has no incoming cut
        c = s.get("cut") or {}
        if not c.get("reason") or not c.get("on") or not c.get("why"):
            missing.append(s["id"])
            continue
        r = set(c["reason"] if isinstance(c["reason"], list) else [c["reason"]])
        if r - REASONS or c["on"] not in CUT_ON or (c.get("type") and c["type"] not in CUT_TYPES):
            bad.append(s["id"])
    return {"missing_reason": missing, "unknown_vocabulary": bad,
            "coverage": round(1 - len(missing) / float(max(len(segs) - 1, 1)), 2)}


def pacing_report(pos, arc, fps):
    """ASL per section (in order of appearance) and disagreements with the tension arc."""
    order, lens = [], {}
    for s, a, b in pos:
        sec = s.get("section", "?")
        if sec not in lens:
            order.append(sec)
            lens[sec] = []
        lens[sec].append(b - a)
    allv = [b - a for _, a, b in pos]
    asl_all = sum(allv) / float(len(allv)) / fps if allv else 0
    rows, flags = [], []
    for sec in order:
        v = lens[sec]
        asl = sum(v) / float(len(v)) / fps
        cv = (math.sqrt(sum((x - sum(v) / len(v)) ** 2 for x in v) / len(v)) / (sum(v) / len(v))) if len(v) > 1 else None
        rows.append({"section": sec, "shots": len(v), "asl_s": round(asl, 2), "tension": arc.get(sec),
                     "variation": round(cv, 2) if cv is not None else None})
        if cv is not None and len(v) >= 4 and cv < 0.08 and "metric" not in sec:
            flags.append("%s: %d shots of nearly equal length — mechanical unless metric on purpose" % (sec, len(v)))
        if "metric" in sec and len(v) >= 3 and any(b > a * 1.05 for a, b in zip(v, v[1:])):
            flags.append("%s: metric section does not accelerate (lengths %s)" % (sec, v))
    known = [r for r in rows if r["tension"] is not None]
    # v2.7.0: tension is not cut speed. A section whose cuts are mostly emotion-driven (BoConCN: the payoff
    # with the child's smile, slow by design) is allowed to cut slower than a calmer one.
    emo = set()
    for r in rows:
        segs = [s for s, _, _ in pos if s.get("section") == r["section"]]
        if segs and sum(1 for s in segs if (s.get("cut") or {}).get("reason") == "emotion") * 2 >= len(segs):
            emo.add(r["section"])
    for x in known:
        for y in known:
            if x["tension"] - y["tension"] >= 2 and x["asl_s"] >= y["asl_s"] and x["section"] not in emo:
                flags.append("%s (tension %s) cuts no faster than %s (tension %s): ASL %.2f vs %.2f s" % (
                    x["section"], x["tension"], y["section"], y["tension"], x["asl_s"], y["asl_s"]))
    if known:
        peak = max(known, key=lambda r: r["tension"])["section"]
        idx = [i for i, (s, _, _) in enumerate(pos) if s.get("section") == peak]
        if idx and idx[-1] + 1 < len(pos):
            s, a, b = pos[idx[-1] + 1]
            if (b - a) / float(fps) < 1.5 * asl_all:
                flags.append("no release after the peak: %s is %.2f s (< 1.5 × ASL %.2f s)" % (s["id"], (b - a) / float(fps), asl_all))
    return {"asl_s": round(asl_all, 2), "sections": rows, "flags": flags}


def beat_report(pos, beats_s, fps, drop_frame=None, tol=1):
    beats = [int(round(t * fps)) for t in beats_s]
    off = []
    on_beat = 0
    for s, a, _ in pos[1:]:
        near = min((abs(a - b) for b in beats), default=None)
        if near is not None and near <= tol:
            on_beat += 1
        elif (s.get("cut") or {}).get("on") == "beat":
            off.append({"id": s["id"], "frame": a, "nearest_beat_off": near})
    res = {"cuts_on_grid": on_beat, "cuts": max(len(pos) - 1, 0), "claimed_beat_but_off": off}
    if drop_frame is not None:
        peak = [a for s, a, _ in pos if s.get("section") == "peak"]
        res["drop"] = {"drop_frame": drop_frame, "peak_start": peak[0] if peak else None,
                       "ok": bool(peak) and abs(peak[0] - drop_frame) <= tol}
    return res


def continuity_report(segs, eye_max=EYE_TRACE_MAX, clip_fps=None, ellipsis_gap_s=ELLIPSIS_GAP_S):
    flags = []
    clip_fps = clip_fps or {}
    for p, n in zip(segs, segs[1:]):
        c = n.get("cut") or {}
        typ = c.get("type")
        reasons = set(c.get("reason") or []) if isinstance(c.get("reason"), list) else {c.get("reason")}
        gap = None
        if p.get("clip") == n.get("clip") and p.get("src_out") is not None and n.get("src_in") is not None:
            gap = abs(n["src_in"] - p["src_out"]) / float(clip_fps.get(p["clip"]) or 25.0)
        if p.get("clip") == n.get("clip") and p.get("size") and p.get("size") == n.get("size") \
                and typ not in ("jump", "ellipsis", "action_match") and not (gap is not None and gap >= ellipsis_gap_s):
            pp, nn = p.get("props") or {}, n.get("props") or {}
            if pp.get("ZoomX", 1) == nn.get("ZoomX", 1) and pp.get("Pan", 0) == nn.get("Pan", 0):
                flags.append("%s→%s: same clip, same size %s — reads as a jump cut (change size/position, cover, or mark type 'jump')"
                             % (p["id"], n["id"], n["size"]))
        if p.get("size") in SIZES and n.get("size") in SIZES:
            step = abs(SIZES.index(p["size"]) - SIZES.index(n["size"]))
            if step >= 4 and not reasons & {"emotion", "reveal", "idea"}:
                flags.append("%s→%s: %s → %s is a big jump in scale — give it an emotion/reveal reason or add a middle size"
                             % (p["id"], n["id"], p["size"], n["size"]))
        if p.get("section") == n.get("section") and p.get("direction") and n.get("direction") \
                and OPPOSITE.get(p["direction"]) == n["direction"] and c.get("on") != "contrast" and typ != "smash":
            flags.append("%s→%s: screen direction flips (%s → %s) inside '%s' — keep it or mark the cut as contrast"
                         % (p["id"], n["id"], p["direction"], n["direction"], n.get("section")))
        if p.get("subject_out") and n.get("subject_in"):
            d = math.hypot(p["subject_out"][0] - n["subject_in"][0], p["subject_out"][1] - n["subject_in"][1])
            if d > eye_max and typ not in INTENDED_JOLT and not reasons & {"reveal", "idea"} and c.get("on") != "contrast":
                flags.append("%s→%s: eye-trace jumps %.2f of the frame — place the new subject near (%.2f, %.2f) or mark it intended"
                             % (p["id"], n["id"], d, p["subject_out"][0], p["subject_out"][1]))
    return flags


def parallel_report(segs, pos=None):
    """Runs of the same `thread` must shorten toward convergence (frames per run)."""
    runs = []
    lens = {s["id"]: b - a for s, a, b in (pos or [])}
    for s in segs:
        t = s.get("thread")
        if not t:
            continue
        if runs and runs[-1][0] == t:
            runs[-1][1] += lens.get(s["id"], 1)
        else:
            runs.append([t, lens.get(s["id"], 1)])
    flags = []
    if len(runs) >= 4:
        lengths = [r[1] for r in runs]
        pairs = [lengths[i] + lengths[i + 1] for i in range(0, len(lengths) - 1, 2)]
        if any(b > a * 1.1 for a, b in zip(pairs, pairs[1:])):
            flags.append("parallel threads do not tighten toward convergence: alternation lengths %s" % lengths)
    return {"alternations": len(runs), "flags": flags}


def expand_split_edits(bp, clip_fps=None, tl_fps=None, audio_track=SPLIT_AUDIO_TRACK):
    """J/L cuts -> picture rows (media video) + sound rows (media audio) with explicit record frames.
    The audio edit point between segment i-1 and i moves to start_i - audio_lead_i + audio_tail_(i-1); rows
    stay on one track without overlap. Only media 'both' segments at 100 % speed are split; others are kept
    and listed. Returns (new_bp, notes)."""
    clip_fps = clip_fps or {}
    pos = positions(bp, clip_fps, tl_fps)
    notes, segs_out, audio_out = [], [], list(bp.get("audio", []))
    split_ok = [s.get("media") == "both" and (s.get("speed", 100) == 100) and not s.get("ramp") for s, _, _ in pos]
    has_split = any(s.get("audio_lead") or s.get("audio_tail") for s, _, _ in pos)
    if not has_split:
        return bp, ["no audio_lead/audio_tail: nothing to split"]
    bounds = []
    for i, (s, a, b) in enumerate(pos):
        lead = int(s.get("audio_lead") or 0)
        tail_prev = int(pos[i - 1][0].get("audio_tail") or 0) if i else 0
        contiguous = i > 0 and pos[i - 1][2] == a
        bounds.append(max(0, a - lead + tail_prev) if (i and contiguous) else max(0, a - lead))
    for i, (s, a, b) in enumerate(pos):
        if not split_ok[i]:
            segs_out.append(dict(s))
            if s.get("audio_lead") or s.get("audio_tail"):
                notes.append("%s: not split (needs media 'both' at 100 %% speed)" % s["id"])
            continue
        ratio = float(clip_fps.get(s.get("clip")) or tl_fps or 1) / float(tl_fps or clip_fps.get(s.get("clip")) or 1)
        a_in = bounds[i]
        nxt_contig = i + 1 < len(pos) and pos[i + 1][1] == b
        a_out = bounds[i + 1] if nxt_contig else b + int(s.get("audio_tail") or 0)
        v = {k: x for k, x in s.items() if k not in ("audio_lead", "audio_tail")}
        v.update({"media": "video", "record": a})
        segs_out.append(v)
        src_in = s["src_in"] + int(round((a_in - a) * ratio))
        src_out = s["src_out"] + int(round((a_out - b) * ratio))
        if src_in < 0:
            notes.append("%s: J-cut of %d frames needs source before frame 0 — lead shortened" % (s["id"], a - a_in))
            a_in += int(math.ceil(-src_in / ratio))
            src_in = 0
        audio_out.append({"id": s["id"] + "_a", "clip": s["clip"], "src_in": src_in, "src_out": src_out,
                          "track": audio_track, "record": a_in, "media": "audio",
                          "split_of": s["id"], "lead": a - a_in, "tail": a_out - b})
    new = dict(bp)
    new["segments"] = segs_out
    new["audio"] = audio_out
    return new, notes


def research_report(bp, pos, fps):
    """v2.5: does the plan deliver what the Research Card promised (bp["research"], research_card.py)?"""
    r = bp.get("research") or {}
    flags = []
    total = pos[-1][2] if pos else 0
    target = r.get("target_dur")
    if target and total and abs(total / fps - target) > 0.25 * target:
        flags.append("runtime %.1f s is far from the researched target %.0f s" % (total / fps, target))
    hook = (r.get("hook_text") or "").split()
    if len(hook) > 7:
        flags.append("hook text has %d words (> 7): shorten it" % len(hook))
    starts = {s.get("role"): a for s, a, _ in reversed(pos) if s.get("role")}   # first occurrence wins
    pattern = r.get("hook_pattern")
    if pattern == "result_first" and starts.get("payoff", total) > 2 * fps:
        flags.append("hook 'result_first' but no segment with role 'payoff' starts in the first 2 s")
    if pattern == "question" and total and "answer" in starts and starts["answer"] < 0.65 * total:
        flags.append("hook 'question' but the answer arrives at %.0f %% of the runtime (keep it for the last act)"
                     % (100.0 * starts["answer"] / total))
    ref = r.get("opening_asl_s")
    opening = [(b - a) for _, a, b in pos if a < 3 * fps]
    if ref and opening:
        asl = sum(opening) / float(len(opening)) / fps
        if asl > 1.5 * ref:
            flags.append("opening ASL %.2f s is much slower than the researched %.2f s (first 3 s)" % (asl, ref))
    return {"pattern": pattern, "target_dur": target, "flags": flags}


def equal_run_report(pos, fps, run=None, tol=None):
    """Runs of >= `run` consecutive shots with nearly equal lengths (breathing rhythm check).
    Shots inside a section whose name contains "metric" are skipped (equal lengths there are the point)."""
    run = run or EQUAL_RUN
    tol = EQUAL_TOL if tol is None else tol
    items = []
    for s, a, b in pos:
        items.append((s.get("id", "?"), s.get("section", "?"), max(b - a, 0)))
    flags, i = [], 0
    while i < len(items):
        j = i + 1
        lo = hi = items[i][2]
        while j < len(items) and lo > 0:
            nlo, nhi = min(lo, items[j][2]), max(hi, items[j][2])
            if nlo <= 0 or nhi / float(nlo) - 1 > tol:
                break
            lo, hi, j = nlo, nhi, j + 1
        chunk = [it for it in items[i:j] if "metric" not in str(it[1])]
        if len(items[i:j]) >= run and len(chunk) == len(items[i:j]):
            flags.append("%s..%s: %d shots of nearly equal length (%.2f-%.2f s) — vary at least one (breathing rhythm)" % (
                items[i][0], items[j - 1][0], j - i, lo / float(fps), hi / float(fps)))
        i = max(j, i + 1)
    return flags


def repeat_report(segs, overlap=None, run=None):
    """v3.2.0 repeat checks on the blueprint's V1 segments (references/shot-selection-and-continuity.md §6).
    Level 1 source frames, level 2 same picture (`shot`/`grp`), level 3 same information (`info`), level 4 same pattern.
    A segment with `callback: true` may repeat (a deliberate mirror); stepped-ramp boundary frames are not repeats
    because ranges are half-open [src_in, src_out)."""
    overlap = OVERLAP_FRAMES if overlap is None else overlap
    run = run or REPEAT_RUN
    flags = []
    by_clip = {}
    for s in segs:
        if s.get("callback") or s.get("media") == "audio":
            continue
        a, b = s.get("src_in"), s.get("src_out")
        if a is None or b is None:
            continue
        for o in by_clip.get(s.get("clip"), []):
            ov = min(b, o[2]) - max(a, o[1])
            if ov > overlap:
                flags.append("%s reuses %d source frames of %s already used by %s — never the same frames twice" % (
                    s.get("id", "?"), ov, s.get("clip"), o[0]))
        by_clip.setdefault(s.get("clip"), []).append((s.get("id", "?"), a, b))
    for key, what in (("shot", "shot"), ("grp", "image group"), ("info", "information")):
        seen = {}
        for s in segs:
            v = s.get(key)
            if not v or s.get("callback"):
                continue
            if v in seen:
                flags.append("%s repeats the %s %s of %s — one per video unless it is a declared callback" % (
                    s.get("id", "?"), what, v, seen[v]))
            else:
                seen[v] = s.get("id", "?")
    for key in ("size", "move", "direction"):
        i = 0
        while i < len(segs):
            v = segs[i].get(key)
            j = i + 1
            while v and j < len(segs) and segs[j].get(key) == v:
                j += 1
            if v and j - i >= run:
                flags.append("%s..%s: %d shots in a row with %s %s — change at least one before the third" % (
                    segs[i].get("id", "?"), segs[j - 1].get("id", "?"), j - i, key, v))
            i = max(j, i + 1)
    if any(s.get("shot") for s in segs):
        nowhy = [s.get("id", "?") for s in segs if not s.get("why")]
        if nowhy:
            flags.append("no `why` (reason for the shot) on: %s" % ", ".join(nowhy))
    return flags


def broll_report(bp, clip_fps=None, tl_fps=24, v1_pos=None):
    """v3.4.0 B-roll layer on V2 (references/broll.md §0): enough short cutaways over the V1 spine, each with a type
    and a reason, none repeating a V1 or V2 picture. -> {"count", "coverage", "flags"}"""
    fps = float(tl_fps)
    v1 = v1_pos if v1_pos is not None else positions(bp, clip_fps, tl_fps, track=1)
    v2 = positions(bp, clip_fps, tl_fps, track=2)
    total = v1[-1][2] if v1 else 0
    flags = []
    need = max(BROLL_MIN, int(math.ceil(total / fps / BROLL_EVERY_S))) if total else BROLL_MIN
    if len(v2) < need:
        flags.append("B-roll layer: %d cutaway(s) on V2, the plan needs at least %d for %.1f s (one every %.0f s)"
                     % (len(v2), need, total / fps if total else 0, BROLL_EVERY_S))
    cover = sum(b - a for _, a, b in v2)
    if total and v2 and not BROLL_COVER[0] <= cover / float(total) <= BROLL_COVER[1]:
        flags.append("B-roll covers %.0f %% of the runtime (aim %d–%d %%)" % (100.0 * cover / total, 100 * BROLL_COVER[0], 100 * BROLL_COVER[1]))
    last_end = -1
    for s, a, b in v2:
        sid = s.get("id", "?")
        if not BROLL_LEN_S[0] <= (b - a) / fps <= BROLL_LEN_S[1]:
            flags.append("%s: B-roll %.2f s (keep %.1f–%.1f s)" % (sid, (b - a) / fps, BROLL_LEN_S[0], BROLL_LEN_S[1]))
        if a < last_end:
            flags.append("%s overlaps the previous B-roll on V2" % sid)
        last_end = b
        if total and (a < 0 or b > total):
            flags.append("%s is outside the V1 spine (B-roll sits over V1)" % sid)
        if s.get("broll_type") not in BROLL_TYPES:
            flags.append("%s: no `broll_type` (%s)" % (sid, " / ".join(sorted(BROLL_TYPES))))
        if not s.get("why"):
            flags.append("%s: B-roll without `why` (where / what / how it feels)" % sid)
        if not s.get("text_checked"):                      # v3.5.0: the catalogue missed burned subtitles twice
            flags.append("%s: not checked for burned text on stills of its own range (`text_checked`)" % sid)
    allsegs = [s for s, _, _ in v1] + [s for s, _, _ in v2]
    v2ids = {s.get("id") for s, _, _ in v2}
    flags += [f for f in repeat_report(allsegs, run=10 ** 6) if f.split(" ", 1)[0] in v2ids and "no `why`" not in f]
    return {"count": len(v2), "coverage": round(cover / float(total), 3) if total else 0, "flags": flags}


def ramp_feel(s, tl_fps=24, clip_fps=None):
    """v3.5.1: flags for one blueprint `ramp` that is too short or too flat to be felt."""
    steps = s.get("ramp") or []
    if not steps:
        return []
    fps = float(tl_fps)
    k = fps / float(clip_fps) if clip_fps else 1.0
    on = [float(x["frames"]) * k * 100.0 / float(x["speed"]) / fps for x in steps]    # seconds on screen per step
    speeds = [float(x["speed"]) for x in steps]
    sid, flags = s.get("id", "?"), []
    short = [round(t, 2) for t in on if t < RAMP_STEP_MIN_S]
    if short:
        flags.append("%s: ramp steps of %s s are too short to feel — each step ≥ %.2f s" % (sid, short, RAMP_STEP_MIN_S))
    if sum(on) < RAMP_MIN_S:
        flags.append("%s: the ramp lasts %.2f s — give the shot ≥ %.1f s" % (sid, sum(on), RAMP_MIN_S))
    slow = sum(t for t, v in zip(on, speeds) if v < 100)
    if min(speeds) < 100 and slow < RAMP_HOLD_MIN_S:
        flags.append("%s: the slow part lasts %.2f s — hold it ≥ %.1f s" % (sid, slow, RAMP_HOLD_MIN_S))
    if max(speeds) / min(speeds) < RAMP_CONTRAST:
        flags.append("%s: speeds %s–%s %% are too close — fastest/slowest ≥ %.1f×" % (sid, min(speeds), max(speeds), RAMP_CONTRAST))
    return flags


def fx_report(bp, pos, tl_fps=24):
    """v3.4.0 cinematic density (references/motion-effects.md §0): speed ramps and zoom moves planned in the
    blueprint (`ramp`, or `fx_plan` names) for every shot. -> {"ramps", "zoom_share", "flags"}"""
    fps = float(tl_fps)
    segs = [s for s, _, _ in pos] + [s for s, _, _ in positions(bp, None, tl_fps, track=2)]
    total_s = (pos[-1][2] / fps) if pos else 0
    ramps = sum(1 for s in segs if s.get("ramp") or any(str(f).startswith("ramp") for f in s.get("fx_plan") or []))
    zooms = sum(1 for s in segs if any(str(f).split("_")[0] in ZOOM_FX for f in s.get("fx_plan") or []))
    flags = []
    need = int(math.ceil(RAMPS_PER_30S * total_s / 30.0)) if total_s else 0
    if ramps < need:
        flags.append("speed ramps: %d planned, aim for at least %d in %.0f s (hero ramp + ramp transitions)" % (ramps, need, total_s))
    share = zooms / float(len(segs)) if segs else 0
    if segs and share < ZOOM_SHARE:
        flags.append("zoom moves on %.0f %% of shots, aim for at least %.0f %% (`fx_plan`: push / pull / punch / snap / zoomthrough)"
                     % (100 * share, 100 * ZOOM_SHARE))
    for s in segs:
        flags += ramp_feel(s, fps)
    for i in range(len(pos) - 2):
        p = [tuple(pos[i + k][0].get("fx_plan") or ()) for k in range(3)]
        if p[0] and p[0] == p[1] == p[2]:
            flags.append("%s..%s: the same effect plan three shots in a row — vary it" % (pos[i][0].get("id"), pos[i + 2][0].get("id")))
    return {"ramps": ramps, "zoom_share": round(share, 2), "flags": flags}


def analyse(bp, clip_fps=None, tl_fps=None, beats_s=()):
    tl_fps = tl_fps or bp.get("expected_fps") or 24
    pos = positions(bp, clip_fps, tl_fps)
    segs = [s for s, _, _ in pos]
    res = {"shots": len(segs), "frames": pos[-1][2] if pos else 0,
           "rationale": rationale_report(segs),
           "pacing": pacing_report(pos, bp.get("arc") or {}, float(tl_fps)),
           "continuity": continuity_report(segs, EYE_TRACE_MAX, clip_fps),
           "parallel": parallel_report(segs, pos)}
    if beats_s or bp.get("drop_frame") is not None:
        res["music"] = beat_report(pos, beats_s, float(tl_fps), bp.get("drop_frame"))
    split, notes = expand_split_edits(bp, clip_fps, tl_fps)
    res["split_edits"] = {"notes": notes, "audio_rows": [a for a in split.get("audio", []) if a.get("split_of")]}
    res["blueprint_split"] = split if split is not bp else None
    res["pacing"]["equal_runs"] = equal_run_report(pos, float(tl_fps))
    res["repeat"] = repeat_report(segs)
    if res["frames"] and res["frames"] / float(tl_fps) > MAX_RUNTIME_S + 0.05:
        res["repeat"].append("runtime %.1f s is above the %.0f s maximum" % (res["frames"] / float(tl_fps), MAX_RUNTIME_S))
    res["broll"] = broll_report(bp, clip_fps, tl_fps, pos)
    res["fx"] = fx_report(bp, pos, tl_fps)
    flags = res["pacing"]["flags"] + res["pacing"]["equal_runs"] + res["continuity"] + res["parallel"]["flags"] + res["repeat"]
    flags += res["broll"]["flags"] + res["fx"]["flags"]
    if bp.get("research"):
        res["research"] = research_report(bp, pos, float(tl_fps))
        flags += res["research"]["flags"]
    if res["rationale"]["missing_reason"]:
        flags.insert(0, "cuts without a reason: %s" % ", ".join(res["rationale"]["missing_reason"]))
    res["verdict"] = "READY" if not flags else "%d note(s) to resolve or accept" % len(flags)
    res["notes"] = flags
    return res


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    fps_map = {}

    def walk(f):
        for c in f.GetClipList() or []:
            try:
                fps_map[c.GetName()] = float(c.GetClipProperty("FPS"))
            except Exception:
                pass
        for s in f.GetSubFolderList() or []:
            walk(s)
    walk(project.GetMediaPool().GetRootFolder())
    tl = project.GetCurrentTimeline()
    tfps = BLUEPRINT.get("expected_fps") or (float(tl.GetSetting("timelineFrameRate")) if tl else 24)
    result = analyse(BLUEPRINT, fps_map, tfps, BEATS_S)
    result["status"] = "ANALYSED"
