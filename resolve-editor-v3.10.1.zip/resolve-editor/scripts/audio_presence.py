# audio_presence.py — is the music / SFX really in the mix? Render a few seconds of audio and correlate
# it with the source files (v2.3.0; v2.6.2 joint fit + start recipes, live run on BoConCN 2026-10-25).
# v2.6.2 check: all items are fitted together; each is judged on the residual after the others are removed,
# plus the fitted gain vs its AudioVolume ("present but buried" when it sits > 20 dB under the mix).
# Tool: run_script_unsafe (render + ffmpeg decode). v2.9: renders into RENDER_DIR (/tmp, no spaces — a render
# target with spaces once stayed "Ready"); "check" deletes the render file and its queue job afterwards and points
# the Deliver page at RESET_TARGET_DIR (Desktop/Final), so nothing of the check is left for the user's own render.
# Why: a track-level setting the API cannot read (e.g. Resolve's AI Music Remixer on a template track) made
# everything on that track render as SILENCE while the timeline looked right (appariciojunior/
# video-editor-skills). Read-back cannot catch it; a short render + correlation can.
# MODE "start": queue an audio-only render of [START_S, START_S + LENGTH_S) of the current Draft
#               (ProRes 422 LT .mov, audio LPCM, video off), StartRendering([job], False), restore the Deliver
#               format/codec. Returns JOB_ID.
# MODE "check": when the job is Complete: decode the render and every audio item overlapping the range
#               (from its source file, at its source offset), correlate each one with the mix
#               (best lag within ±0.15 s) and estimate how loud it sits (least-squares gain, dB).
#               ~0.9 = clearly present, < 0.15 = missing. Not a listening test.

# ---- CONFIG ----------------------------------------------------------------
MODE = "start"
START_S = 0.0                     # timeline-relative seconds
LENGTH_S = 6.0
JOB_ID = ""
RENDER_DIR = "/tmp/ClaudeAudioCheck"     # no spaces; emptied by "check"
RESET_TARGET_DIR = "/Users/felix/Desktop/Final"   # where the user's own render should land
SR = 2000                         # analysis rate (Hz): enough for presence, fast in pure Python
MAX_LAG_S = 0.15
PRESENT = 0.35                    # correlation above this = present
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
# ---------------------------------------------------------------------------

import math


def xcorr_best(mix, ref, max_lag):
    """Normalised cross-correlation of ref against mix for lags in [-max_lag, max_lag] samples.
    Returns (best_corr, lag). Uses numpy when present."""
    n = min(len(mix), len(ref))
    if n < 10:
        return 0.0, 0
    try:
        import numpy as np
        m = np.asarray(mix[:n], dtype=float)
        r = np.asarray(ref[:n], dtype=float)
        best = (0.0, 0)
        for lag in range(-max_lag, max_lag + 1):
            a = m[max(0, lag):n + min(0, lag)]
            b = r[max(0, -lag):n - max(0, lag)]
            den = math.sqrt(float((a * a).sum()) * float((b * b).sum()))
            c = float((a * b).sum()) / den if den else 0.0
            if abs(c) > abs(best[0]):
                best = (c, lag)
        return round(best[0], 3), best[1]
    except ImportError:
        best = (0.0, 0)
        step = max(1, max_lag // 30)
        for lag in range(-max_lag, max_lag + 1, step):
            num = ea = eb = 0.0
            for i in range(max(0, -lag), min(n, n - lag)):
                x, y = mix[i + lag], ref[i]
                num += x * y
                ea += x * x
                eb += y * y
            c = num / math.sqrt(ea * eb) if ea and eb else 0.0
            if abs(c) > abs(best[0]):
                best = (c, lag)
        return round(best[0], 3), best[1]


def ls_gain_db(mix, ref, lag=0):
    """Least-squares gain of ref inside mix at the given lag, in dB (how loud the source sits)."""
    n = min(len(mix), len(ref))
    num = den = 0.0
    for i in range(max(0, -lag), min(n, n - lag)):
        num += mix[i + lag] * ref[i]
        den += ref[i] * ref[i]
    g = num / den if den else 0.0
    return round(20 * math.log10(abs(g)), 1) if g else None


def verdict(corr, present=PRESENT):
    return "present" if abs(corr) >= present else ("weak / masked" if abs(corr) >= 0.15 else "MISSING")


def _solve(a, b):
    """Gaussian elimination with partial pivoting for a small dense system; None when singular."""
    n = len(b)
    m = [list(a[i]) + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(m[r][c]))
        if abs(m[p][c]) < 1e-12:
            return None
        m[c], m[p] = m[p], m[c]
        for r in range(n):
            if r != c:
                f = m[r][c] / m[c][c]
                m[r] = [x - f * y for x, y in zip(m[r], m[c])]
    return [m[i][n] / m[i][i] for i in range(n)]


def place_ref(n, ref, start, lag):
    """ref laid into a zero signal of length n at sample `start + lag` (mix coordinates)."""
    out = [0.0] * n
    s = start + lag
    for i, v in enumerate(ref):
        j = s + i
        if 0 <= j < n:
            out[j] = v
    return out


def joint_check(mix, placed, expected_db=None, present=PRESENT, gain_tol_db=4.0, buried_db=-20.0):
    """v2.6.2. mix: rendered samples; placed: [aligned ref signal per item] (place_ref).
    All items are fitted together (least squares: mix ≈ Σ g_i·ref_i). For each item the others are
    subtracted and the residual is correlated with it — a quiet SFX under a music bed is no longer called
    MISSING just because the music dominates the raw correlation (BoConCN riser: raw 0.09, set 0 dB, fitted
    −1.1 dB). expected_db: the items' AudioVolume (dB) to compare the fitted gain with.
    -> [{"gain_db", "resid_corr", "level_in_mix_db", "gain_vs_set_db", "verdict"}]."""
    k = len(placed)
    if not k:
        return []
    dot = lambda x, y: sum(p * q for p, q in zip(x, y))
    gram = [[dot(placed[i], placed[j]) for j in range(k)] for i in range(k)]
    rhs = [dot(placed[i], mix) for i in range(k)]
    g = _solve(gram, rhs) or [rhs[i] / gram[i][i] if gram[i][i] else 0.0 for i in range(k)]
    e_mix = dot(mix, mix) or 1e-12
    rows = []
    for i in range(k):
        others = [0.0] * len(mix)
        for j in range(k):
            if j != i and g[j]:
                others = [o + g[j] * v for o, v in zip(others, placed[j])]
        res = [m - o for m, o in zip(mix, others)]
        sup = [n for n, v in enumerate(placed[i]) if v]
        a = [res[n] for n in sup]
        b = [placed[i][n] for n in sup]
        den = math.sqrt(dot(a, a) * dot(b, b))
        rc = round(dot(a, b) / den, 3) if den else 0.0
        gdb = round(20 * math.log10(abs(g[i])), 1) if g[i] else None
        lvl = round(10 * math.log10(max(g[i] * g[i] * gram[i][i], 1e-12) / e_mix), 1)
        exp = (expected_db or [None] * k)[i]
        dev = round(gdb - exp, 1) if gdb is not None and exp is not None else None
        if rc >= present or (rc >= 0.15 and dev is not None and abs(dev) <= gain_tol_db):
            v = "present"
            if lvl < buried_db:
                v = "present but buried (%.0f dB under the mix)" % -lvl
        elif rc >= 0.15:
            v = "weak / masked"
        else:
            v = "MISSING"
        rows.append({"gain_db": gdb, "resid_corr": rc, "level_in_mix_db": lvl, "gain_vs_set_db": dev,
                     "verdict": v})
    return rows


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, shutil, subprocess, struct, wave, time
    out = {"mode": MODE}
    tl = project.GetCurrentTimeline()
    odir = os.path.expanduser(RENDER_DIR)

    def find_bin(name):
        return shutil.which(name) or next((p for p in (os.path.expanduser("~/.local/bin/" + name),
                                                       "/opt/homebrew/bin/" + name, "/usr/local/bin/" + name)
                                           if os.path.exists(p)), None)

    def decode(path, start_s, length_s):
        ff = find_bin("ffmpeg")
        wav = os.path.join(odir, "dec_%d.wav" % os.getpid())
        try:
            subprocess.run([ff, "-y", "-v", "error", "-ss", "%.3f" % max(start_s, 0), "-t", "%.3f" % length_s,
                            "-i", path, "-vn", "-ac", "1", "-ar", str(SR), wav], capture_output=True, timeout=40)
            with wave.open(wav, "rb") as w:
                raw = w.readframes(w.getnframes())
            return [v / 32768.0 for v in struct.unpack("<%dh" % (len(raw) // 2), raw[:len(raw) // 2 * 2])]
        finally:
            if os.path.exists(wav):
                os.remove(wav)

    if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
        out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_"
    elif MODE == "start":
        os.makedirs(odir, exist_ok=True)
        fps = float(tl.GetSetting("timelineFrameRate"))
        s0 = tl.GetStartFrame()
        a, b = s0 + int(START_S * fps), s0 + int((START_S + LENGTH_S) * fps) - 1
        prev = project.GetCurrentRenderFormatAndCodec() or {}
        name = "presence_%d" % int(time.time())
        base = {"SelectAllFrames": False, "MarkIn": a, "MarkOut": b, "TargetDir": odir,
                "CustomName": name, "ExportVideo": False, "ExportAudio": True}
        # v2.6.2: the first recipe queued a job that StartRendering refused on BoConCN (21.1.1, 2026-10-25),
        # while the same range without the explicit format/codec rendered at once -> try simpler recipes in turn.
        recipes = [("mov_prores_lpcm", ("mov", "ProRes422LT"), {"AudioCodec": "lpcm"}),
                   ("mov_prores", ("mov", "ProRes422LT"), {}),
                   ("current_format", None, {})]
        attempts, job, started = [], None, False
        for label, fmt, extra in recipes:
            okf = project.SetCurrentRenderFormatAndCodec(*fmt) if fmt else True
            st = dict(base, **extra)
            oks = project.SetRenderSettings(st)
            job = project.AddRenderJob() if okf and oks else None
            started = bool(job) and bool(project.StartRendering([job], False))
            attempts.append({"recipe": label, "format_set": bool(okf), "settings_set": bool(oks),
                             "job": bool(job), "started": started})
            if started:
                break
            if job:
                project.DeleteRenderJob(job)
            job = None
        if prev.get("format") and prev.get("codec"):            # jobs keep their own settings
            project.SetCurrentRenderFormatAndCodec(prev["format"], prev["codec"])
        # v2.7.0: the Deliver page keeps CustomName and the marks; a render the user queued next on BoConCN
        # came out as "presence_….mp4". CustomName cannot be cleared (""), so it goes back to the timeline name.
        out["deliver_reset"] = {"select_all": bool(project.SetRenderSettings({"SelectAllFrames": True})),
                                "custom_name": tl.GetName() if project.SetRenderSettings({"CustomName": tl.GetName()}) else None,
                                "target_dir": RESET_TARGET_DIR if project.SetRenderSettings(
                                    {"TargetDir": os.path.expanduser(RESET_TARGET_DIR)}) else None}
        resolve.OpenPage("edit")
        out.update({"status": "RENDERING" if started else "FAILED", "job_id": job, "file_stem": name,
                    "attempts": attempts, "previous_format": prev,
                    "range_frames": [a - s0, b - s0], "next": "MODE check with this JOB_ID" if started else
                    "no recipe started: a dialog may be open in Resolve, or the Deliver page needs a look",
                    "note": "Deliver page reset: whole timeline, timeline name, TargetDir = %s. Run MODE check to remove the test render and its job." % RESET_TARGET_DIR})
    elif MODE == "check":
        st = project.GetRenderJobStatus(JOB_ID) or {}
        if st.get("JobStatus") != "Complete":
            out.update({"status": "NOT_READY", "job": st})
        elif not find_bin("ffmpeg"):
            out["status"] = "NO_FFMPEG"
        else:
            info = next((j for j in (project.GetRenderJobList() or []) if j.get("JobId") == JOB_ID), {})
            rpath = os.path.join(info.get("TargetDir", odir), info.get("OutputFilename", ""))
            fps = float(tl.GetSetting("timelineFrameRate"))
            s0 = tl.GetStartFrame()
            a = s0 + int(START_S * fps)
            mix = decode(rpath, 0, LENGTH_S)
            # v3.0.1: sample peak of the full-rate render (a 2 kHz analysis copy hides clipping). The user's lesson
            # "riser + subdrop clipped at 0 dBFS" needed a render to see it; report it with the presence result.
            try:
                import re as _re
                vd = subprocess.run([find_bin("ffmpeg"), "-nostdin", "-i", rpath, "-vn", "-af", "volumedetect,ebur128=peak=true",
                                     "-f", "null", "-"], capture_output=True, text=True, timeout=30).stderr
                mx = _re.findall(r"max_volume: (-?[\d.]+) dB", vd)
                tp = _re.findall(r"Peak:\s+(-?[\d.]+) dBFS", vd)
                out["mix_peak_dbfs"] = float(mx[-1]) if mx else None
                out["mix_true_peak_dbtp"] = float(tp[-1]) if tp else None
                out["clipping"] = bool(mx) and float(mx[-1]) >= -0.1
                il = _re.findall(r"I:\s+(-?[\d.]+) LUFS", vd)
                out["integrated_lufs"] = float(il[-1]) if il else None     # of the rendered range (whole Draft = START 0)
            except Exception as _e:
                out["mix_peak_dbfs"] = "not measured (%s)" % _e
            rows, placed, expected = [], [], []
            for ti in range(1, (tl.GetTrackCount("audio") or 0) + 1):
                for it in tl.GetItemListInTrack("audio", ti) or []:
                    lo, hi = max(it.GetStart(), a), min(it.GetEnd(), a + int(LENGTH_S * fps))
                    if hi - lo < fps * 0.5:
                        continue
                    mpi = it.GetMediaPoolItem()
                    path = mpi.GetClipProperty("File Path") if mpi else None
                    if not path or not os.path.exists(path):
                        continue
                    src_s = (it.GetLeftOffset() + (lo - it.GetStart())) / fps
                    ref = decode(path, src_s, (hi - lo) / fps)
                    off = int((lo - a) / fps * SR)
                    seg = mix[off:off + len(ref)]
                    c, lag = xcorr_best(seg, ref, int(MAX_LAG_S * SR))
                    rows.append({"track": ti, "item": it.GetName(), "range": [lo - s0, hi - s0], "corr": c,
                                 "lag_ms": round(1000.0 * lag / SR)})
                    placed.append(place_ref(len(mix), ref, off, lag))
                    expected.append((it.GetProperties() or {}).get("AudioVolume"))
            for r, j in zip(rows, joint_check(mix, placed, expected)):
                r.update(j)
            missing = [r["item"] for r in rows if r["verdict"] == "MISSING"]
            # v2.9: leave nothing behind — the test file and its queue job go away
            cleaned = {"file": False, "job": False}
            try:
                if rpath and os.path.isfile(rpath) and os.path.realpath(rpath).startswith(os.path.realpath(odir)):
                    os.remove(rpath)
                    cleaned["file"] = True
            except OSError:
                pass
            try:
                cleaned["job"] = bool(project.DeleteRenderJob(JOB_ID))
            except Exception:
                pass
            out.update({"status": "CHECKED", "render": rpath, "cleaned": cleaned, "items": rows, "missing": missing,
                        "next": "MISSING music: check the track header Inspector (AI Music Remixer, mute, track FX) "
                                "in the UI — the API cannot read it" if missing else "audio present; still listen"})
    else:
        out["status"] = "UNKNOWN_MODE"
    result = out
