# Helper scripts

**v3.0.0:** the text engine (`text_fx.py`, `text_qa.py`, `calibrate_fonts.py`, `fonts.py`, `track_point.py`) and the title modes of `fx_apply.py` were removed — titles, subtitles and graphics are HyperFrames' job; `hyperframes_handoff.py` was added. Older version notes below that mention those tools are historical.

Each script is run through `loader.py` (preferred: shared config injected) or pasted as the `script` argument of the Resolve MCP tool named in its header. Only the CONFIG block at the top is meant to be edited per job — through the loader's `OVERRIDES`, `project.json` or `config/defaults.json`. Every script returns a `result` dict; read it before the next step. Status: rows marked **v2.2** are offline-tested only (UNTESTED live).

| Script | Tool | Writes? | Purpose |
|---|---|---|---|
| `inventory.py` | `run_script` | no | Version, project, timelines (fps, size, tracks), every Media Pool clip with path, fps, frames, resolution, codec, colour space, `kind` (language independent); v2.7 `warnings` (empty pool, fps mismatch, landscape project) |
| `frame_probe.py` | `run_script_unsafe` | `Cache Edit/<job>/footage` (paths.work) | N frames per source clip + contact sheet (needs ffmpeg; reports `NO_FFMPEG`); v2.7: camera proxy (DJI `.LRF`), frame numbers burned in, parallel, `BUDGET_SEC`, MODE range |
| `qc_stills.py` | `run_script_unsafe` | `Cache Edit/<job>` (paths.work) | Stills at cuts/titles/first/last + JPEG previews (`sips`); restores page and playhead |
| `silence_beats.py` | `run_script_unsafe` | temp WAV, deleted | Beat grid of a music file, silence windows, or list a music/SFX folder (ffmpeg or macOS `afconvert`) |
| `build_from_blueprint.py` | `run_script` | new Draft_/Probe_/Test_ timeline | Builds from the blueprint: fps-aware, exclusive endFrame, fill/fit, Pan, speed, **ramps** (stepped speeds on continuous source), **`dur` convergence** (exact lengths despite Resolve's rounding), fades, volume, markers, read-back; v3.3.0: names video items left to right (`shot_01` …, `broll_01` …) and colours music Green, SFX Yellow |
| `motion_fx.py` | `run_script` | clip Fusion comps (MFX_* nodes) | Emphasis effects keyed in each clip comp: push/pull (+drift follow / virtual pan), punch, shake, blur in/out, whip in/out, flash, freeze, spotlight; refreshes the render cache; v2.2 smooth ramp; v2.3 reframe path, invert stutter, ResolveFX nodes |
| `srt_from_transcript.py` | `run_script_unsafe` | `.srt` cue data in Cache Edit (v3.0: data for the hand-over, not imported) | Cues from Resolve transcription remapped to kept segments; correct them, then pass as `subtitle_cues` to `hyperframes_handoff.py` |
| `phase_run.py` (v3.1) | `run_script_unsafe` (via boot) | everything its tools write + `Cache Edit/<Title>/phase_run/` and `STATUS.md` | One call per phase: p1 intake, p6 build, p7 accents + sound, p8 colour, p9 QC, p10 Final; time-budgeted with resume, restarts when inputs change or the last run completed; full results in `<mode>.full.json`, short summary + `look` returned |
| `timeline_ops.py` (v3.0.2) | `run_script_unsafe` | Draft_/Probe_/Test_ only (next_draft duplicates; compare writes stills to Cache Edit/_compare) | Repeated timeline jobs in one call: next_draft (next Draft_vNN), place_media (import + append + read back, new tracks), reappend_audio (new source range, volume/fades kept), set_levels (absolute or delta, read back), compare (two timelines, mean pixel difference + luma per frame) |
| `stage.py` (v3.0.2) | local `python3 -I` | the tools folder | One-command staging: scripts + config copied, removed tools moved to `_obsolete/`, md5 checked |
| `music_intake.py` (v3.3.0) | `run_script_unsafe` | no | Phase 1: did the user send music? Named paths, Media Pool audio, footage folders, project.json → USER_MUSIC / USER_MUSIC_SEVERAL / CHOSEN_BY_CLAUDE / NONE; NONE → `music_request(style)` builds the Music request message (the user sends the file; no previews, no downloads) |
| `hyperframes_handoff.py` (v3.0) | local `python3` or `run_script` | `handoff_<Title>.md` + `.json` (local run) | Phase 10: validates the graphic spec against the Final (bounds, safe zone, anchors to cuts/beats, subtitle length, duplicate ids, unapproved proposals) and writes the Markdown brief + frame-accurate JSON for HyperFrames. Designs nothing |
| `qa_audit.py` | `run_script` | no | Structural audit: runtime, gaps, black frames, overlaps, audio continuity, bounds, repeats, timing, music fade |
| `ending_plan.py` | `run_script_unsafe` | no | Ending diagnosis (music track found automatically, v2.2): music phrase hits/quiet points mapped to timeline frames, verdict on the current end, SHORT / HIT_CUT / RING_OUT candidates, last-shot tail |
| `sfx_library.py` | `run_script_unsafe` | cache JSON; Media Pool bin "SFX" (import mode) | Catalogue of the SFX folder (duration, envelope peak/onset, shape, role tags), ranked picks by role/mood, import of chosen files; `placement()` helper; MODE place; v2.8 context levels from the measured footage/music bed + MODE bed; v3.3.0: placed SFX are coloured Yellow (`SFX_COLOR`) |
| `fx_library.py` | `run_script_unsafe` | cache JSON; `.setting` copies (extract) | Catalogue of installed Fusion templates (.drfx + loose): kind, roles, text layers, fonts + Vietnamese check, length, design size, promo text; ranked picks; extract a template for MODE effect |
| `fx_apply.py` | `run_script_unsafe` | draft: transitions, clip comp (effect) | Built-in transitions with handle fallback (+SFX on the cut); Fusion effect paste with target check, track/clipboard restore. v3.0: title modes removed |
| `boot.py` (v2.7) | `run_script_unsafe` | no | `exec` it, then `run(tool, overrides, project)` — the loader without pasting it |
| `loader.py` (v2.2) | `run_script_unsafe` | `project.json` (project_set), `_prefs.json` (prefs_set) | Runs a staged script with `config/defaults.json` + `_prefs.json` config + `project.json` + OVERRIDES injected; reads/writes per-project wishes and v2.8 cross-video preferences/lessons; md5 of the staged files |
| `music_library.py` (v2.2) | `run_script_unsafe` | cache JSON; Media Pool bin "Music" (import) | Music analysis of the user's track (MODE `analyse`): duration, BPM, energy curve, intro, phrase hits/length, ending type. MODE `pick`/`preview` stay in the file but are not part of the workflow since v3.3.0 (the user supplies the music) |
| `duck_music.py` (v2.2) | `run_script` | Draft A2/A5 music segments | Music ducked under speech by crossfaded segments on two lanes; plan → apply → read back |
| `transcript_cut.py` (v2.3 rewrite) | `run_script` | no (transcribe starts Resolve's analysis) | Transcription → retakes/restart cues/fillers decided → planner (profiles, pause shortening, pads, scene room, waveform edges) → paced punch-ins, review text, blueprint with audio crossfades, KEPT for SRT, speech ranges |
| `color_look.py` (v2.2; v3.0.1 measure/balance) | `run_script` (measure/balance: `run_script_unsafe`, ffmpeg) | colour version `claude_look`: node-1 LUT and/or technical CDL slope | LOG/HDR detection, conversion or combined look LUT per item; v3.0.1 per-item technical balance (WB from neutrals, exposure outliers) with reasons, read back, revert info |
| `picture_tools.py` (v2.2) | `run_script` | Probe_/Test_ (scene cuts), Draft items | DetectSceneCuts shot list, SmartReframe, Stabilize with before/after properties; v2.3 `resolvefx_check` (which ResolveFX exist + their input names) |
| `voice_audit.py` (v2.3) | `run_script_unsafe` | Draft A1 volumes (normalize) | Dialogue source audit (channels, muffled/boomy, loudness, silence) + ranking; speech-only normalise + Voice Isolation |
| `audio_presence.py` (v2.3) | `run_script_unsafe` | render job + WAV-in-MOV in `/tmp/ClaudeAudioCheck`, both removed by MODE check (v2.9) | Audio-only render of a few seconds + correlation per audio item: is it really in the mix? |
| `replace_shot.py` (v2.3) | `run_script` | next Draft version (duplicate) | Swap one V1 shot's picture at the same timing; Pan/zoom/fades/LUT carried, MFX listed to re-run; v3.3.0: the new item keeps the old `shot_NN` name and colour |
| `finalize_project.py` (v2.9) | `run_script_unsafe` | `.drp` backup in `Cache Edit/<Title>/` | the Final approval hand-over: plan (keep/delete/untouched timelines, Vietnamese renames, token) → apply (backup, delete Claude's timelines of this title, Vietnamese track/text/node names + node comments `[claude:<old>]`, tidy node layout via FlowView, bin "Chữ (Text)", Deliver page → Desktop/Final); item counts read back. Never touches picture/timing/values. UNTESTED live |
| `edit_analysis.py` (v2.4; equal-length-run check added in the v2.8.0 addendum) | `run_script` | no | Lead-editor check of a blueprint: cut-reason coverage, ASL per section vs tension arc, release after the peak, metric acceleration, beat grid and drop, jump cuts/size jumps/screen direction/eye-trace, parallel intervals; expands J/L cuts into split-edit rows (`blueprint_split`); v3.2.0 `repeat_report` (source-frame overlap, same `shot`/`grp`/`info`, runs of 3 with the same size/move/direction, missing `why`) and the 30 s runtime check |
| `research_card.py` (v2.5, v2.6) | `run_script` (or local `python3`) | no | Research Card from vidIQ (free credits) and free sources (Creative Center, search pages, Google Trends): sources and credits left, trending sounds + licence note, on-topic trending hashtags first, keyword opportunity + primary keyword, outlier ratios/tiers, hook patterns (VN + EN taxonomy) among the strongest outliers, target runtime, hashtags, warnings, `blueprint_research` for `bp["research"]` |
| `composition_check.py` (v2.4) | `run_script` | no | 9:16 framing from a subject box read off a still: power points, eye line, headroom, look/lead room, UI overlap, suggested Pan, `subject_in/out` for the blueprint |
| `audio_ingest.py` (v2.8) | `run_script_unsafe` (or local `python3`) | `<music/sfx>/_Free/<source>/` + `.licence.json` | Approved free music/SFX: ingest from Downloads or fetch direct https links on allowed hosts, licence check (blocks NC/ND/RemArc/unknown), never overwrites; MODE credits → credit lines for the post |
| `render_deliver.py` (v2.2) | `run_script_unsafe` | render job + file in `~/Movies/Exports` | Platform presets, never overwrite, start/poll render, ffprobe + ebur128 file and loudness check, cover JPEG |

Live-tested on the user's Resolve Studio 21.1.1 (2026-10-24): inventory, qa_audit, qc_stills, silence_beats (afconvert), build_from_blueprint (fit + fill drafts), fonts (audit + install of 14 files), calibrate_fonts, text_fx (the final file run unchanged on DRAFT_HK_v01_fit: title event, read-back BUILT_READ_BACK, SFX on A3 at −20 dB, still checked; whisper/emphasis/label/halo built with the same calls), text_qa, track_point export/track/path (follow applied via one Transform; drift on rotating aerial). v1.6.0 (same day, on `DRAFT_fxprobe`): sfx_library scan (2,436 files) + pick, fx_library scan (352 templates) + extract, fx_apply transitions (40 names), title (mTitle 08, Smooth Title 02, VES Location 01 auto-fit), effect (Neo Glow verified visually; Neo Zoom Lite wired but no visible push). Offline only: srt_from_transcript, frame_probe, `cues_to_events` subtitles. offline tests: `python3 -m unittest discover -s tests`.

Writable timelines: names starting with `Draft_`, `Probe_`, `Test_` (case-insensitive); `Final_` timelines are never written (`ending_plan.py` reads them).

v2.0 (2026-10-24, HuongCang): build_from_blueprint ramps + dur convergence, motion_fx (all effects verified with on/off still pairs), qa_audit ramp-aware repeats, Final duplicate render check.

v2.1 (2026-10-25, HongKong): frame_probe live-tested with ffmpeg in `~/.local/bin` (contact sheet of clip 01); qc_stills `SETTLE_S` + warm-up (stale stills fixed, contact sheet verified); ending_plan `refine_hit` (20 ms); build_from_blueprint `planned_length` honours `dur` and ramps. 49 offline tests.

v2.2 (2026-10-25, offline only): shared config + loader, music_library, duck_music, transcript_cut, color_look, picture_tools, render_deliver; motion_fx `ramp_smooth`; build_from_blueprint `resolution` + `fill_geometry()`; fonts CJK; ending_plan/qa_audit find the MUSIC track; text_fx safe zone = TikTok zone. Tests: `python3 -m unittest discover -s tests` (49 + v2.2 tests).

v2.3 (2026-10-25, offline only): transcript_cut rewrite, build `audio_xfade`, qa `av_sync_linked`, adaptive silence floor, voice_audit, audio_presence, motion_fx `reframe_path`/`invert`/`resolvefx`, picture_tools `resolvefx_check`, text_fx `layout_collisions`, replace_shot; traps fixed in srt_from_transcript, render_deliver, fx_apply, duck_music.

v2.8.0 (2026-10-25, offline only): sfx_library context levels + MODE bed, text_fx beat accents/kinetic/density plan, loader prefs, audio_ingest. 186 offline tests.
v2.7.0 (2026-10-25, BoConCN live): boot.py, inventory warnings, frame_probe proxies/range/budget, replace_shot SHOTS, edit_analysis ellipsis + emotional payoff, color_look warm_soft, levels_db recalibrated by ear. 162 offline tests.
v2.6.2 (2026-10-25, BoConCN live): sfx_library MODE place + file-loudness levels (`auto_level`), ending_plan merges catalogue hits and recognises hit + fade, audio_presence joint fit + start recipes. v2.6.1: loader injects before the first def.
v2.6 (2026-10-25, offline only): free-first research (vidIQ free credits, then free sources), trending sounds/hashtags in research_card.
v2.5 (2026-10-25, offline only): research_card; trend-research reference (vidIQ research pass); edit_analysis research check.
v2.4 (2026-10-25, offline only): edit_analysis, composition_check; montage-advanced / story-structure / composition references; SKILL lead-editor rules.

### Shared config (v2.2)
`config/defaults.json` is the one place for paths, track layout, levels, loudness targets, safe zones, delivery presets and timeouts. Its `scripts` table maps each script's CONFIG names to config values (`"${paths.sfx}"`). `loader.py` resolves the references, merges `~/Movies/ClaudeQC/<Title>/project.json` (same shape, any subset) and your `OVERRIDES`, and injects the result as plain assignments just before the script's `try:\n    resolve` block. Scripts keep their own defaults, equal to the config, so pasting a script without the loader still works.
```python
# run_script_unsafe — paste scripts/loader.py with:
MODE = "run"; TOOL = "sfx_library.py"; PROJECT = "HongKong"
OVERRIDES = {"MODE": "pick", "QUERY": {"role": "whoosh", "mood": "soft", "n": 6}}
```
```python
MODE = "project_set"; PROJECT = "HongKong"
PROJECT_DATA = {"notes": ["ending: wide bookend + CTA"], "levels_db": {"whoosh": -14}}
```

### Running the large scripts from the Mac copy (manual route, before v2.2)
The three library scripts are long. Copy them once to `/Users/felix/Desktop/Final/Cache Edit/_tools/` (device file tools; give each staged copy a new name and check the md5 on the Mac — a re-staged file with the same name was served stale once), then run with a loader that injects CONFIG overrides just before the Resolve block. The loader reads files, so call it from **`run_script_unsafe`** (the `run_script` sandbox refuses `import os`, even for scripts marked `run_script` above); read override files with `encoding="utf-8"`:
```python
import os
def run_tool(name, overrides=""):
    p = os.path.expanduser("/Users/felix/Desktop/Final/Cache Edit/_tools/" + name)
    src = open(p, encoding="utf-8").read().replace("\ntry:\n    resolve", "\n" + overrides + "\ntry:\n    resolve", 1)
    g = {"resolve": resolve, "project": project, "__name__": "tool"}
    exec(compile(src, p, "exec"), g)
    return g.get("result")
result = run_tool("fx_apply.py", 'MODE = "transitions"\nTRANSITIONS = [...]')
```

Sandbox note: `run_script` has no `globals()`; scripts detect Resolve with `try: resolve`.

## Blueprint schema (JSON / Python dict)
```json
{
  "timeline_name": "Draft_HongKong_v02",
  "expected_fps": 24,
  "resolution": [2160, 3840],
  "target_frames": 384,
  "landscape": "fill",
  "retime": "optical_flow",
  "video_tracks": 3,
  "audio_tracks": 4,
  "track_names": {"video": {"1": "FOOTAGE", "2": "TITLES A", "3": "TITLES B"},
                  "audio": {"1": "DIALOGUE", "2": "MUSIC", "3": "SFX", "4": "AMBIENCE"}},
  "segments": [
    {"id": "s01", "clip": "02 HongKong RAW.mov", "src_in": 0, "src_out": 100, "dur": 96,
     "track": 1, "record": "auto", "media": "video", "speed": 48,
     "section": "hook", "purpose": "skyline establishing, slow",
     "props": {"Pan": 300.0},
     "fades": {"FadeIn": 12},
     "marker": {"color": "Blue", "name": "HOOK", "note": "skyline at dusk"}}
  ],
  "audio": [
    {"id": "m01", "clip": "mixkit-silent-descent-614.mp3", "src_in": 0, "src_out": 384,
     "track": 2, "record": 0, "volume": -10.0, "fades": {"FadeIn": 6, "FadeOut": 36}}
  ]
}
```
Rules:
- `src_in`/`src_out` are frames in the **clip's own fps**, `src_out` exclusive.
- `dur` (recommended): exact timeline length; the builder adjusts the speed until the item is exactly this long (cuts stay on music hits).
- `ramp`: `[{"frames": source frames, "speed": %}, ...]` summing to `src_out − src_in`; `dur` then applies to the whole ramp.
- `record` is a timeline-relative frame or `"auto"` (after the previous item on that track).
- Timeline length of a row = `(src_out − src_in) × timeline_fps / clip_fps × 100 / speed`. For frame-for-frame slow motion from 50 fps into 24 fps, `speed = 48`.
- For audio-only files the "clip fps" Resolve reports is a timeline-style rate; measure music rows in timeline frames and read back the length.
- `props` keys must be valid `TimelineItemProperties` (see `references/api-cookbook.md` §4).
- `resolution` (optional, v2.2): custom timeline size `[w, h]` for other platforms (`delivery.md` §7); omitted = project setting. `fill_geometry(src_w, src_h, tl_w, tl_h)` says which axis to reframe and how much of the source shows.
- `media: "both"` (used by `transcript_cut.py`) appends linked video + audio.
- v2.4 editorial fields (read by `edit_analysis.py`, ignored by the builder): `cut` {reason, on, type, why}, `size`, `direction`, `tone`, `thread`, `subject_in`/`subject_out`, `broll_layer`, `audio_lead`/`audio_tail` (J/L, timeline frames); blueprint-level `arc` {section: tension 1–5} and `drop_frame`. v2.5: blueprint-level `research` {primary_keyword, hook_pattern, hook_text, target_dur, evidence, source} and segment `role` (`payoff`, `answer`) — `edit_analysis.py` checks runtime vs target and hook delivery. Build J/L cuts from `blueprint_split` (picture rows `media: "video"`, sound rows `media: "audio"` with explicit records).
- v3.2.0 selection fields (plain data for the builder, read by `edit_analysis.py` `repeat_report`): `shot` (catalogue ID `C03.S02`), `grp` (image group), `info` (the fact the shot gives), `size`, `move`, `direction`, `score`, `why`, `rejected` [{shot, score, why}], `link` (`shape|colour|motion|sound|theme|contrast|callback`), `callback` (true = a deliberate repeat). `edit_analysis.py` flags: overlapping source ranges of one clip (> 2 frames), the same `shot` or `grp` twice, the same `info` twice, runs of 3 with the same `size`/`move`/`direction`, missing `why`, and a runtime above `MAX_RUNTIME_S` (30 s).
- Section durations must sum to `target_frames`; check `planned_frames_at_expected_fps` in the build result (and with `DRY_RUN = True` before writing).

v2.9.0 (2026-10-26, offline only): finalize_project (the Final approval hand-over), temp work in paths.work (Cache Edit) with persistent data kept in ~/Movies/ClaudeQC, audio_presence renders in /tmp and cleans up, motion_fx maps Vietnamese node names back, qc_stills previews 720 px, text_fx event sfx left to the cue sheet.
