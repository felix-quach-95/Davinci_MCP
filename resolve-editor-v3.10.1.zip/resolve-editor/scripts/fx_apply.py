# fx_apply.py — use the user's installed effects library on a DRAFT_ timeline.
# Tool: run_script_unsafe (title measuring and effect pasting need the filesystem / clipboard).
#
# MODE "transitions": built-in Resolve transitions between clips (TimelineItem.AddTransition, verified 21.1.1).
# MODE "effect":      paste a Fusion effect macro (.setting from fx_library.py MODE "extract") into one
#                     clip's Fusion comp, wire it at the end of the chain, set its controls.
# All modes refuse timelines whose name does not start with REQUIRE_PREFIX. Read the result; then look
# at the stills (qc_stills.py). v3.0: no title/text modes — titles and graphics belong to HyperFrames.

MODE = "transitions"
JOB = "job"
REQUIRE_PREFIX = ("draft_", "probe_", "test_")   # writable timelines (case-insensitive); never "Final_"
SFX_TRACK = 3
FX_CATALOG = "~/Movies/ClaudeQC/_fx/catalog.json"

TRANSITIONS = [
    # {"track": 1, "index": 3, "position": "start", "type": "Blur Dissolve", "category": "simple",
    #  "alignment": "center", "duration": 12,
    #  "sfx": {"clip": "Whoosh 03.wav", "offset": -7, "volume": -20.0}},   # offset relative to the cut
]
EFFECT = {"track": 1, "index": 1, "setting": "~/Movies/ClaudeQC/_fx/settings/Neo Glow.setting",
          "inputs": {"Intensity": 0.15}}

# ---------------- pure helpers (offline-tested) ----------------
def frame_tc(frame, fps):
    f = int(frame)
    fps = int(round(fps))
    return "%02d:%02d:%02d:%02d" % (f // (3600 * fps), (f // (60 * fps)) % 60, (f // fps) % 60, f % fps)


def alignment_attempts(position, alignment):
    """Order to try. 'center' needs handles on both clips; 'right' (start on the edit) needs the
    outgoing clip's tail; 'left' (end on the edit) needs the incoming clip's head."""
    order = [alignment] if alignment else []
    for a in ("center", "right", "left"):
        if a not in order:
            order.append(a)
    return order


# ---------------- Resolve side ----------------
try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, time, json, subprocess
    mp = project.GetMediaPool()
    draft = project.GetCurrentTimeline()
    fps = float(draft.GetSetting("timelineFrameRate") or 24) if draft else 24.0
    out = {"mode": MODE, "errors": []}

    def all_timelines():
        return {project.GetTimelineByIndex(i).GetName(): project.GetTimelineByIndex(i)
                for i in range(1, project.GetTimelineCount() + 1)}

    def find_clip(name, folder):
        for c in folder.GetClipList() or []:
            if c.GetName() == name:
                return c
        for s in folder.GetSubFolderList() or []:
            r = find_clip(name, s)
            if r:
                return r
        return None

    def add_sfx(sfx, at_frame):
        clip = find_clip(sfx["clip"], mp.GetRootFolder())
        if clip is None:
            out["errors"].append("SFX '%s' not in media pool (sfx_library.py MODE import)" % sfx["clip"])
            return None
        while (draft.GetTrackCount("audio") or 0) < SFX_TRACK:
            draft.AddTrack("audio", "stereo")
        s0 = draft.GetStartFrame()
        info = {"mediaPoolItem": clip, "trackIndex": SFX_TRACK, "recordFrame": float(s0 + max(int(at_frame), 0)), "mediaType": 2}
        items = mp.AppendToTimeline([info]) or []
        for ai in items:
            if "volume" in sfx:
                ai.SetProperties({"AudioVolume": float(sfx["volume"])})
        return [[ai.GetTrackTypeAndIndex(), ai.GetStart() - s0, ai.GetDuration()] for ai in items]


    if draft is None or not draft.GetName().lower().startswith(tuple(REQUIRE_PREFIX) if not isinstance(REQUIRE_PREFIX, str) else REQUIRE_PREFIX.lower()):
        out["status"] = "REFUSED: current timeline is not a draft (%s)" % (draft.GetName() if draft else None)

    elif MODE == "transitions":
        resolve.OpenPage("edit")
        time.sleep(0.8)
        s0 = draft.GetStartFrame()
        done = []
        for t in TRANSITIONS:
            items = draft.GetItemListInTrack("video", int(t.get("track", 1))) or []
            idx = int(t["index"]) - 1
            if not 0 <= idx < len(items):
                out["errors"].append("no item %s on V%s" % (t["index"], t.get("track", 1)))
                continue
            it = items[idx]
            pos = t.get("position", "end")
            got, used = None, None
            for al in alignment_attempts(pos, t.get("alignment", "center")):
                opt = {"type": t["type"], "category": t.get("category", "simple"), "position": pos, "alignment": al}
                if t.get("duration"):
                    opt["duration"] = int(t["duration"])
                got = it.AddTransition(opt)
                if got:
                    used = al
                    break
            if not got:
                out["errors"].append("%s on V%s#%s %s: not added (name wrong or no handles)" % (t["type"], t.get("track", 1), t["index"], pos))
                continue
            rec = {"type": t["type"], "shown_as": got.GetName(), "alignment": used, "start": got.GetStart() - s0,
                   "dur": got.GetDuration()}
            cut = (it.GetEnd() if pos == "end" else it.GetStart()) - s0
            rec["cut"] = cut
            if t.get("sfx"):
                rec["sfx"] = add_sfx(t["sfx"], cut + int(t["sfx"].get("offset", 0)))
            done.append(rec)
        out["transitions"] = done
        out["status"] = "BUILT_WITH_ERRORS" if out["errors"] else "BUILT_READ_BACK"

    elif MODE == "effect":
        E = EFFECT
        s0 = draft.GetStartFrame()
        items = draft.GetItemListInTrack("video", int(E["track"])) or []
        target = items[int(E["index"]) - 1] if 0 < int(E["index"]) <= len(items) else None
        setting = os.path.expanduser(E["setting"])
        if target is None or not os.path.exists(setting):
            out["status"] = "STOPPED: target item or .setting missing"
        else:
            if not target.GetFusionCompCount():
                target.AddFusionComp()
            tcomp = target.GetFusionCompByIndex(1)
            before = {t.GetAttrs("TOOLS_Name") for t in tcomp.GetToolList(False).values()}
            _o = tcomp.FindTool("MediaOut1").Input.GetConnectedOutput()
            src_before = _o.GetTool().GetAttrs("TOOLS_Name") if _o else "MediaIn1"   # chain end BEFORE the paste
            mid = (target.GetStart() + target.GetEnd()) // 2
            prev_tc = draft.GetCurrentTimecode()
            draft.SetCurrentTimecode(frame_tc(mid, fps))
            nv = draft.GetTrackCount("video")
            states = {t: draft.GetIsTrackEnabled("video", t) for t in range(1, nv + 1) if t != int(E["track"])}
            # SetTrackEnable only acts on the Edit page (on other pages it returns True and does nothing)
            resolve.OpenPage("edit")
            time.sleep(0.5)
            for t in states:
                draft.SetTrackEnable("video", t, False)
            saved = subprocess.run(["pbpaste"], capture_output=True).stdout
            try:
                resolve.OpenPage("fusion")
                time.sleep(1.5)
                cur = draft.GetCurrentVideoItem()
                same = cur is not None and cur.GetTrackTypeAndIndex() == target.GetTrackTypeAndIndex() and cur.GetStart() == target.GetStart()
                if not same:
                    out["status"] = "STOPPED: Fusion page did not open the target clip (nothing pasted)"
                else:
                    comp = resolve.Fusion().GetCurrentComp()
                    subprocess.run(["pbcopy"], input=open(setting, "rb").read())
                    comp.Lock()
                    ok = comp.Paste()
                    comp.Unlock()
                    tools = {t.GetAttrs("TOOLS_Name"): t for t in tcomp.GetToolList(False).values()}
                    new = [n for n in tools if n not in before]
                    macro = [tools[n] for n in new if tools[n].GetAttrs("TOOLS_RegID") in ("MacroOperator", "GroupOperator")]
                    if not ok or not new:
                        out["status"] = "STOPPED: paste did not land in the target comp"
                    elif not macro:
                        out["status"] = "PASTED_NO_MACRO: wire by hand"
                        out["new_tools"] = new
                    else:
                        m = macro[0]
                        img = [inp.GetAttrs()["INPS_ID"] for inp in m.GetInputList().values() if inp.GetAttrs().get("INPS_DataType") == "Image"]
                        mo = tcomp.FindTool("MediaOut1")
                        src = tcomp.FindTool(src_before)
                        tcomp.Lock()
                        tcomp.StartUndo("claude effect")
                        cur_in = m[img[0]].GetConnectedOutput() if img else None
                        auto = cur_in is not None and cur_in.GetTool().GetAttrs("TOOLS_Name") == src_before
                        if not auto:                     # Fusion sometimes inserts the pasted macro itself
                            m.ConnectInput(img[0], src)
                            mo.ConnectInput("Input", m)
                        out["auto_inserted_by_paste"] = auto
                        setv = {}
                        byname = {inp.GetAttrs().get("INPS_Name"): inp.GetAttrs().get("INPS_ID") for inp in m.GetInputList().values()}
                        for k, v in (E.get("inputs") or {}).items():
                            iid = k if m.GetInput(k) is not None else byname.get(k)
                            if iid:
                                m.SetInput(iid, v)
                                setv[k] = m.GetInput(iid)
                            else:
                                out["errors"].append("control %s not found" % k)
                        tcomp.EndUndo(True)
                        tcomp.Unlock()
                        out.update({"macro": m.GetAttrs("TOOLS_Name"), "wired_after": src.GetAttrs("TOOLS_Name"),
                                    "main_input": img[0] if img else None, "set": setv, "new_tools": len(new),
                                    "status": "BUILT_WITH_ERRORS" if out["errors"] else "BUILT_READ_BACK"})
            finally:
                subprocess.run(["pbcopy"], input=saved)
                resolve.OpenPage("edit")          # back on the Edit page BEFORE restoring track states
                time.sleep(0.5)
                for t, v in states.items():
                    draft.SetTrackEnable("video", t, v)
                draft.SetCurrentTimecode(prev_tc)
            out["tracks_restored"] = all(draft.GetIsTrackEnabled("video", t) == v for t, v in states.items())
            out["clipboard_restored"] = subprocess.run(["pbpaste"], capture_output=True).stdout == saved
    result = out
