# audio_ingest.py — bring free music / SFX from approved online sources into the user's library, with the
# licence kept next to every file (v2.8.0, offline-tested; UNTESTED live). references/free-audio-sources.md.
# Tool: run_script_unsafe (filesystem; MODE fetch uses the network) or locally with python3.
# Only after the user approved the list of files (title, source, licence) in chat — downloads are never silent.
#
# MODE "ingest":  FILES = [{"path": "~/Downloads/x.mp3", "kind": "music"|"sfx", "source": "pixabay", "url": "...",
#                 "licence": "Pixabay Content License", "title": "...", "artist": "...", "attribution": null}]
#                 -> copied (never moved, never overwritten) into <music or sfx root>/_Free/<source>/ with a
#                 sidecar "<file>.licence.json"; returns the relative paths for music_library / sfx_library
#                 MODE "scan" (both walk their root, so _Free is catalogued like the rest).
# MODE "fetch":   same rows with "download_url" instead of "path": https only, host must be in ALLOWED_HOSTS
#                 (direct file links shown on the source's own page), size capped by MAX_MB.
# MODE "credits": for the current timeline (or USED = [file paths]): every used file that has a sidecar ->
#                 credit lines for the caption/description and licence warnings (attribution needed,
#                 non-commercial, per-video credit codes such as Uppbeat's).
# Licences that are never ingested: see BLOCKED_LICENCES (non-commercial, BBC RemArc, unknown).

# ---- CONFIG ----------------------------------------------------------------
MODE = "ingest"
FILES = []
USED = None                        # MODE credits: list of absolute paths; None = audio items of the current timeline
MUSIC_ROOT = "/Users/felix/Desktop/Asset/Music"
SFX_ROOT = "/Users/felix/Desktop/Asset/Sound Effect"
FREE_DIR = "_Free"
MAX_MB = 80
ALLOWED_HOSTS = ["cdn.pixabay.com", "pixabay.com", "assets.mixkit.co", "mixkit.co", "freesound.org",
                 "cdn.freesound.org", "incompetech.com", "incompetech.filmmusic.io", "sonniss.com",
                 "uppbeat.io", "freemusicarchive.org", "files.freemusicarchive.org"]
AUDIO_EXT = (".wav", ".mp3", ".aif", ".aiff", ".m4a", ".flac", ".ogg", ".aac", ".zip")
# ---------------------------------------------------------------------------

LICENCES = {
    # key (lower-case match) -> (commercial ok, attribution needed, note)
    "pixabay": (True, False, "Pixabay Content License: no credit needed; keep the download page URL as proof (Content ID claims happen)"),
    "mixkit": (True, False, "Mixkit Free License: social / YouTube / ads ok; no broadcast, no resale, do not register the track"),
    "cc0": (True, False, "CC0 public domain"),
    "sonniss": (True, False, "Sonniss GDC bundle licence: royalty-free, no credit; not for AI training"),
    "cc-by-sa": (True, True, "CC BY-SA: credit + share-alike"),
    "cc-by": (True, True, "CC BY: credit the author (name, title, source, licence) in the caption/description"),
    "incompetech": (True, True, "Kevin MacLeod CC BY: credit 'Kevin MacLeod (incompetech.com)' + licence"),
    "youtube audio library": (True, None, "per-track licence; CC BY tracks need credit; off-YouTube use unclear"),
    "uppbeat": (True, True, "Uppbeat free: one credit code per video, individuals only, no brand/sponsored content"),
}
BLOCKED_LICENCES = ["nc", "non-commercial", "noncommercial", "remarc", "bbc", "unknown", "personal use only",
                    "no derivatives", "nd"]


def licence_info(text):
    """-> {"ok": bool, "commercial": bool|None, "attribution": bool|None, "note": str}."""
    t = " ".join((text or "").strip().lower().replace("-", " ").split())
    if not t:
        return {"ok": False, "commercial": None, "attribution": None, "note": "no licence given: not ingested"}
    import re
    for b in BLOCKED_LICENCES:
        if re.search(r"(?<![a-z])" + re.escape(b.replace("-", " ")) + r"(?![a-z])", t):
            return {"ok": False, "commercial": False, "attribution": None,
                    "note": "blocked licence (%s): not for monetised short-form" % b}
    for k in sorted(LICENCES, key=len, reverse=True):
        if k.replace("-", " ") in t:
            c, a, note = LICENCES[k]
            return {"ok": True, "commercial": c, "attribution": a, "note": note}
    return {"ok": False, "commercial": None, "attribution": None,
            "note": "licence %r not in the known list: ask the user before ingesting" % text}


def safe_name(s, maxlen=80):
    import re
    s = re.sub(r"[\\/:*?\"<>|]+", "-", str(s or "")).strip(" .-")
    return (s or "untitled")[:maxlen]


def download_name(url, row):
    """v3.0.1 (live run): Mixkit links end in '640.mp3', Pixabay CDN in 'audio_0eaceb1002.mp3' — names that say
    nothing in the library or a preview. Use the ?filename= the source provides, else '<artist>-<title>-<id>.ext'."""
    import re as _re
    from urllib.parse import urlparse, parse_qs, unquote
    u = urlparse(url)
    q = parse_qs(u.query).get("filename")
    if q and q[0].strip():
        return unquote(q[0]).strip()
    last = unquote(u.path.rsplit("/", 1)[-1])
    stem, ext = (last.rsplit(".", 1) + [""])[:2]
    words = "-".join(x for x in (row.get("artist"), row.get("title")) if x)
    slug = _re.sub(r"[^a-z0-9]+", "-", words.lower()).strip("-")[:60]
    return ("%s-%s.%s" % (slug, stem, ext or "mp3")) if slug else last


def target_path(root, free_dir, source, filename, exists=None):
    """<root>/<free_dir>/<source>/<filename>, never an existing file: '_2', '_3'… before the extension."""
    import os
    exists = exists or os.path.exists
    d = os.path.join(root, free_dir, safe_name(source or "other").lower())
    base, ext = os.path.splitext(safe_name(filename))
    p = os.path.join(d, base + ext)
    k = 2
    while exists(p):
        p = os.path.join(d, "%s_%d%s" % (base, k, ext))
        k += 1
    return p


def host_allowed(url, hosts):
    from urllib.parse import urlparse
    u = urlparse(url or "")
    h = (u.hostname or "").lower()
    return u.scheme == "https" and any(h == x or h.endswith("." + x) for x in hosts)


def credit_line(meta):
    """One caption/description line for a file that needs credit."""
    parts = []
    if meta.get("title"):
        parts.append("“%s”" % meta["title"])
    if meta.get("artist"):
        parts.append("by %s" % meta["artist"])
    if meta.get("source"):
        parts.append("(%s)" % meta["source"])
    if meta.get("licence"):
        parts.append("— %s" % meta["licence"])
    line = " ".join(parts) or meta.get("file", "")
    if meta.get("attribution"):
        line = meta["attribution"]
    return line


def sidecar(meta, info, today):
    return {"title": meta.get("title"), "artist": meta.get("artist"), "source": meta.get("source"),
            "page_url": meta.get("url"), "download_url": meta.get("download_url"), "licence": meta.get("licence"),
            "commercial": info["commercial"], "attribution_needed": info["attribution"],
            "attribution": meta.get("attribution"), "licence_note": info["note"], "kind": meta.get("kind"),
            "downloaded": today, "approved_by_user": True}


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = __name__ == "__main__"

if _IN_RESOLVE:
    import os, json, shutil, datetime
    out = {"mode": MODE}
    today = datetime.date.today().isoformat()
    roots = {"music": os.path.expanduser(MUSIC_ROOT), "sfx": os.path.expanduser(SFX_ROOT)}

    if MODE in ("ingest", "fetch"):
        rows, errors = [], []
        for n, f in enumerate(FILES):
            kind = f.get("kind")
            if kind not in roots:
                errors.append("#%d: kind must be music or sfx" % n)
                continue
            info = licence_info(f.get("licence"))
            if not info["ok"]:
                errors.append("#%d %s: %s" % (n, f.get("title"), info["note"]))
                continue
            if MODE == "fetch":
                url = f.get("download_url")
                if not host_allowed(url, ALLOWED_HOSTS):
                    errors.append("#%d: %s is not https on an allowed host" % (n, url))
                    continue
                import urllib.request, tempfile
                fname = safe_name(f.get("filename") or download_name(url, f))
                tmp = os.path.join(tempfile.gettempdir(), "ingest_%d_%s" % (os.getpid(), fname))
                try:
                    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=30) as r, open(tmp, "wb") as fh:
                        size = 0
                        while True:
                            chunk = r.read(1 << 16)
                            if not chunk:
                                break
                            size += len(chunk)
                            if size > MAX_MB * 1024 * 1024:
                                raise ValueError("larger than %d MB" % MAX_MB)
                            fh.write(chunk)
                except Exception as ex:
                    errors.append("#%d %s: download failed (%s)" % (n, url, str(ex)[:80]))
                    if os.path.exists(tmp):
                        os.remove(tmp)
                    continue
                src = tmp
            else:
                src = os.path.expanduser(f.get("path") or "")
                fname = os.path.basename(src)
                if not os.path.isfile(src):
                    errors.append("#%d: %s not found" % (n, src))
                    continue
            if not fname.lower().endswith(AUDIO_EXT):
                errors.append("#%d: %s is not an audio file" % (n, fname))
                continue
            dst = target_path(roots[kind], FREE_DIR, f.get("source"), fname)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            if MODE == "fetch":
                os.remove(src)
            with open(dst + ".licence.json", "w", encoding="utf-8") as fh:
                json.dump(sidecar(f, info, today), fh, ensure_ascii=False, indent=2)
            rows.append({"kind": kind, "file": dst, "rel": os.path.relpath(dst, roots[kind]),
                         "attribution_needed": info["attribution"], "note": info["note"]})
        out.update({"ingested": rows, "errors": errors,
                    "status": "INGESTED" if rows and not errors else ("INGESTED_WITH_ERRORS" if rows else "NOTHING_INGESTED"),
                    "next": "music_library.py / sfx_library.py MODE scan (only new files are processed), then pick"})
    elif MODE == "credits":
        used = USED
        if used is None:
            used = []
            tl = project.GetCurrentTimeline() if "project" in globals() else None
            if tl is not None:
                for t in range(1, (tl.GetTrackCount("audio") or 0) + 1):
                    for it in tl.GetItemListInTrack("audio", t) or []:
                        mpi = it.GetMediaPoolItem()
                        p = mpi.GetClipProperty("File Path") if mpi else None
                        if p and p not in used:
                            used.append(p)
        lines, warnings, files = [], [], []
        for p in used:
            sc = p + ".licence.json"
            if not os.path.exists(sc):
                continue
            meta = json.load(open(sc, encoding="utf-8"))
            meta["file"] = os.path.basename(p)
            files.append({"file": p, "licence": meta.get("licence"), "source": meta.get("source")})
            if meta.get("attribution_needed"):
                lines.append(credit_line(meta))
            if meta.get("attribution_needed") is None:
                warnings.append("%s: per-track licence, check the page %s" % (meta["file"], meta.get("page_url")))
            if (meta.get("source") or "").lower() == "uppbeat":
                warnings.append("%s: Uppbeat needs its credit code for THIS video in the description" % meta["file"])
        out.update({"status": "OK", "free_files_used": files, "credit_lines": lines, "warnings": warnings})
    result = out
    if __name__ == "__main__":
        print(json.dumps(out, ensure_ascii=False, indent=2))
