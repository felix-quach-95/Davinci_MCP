# finalize_project.py — hand the Final over to the user: clean project, Vietnamese names, tidy nodes
# (v2.9.0, user rule 2026-10-26; offline-tested, UNTESTED live — every write is read back).
# Tool: run_script_unsafe (writes a .drp backup file). Runs ONLY after the user approved the Final (the Final approval).
#
# MODE "plan"  (read-only): which timelines are kept / deleted / left alone, every rename, the backup path,
#              and PLAN_TOKEN. Claude shows this list to the user and asks once (the Final approval).
# MODE "apply": refuses unless PLAN_TOKEN matches a fresh plan (nothing changed since the user saw it). Then:
#   1. SaveProject + export a backup .drp into BACKUP_DIR (Cache Edit) — stops if the backup fails.
#   2. Deletes only Claude's timelines: Probe_*, Test_*, Draft_*, older Final_<TITLE>_NN, and TXT_* text
#      timelines the kept Final does not use. Media files, the user's own timelines and anything else are
#      never deleted. Text timelines used by the Final are kept (deleting them would delete the Final's text).
#   3. Vietnamese names: the Final timeline (FINAL_NAME_VI), its tracks, its text items and their text
#      timelines ("Chữ 03 – <first words>"), Fusion nodes (ASCII names such as Chu_01 / HieuUng_KhungHinh,
#      because Fusion node names allow no spaces or accents, plus a Vietnamese description in each node's
#      Comments), the colour version "claude_look" -> "Màu Claude"; clip colours by role.
#   4. Tidies node trees left-to-right (FlowView, when Resolve exposes it for a comp; otherwise reported).
#   5. Moves the text timelines into the bin TEXT_BIN_VI, deletes Claude's empty bins, points the Deliver page
#      at Desktop/Final with the Final's name (the user renders), saves the project.
#   Read-back: item counts per track of the Final before/after must be identical.
# v3.0: Claude builds no text timelines any more; the TXT_* handling below only serves older projects or nested
# timelines the user imported from HyperFrames. V2 is B-roll; V3–V5 are renamed 'Đồ họa A/B/C (HyperFrames)' and stay empty.
# Picture, timing, text content, effects values and grades are never changed here.

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
TITLE = "HongKong"                 # <Title> used in Draft_/Final_ names
FINAL = ""                         # exact name of the approved Final; "" = highest Final_<TITLE>_NN
FINAL_NAME_VI = ""                 # e.g. "FINAL – Hồng Kông về đêm"; "" = keep the current name
PLAN_TOKEN = ""                    # from MODE "plan" (apply refuses without the matching token)
KEEP_EXTRA = []                    # timelines the user wants kept too (the Final approval "giữ Draft cuối"); their text timelines stay
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"
FINAL_DIR = "/Users/felix/Desktop/Final"
SKIP_BACKUP = False                # True only if the user said so after a failed backup
TEXT_BIN_VI = "Chữ (Text)"
CLAUDE_BINS = ["_claude_text", "Chữ (Text)"]   # emptied bins that may be deleted
TIMELINE_BIN_VI = "Timeline"       # v3.0.1: timelines created while a media bin was current land in it (TNCRoast:
MEDIA_BINS = ["Music", "SFX", "Đồ họa (HyperFrames)", "Giọng đọc"]   # all in "Music"); they are moved here
COLOR_VERSION = ["claude_look", "Màu Claude"]
TRACKS_VI = {
    "video": {"FOOTAGE": "Hình chính", "B-ROLL": "B-roll", "BROLL": "B-roll", "GRAPHICS A": "Đồ họa A (HyperFrames)",
              "GRAPHICS B": "Đồ họa B (HyperFrames)", "GRAPHICS C": "Đồ họa C (HyperFrames)", "OVERLAY": "Lớp phủ"},
    "audio": {"DIALOGUE": "Âm thanh gốc / lời thoại", "MUSIC": "Nhạc nền", "SFX": "Hiệu ứng âm thanh (SFX)",
              "AMBIENCE": "Âm thanh môi trường", "MUSIC DUCK": "Nhạc (giảm dưới lời thoại)"},
}
TEXT_TRACKS = [3, 4, 5]           # v3.0: graphics tracks (V2 = B-roll)
MUSIC_TRACKS = [2, 5]
SFX_TRACKS = [3, 4]
CLIP_COLORS = {"text": "Orange", "music": "Green", "sfx": "Yellow"}
# ---------------------------------------------------------------------------

import hashlib
import json
import re
import unicodedata

# Fusion node renames: old name pattern -> (new ASCII name, Vietnamese description for Comments)
FUSION_VI = [
    (r"^MFX_Xf$", "HieuUng_KhungHinh", "Zoom / đẩy khung / rung / di chuyển khung (Transform)"),
    (r"^MFX_Blur$", "HieuUng_Mo", "Làm mờ nhấn (Blur)"),
    (r"^MFX_DBlur$", "HieuUng_MoChuyenDong", "Mờ theo hướng chuyển động (Directional Blur)"),
    (r"^MFX_Flash$", "HieuUng_Flash", "Chớp sáng (Brightness/Contrast)"),
    (r"^MFX_Time$", "HieuUng_TocDo", "Đổi tốc độ / đóng băng khung (Time Stretcher)"),
    (r"^MFX_Spot$", "HieuUng_Spotlight", "Làm tối xung quanh chủ thể (spotlight)"),
    (r"^MFX_SpotMask$", "HieuUng_Spotlight_Mask", "Vùng sáng của spotlight (Ellipse mask)"),
    (r"^MFX_Inv$", "HieuUng_DaoMau", "Đảo màu 1–2 khung (invert stutter)"),
    (r"^MFX_OFX_(\w+)$", "HieuUng_ResolveFX_\\1", "Hiệu ứng ResolveFX"),
    (r"^T(\d\d)$", "Chu_\\1", "Dòng chữ số \\1 (Text+)"),
    (r"^G(\d\d)$", "PhatSang_\\1", "Phát sáng cho dòng chữ \\1 (Soft Glow)"),
    (r"^Follow$", "BamTheo", "Chữ bám theo điểm (tracked pin)"),
    (r"^Fit916$", "VuaKhung_916", "Đưa template về khung dọc 9:16"),
]
TAG = "[claude:%s]"               # original name kept in Comments, so a later Draft can map it back


def strip_accents(s):
    s = s.replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def fusion_vi(name):
    """(new_name, comment) for a Claude-made Fusion node, or None to leave it."""
    for pat, new, desc in FUSION_VI:
        m = re.match(pat, name or "")
        if m:
            nn = m.expand(new)
            nn = re.sub(r"[^A-Za-z0-9_]", "_", strip_accents(nn))
            return nn, "%s %s" % (m.expand(desc), TAG % name)
    return None


def text_label(text, n=28):
    t = re.sub(r"\s+", " ", (text or "").replace("\n", " ")).strip()
    return t if len(t) <= n else t[:n - 1].rstrip() + "…"


def text_name(index, text):
    lab = text_label(text)
    return "Chữ %02d – %s" % (index, lab) if lab else "Chữ %02d" % index


def unique(name, taken):
    out, k = name, 2
    while out in taken:
        out = "%s (%d)" % (name, k)
        k += 1
    taken.add(out)
    return out


def final_rank(name, title):
    m = re.match(r"^Final_%s_(\d+)$" % re.escape(title), name or "")
    return int(m.group(1)) if m else None


def pick_final(names, title, final=""):
    if final:
        return final if final in names else None
    ranked = [(final_rank(n, title), n) for n in names if final_rank(n, title) is not None]
    return max(ranked)[1] if ranked else None


def is_claude_work(name, title):
    """Claude's working timelines of THIS video (another video's Draft_/Probe_ in the same project is left)."""
    t = re.escape(title)
    return bool(re.match(r"^(Draft_%s_v\d+|Probe_%s(_.*)?|Test_.+)$" % (t, t), name or "")) or final_rank(name, title) is not None


def classify_timelines(names, final, nested_used, title, nested_by_others=()):
    """keep / delete / untouched. Only Claude's naming patterns are ever deleted; a TXT_ text timeline is deleted
    only when neither the kept Final nor any timeline that stays (the user's own, another video's) uses it."""
    keep, delete, untouched = [], [], []
    for n in names:
        if n == final or n in nested_used:
            keep.append(n)
        elif is_claude_work(n, title):
            delete.append(n)
        elif n.startswith("TXT_") and n not in set(nested_by_others):
            delete.append(n)
        else:
            untouched.append(n)
    return {"keep": keep, "delete": delete, "untouched": untouched}


def track_vi(kind, current):
    m = TRACKS_VI.get(kind, {})
    return m.get((current or "").strip().upper())


def make_token(plan):
    core = {k: plan.get(k) for k in ("final", "timelines", "renames")}
    return hashlib.md5(json.dumps(core, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:12]


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os
    pm = resolve.GetProjectManager()
    mp = project.GetMediaPool()
    out = {"mode": MODE}
    tls = {}
    for i in range(1, (project.GetTimelineCount() or 0) + 1):
        t = project.GetTimelineByIndex(i)
        if t:
            tls[t.GetName()] = t
    fin_name = pick_final(list(tls), TITLE, FINAL)

    def nested_in(tl):
        used, rows = [], []
        for tr in range(1, (tl.GetTrackCount("video") or 0) + 1):
            for it in tl.GetItemListInTrack("video", tr) or []:
                mpi = it.GetMediaPoolItem()
                nm = mpi.GetName() if mpi else None
                if nm in tls:
                    used.append(nm)
                    rows.append((it.GetStart(), tr, it, nm))
        rows.sort(key=lambda r: (r[0], r[1]))
        return used, rows

    def counts(tl):
        return {"%s%d" % (k[0], i): len(tl.GetItemListInTrack(k, i) or [])
                for k in ("video", "audio") for i in range(1, (tl.GetTrackCount(k) or 0) + 1)}

    def first_text(ntl):
        for tr in range(1, (ntl.GetTrackCount("video") or 0) + 1):
            for it in ntl.GetItemListInTrack("video", tr) or []:
                if it.GetFusionCompCount():
                    comp = it.GetFusionCompByIndex(1)
                    for tool in (comp.GetToolList(False) or {}).values():
                        if tool.GetAttrs("TOOLS_RegID") == "TextPlus":
                            return tool.GetInput("StyledText") or ""
        return ""

    if not fin_name:
        out["status"] = "NO_FINAL: create Final_%s_NN from the approved Draft first (the Draft review)" % TITLE
    else:
        fin = tls[fin_name]
        used, rows = nested_in(fin)
        extra = [n for n in KEEP_EXTRA if n in tls and n != fin_name]
        stays = [n for n in tls if n != fin_name and (n in extra or (not is_claude_work(n, TITLE)
                                                                   and not n.startswith("TXT_")))]
        by_others = set()
        for n in stays:
            by_others.update(nested_in(tls[n])[0])
        cls = classify_timelines(list(tls), fin_name, set(used) | set(extra), TITLE, by_others)
        taken = set(n for n in tls if n not in cls["delete"])
        renames = {"timeline": {fin_name: FINAL_NAME_VI} if FINAL_NAME_VI and FINAL_NAME_VI != fin_name else {},
                   "tracks": {}, "text": []}
        for kind in ("video", "audio"):
            for i in range(1, (fin.GetTrackCount(kind) or 0) + 1):
                cur = fin.GetTrackName(kind, i)
                vi = track_vi(kind, cur)
                if vi and vi != cur:
                    renames["tracks"]["%s%d" % (kind[0], i)] = [cur, vi]
        seen = set()
        k = 0
        for start, tr, it, nm in rows:
            if nm in seen or not nm.startswith("TXT_"):
                continue
            seen.add(nm)
            k += 1
            taken.discard(nm)
            renames["text"].append([nm, unique(text_name(k, first_text(tls[nm])), taken)])
        plan = {"final": fin_name, "timelines": cls, "renames": renames}
        token = make_token(plan)
        bdir = os.path.join(os.path.expanduser(WORK_DIR), TITLE)
        out.update(plan)
        # v3.0.1: a second hand-over (Final_02) reused the first backup's name and would have overwritten it
        bk = os.path.join(bdir, "TruocKhiDon_%s.drp" % TITLE)
        n_ = 2
        while os.path.exists(bk):
            bk = os.path.join(bdir, "TruocKhiDon_%s_%d.drp" % (TITLE, n_))
            n_ += 1
        out.update({"plan_token": token, "backup": bk,
                    "items_per_track": counts(fin)})
        if MODE == "plan":
            out["status"] = "PLANNED"
            out["next"] = "show keep/delete/untouched + renames to the user; on approval MODE apply with PLAN_TOKEN"
        elif MODE == "apply":
            if PLAN_TOKEN != token:
                out["status"] = "REFUSED: plan changed since it was shown (token %s != %s) — show the new plan" % (PLAN_TOKEN, token)
            else:
                log, errors = [], []
                before = counts(fin)
                project.SetCurrentTimeline(fin)
                pm.SaveProject()
                if not SKIP_BACKUP:
                    os.makedirs(bdir, exist_ok=True)
                    ok = False
                    try:
                        ok = bool(pm.ExportProject(project.GetName(), out["backup"], False))
                    except Exception as e:
                        errors.append("backup: %s" % e)
                    if not ok or not os.path.exists(out["backup"]):
                        out["status"] = "STOPPED: backup .drp failed — nothing deleted; ask the user (SKIP_BACKUP)"
                        out["errors"] = errors
                if not out.get("status"):
                    dels = [tls[n] for n in cls["delete"]]
                    if dels:
                        log.append(["deleted_timelines", len(dels), bool(mp.DeleteTimelines(dels))])
                    for tk, (cur, vi) in renames["tracks"].items():
                        kind = "video" if tk[0] == "v" else "audio"
                        log.append(["track", tk, vi, bool(fin.SetTrackName(kind, int(tk[1:]), vi))])
                    textmap = dict((a, b) for a, b in renames["text"])
                    for start, tr, it, nm in rows:
                        if nm in textmap:
                            it.SetName(textmap[nm])
                            it.SetClipColor(CLIP_COLORS["text"])
                    for old, new in renames["text"]:
                        ntl = tls[old]
                        log.append(["text_timeline", new, bool(ntl.SetName(new))])

                    tidy = {"renamed": 0, "positioned": 0, "comps": 0, "no_flowview": 0}

                    def tidy_comp(comp):
                        tidy["comps"] += 1
                        tools = list((comp.GetToolList(False) or {}).values())
                        comp.Lock()
                        comp.StartUndo("Claude: đặt tên tiếng Việt")
                        for t in tools:
                            r = fusion_vi(t.GetAttrs("TOOLS_Name"))
                            if r:
                                t.SetAttrs({"TOOLS_Name": r[0]})
                                t.SetInput("Comments", r[1])
                                tidy["renamed"] += 1
                        fv = None
                        try:
                            fv = comp.CurrentFrame.FlowView
                        except Exception:
                            fv = None
                        if fv:
                            # left-to-right in current order; masks one row above their tool
                            pos = []
                            for t in tools:
                                try:
                                    p = fv.GetPos(t)
                                    x = p[1] if isinstance(p, dict) else p[0]
                                except Exception:
                                    x = 0
                                pos.append((x, t))
                            pos.sort(key=lambda p: p[0])
                            for n, (_, t) in enumerate(pos):
                                row = -1 if "Mask" in (t.GetAttrs("TOOLS_RegID") or "") else 0
                                fv.SetPos(t, float(n), float(row))
                                tidy["positioned"] += 1
                        else:
                            tidy["no_flowview"] += 1
                        comp.EndUndo(True)
                        comp.Unlock()

                    for tr in range(1, (fin.GetTrackCount("video") or 0) + 1):
                        for it in fin.GetItemListInTrack("video", tr) or []:
                            for ci in range(1, (it.GetFusionCompCount() or 0) + 1):
                                tidy_comp(it.GetFusionCompByIndex(ci))
                            try:
                                if COLOR_VERSION[0] in (it.GetVersionNameList(0) or []):
                                    it.RenameVersionByName(COLOR_VERSION[0], COLOR_VERSION[1], 0)
                            except Exception:
                                pass
                    for old, new in renames["text"]:
                        ntl = tls[old]
                        for tr in range(1, (ntl.GetTrackCount("video") or 0) + 1):
                            for it in ntl.GetItemListInTrack("video", tr) or []:
                                for ci in range(1, (it.GetFusionCompCount() or 0) + 1):
                                    tidy_comp(it.GetFusionCompByIndex(ci))
                    log.append(["fusion", tidy])
                    for tr in range(1, (fin.GetTrackCount("audio") or 0) + 1):
                        col = CLIP_COLORS["music"] if tr in MUSIC_TRACKS else CLIP_COLORS["sfx"] if tr in SFX_TRACKS else None
                        if col:
                            for it in fin.GetItemListInTrack("audio", tr) or []:
                                it.SetClipColor(col)
                    # bins: text timelines into one Vietnamese bin, Claude's empty bins removed
                    root = mp.GetRootFolder()
                    sub = {f.GetName(): f for f in (root.GetSubFolderList() or [])}
                    moved = []
                    for old, new in renames["text"]:
                        for f in [root] + list(sub.values()):
                            for c in f.GetClipList() or []:
                                if c.GetName() == new:
                                    moved.append(c)
                    if moved:   # v3.0.1: the text bin is made only when there are text timelines to put in it
                        tbin = sub.get(TEXT_BIN_VI) or mp.AddSubFolder(root, TEXT_BIN_VI)
                        log.append(["moved_text_timelines", len(moved), bool(mp.MoveClips(moved, tbin))])
                    stray = []
                    for bn in MEDIA_BINS:
                        for c in (sub[bn].GetClipList() or []) if bn in sub else []:
                            pr = c.GetClipProperty() or {}
                            if not pr.get("File Path") and not pr.get("Video Codec") and "x" in str(pr.get("Resolution") or "").lower():
                                stray.append(c)          # a timeline item (no file, has a resolution)
                    if stray:
                        tlb = sub.get(TIMELINE_BIN_VI) or mp.AddSubFolder(root, TIMELINE_BIN_VI)
                        log.append(["moved_timelines_out_of_media_bins", len(stray), bool(mp.MoveClips(stray, tlb))])
                    empty = [sub[n] for n in CLAUDE_BINS if n in sub and not (sub[n].GetClipList() or [])
                             and not (sub[n].GetSubFolderList() or [])]
                    if empty:
                        log.append(["deleted_empty_bins", [f.GetName() for f in empty], bool(mp.DeleteFolders(empty))])
                    if FINAL_NAME_VI and FINAL_NAME_VI != fin_name:
                        log.append(["final_name", FINAL_NAME_VI, bool(fin.SetName(FINAL_NAME_VI))])
                    project.SetRenderSettings({"TargetDir": os.path.expanduser(FINAL_DIR)})
                    project.SetRenderSettings({"CustomName": fin.GetName()})
                    project.SetRenderSettings({"SelectAllFrames": True})
                    pm.SaveProject()
                    after = counts(fin)
                    left = sorted(project.GetTimelineByIndex(i).GetName()
                                  for i in range(1, (project.GetTimelineCount() or 0) + 1))
                    out.update({"status": "DONE" if after == before else "CHECK: item counts changed",
                                "log": log, "errors": errors, "items_before": before, "items_after": after,
                                "timelines_now": left,
                                "next": "export stills of the Final (first/last, every text) and look; tell the user "
                                        "the backup path and that Cache Edit can be deleted"})
        else:
            out["status"] = "UNKNOWN_MODE"
    result = out
