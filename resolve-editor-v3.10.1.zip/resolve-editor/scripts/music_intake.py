# music_intake.py — Phase 1: has the user already supplied background music, and where? (v3.3.0)
# Tool: run_script_unsafe (lists folders). Read-only: imports nothing, moves nothing, never searches outside the places below.
#
# Why: the music sets the cut grid, so this check runs in Phase 1. v3.3.0 (user request 2026-10-27): the user always
# supplies the music. No previews, no library picks, no downloads: when nothing is found, Claude sends one Music
# request (music_request) after the style choice and waits for the file.
#
# Looks in (in this order, nothing else):
#   1. NAMED_PATHS — files or folders the user named in the brief or chat (Claude copies them here verbatim);
#   2. the Media Pool — every audio-only item (bins and names reported);
#   3. the folders that hold the footage (non-recursive) — music dropped next to the clips;
#   4. project.json "music" — a track already chosen for this title, and by whom ("user" / "claude_pick").
# Returns status:
#   USER_MUSIC            one track the user supplied → Phase 2 analyses it (music_library.py MODE "analyse")
#   USER_MUSIC_SEVERAL    more than one → ask which one (and whether the others are alternatives)
#   CHOSEN_BY_CLAUDE      only a track from an earlier project or Claude's bin → ask: use it, or the user sends another
#   NONE                  no music anywhere → after the style choice send music_request(style) and wait for the file.
# Short audio (< MIN_MUSIC_S) is listed as "short" (SFX, voice memos), never as music.

# ---- CONFIG ----------------------------------------------------------------
TITLE = ""                         # <Title>: reads WORK_DIR/<Title>/project.json "music" when present
NAMED_PATHS = []                   # paths the user gave ("~/Downloads/song.mp3", "/Users/felix/Desktop/Nhac")
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"
MUSIC_ROOT = "/Users/felix/Desktop/Asset/Music"   # the user's library (paths.music)
MIN_MUSIC_S = 20.0                 # shorter audio is not a music bed
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".flac", ".caf", ".ogg")
# ---------------------------------------------------------------------------


def tc_seconds(tc, fps=30.0):
    """'00:01:05:12' -> seconds; None when unreadable."""
    try:
        h, m, s, f = [int(x) for x in str(tc).replace(";", ":").split(":")]
        return h * 3600 + m * 60 + s + f / float(fps or 30.0)
    except (ValueError, TypeError):
        return None


def classify(candidates, chosen=None, music_root=MUSIC_ROOT, min_s=MIN_MUSIC_S):
    """candidates: [{"path", "where": "named"|"media_pool"|"footage_folder", "duration_s", "bin"?}]
    chosen: project.json "music" ({"file", "chosen_by"}) or None.
    -> {"status", "user_music", "claude_pick", "library_items", "short"}"""
    import os as _os
    chosen = chosen or {}
    pick_name = _os.path.basename(str(chosen.get("file") or "")) if chosen.get("chosen_by", "claude_pick") != "user" else ""
    root = _os.path.expanduser(music_root).rstrip("/") + "/"
    user, claude, library, short, seen = [], [], [], [], set()
    for c in candidates:
        key = _os.path.realpath(_os.path.expanduser(c.get("path") or "")) or c.get("name")
        if key in seen:
            continue
        seen.add(key)
        d = c.get("duration_s")
        if d is not None and d < min_s:
            short.append(c)
            continue
        name = _os.path.basename(c.get("path") or c.get("name") or "")
        if pick_name and name == pick_name and c.get("where") != "named":
            claude.append(c)
        elif c.get("where") == "media_pool" and str(c.get("path") or "").startswith(root) and c.get("bin") == "Music":
            library.append(c)          # imported from the library into Claude's bin, chooser unknown
        else:
            user.append(c)
    if chosen.get("chosen_by") == "user" and chosen.get("file"):
        named = [c for c in user if _os.path.basename(c.get("path") or "") == _os.path.basename(chosen["file"])]
        user = named or user
    if len(user) == 1:
        status = "USER_MUSIC"
    elif len(user) > 1:
        status = "USER_MUSIC_SEVERAL"
    elif claude or library:
        status = "CHOSEN_BY_CLAUDE"
    else:
        status = "NONE"
    return {"status": status, "user_music": user, "claude_pick": claude, "library_items": library, "short": short}


def music_request(style=None, runtime_s=30):
    """v3.3.0 Music request (Phase 1, right after the style choice): one Vietnamese message asking the user to send
    the background music. Claude proposes, previews and downloads nothing. style: the project style
    ({"label", "asl_s", "audio", "ending"}) — it only shapes the hint about what fits."""
    style = style or {}
    lines = ["**Yêu cầu gửi nhạc nền**"]
    if style.get("label"):
        lines.append("Phong cách đã chọn: %s." % style["label"])
    hint = [x for x in (style.get("audio"), ("nhịp cắt %s–%s s mỗi cảnh" % tuple(style["asl_s"])) if style.get("asl_s") else None,
                        ("kết: %s" % style["ending"]) if style.get("ending") else None) if x]
    if hint:
        lines.append("Nhạc hợp với phong cách này: %s." % "; ".join(hint))
    lines += ["Độ dài video tối đa %d s — bài dài hơn cũng được, tôi sẽ chọn đoạn theo câu nhạc." % int(runtime_s),
              "Cách gửi: dán đường dẫn file, kéo vào Media Pool, hoặc để chung thư mục footage (mp3, wav, m4a, aiff, flac).",
              "Tôi chờ file của bạn rồi mới phân tích nhạc (Phase 2)."]
    return "\n".join(lines)


def question(status, user_music=None, claude_pick=None):
    """Music question for the status (Vietnamese labels); None = nothing to ask (USER_MUSIC: go on; NONE: send
    music_request(style) as a message and wait)."""
    import os as _os
    if status == "USER_MUSIC":
        return None
    if status == "USER_MUSIC_SEVERAL":
        opts = [{"label": _os.path.basename(c["path"])[:40], "description": "%s, %.0f s" % (c["where"], c.get("duration_s") or 0)}
                for c in (user_music or [])[:3]]
        return {"header": "Nhạc nền", "question": "Bạn gửi nhiều bài — dùng bài nào làm nhạc nền chính?", "options": opts}
    if status == "CHOSEN_BY_CLAUDE":
        name = _os.path.basename((claude_pick or [{}])[0].get("path") or "") if claude_pick else "bài trong bin Music"
        return {"header": "Nhạc nền", "question": "Media Pool chỉ có %s (không phải bài bạn gửi). Dùng bài này hay bạn gửi bài khác?" % name,
                "options": [{"label": "Dùng bài này", "description": "%s làm nhạc nền." % name},
                            {"label": "Tôi gửi bài khác", "description": "Dán đường dẫn, kéo vào Media Pool hoặc để chung thư mục footage."}]}
    return None


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, json
    out = {"looked_in": [], "warnings": []}
    cands = []
    for p in NAMED_PATHS:
        ap = os.path.expanduser(p)
        out["looked_in"].append(ap)
        if os.path.isdir(ap):
            for f in sorted(os.listdir(ap)):
                if f.lower().endswith(AUDIO_EXT):
                    cands.append({"path": os.path.join(ap, f), "where": "named", "duration_s": None})
        elif os.path.isfile(ap):
            cands.append({"path": ap, "where": "named", "duration_s": None})
        else:
            out["warnings"].append("not found: %s" % p)
    mp = project.GetMediaPool()
    fps = float(project.GetSetting("timelineFrameRate") or 30)
    footage_dirs = set()

    def walk(folder, path):
        for c in folder.GetClipList() or []:
            pr = c.GetClipProperty() or {}
            fp = pr.get("File Path") or ""
            res = str(pr.get("Resolution") or "")
            if fp and "x" in res.lower() and pr.get("Video Codec"):
                footage_dirs.add(os.path.dirname(fp))
            elif fp and fp.lower().endswith(AUDIO_EXT):
                cands.append({"path": fp, "name": c.GetName(), "where": "media_pool", "bin": path or "Master",
                              "duration_s": tc_seconds(pr.get("Duration"), fps)})
        for s in folder.GetSubFolderList() or []:
            walk(s, s.GetName())
    walk(mp.GetRootFolder(), "")
    out["looked_in"].append("Media Pool")
    for d in sorted(footage_dirs):
        out["looked_in"].append(d)
        try:
            for f in sorted(os.listdir(d)):
                if f.lower().endswith(AUDIO_EXT):
                    cands.append({"path": os.path.join(d, f), "where": "footage_folder", "duration_s": None})
        except OSError as e:
            out["warnings"].append("%s: %s" % (d, e))
    chosen = None
    if TITLE:
        pj = os.path.join(os.path.expanduser(WORK_DIR), TITLE, "project.json")
        if os.path.exists(pj):
            with open(pj, encoding="utf-8") as fh:
                chosen = (json.load(fh) or {}).get("music")
        out["looked_in"].append(pj)
    # durations of files not in the pool (ffprobe when available; unknown stays None and counts as music)
    probe = next((p for p in (os.path.expanduser("~/.local/bin/ffprobe"), "/opt/homebrew/bin/ffprobe", "/usr/local/bin/ffprobe")
                  if os.path.exists(p)), None)
    if probe:
        import subprocess
        for c in cands:
            if c.get("duration_s") is None:
                r = subprocess.run([probe, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", c["path"]],
                                   capture_output=True, text=True, timeout=10)
                try:
                    c["duration_s"] = round(float(r.stdout.strip()), 2)
                except ValueError:
                    pass
    cls = classify(cands, chosen, MUSIC_ROOT, MIN_MUSIC_S)
    out.update(cls)
    out["chosen_in_project"] = chosen
    out["question"] = question(cls["status"], cls["user_music"], cls["claude_pick"] or cls["library_items"])
    out["next"] = {"USER_MUSIC": "Phase 2: music_library.py MODE analyse FILES=[that path] + silence_beats.py beats; "
                                 "project_set music {file, chosen_by: 'user'}",
                   "USER_MUSIC_SEVERAL": "ask `question`, then analyse the chosen one",
                   "CHOSEN_BY_CLAUDE": "ask `question` (use this track, or the user sends another)",
                   "NONE": "after the style choice send music_request(project style) as a message and wait for the "
                           "user's file; then run this check again with NAMED_PATHS = [the path they give]"}[cls["status"]]
    result = out
