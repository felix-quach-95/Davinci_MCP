# transcript_cut.py — talking footage: Resolve transcription -> paper edit (v2.3.0, UNTESTED live).
# Tool: run_script (sandbox is enough). Writes nothing in "plan"; "transcribe" only starts Resolve's own
# transcription of CLIP (no install, nothing uploaded).
# MODE "transcribe": CLIP.TranscribeAudio(); then poll MODE "status".
# MODE "status":     project.GetTranscribeAudioStatus().
# MODE "plan":       words -> decide WHAT stays (retakes, restart cues, fillers) -> the planner decides WHERE
#                    each cut lands (pads, pause shortening, scene room, silence edges, frame snap) -> zoom per
#                    piece (paced punch-ins) -> a blueprint for build_from_blueprint.py (with 2-frame audio
#                    crossfades on every join), KEPT for srt_from_transcript.py, speech_ranges for duck_music.py,
#                    a review text (cut words struck through) and every drop/flag with its reason.
# Claude reads the review text before building: meaning must not change; unsure = keep and flag.
#
# v2.3 method (learned from appariciojunior/video-editor-skills, AdamGarceau/resolve-toolkit and
# CiprianSpiridon/davinci-resolve-mcp — ideas only):
# - cut from words, refine with the waveform: SILENCES (seconds, from silence_beats.py MODE "silence",
#   SILENCE_DB "auto") confirm pauses and move edges to where the voice really starts/stops;
# - pauses are SHORTENED, not removed: gaps > max_pause keep pause_keep (40 % before / 60 % after);
# - word pads (−0.08 s in, +0.12 s out), scene room (0.5 s before the first word of a clip, 0.6 s after the last);
# - zoom changes only on jump cuts, a new scene opens at 100 %, "paced" holds a framing ≥ 4 s,
#   a punchline gets 115 % for that line only.

# ---- CONFIG ----------------------------------------------------------------
MODE = "plan"
CLIP = "C0001.MP4"
TIMELINE_NAME = "Draft_Vlog_v01"
EXPECTED_FPS = 30                   # the timeline fps the draft will use
PROFILE = "story"                   # shorts | story | vlog | class (PROFILES below); chosen at the Story approval
SILENCES = []                       # [[start_s, end_s], ...] source seconds; [] = words only
FILLER_MODE = "isolated"            # isolated (cut fillers standing in a pause; flag embedded ones) | all | keep
FILLERS = ["ờ", "ơ", "ừ", "ừm", "ưm", "ờm", "hmm", "uh", "um", "uhm", "kiểu là", "kiểu như là"]
RESTART_CUES = ["làm lại", "nói lại", "quay lại nhé", "để mình nói lại", "lại nhé", "let me do that again"]
RETAKE_WORDS = 4                    # sentences starting with the same N words = retake (keep the last)
SWITCHING = "paced"                 # paced | dynamic | hold
ZOOMS = (1.0, 1.075)                # alternate on jump cuts
PUNCH = 1.15                        # punchline zoom (that line only)
PUNCHLINES = []                     # [[first_word_index, last_word_index], ...] chosen by Claude/user
MIN_HOLD_S = 4.0                    # paced: keep a framing at least this long
MIN_SEGMENT = 0.5                   # s: shorter kept pieces merge into a neighbour or drop
AUDIO_XFADE = 2                     # frames of audio crossfade on every join (0 = none)
LANDSCAPE = "fill"
PROFILES = {                        # max_pause, pause_keep (seconds)
    "shorts": (0.28, 0.14),         # tight vertical tips
    "story":  (0.55, 0.25),         # calm personal shorts (default)
    "vlog":   (1.0, 0.6),           # breathing room; 0.5/0.3 felt "popping" on vlogs
    "class":  (0.5, 0.3),           # tutorials
}
PAD_IN, PAD_OUT = 0.08, 0.12        # seconds around kept words
REFINE_IN, REFINE_OUT = 0.25, 0.30  # max reach to a silence edge
LEAD_IN, TAIL = 0.5, 0.6            # scene room at the first/last word of the clip
# ---------------------------------------------------------------------------

import math
import re


def tc_to_frames(tc, fps):
    nom = int(round(float(fps)))
    hh, mm, ss, ff = [int(x) for x in tc.replace(";", ":").split(":")]
    return ((hh * 60 + mm) * 60 + ss) * nom + ff


def words_from_transcription(tr, clip_start_tc, fps):
    """[(src_frame_start, src_frame_end, word)] relative to the clip start (same as srt_from_transcript)."""
    base = tc_to_frames(clip_start_tc, fps)
    out = []
    for seg in tr.get("segments", []):
        ws = seg.get("words") or []
        if ws:
            for w in ws:
                txt = (w.get("text") or "").strip()
                if txt and txt != "(...)":
                    a = tc_to_frames(w["start"], fps) - base
                    out.append((a, max(tc_to_frames(w["end"], fps) - base, a + 1), txt))
        else:
            txt = (seg.get("text") or "").replace("(...)", "").strip()
            if txt:
                a, b = tc_to_frames(seg["start"], fps) - base, tc_to_frames(seg["end"], fps) - base
                parts = txt.split()
                step = (b - a) / float(len(parts))
                out += [(int(a + i * step), int(a + (i + 1) * step), p) for i, p in enumerate(parts)]
    return sorted(out)


def norm(w):
    return re.sub(r"[^\w]", "", w.lower(), flags=re.UNICODE)


def _phrase_hits(words, phrases):
    """{index: phrase} for every word belonging to one of the (possibly multi-word) phrases."""
    toks = [norm(w[2]) for w in words]
    hits = {}
    for ph in phrases:
        parts = [norm(p) for p in ph.split()]
        for i in range(len(toks) - len(parts) + 1):
            if toks[i:i + len(parts)] == parts:
                for k in range(i, i + len(parts)):
                    hits[k] = ph
    return hits


def mark_fillers(words, fps, fillers=FILLERS, mode=FILLER_MODE, gap_s=0.15):
    """-> (drop {index: reason}, flags [(index, note)]). 'isolated': a filler is cut only when a pause
    (>= gap_s) touches it or it starts a sentence; fillers inside fluent speech are flagged (cutting them
    forces a visible jump cut)."""
    hits = _phrase_hits(words, fillers)
    drop, flags = {}, []
    if mode == "keep":
        return drop, [(i, "filler '%s' kept" % ph) for i, ph in sorted(hits.items())]
    g = gap_s * fps
    for i, ph in sorted(hits.items()):
        before = words[i][0] - words[i - 1][1] if i > 0 else 1e9
        after = words[i + 1][0] - words[i][1] if i + 1 < len(words) else 1e9
        starts = i == 0 or words[i - 1][2].endswith((".", "?", "!", "…"))
        if mode == "all" or before >= g or after >= g or starts or (i - 1 in drop):
            drop[i] = "filler '%s'" % ph
        else:
            flags.append((i, "filler '%s' inside fluent speech: kept (cutting it forces a jump)" % ph))
    return drop, flags


def sentences(words, fps, pause_s=0.6):
    """Split word indexes into sentences on final punctuation or a pause."""
    out, cur = [], []
    for i, (a, b, w) in enumerate(words):
        if cur and a - words[cur[-1]][1] > pause_s * fps:
            out.append(cur)
            cur = []
        cur.append(i)
        if w.endswith((".", "?", "!", "…")):
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def mark_retakes(words, sents, n=RETAKE_WORDS, dropped=(), cues=RESTART_CUES):
    """-> (drop {index: reason}, flags). A sentence whose first n words (fillers ignored) start one of the
    next two sentences is an earlier take; a restart cue ("làm lại") drops itself and the sentence before.
    Similar but not identical openings are flagged, not cut."""
    skip = set(dropped)
    drop, flags = {}, []

    def head(s, k=n):
        return [norm(words[i][2]) for i in s if i not in skip][:k]
    cue_hits = _phrase_hits(words, cues)
    for k, s in enumerate(sents):
        h = head(s)
        if len(h) >= min(n, 2):
            for nxt in sents[k + 1:k + 3]:
                hn = head(nxt)
                if hn[:len(h)] == h:
                    for i in s:
                        drop[i] = "earlier take of '%s…'" % " ".join(words[j][2] for j in s[:n])
                    break
                h6, n6 = head(s, 6), head(nxt, 6)
                common = len(set(h6) & set(n6))
                if h6 and common >= max(3, int(0.6 * len(h6))):
                    flags.append((s[0], "possible retake ('%s…' / '%s…'): both kept" % (
                        " ".join(words[j][2] for j in s[:4]), " ".join(words[j][2] for j in nxt[:4]))))
                    break
        if any(i in cue_hits for i in s):
            for i in s:
                if i in cue_hits:
                    drop[i] = "restart cue '%s'" % cue_hits[i]
            if k > 0:
                for i in sents[k - 1]:
                    drop.setdefault(i, "take abandoned before a restart cue")
    return drop, flags


def _silence_frac(a, b, silences_f):
    if b <= a:
        return 1.0
    cov = sum(max(0.0, min(b, sb) - max(a, sa)) for sa, sb in silences_f)
    return cov / float(b - a)


def plan_pieces(words, drop, fps, profile="story", silences_s=(), src_total=None, profiles=PROFILES,
                pad_in=PAD_IN, pad_out=PAD_OUT, refine_in=REFINE_IN, refine_out=REFINE_OUT,
                lead_in=LEAD_IN, tail=TAIL, min_seg=MIN_SEGMENT):
    """Kept words -> [{"a", "b", "words": [indexes], "join": "scene"|"jump"}] in source frames (b exclusive).
    A dropped word or a shortened pause makes a cut ("jump"); the first piece is a "scene" start."""
    max_pause, keep = profiles[profile]
    sil = [(s * fps, e * fps) for s, e in silences_s]
    kept = [i for i in range(len(words)) if i not in drop]
    if not kept:
        return []
    runs, cur = [], [kept[0]]
    for i in kept[1:]:
        j = cur[-1]
        cut_word = any(k in drop for k in range(j + 1, i))
        gap = words[i][0] - words[j][1]
        is_pause = gap > max_pause * fps and (not sil or _silence_frac(words[j][1], words[i][0], sil) >= 0.85)
        if cut_word or is_pause:
            runs.append((cur, "word" if cut_word else "pause"))
            cur = [i]
        else:
            cur.append(i)
    runs.append((cur, None))
    pieces = []
    for n, (idx, why_next) in enumerate(runs):
        first, last = words[idx[0]], words[idx[-1]]
        a = first[0] - pad_in * fps
        b = last[1] + pad_out * fps
        # refine to the waveform: a silence that ends just before the word start / starts just after the end
        for sa, sb in sil:
            if first[0] - refine_in * fps <= sb <= first[0]:
                a = min(a, sb)
            if last[1] <= sa <= last[1] + refine_out * fps:
                b = max(b, sa)
        prev_why = runs[n - 1][1] if n else None
        if prev_why == "pause":                     # shortened pause: leave 60 % of pause_keep before
            a = min(a, first[0] - 0.6 * keep * fps)
        if why_next == "pause":                     # ... and 40 % after the previous words
            b = max(b, last[1] + 0.4 * keep * fps)
        if n == 0:
            a = min(a, first[0] - lead_in * fps)
        if n == len(runs) - 1:
            b = max(b, last[1] + tail * fps)
        # never reach into a word that was cut
        lo_word = max([words[k][1] for k in drop if words[k][1] <= first[0]] or [0])
        hi_word = min([words[k][0] for k in drop if words[k][0] >= last[1]] or [1e12])
        a, b = max(a, lo_word, 0), min(b, hi_word)
        if src_total:
            b = min(b, src_total)
        pieces.append({"a": int(math.floor(a)), "b": int(math.ceil(b)), "words": idx,
                       "join": "scene" if n == 0 else "jump"})
    out = []
    for p in pieces:                                 # remove overlaps, merge touching pieces
        if out and p["a"] <= out[-1]["b"] + 1:
            out[-1]["b"] = max(out[-1]["b"], p["b"])
            out[-1]["words"] = out[-1]["words"] + p["words"]
            continue
        out.append(p)
    res = []
    for p in out:
        if p["b"] - p["a"] < min_seg * fps:
            if res and p["a"] - res[-1]["b"] <= 0.3 * fps:
                res[-1]["b"] = p["b"]
                res[-1]["words"] += p["words"]
            continue
        res.append(p)
    if res:
        res[0]["join"] = "scene"
    return res


def split_punchlines(pieces, words, punchlines):
    """Split pieces so each punchline [first_word, last_word] is its own contiguous piece ("punch")."""
    out = []
    for p in pieces:
        parts = [dict(p, words=list(p["words"]))]
        for f, l in punchlines:
            nxt = []
            for q in parts:
                inside = [i for i in q["words"] if f <= i <= l]
                if not inside or q.get("punch"):
                    nxt.append(q)
                    continue
                a_cut, b_cut = words[inside[0]][0], words[inside[-1]][1]
                before = [i for i in q["words"] if i < f]
                after = [i for i in q["words"] if i > l]
                if before:
                    nxt.append(dict(q, b=a_cut, words=before))
                nxt.append(dict(q, a=a_cut if before else q["a"], b=b_cut if after else q["b"], words=inside,
                                punch=True, join=q["join"] if not before else "contiguous"))
                if after:
                    nxt.append(dict(q, a=b_cut, words=after, join="contiguous"))
            parts = nxt
        out += parts
    return out


def assign_zoom(pieces, fps, mode=SWITCHING, zooms=ZOOMS, punch=PUNCH, min_hold_s=MIN_HOLD_S):
    """Zoom per piece. Scene start = zooms[0]; jump cuts toggle (dynamic) or toggle when the framing has
    been held >= min_hold_s (paced); hold = never. Punch pieces get `punch` and the framing returns after.
    Returns the list of joins left as same-scale jump cuts (cover with B-roll or accept)."""
    cur, held, uncovered = zooms[0], 0.0, []
    for k, p in enumerate(pieces):
        dur = (p["b"] - p["a"]) / float(fps)
        if p["join"] == "scene":
            cur, held = zooms[0], 0.0
        elif p["join"] == "jump" and mode != "hold":
            if mode == "dynamic" or held >= min_hold_s:
                cur = zooms[1] if cur == zooms[0] else zooms[0]
                held = 0.0
            else:
                uncovered.append(k)
        elif p["join"] == "jump":
            uncovered.append(k)
        p["zoom"] = punch if p.get("punch") else cur
        if not p.get("punch"):
            held += dur
    return uncovered


def review_text(words, drop, pieces):
    """Transcript with cut words struck through and ‖ at every cut."""
    kept_starts = {p["words"][0] for p in pieces[1:]}
    out = []
    for i, (_, _, w) in enumerate(words):
        if i in kept_starts:
            out.append("‖")
        out.append("~~%s~~" % w if i in drop else w)
    return " ".join(out)


def to_outputs(pieces, words, clip, clip_fps, tl_fps, name, landscape=LANDSCAPE, xfade=AUDIO_XFADE):
    """Blueprint rows, KEPT (timeline-rate units, as srt_from_transcript.py expects) and speech_ranges."""
    ratio = float(tl_fps) / float(clip_fps)
    rows, kept, speech, rec = [], [], [], 0
    for i, p in enumerate(pieces):
        dur = int(round((p["b"] - p["a"]) * ratio))
        text = " ".join(words[k][2] for k in p["words"])
        row = {"id": "t%02d" % (i + 1), "clip": clip, "src_in": int(p["a"]), "src_out": int(p["b"]), "track": 1,
               "record": "auto", "media": "both", "section": "punch" if p.get("punch") else "talk",
               "purpose": text[:60]}
        if abs(p.get("zoom", 1.0) - 1.0) > 1e-6:
            row["props"] = {"ZoomX": p["zoom"], "ZoomY": p["zoom"]}
        rows.append(row)
        kept.append({"src_in": p["a"] * ratio, "src_out": p["b"] * ratio, "record": rec})
        ws = [words[k] for k in p["words"]]
        if ws:
            speech.append([int(rec + (ws[0][0] - p["a"]) * ratio), int(rec + (ws[-1][1] - p["a"]) * ratio)])
        rec += dur
    bp = {"timeline_name": name, "expected_fps": tl_fps, "target_frames": rec, "landscape": landscape,
          "video_tracks": 3, "audio_tracks": 4,
          "track_names": {"video": {"1": "FOOTAGE", "2": "B-ROLL", "3": "GRAPHICS A"},
                          "audio": {"1": "DIALOGUE", "2": "MUSIC", "3": "SFX", "4": "AMBIENCE"}},
          "segments": rows, "audio": []}
    if xfade:
        bp["audio_xfade"] = {"track": 1, "frames": int(xfade)}
    return bp, kept, speech


def plan_all(words, fps, tl_fps, clip, name, profile=PROFILE, silences=(), src_total=None,
             punchlines=PUNCHLINES, switching=SWITCHING):
    """The whole MODE "plan" without Resolve: returns a result dict."""
    fill_drop, fill_flags = mark_fillers(words, fps)
    sents = sentences(words, fps)
    ret_drop, ret_flags = mark_retakes(words, sents, RETAKE_WORDS, list(fill_drop))
    drop = dict(fill_drop)
    drop.update(ret_drop)
    pieces = plan_pieces(words, drop, fps, profile, silences, src_total)
    pieces = split_punchlines(pieces, words, punchlines)
    uncovered = assign_zoom(pieces, fps, switching)
    bp, kept, speech = to_outputs(pieces, words, clip, fps, tl_fps, name)
    src_total_kept = sum(p["b"] - p["a"] for p in pieces)
    raw = (words[-1][1] - words[0][0]) if words else 0
    return {"profile": profile, "words": len(words), "pieces": len(pieces),
            "raw_s": round(raw / float(fps), 2), "cut_s": round(src_total_kept / float(fps), 2),
            "dropped": [{"i": i, "word": words[i][2], "src": words[i][0], "why": why} for i, why in sorted(drop.items())],
            "flags": [{"i": i, "note": n} for i, n in fill_flags + ret_flags],
            "uncovered_jump_cuts": [{"piece": k, "record": kept[k]["record"]} for k in uncovered],
            "review": review_text(words, drop, pieces),
            "blueprint": bp, "kept_for_srt": kept, "speech_ranges": speech}


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    out = {"mode": MODE}
    found = []

    def walk(f):
        for c in f.GetClipList() or []:
            if c.GetName() == CLIP:
                found.append(c)
        for s in f.GetSubFolderList() or []:
            walk(s)
    walk(project.GetMediaPool().GetRootFolder())
    clip = found[0] if found else None
    if MODE == "status":
        out.update({"status": "OK", "transcribe": project.GetTranscribeAudioStatus()})
    elif clip is None:
        out["status"] = "CLIP_NOT_FOUND: %s" % CLIP
    elif MODE == "transcribe":
        out.update({"status": "STARTED" if clip.TranscribeAudio() else "FAILED",
                    "next": "poll MODE status until Complete, then MODE plan"})
    else:
        tr = clip.GetTranscription() or {}
        if not tr.get("segments"):
            out["status"] = "NO_TRANSCRIPTION: run MODE transcribe first"
        else:
            p = clip.GetClipProperty() or {}
            cfps = float(p.get("FPS") or 30)
            total = int(float(p.get("Frames") or 0)) or None
            words = words_from_transcription(tr, p.get("Start TC") or "00:00:00:00", cfps)
            out.update(plan_all(words, cfps, EXPECTED_FPS, CLIP, TIMELINE_NAME, PROFILE, SILENCES, total))
            out.update({"status": "PLAN", "language": tr.get("language"),
                        "silence_map": "waveform" if SILENCES else "words only (run silence_beats.py MODE silence)",
                        "next": "read 'review', 'dropped' and 'flags' (meaning unchanged?), choose PUNCHLINES, then "
                                "build_from_blueprint.py; srt_from_transcript.py with KEPT; duck_music.py with "
                                "RANGES = speech_ranges; cover 'uncovered_jump_cuts' with B-roll where possible"})
    result = out
