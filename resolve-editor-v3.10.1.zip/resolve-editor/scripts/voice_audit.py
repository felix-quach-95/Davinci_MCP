# voice_audit.py — measure dialogue sources before cutting, and level the voice safely (v2.3.0, UNTESTED live).
# Tool: run_script_unsafe (ffmpeg/ffprobe from ~/.local/bin). Reads source files; never modifies them.
# MODE "audit":     per clip with audio (CLIPS = names, or "all" video/audio clips): integrated loudness, true
#                   peak, per-channel level, L−R difference (dual mono? two different mics summed?), band levels
#                   (< 300 Hz, > 3 kHz, > 6 kHz) to spot a covered/muffled mic, share of silence. Issues in plain
#                   words + a ranking of the sources for dialogue.
# MODE "normalize": NormalizeAudioLevel on the SPEECH items only (ITU-R BS.1770-4, −16 LKFS, −2 dBTP,
#                   independent) + optional Voice Isolation; items not listed are untouched — normalising a
#                   silent B-roll clip boosted it +30 dB into hiss (reported). Reads gains back and flags
#                   any item raised more than 20 dB.
# Ideas from appariciojunior/video-editor-skills (voice-and-audio) and ChaiWithJai/davinci-resolve-claude-skills
# (audio_quality_audit): measure before treating; LUFS is a gate, not a verdict — listen.

# ---- CONFIG ----------------------------------------------------------------
MODE = "audit"
CLIPS = "all"                    # "all" or [clip names]
SAMPLE_SECONDS = 60              # analyse at most this much of each file (budget)
BUDGET_SEC = 45
SPEECH_TRACK = 1                 # normalize: audio track with dialogue
SPEECH_ITEMS = []                # normalize: 1-based item indexes on SPEECH_TRACK ([] = refuse: list them)
TARGET_LKFS = -16.0
TARGET_TP = -2.0
ISOLATION = 0                    # 0 = off; 30–60 = Voice Isolation amount on the speech items
REQUIRE_PREFIX = ("draft_", "probe_", "test_")
# ---------------------------------------------------------------------------

import re


def parse_volumedetect(text):
    """ffmpeg volumedetect stderr -> {"mean": dB, "max": dB} (None when absent)."""
    def grab(key):
        m = re.search(key + r":\s*(-?[0-9.]+|-inf) dB", text)
        if not m:
            return None
        return -120.0 if m.group(1) == "-inf" else float(m.group(1))
    return {"mean": grab("mean_volume"), "max": grab("max_volume")}


def parse_ebur128(text):
    txt = text[text.rfind("Summary:"):] if "Summary:" in text else text

    def grab(pattern):
        m = re.search(pattern, txt)
        return float(m.group(1)) if m else None
    return {"lufs": grab(r"I:\s*(-?[0-9.]+)\s*LUFS"), "lra": grab(r"LRA:\s*(-?[0-9.]+)\s*LU\b"),
            "tp": grab(r"Peak:\s*(-?[0-9.]+)\s*dBFS")}


def parse_silence_total(text, duration):
    """Share of the analysed time that silencedetect called silent."""
    tot = 0.0
    for m in re.finditer(r"silence_duration:\s*([0-9.]+)", text):
        tot += float(m.group(1))
    return round(min(tot / duration, 1.0), 3) if duration else None


def judge(row):
    """Plain-language issues for one source. row keys: channels, L, R, diff, full, low, hf3, hf6, lufs, tp,
    silent_share (levels are mean dB from volumedetect)."""
    issues = []
    L, R, D = row.get("L"), row.get("R"), row.get("diff")
    if row.get("channels", 1) >= 2 and L is not None and R is not None:
        if min(L, R) < -60 and max(L, R) > -50:
            issues.append("one channel is silent: use the good channel as dual mono")
        elif abs(L - R) > 10:
            issues.append("channels differ by %.0f dB: likely two different mics; use the cleaner one" % abs(L - R))
        elif D is not None and D < max(L, R) - 40:
            issues.append("true dual mono (L = R)")
        elif D is not None and D > max(L, R) - 6:
            issues.append("L and R are different signals at similar level: summing them can comb-filter "
                          "('underwater' voice) — pick one channel")
    if row.get("hf3") is not None and row.get("full") is not None:
        gap = row["full"] - row["hf3"]
        if gap > 18:
            issues.append("3 kHz+ band %.0f dB under the total (clean voice ≈ 10–15): muffled / covered mic — "
                          "EQ presence (+3 dB at 3.5 kHz) by hand, Voice Isolation helps" % gap)
    if row.get("low") is not None and row.get("full") is not None and row["low"] > row["full"] - 1.5:
        issues.append("most energy below 300 Hz: boomy — high-pass 80 Hz, −3 dB at 250 Hz")
    if row.get("tp") is not None and row["tp"] > -1.0:
        issues.append("true peak %.1f dBTP: clipping risk" % row["tp"])
    if row.get("lufs") is not None and row["lufs"] < -35:
        issues.append("very quiet (%.1f LUFS): noise will rise when levelled" % row["lufs"])
    if row.get("silent_share") is not None and row["silent_share"] > 0.6:
        issues.append("%.0f %% silent: not a dialogue source (B-roll / room tone?)" % (100 * row["silent_share"]))
    return issues


def score(row):
    """Higher = better dialogue source."""
    s = 0.0
    if row.get("lufs") is not None:
        s -= abs(row["lufs"] + 20) * 0.3
    if row.get("hf3") is not None and row.get("full") is not None:
        s -= max(0.0, (row["full"] - row["hf3"]) - 15) * 0.5
    if row.get("tp") is not None and row["tp"] > -1:
        s -= 3
    if row.get("silent_share") is not None:
        s -= row["silent_share"] * 5
    s -= 2 * sum(1 for i in judge(row) if "silent" in i or "comb" in i or "differ" in i)
    return round(s, 2)


def normalize_report(before, after, max_gain=20.0):
    """before/after {name: AudioVolume dB} -> items whose gain rose more than max_gain (hiss risk)."""
    return [n for n in after if before.get(n) is not None and after[n] is not None
            and after[n] - before[n] > max_gain]


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, shutil, subprocess, time, json
    t0 = time.time()
    out = {"mode": MODE}

    def find_bin(name):
        return shutil.which(name) or next((p for p in (os.path.expanduser("~/.local/bin/" + name),
                                                       "/opt/homebrew/bin/" + name, "/usr/local/bin/" + name)
                                           if os.path.exists(p)), None)

    if MODE == "audit":
        ff, fp = find_bin("ffmpeg"), find_bin("ffprobe")
        if not ff or not fp:
            out["status"] = "NO_FFMPEG: install as in INSTALL.md"
        else:
            def run(args, timeout=40):
                return subprocess.run(args, capture_output=True, text=True, timeout=timeout)

            def vd(path, af):
                r = run([ff, "-hide_banner", "-nostats", "-t", str(SAMPLE_SECONDS), "-i", path, "-vn", "-af",
                         af + ",volumedetect", "-f", "null", "-"])
                return parse_volumedetect(r.stderr)["mean"]
            clips = []

            def walk(f):
                for c in f.GetClipList() or []:
                    clips.append(c)
                for s in f.GetSubFolderList() or []:
                    walk(s)
            walk(project.GetMediaPool().GetRootFolder())
            rows, skipped = [], []
            for c in clips:
                if CLIPS != "all" and c.GetName() not in CLIPS:
                    continue
                path = c.GetClipProperty("File Path")
                if not path or not os.path.exists(path):
                    continue
                if time.time() - t0 > BUDGET_SEC:
                    skipped.append(c.GetName())
                    continue
                pr = json.loads(run([fp, "-v", "error", "-select_streams", "a:0", "-show_entries",
                                     "stream=channels:format=duration", "-of", "json", path]).stdout or "{}")
                st = (pr.get("streams") or [{}])[0]
                if not st:
                    continue
                ch = int(st.get("channels") or 1)
                dur = min(float((pr.get("format") or {}).get("duration") or 0), SAMPLE_SECONDS)
                row = {"clip": c.GetName(), "channels": ch, "full": vd(path, "anull"),
                       "low": vd(path, "lowpass=f=300"), "hf3": vd(path, "highpass=f=3000"),
                       "hf6": vd(path, "highpass=f=6000")}
                if ch >= 2:
                    row.update({"L": vd(path, "pan=mono|c0=c0"), "R": vd(path, "pan=mono|c0=c1"),
                                "diff": vd(path, "pan=mono|c0=c0-c1")})
                r = run([ff, "-hide_banner", "-nostats", "-t", str(SAMPLE_SECONDS), "-i", path, "-vn", "-af",
                         "ebur128=peak=true", "-f", "null", "-"])
                row.update({k: v for k, v in parse_ebur128(r.stderr).items()})
                r = run([ff, "-hide_banner", "-nostats", "-t", str(SAMPLE_SECONDS), "-i", path, "-vn", "-af",
                         "silencedetect=noise=-40dB:d=0.5", "-f", "null", "-"])
                row["silent_share"] = parse_silence_total(r.stderr, dur)
                row["issues"] = judge(row)
                row["score"] = score(row)
                rows.append(row)
            rows.sort(key=lambda x: -x["score"])
            out.update({"status": "OK", "sources": rows, "not_analysed_budget": skipped,
                        "note": "Measured on the first %d s of each file. A ranking, not a listening test." % SAMPLE_SECONDS})
    elif MODE == "normalize":
        tl = project.GetCurrentTimeline()
        if tl is None or not tl.GetName().lower().startswith(REQUIRE_PREFIX):
            out["status"] = "REFUSED: current timeline is not Draft_/Probe_/Test_"
        elif not SPEECH_ITEMS:
            items = tl.GetItemListInTrack("audio", SPEECH_TRACK) or []
            out.update({"status": "LIST_SPEECH_ITEMS_FIRST",
                        "items": [{"index": i + 1, "name": it.GetName(), "start": it.GetStart() - tl.GetStartFrame()}
                                  for i, it in enumerate(items)]})
        else:
            items = tl.GetItemListInTrack("audio", SPEECH_TRACK) or []
            chosen = [items[i - 1] for i in SPEECH_ITEMS if 1 <= i <= len(items)]
            resolve.OpenPage("edit")
            before = {"%d:%s" % (k, it.GetName()): (it.GetProperties() or {}).get("AudioVolume") for k, it in enumerate(chosen)}
            modes = tl.GetNormalizeAudioModes() or []
            mode = next((m for m in modes if "1770" in str(m)), modes[0] if modes else None)
            opts = {"normalizationMode": mode, "targetLevel": TARGET_TP, "targetLoudness": TARGET_LKFS}
            if hasattr(resolve, "NORMALIZE_AUDIO_SET_LEVEL_INDEPENDENT"):
                opts["setLevelMode"] = resolve.NORMALIZE_AUDIO_SET_LEVEL_INDEPENDENT
            ok = tl.NormalizeAudioLevel(chosen, opts)
            iso = []
            if ISOLATION:
                for it in chosen:
                    iso.append(bool(it.SetVoiceIsolationState({"isEnabled": True, "amount": int(ISOLATION)})))
            after = {"%d:%s" % (k, it.GetName()): (it.GetProperties() or {}).get("AudioVolume") for k, it in enumerate(chosen)}
            out.update({"status": "NORMALIZED" if ok else "RETURNED_FALSE (do it by hand: select A%d items > Normalize "
                        "Audio Levels, ITU-R BS.1770-4, %.0f LKFS, %.0f dBTP, Independent)" % (SPEECH_TRACK, TARGET_LKFS, TARGET_TP),
                        "mode_used": mode, "available_modes": modes, "before": before, "after": after,
                        "big_gain_check_hiss": normalize_report(before, after), "isolation_set": iso,
                        "note": "Levels set, not auditioned. EQ is not scriptable: see references/voice-audio.md."})
    else:
        out["status"] = "UNKNOWN_MODE"
    result = out
