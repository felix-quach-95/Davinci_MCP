# fx_library.py — catalogue the user's installed Resolve effects (Fusion templates) and pick by role.
# Tool: run_script_unsafe (reads ~/Library/Application Support/.../Fusion/Templates, incl. .drfx bundles).
# MODE "scan": parse every .setting (inside .drfx zips and loose files) under Edit/Titles, Edit/Effects,
#              Edit/Transitions, Edit/Generators -> CACHE (JSON) with: name (as shown in the Effects
#              library), kind, pack, category, text tools, fonts (+ Vietnamese coverage on this Mac),
#              length, design resolution, published controls, roles, promo/watermark text flags.
# MODE "pick": QUERY -> ranked templates. MODE "extract": copy one template's .setting to SETTINGS_DIR
#              (needed by fx_apply.py MODE "effect"). Nothing in the Templates folder is changed.

MODE = "scan"                 # "scan" | "pick" | "extract" | "stats"
CACHE = "~/Movies/ClaudeQC/_fx/catalog.json"
SETTINGS_DIR = "~/Movies/ClaudeQC/_fx/settings"
QUERY = {"kind": "Title", "role": "title_cinematic", "mood": "cinematic", "vn_ok": None, "n": 10}
EXTRACT = "Neo Glow"          # template name for MODE "extract"
EXTRACT_KIND = "Effect"       # preferred kind when two templates share a name (e.g. Neo Zoom Lite)

TEMPLATE_ROOTS = ["~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates",
                  "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates"]
FONT_DIRS = ["~/Library/Fonts", "/Library/Fonts", "/System/Library/Fonts", "/System/Library/Fonts/Supplemental"]

# Role rules: (role, [keywords matched against "pack/category/name", lower-case])
ROLE_RULES = [
    ("title_cinematic", ["mtitle cinematic", "cinematic"]),
    ("credits",         ["mtitle cinematic 3", "mtitle cinematic 4", "mtitle cinematic 5"]),
    ("location",        ["location", "call out", "callout", "pointer", "mtitle cinematic 29"]),
    ("time_date",       ["time & date", "timer", "mtitle cinematic 30"]),
    ("quote",           ["quote", "smooth title"]),
    ("intro_card",      ["intro card", "centered"]),
    ("lower_third",     ["lower third"]),
    ("kinetic_bold",    ["text animation", "glitch text", "clean simple title", "styled text"]),
    ("text_anim",       ["clean motion"]),
    ("handdrawn",       ["drawing text"]),
    ("cta_social",      ["call to action", "social media"]),
    ("info",            ["infographic", "icons", "arrows", "miscellan"]),
    ("background",      ["background", "gradient"]),
    ("zoom_move",       ["zoom", "continuous zoom", "levitation", "animation in & out"]),
    ("whip",            ["transitiononly", "magicanimate"]),
    ("shake",           ["midanimationonly", "shake"]),
    ("glow_light",      ["glow", "light sweep", "neon", "lightsaber"]),
    ("glitch",          ["glitch", "rgb", "echo", "flicker"]),
    ("stylize",         ["glass", "phone effect", "icon mask", "exclusion", "shadow, glow"]),
]
# Feel per role, used by "pick" with QUERY["mood"]
ROLE_MOODS = {
    "title_cinematic": {"cinematic", "soft"}, "credits": {"cinematic"}, "location": {"soft", "cinematic", "energetic", "tech"},
    "time_date": {"soft", "energetic"}, "quote": {"soft", "cinematic"}, "intro_card": {"energetic", "tech"},
    "lower_third": {"tech", "energetic"}, "kinetic_bold": {"energetic"}, "text_anim": {"soft", "energetic", "cinematic"},
    "handdrawn": {"energetic", "funny"}, "cta_social": {"energetic", "tech"}, "info": {"tech"},
    "background": {"tech"}, "zoom_move": {"soft", "cinematic", "energetic"}, "whip": {"energetic"},
    "shake": {"energetic"}, "glow_light": {"cinematic", "soft"}, "glitch": {"tech", "energetic"}, "stylize": {"tech"},
}
PROMO_MARKERS = ["t.me/", "telegram", "@davinci", "http://", "https://", "www.", "videoeditorstudio", "download"]

# Vietnamese-safe substitutes for template fonts that lack Vietnamese glyphs (checked on the user's Mac).
FONT_SUB = {
    "Poppins": "Be Vietnam Pro", "Lato": "Be Vietnam Pro", "Red Hat Display": "Be Vietnam Pro",
    "Hanson": "Unbounded", "Bowlby One SC": "Dela Gothic One", "Russo One": "Unbounded",
    "Uni Sans": "Montserrat", "Basement Grotesque": "Anton", "Monoton": "Unbounded",
    "Caveat": "Dancing Script", "Permanent Marker": "Dela Gothic One", "Rajdhani": "Barlow Condensed",
}
STYLE_SUB = {"Heavy CAPS": "Black", "Heavy Italic CAPS": "Black", "Black Italic": "Black"}

import re


def _blocks(txt, kw):
    for m in re.finditer(r"(\w+)\s*=\s*" + kw + r"\s*\{", txt):
        i, d = m.end(), 1
        while d and i < len(txt):
            c = txt[i]
            if c == "{":
                d += 1
            elif c == "}":
                d -= 1
            elif c == '"':
                i += 1
                while i < len(txt) and txt[i] != '"':
                    if txt[i] == "\\":
                        i += 1
                    i += 1
            i += 1
        yield m.group(1), txt[m.end():i - 1]


def _field(body, key):
    m = re.search(r"\b" + key + r'\s*=\s*("(?:[^"\\]|\\.)*"|[-\w.]+)', body)
    if not m:
        return None
    v = m.group(1)
    return v[1:-1] if v.startswith('"') else v


def parse_setting(text, rel):
    """rel: path inside the Templates root, e.g. 'Edit/Titles/Smooth Titles/Smooth Title 01.setting'."""
    parts = rel.replace("\\", "/").split("/")
    kind = {"Titles": "Title", "Effects": "Effect", "Transitions": "Transition", "Generators": "Generator"}.get(
        parts[1] if len(parts) > 2 else "", "?")
    name = parts[-1][:-8] if parts[-1].endswith(".setting") else parts[-1]
    category = "/".join(parts[2:-1])
    fonts = sorted(set(re.findall(r'Font = Input \{ Value = "([^"]+)", \},\s*\n\s*Style = Input \{ Value = "([^"]+)"', text)))
    if not fonts:
        fonts = [(f, "") for f in sorted(set(re.findall(r'\bFont\s*=\s*Input\s*\{\s*Value\s*=\s*"([^"]*)"', text)))]
    texts = re.findall(r'StyledText\s*=\s*Input\s*\{\s*Value\s*=\s*"((?:[^"\\]|\\.)*)"', text)
    texts += re.findall(r'\bText\s*=\s*Input\s*\{\s*Value\s*=\s*"((?:[^"\\]|\\.)*)"', text)
    pub = []
    for _, b in _blocks(text, "InstanceInput"):
        n = _field(b, "Name") or _field(b, "Source")
        if n and n not in pub:
            pub.append(n)
    kf = [float(x) for x in re.findall(r"\[\s*(-?\d+(?:\.\d+)?)\s*\]\s*=\s*\{\s*-?\d", text)]
    w = re.findall(r"\bWidth\s*=\s*Input\s*\{\s*Value\s*=\s*(\d+)", text)
    h = re.findall(r"\bHeight\s*=\s*Input\s*\{\s*Value\s*=\s*(\d+)", text)
    key = (category + "/" + name).lower()
    roles = [r for r, kws in ROLE_RULES if any(k in key for k in kws)]
    low = text.lower()
    promo = sorted(set(m for m in PROMO_MARKERS if m in low))
    promo_text = [t for t in texts if any(m in t.lower() for m in PROMO_MARKERS)]
    return {"name": name, "kind": kind, "category": category,
            "n_text": len(re.findall(r"=\s*TextPlus\s*\{", text)),
            "follower": "StyledTextFollower" in text, "fonts": [list(f) for f in fonts],
            "sample_text": [t[:40] for t in texts if t.strip()][:4], "promo_text": [t[:60] for t in promo_text],
            "promo_markers": promo, "pub": pub[:40], "length": int(max(kf)) + 1 if kf and max(kf) > 2 else None,
            "design_res": [int(w[0]), int(h[0])] if w and h and int(w[0]) > 16 else None, "roles": roles or ["other"]}


def font_plan(fonts, vn_ok):
    """fonts: [[family, style]]; vn_ok: {family: bool}. -> [[family, style, new_family, new_style, reason]]"""
    out = []
    for fam, sty in fonts:
        if vn_ok.get(fam, False):
            out.append([fam, sty, fam, sty, "ok"])
        elif fam in FONT_SUB:
            out.append([fam, sty, FONT_SUB[fam], STYLE_SUB.get(sty, sty or "Regular"), "no Vietnamese glyphs"])
        else:
            out.append([fam, sty, "Be Vietnam Pro", STYLE_SUB.get(sty, sty or "Regular"),
                        "not installed" if fam not in vn_ok else "no Vietnamese glyphs"])
    return out


def rank(entries, q):
    out = []
    for e in entries:
        if q.get("kind") and e["kind"] != q["kind"]:
            continue
        if q.get("role") and q["role"] not in e["roles"]:
            continue
        if q.get("vn_ok") is True and not e.get("vn_ok_all", False):
            continue
        s = 0.0
        if q.get("mood"):
            s += sum(1.0 for r in e["roles"] if q["mood"] in ROLE_MOODS.get(r, ()))
        s += 0.5 if e.get("vn_ok_all") else 0.0
        s -= 2.0 if e.get("promo_text") else 0.0
        out.append((round(s, 2), e))
    out.sort(key=lambda t: (-t[0], t[1]["name"]))
    return out[: int(q.get("n", 10))]


try:
    resolve
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, json, zipfile, struct
    cache_p = os.path.expanduser(CACHE)
    os.makedirs(os.path.dirname(cache_p), exist_ok=True)
    out = {"mode": MODE}

    def _sources():
        for root in TEMPLATE_ROOTS:
            root = os.path.expanduser(root)
            if not os.path.isdir(root):
                continue
            for dp, dn, fn in os.walk(root):
                for f in fn:
                    p = os.path.join(dp, f)
                    if f.lower().endswith(".drfx"):
                        try:
                            z = zipfile.ZipFile(p)
                        except Exception:
                            continue
                        for n in z.namelist():
                            if n.endswith(".setting") and not n.startswith("__MACOSX") and n.startswith("Edit/"):
                                yield f, n, (lambda z=z, n=n: z.read(n).decode("utf-8", "replace"))
                    elif f.endswith(".setting"):
                        rel = os.path.relpath(p, root)
                        if rel.startswith("Edit"):
                            yield "(loose)", rel, (lambda p=p: open(p, encoding="utf-8", errors="replace").read())

    def _vn_fonts():
        VI = "ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯư" + "".join(chr(c) for c in range(0x1EA0, 0x1EFA))

        def cmap(data, base):
            n = struct.unpack(">H", data[base + 4:base + 6])[0]
            off = None
            for i in range(n):
                r = base + 12 + 16 * i
                if data[r:r + 4] == b"cmap":
                    off = struct.unpack(">I", data[r + 8:r + 12])[0]
                    break
            cps = set()
            if off is None:
                return cps
            for i in range(struct.unpack(">H", data[off + 2:off + 4])[0]):
                _, _, so = struct.unpack(">HHI", data[off + 4 + 8 * i:off + 12 + 8 * i])
                st = off + so
                fmt = struct.unpack(">H", data[st:st + 2])[0]
                if fmt == 4:
                    seg = struct.unpack(">H", data[st + 6:st + 8])[0] // 2
                    ends = struct.unpack(">%dH" % seg, data[st + 14:st + 14 + 2 * seg])
                    starts = struct.unpack(">%dH" % seg, data[st + 16 + 2 * seg:st + 16 + 4 * seg])
                    for a, b in zip(starts, ends):
                        if a != 0xFFFF:
                            cps.update(range(a, b + 1))
                elif fmt == 12:
                    for g in range(struct.unpack(">I", data[st + 12:st + 16])[0]):
                        a, b, _ = struct.unpack(">III", data[st + 16 + 12 * g:st + 28 + 12 * g])
                        cps.update(range(a, b + 1))
            return cps

        fam_ok = {}
        for d in FONT_DIRS:
            d = os.path.expanduser(d)
            if not os.path.isdir(d):
                continue
            for fn in os.listdir(d):
                if not fn.lower().endswith((".ttf", ".otf", ".ttc")):
                    continue
                key = re.sub(r"[\[\-_ ].*$", "", fn.rsplit(".", 1)[0]).lower()
                try:
                    data = open(os.path.join(d, fn), "rb").read()
                    base = struct.unpack(">I", data[12:16])[0] if data[:4] == b"ttcf" else 0
                    ok = all(ord(c) in cmap(data, base) for c in VI)
                except Exception:
                    continue
                fam_ok[key] = fam_ok.get(key, False) or ok
        return fam_ok

    if MODE == "scan":
        fam_ok = _vn_fonts()
        items = []
        for pack, rel, reader in _sources():
            try:
                e = parse_setting(reader(), rel)
            except Exception as ex:
                e = {"name": rel, "error": str(ex)[:80], "kind": "?", "roles": ["other"], "fonts": []}
            e["pack"] = pack
            e["rel"] = rel
            vn = {}
            for fam, sty in e.get("fonts", []):
                vn[fam] = fam_ok.get(fam.replace(" ", "").lower(), False)
            e["vn_ok_all"] = all(vn.values()) if vn else True
            e["font_plan"] = font_plan(e.get("fonts", []), vn)
            items.append(e)
        json.dump({"items": items}, open(cache_p, "w"), ensure_ascii=False)
        from collections import Counter
        out.update({"n": len(items), "kinds": Counter(e["kind"] for e in items).most_common(),
                    "roles": Counter(r for e in items for r in e["roles"]).most_common(),
                    "need_font_sub": sum(1 for e in items if not e["vn_ok_all"]),
                    "promo_text": [e["name"] for e in items if e.get("promo_text")]})
    else:
        items = json.load(open(cache_p))["items"]
        if MODE == "stats":
            from collections import Counter
            out["packs"] = Counter(e["pack"] for e in items).most_common()
        elif MODE == "pick":
            out["candidates"] = [{"score": s, "name": e["name"], "kind": e["kind"], "pack": e["pack"],
                                  "category": e["category"], "roles": e["roles"], "n_text": e.get("n_text"),
                                  "length": e.get("length"), "vn_ok_all": e.get("vn_ok_all"),
                                  "font_plan": e.get("font_plan"), "promo_text": e.get("promo_text")}
                                 for s, e in rank(items, QUERY)]
        elif MODE == "extract":
            hit = sorted([e for e in items if e["name"] == EXTRACT], key=lambda e: e["kind"] != EXTRACT_KIND)
            if not hit:
                out["error"] = "no template named %r" % EXTRACT
            else:
                e = hit[0]
                txt = None
                for pack, rel, reader in _sources():
                    if rel == e["rel"] and pack == e["pack"]:
                        txt = reader()
                        break
                d = os.path.expanduser(SETTINGS_DIR)
                os.makedirs(d, exist_ok=True)
                p = os.path.join(d, re.sub(r"[^\w .&()\-\[\]]", "_", EXTRACT) + ".setting")
                open(p, "w", encoding="utf-8").write(txt)
                out.update({"path": p, "kind": e["kind"], "pub": e.get("pub")})
    result = out
