# silence_beats.py — local audio analysis (no install, nothing uploaded).
# Decoder: ffmpeg if present, otherwise macOS built-in `afconvert` (always on macOS).
#   MODE "silence": silence windows in a source clip (cut candidates for talking footage)
#   MODE "beats"  : tempo estimate + beat grid of a music file (for cut/SFX timing)
#   MODE "list"   : list audio files in a folder with durations (pick music/SFX)
# Paste into run_script_unsafe. Pure-python analysis; uses numpy only if present.
# Temporary WAV goes to WORK_DIR/_tmp (Cache Edit, v2.9) and is removed afterwards.
# Beat results are estimates: report confidence and do not force cuts onto weak grids.

# ---- CONFIG ----------------------------------------------------------------
MODE = "beats"                    # silence | beats | list
FILE = "/Users/felix/Desktop/Asset/Music/example.mp3"
FOLDER = "/Users/felix/Desktop/Asset/Music"      # for MODE "list"
SILENCE_DB = "auto"               # dB threshold, or "auto" = PEAK_MARGIN below the loudest 10 ms window (v2.3:
                                  # a fixed -30/-35 dB called quiet speech silence on a -26 dB peak mic —
                                  # AdamGarceau/resolve-toolkit; peak-relative adapts to the recording)
PEAK_MARGIN = 24
SILENCE_MIN = 0.35                # seconds
BPM_RANGE = (70, 180)
MAX_SECONDS = 240                 # analyse at most this much audio
WORK_DIR = "/Users/felix/Desktop/Final/Cache Edit"   # v2.9: temp WAVs (removed after use)
# ---------------------------------------------------------------------------

SR = 11025
HOP = 256


def parse_silencedetect(stderr_text):
    out, start = [], None
    for line in stderr_text.splitlines():
        if "silence_start:" in line:
            try:
                start = float(line.split("silence_start:")[1].split()[0])
            except (ValueError, IndexError):
                start = None
        elif "silence_end:" in line and start is not None:
            try:
                end = float(line.split("silence_end:")[1].split()[0])
                out.append((round(start, 3), round(end, 3)))
            except (ValueError, IndexError):
                pass
            start = None
    return out


def onset_envelope(samples, hop=HOP):
    """samples: list/array of floats. Returns half-wave rectified energy flux per hop."""
    env, prev = [], 0.0
    n = len(samples) // hop
    for i in range(n):
        seg = samples[i * hop:(i + 1) * hop]
        e = sum(x * x for x in seg) / hop
        d = e - prev
        env.append(d if d > 0 else 0.0)
        prev = e
    m = sum(env) / len(env) if env else 0
    return [max(v - m, 0.0) for v in env]


def estimate_tempo(env, sr=SR, hop=HOP, bpm_range=BPM_RANGE):
    """Autocorrelation tempo + best phase. Returns (bpm, offset_seconds, confidence)."""
    fr = sr / float(hop)
    lo = int(fr * 60.0 / bpm_range[1])
    hi = int(fr * 60.0 / bpm_range[0])
    n = len(env)
    if n < hi * 4:
        return None, None, 0.0
    lo, hi = max(lo, 2), hi + 1
    raw = {}
    for lag in range(lo - 1, hi + 2):
        raw[lag] = sum(env[i] * env[i + lag] for i in range(0, n - lag))
    best, best_lag, scores = -1.0, None, []
    for lag in range(lo, hi + 1):
        bpm = 60.0 * fr / lag
        w = 1.0 - 0.15 * min(abs(bpm - 115) / 60.0, 1.0)   # mild prior for 90-140 bpm
        scores.append(raw[lag] * w)
        if raw[lag] * w > best:
            best, best_lag = raw[lag] * w, lag
    mean = sum(scores) / len(scores) if scores else 0
    conf = (best - mean) / best if best > 0 else 0.0
    # fractional lag: parabolic interpolation around the peak
    y0, y1, y2 = raw[best_lag - 1], raw[best_lag], raw[best_lag + 1]
    den = y0 - 2 * y1 + y2
    period = best_lag + (0.5 * (y0 - y2) / den if den != 0 else 0.0)
    # phase: comb sum at the real (fractional) period
    best_ph, best_sum = 0.0, -1.0
    steps = max(int(period * 4), 1)
    for k in range(steps):
        ph = k * period / steps
        tot, t = 0.0, ph
        while t < n - 1:
            i = int(t)
            frac = t - i
            tot += env[i] * (1 - frac) + env[i + 1] * frac
            t += period
        if tot > best_sum:
            best_sum, best_ph = tot, ph
    # refine: snap to the local peak near each predicted beat, then least-squares fit
    pts, k, t = [], 0, best_ph
    win = max(int(period / 4), 1)
    while t < n - 1:
        c = int(round(t))
        a, b = max(c - win, 0), min(c + win + 1, n)
        seg = env[a:b]
        if seg and max(seg) > 0:
            pts.append((k, a + seg.index(max(seg))))
        k += 1
        t = best_ph + k * period
    if len(pts) >= 4:
        mk = sum(p[0] for p in pts) / float(len(pts))
        mp = sum(p[1] for p in pts) / float(len(pts))
        sxx = sum((p[0] - mk) ** 2 for p in pts)
        if sxx > 0:
            period = sum((p[0] - mk) * (p[1] - mp) for p in pts) / sxx
            best_ph = mp - period * mk
            while best_ph < 0:
                best_ph += period
    return round(60.0 * fr / period, 2), round(best_ph / fr, 3), round(conf, 3)


def adaptive_floor_db(x, sr=SR, margin=24, win=0.01):
    """Threshold in dBFS = the loudest window's RMS minus margin (95th percentile, so one click does not
    set it)."""
    import math
    n = max(int(sr * win), 1)
    rms = sorted(math.sqrt(sum(v * v for v in x[i:i + n]) / n) for i in range(0, len(x) - n + 1, n))
    if not rms:
        return -60.0
    ref = rms[int(0.95 * (len(rms) - 1))]
    return round(20 * math.log10(max(ref, 1e-6)) - margin, 1)


def silences_from_pcm(x, sr=SR, db=-35, min_len=0.35, win=0.01, margin=24):
    """x: floats in [-1, 1]. Returns [(start_s, end_s)] where RMS stays below db ("auto" = adaptive)."""
    import math
    n = max(int(sr * win), 1)
    if db == "auto":
        db = adaptive_floor_db(x, sr, margin, win)
    thr = 10 ** (db / 20.0)
    out, start = [], None
    for i in range(0, len(x) - n + 1, n):
        seg = x[i:i + n]
        rms = math.sqrt(sum(v * v for v in seg) / n)
        t = i / float(sr)
        if rms < thr:
            if start is None:
                start = t
        else:
            if start is not None and t - start >= min_len:
                out.append((round(start, 3), round(t, 3)))
            start = None
    end = len(x) / float(sr)
    if start is not None and end - start >= min_len:
        out.append((round(start, 3), round(end, 3)))
    return out


def beat_grid(bpm, offset, duration):
    if not bpm:
        return []
    step = 60.0 / bpm
    t, out = offset, []
    while t < duration:
        out.append(round(t, 3))
        t += step
    return out


try:
    resolve  # injected by the Resolve MCP; absent in offline tests
    _IN_RESOLVE = True
except NameError:
    _IN_RESOLVE = False

if _IN_RESOLVE:
    import os, shutil, subprocess, struct, wave, re

    def find_bin(name):
        return shutil.which(name) or next((p for p in ("/opt/homebrew/bin/" + name, "/usr/local/bin/" + name,
                                                       os.path.expanduser("~/.local/bin/" + name),
                                                       "/usr/bin/" + name) if os.path.exists(p)), None)

    ff, afc, afi = find_bin("ffmpeg"), find_bin("afconvert"), find_bin("afinfo")
    res = {"mode": MODE, "decoder": "ffmpeg" if ff else ("afconvert" if afc else None)}

    def duration_of(path):
        if afi:
            r = subprocess.run([afi, path], capture_output=True, text=True, timeout=15)
            m = re.search(r"estimated duration:\s*([0-9.]+)", r.stdout)
            if m:
                return round(float(m.group(1)), 2)
        return None

    def decode(path):
        """Mono 16-bit PCM at SR as floats (first MAX_SECONDS)."""
        tmp = os.path.join(os.path.expanduser(WORK_DIR), "_tmp")
        os.makedirs(tmp, exist_ok=True)
        wav = os.path.join(tmp, "decode_%d.wav" % os.getpid())
        try:
            if ff:
                cmd = [ff, "-y", "-v", "error", "-t", str(MAX_SECONDS), "-i", path, "-ac", "1", "-ar", str(SR), wav]
            else:
                cmd = [afc, "-f", "WAVE", "-d", "LEI16@%d" % SR, "-c", "1", path, wav]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=40)
            if r.returncode != 0 or not os.path.exists(wav):
                raise RuntimeError("decode failed: " + (r.stderr or r.stdout)[-300:])
            with wave.open(wav, "rb") as w:
                n = min(w.getnframes(), SR * MAX_SECONDS)
                raw = w.readframes(n)
            return [v / 32768.0 for v in struct.unpack("<%dh" % (len(raw) // 2), raw[:len(raw) // 2 * 2])]
        finally:
            if os.path.exists(wav):
                os.remove(wav)

    if MODE == "list":
        rows = []
        for name in sorted(os.listdir(FOLDER)):
            if name.lower().endswith((".mp3", ".wav", ".m4a", ".aac", ".aif", ".aiff", ".flac", ".caf")):
                pth = os.path.join(FOLDER, name)
                rows.append({"file": name, "path": pth, "seconds": duration_of(pth)})
        res.update({"status": "OK", "files": rows})
    elif not res["decoder"]:
        res["status"] = "NO_DECODER: cut by structure; do not install without approval"
    else:
        try:
            x = decode(FILE)
        except Exception as e:
            x = None
            res["status"] = "DECODE_FAILED: %s" % e
        if x is not None and MODE == "silence":
            floor = adaptive_floor_db(x, SR, PEAK_MARGIN) if SILENCE_DB == "auto" else SILENCE_DB
            res.update({"status": "OK", "silence_floor_db": floor,
                        "silences_sec": silences_from_pcm(x, SR, floor, SILENCE_MIN),
                        "note": "seconds from the start of the file; convert with clip FPS"})
        elif x is not None:
            env = onset_envelope(x)
            dur = len(x) / float(SR)
            bpm, off, conf = estimate_tempo(env)
            grid = beat_grid(bpm, off, dur)
            res.update({"status": "OK" if bpm else "TOO_SHORT", "bpm": bpm, "first_beat_sec": off,
                        "confidence": conf, "duration_sec": round(dur, 2),
                        "beats_sec": grid[:400], "downbeats_guess_sec": grid[::4][:100],
                        "note": "confidence < 0.25 = weak grid; tempo may be half/double (check by ear/structure)"})
    result = res
